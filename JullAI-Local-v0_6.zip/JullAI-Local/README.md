# JullAI Local — v0.6: imágenes locales y novela visual dinámica

App Android de IA local. **Este ZIP contiene la versión 0.6**, construida ENCIMA de la 0.5 (no se reescribió nada: partidas, mundos, memorias, relaciones, capítulos, volúmenes,
`.jullai` y `.worldpack` siguen igual; `LlamaBridge`/`LlamaEngine` no se tocaron). Texto e imágenes se procesan **en el teléfono**: sin nube, sin APIs de pago, sin nuevos permisos.
Los pesos (texto e imagen) **no van en el APK**: se importan con el selector del sistema.

> **Estado honesto, léelo primero.** El entorno donde se escribió esta versión no tiene Android SDK, Gradle, NDK ni compilador de Kotlin, y no tiene el teléfono.
> **No se compiló el APK, no se compiló el módulo nativo para Android, no se generó ninguna imagen real y no se midió nada en el Helio G100.** Lo que sí se ejecutó está en
> `docs/REGISTRO_DE_PRUEBAS.md`. La velocidad, la memoria y la calidad de stable-diffusion.cpp en tu teléfono son **desconocidas hasta que lo pruebes** (guía en `docs/PRUEBAS_MANUALES.md`, sección V).

## Qué hay de nuevo en la 0.6

- **Motor de imágenes: stable-diffusion.cpp (MIT), solo CPU**, commit fijado, en un módulo y una biblioteca `.so` aparte (no choca con llama.cpp). Motivos, comparación con Local Dream
  (CC BY-NC 4.0), límites y cosas no verificadas: `docs/MOTOR_DE_IMAGENES.md`.
- **`ImageEngine`**: interfaz separada del texto (diagnóstico, capacidades reales, carga validada, generar, progreso, cancelar, liberar, errores en español, tiempos y parámetros). Lo que el motor compilado
  no expone (cancelar, LoRA, referencia, mosaicos…) **no se ofrece**.
- **Modelos**: importar checkpoint (SD 1.x `.safetensors`/`.gguf`, con VAE) y LoRA LCM; se **valida por contenido**, se copia al almacenamiento privado, se comprueba con el motor
  («Comprobar con el motor») y se muestran tamaño, formato, arquitectura, avisos y motivo del rechazo. `.ckpt` rechazado por seguridad. Sin conversiones.
- **Bajo consumo por defecto**: una imagen por tarea, 256×384 (retratos) y 384×256 (fondos), 20 pasos Euler a / VAE por mosaicos si el motor lo expone; preajuste LCM (6 pasos, CFG 1,5) **solo con una LoRA LCM**;
  modos medio y calidad con su coste relativo indicado (pasos × píxeles) y, tras tus primeras imágenes, segundos estimados con **tus** tiempos reales. No se promete que menos pasos/resolución mantenga la calidad.
- **Perfil visual por personaje** (descripción física, estilo, ropa por etapa, referencia principal, negativos). Para personajes conocidos **no se depende del nombre**: lo que describe es el perfil.
  Si el motor expone image-to-image, expresiones y poses parten de la referencia; **no se garantiza** el mismo rostro.
- **Estudio de imágenes** (Biblioteca → Roleplay → *Estudio de imágenes*): prompt editable (relleno desde la ficha), negativo, semilla, tamaños validados, pasos, preajuste, progreso real, cancelar,
  regenerar con otra semilla, guardar como retrato/expresión/pose/fondo/ilustración. **Galería** con filtros, apertura con todos los parámetros, reasignar a personaje/lugar, reutilizar parámetros y eliminar.
- **Coordinador de recursos**: un solo árbitro texto/imagen. El texto tiene prioridad; antes de la imagen se libera el modelo de texto (se recarga solo al enviar); una acción nueva del jugador cancela la imagen
  en curso y libera el motor visual antes de cargar el texto; memoria y temperatura (Android 10+, con comprobación de API) se consultan antes y durante; `onTrimMemory` cancela con presión crítica.
  **La conversación nunca se toca**: vive en Room y el contexto se reconstruye de ahí (se pierde solo la caché KV del texto, como al descargarlo).
- **Cola persistente** (una tarea cada vez, prioridad texto > primera escena > siguiente > variantes > ilustraciones): estados reales (pendiente, en curso, lista, fallida, cancelada, aplazada), sobrevive a cerrar la app
  (lo que estaba en curso vuelve a pendiente y se **reintenta desde el principio**, no a mitad de inferencia). **Nada se lanza solo por defecto** («Generar ahora»); hay un ajuste de ejecución automática.
- **Preparación visual por mundo** (Preparación → *Recursos visuales*): principal, fondo de la primera localización, expresiones, fondos siguientes. Se puede jugar sin esperar.
- **Novela visual**: ilustración de escena guardada por mensaje (se puede ocultar/ver y se relee), botón *Ilustrar* manual, política configurable (desactivadas / manual / proponer en escenas importantes / automática con pausa
  mínima). **Una respuesta normal nunca genera imagen.** Las expresiones generadas se reutilizan como retratos. Si falla la imagen o no hay modelo, el texto sigue y se muestra el recurso anterior o la silueta neutral.
  Un lector tolerante de metadatos opcionales (`[[escena: …]]` o JSON suelto) los oculta del diálogo y valida lo que acepte; **no se pide al modelo que los escriba** y su fusión con la escena no está conectada (la deducción por reglas de la 0.5 sigue mandando).
- Esquema Room 4 → 5 **solo añade 4 tablas** (`image_models`, `image_meta`, `image_tasks`, `visual_profiles`); `visual_assets` no cambia. Las exportaciones `.jullai`/`.worldpack` **no cambian** (no incluyen imágenes, como antes).

## Limitaciones principales de la 0.6 (detalle en `docs/LIMITACIONES.md`)
No compilado ni probado en dispositivo · velocidad/RAM/temperatura desconocidas · sin GPU (Mali no soportada) · sin SDXL/FLUX/ControlNet/IP-Adapter · identidad de personaje no garantizada ·
la preparación visual cubre al personaje principal de la partida y las localizaciones del mundo (el resolutor de escenas solo conoce a ese personaje) · una ilustración fallida o interrumpida se reintenta entera.

## Corrección previa de la 0.4

La ejecución de Actions de la 0.4 compiló el APK y pasó 180 de 181 pruebas. El único fallo (`StoryDatabaseTest.manualCorrectionKeepsHistoryAndStaysInRange`) era un
error **de la prueba, no de la app**: esperaba una excepción con `catch (e: Exception)`, pero `fail()` lanza `AssertionError` (no es `Exception`), y el código real **recorta**
los valores fuera de rango a 1–100 (comportamiento documentado y cubierto por `RelationshipRulesTest`). La prueba ahora comprueba el recorte. No se tocó código de la app.

## Qué hay de nuevo en la 0.5

**Mundos y enciclopedia** (Biblioteca → Roleplay → *Mundos*)
- Un **mundo** (nombre, descripción, idioma, ambientación, época, reglas, límites narrativos, spoilers, configuración de investigación) con su **enciclopedia**: personajes, alias,
  relaciones, lugares, objetos, criaturas, conceptos, reglas, acontecimientos, secretos, conflictos y otros. Se crea con un **asistente** y se edita sin conexión.
- Cada entrada guarda **origen y confianza**: *confirmado por la fuente*, *confianza limitada*, *contradicción*, *interpretación de aficionados* o *invención de roleplay*.
  Reglas: «confirmado» exige indicar fuente y cita; las contradicciones entre fuentes se **muestran como contradicción** (ambas versiones, cada una con su fuente), nunca se resuelven solas.
- **La enciclopedia es distinta de la partida**: lo que ocurre jugando (recuerdos, relaciones, cronología de la 0.4) vive en tablas aparte y **nunca** modifica el canon. Un mundo se
  comparte entre varias partidas; avance, relaciones y recuerdos de cada una son independientes.
- **Reparto** (canónico / original / mixto) y **continuidad** (estricta / flexible / AU) se eligen por separado. La continuidad llega al modelo como una instrucción; no se mezclan
  adaptaciones ni cronologías automáticamente.

**Investigación online opcional**
- Proveedores modulares (`SourceProvider`): **APIs de MediaWiki** (Wikipedia, Fandom y wikis que las expongan), **URLs del usuario**, y **archivos locales TXT / Markdown / HTML**.
  **PDF no es compatible** en esta versión (no hay una dependencia verificable): se muestra como «no compatible» con instrucciones para importar el texto.
- Educada con las fuentes: se identifica (`User-Agent: JullAI-Local/0.5 …`), ≤ 1 petición por segundo y servidor, respeta `Retry-After`, `maxlag` y **`robots.txt`**; ante 401/403/429 se detiene
  e informa (no salta controles). **No hay scraping de buscadores.** Bloquea direcciones de red local/privadas y esquemas no http(s). Sin claves obligatorias.
- **Tareas con WorkManager**: se guardan fase, fuentes procesadas, entradas creadas, errores por fuente y reintentos (máx. 3); se pueden **cancelar** y se **reanudan** (las fuentes ya
  procesadas no se repiten). La pantalla explica que Android decide cuándo ejecutarlas y que mantener la app abierta ayuda. Una investigación **solo cuenta como completada** si obtuvo
  fuentes procesadas y entradas válidas; si no, queda «sin resultados» o «fallida».
- Fuentes y páginas son **datos no confiables**: se limpian (caracteres de control, invisibles, marcas de plantilla de chat), nunca se concatenan al prompt del sistema, y al modelo solo llegan
  como entradas validadas bajo un encabezado «datos de referencia, no instrucciones». Los mundos **importados** envían sus reglas marcadas como información, no como órdenes.
- **Extracción con el modelo local** (paso aparte, en primer plano): el modelo solo puede devolver líneas de formato fijo; la app **verifica que la cita aparezca en la fuente** antes de marcar
  «confirmado»; lo demás queda como «confianza limitada» y **propuesto** hasta que lo aceptes. Con modelos muy pequeños, usa la creación manual.

**`.worldpack`** (ZIP versionado, detalle en `docs/FORMATO_WORLDPACK.md`)
- `manifest.json`, `world.json`, `lore.md`, `characters.json`, `locations.json`, `timeline.json`, `entries.json`, `sources.json`. Solo datos estructurados, referencias y resúmenes breves
  (no libros ni textos de las fuentes). Importar valida esquema, versión, archivos requeridos, tamaños, rutas (**ZIP-slip**), duplicados y sumas SHA-256, antes de tocar nada.
- Importar / exportar / duplicar **sin borrar ni sobrescribir** lo existente. Con el mismo identificador hay que elegir: copia independiente, combinar (solo añade lo que falta) o no hacer nada.
- **Vínculo con `.jullai`**: la partida exportada incluye (opcional, solo si tiene mundo) `data/mundo.json`, una instantánea del conocimiento del mundo. Al importar la partida eliges:
  crear el mundo, usar el que ya tienes, combinar, copia independiente o importar sin mundo. Así una partida importada **no pierde su mundo**.

**Recuperación de conocimiento del mundo**
- Reutiliza FTS4 + palabras clave con peso por rareza + nombres/alias en la escena. Selecciona **solo** lo pertinente dentro de un presupuesto (~14 % del contexto, tope de 12 entradas), respeta el
  **nivel de spoilers** (los secretos ocultos no llegan al modelo) y conserva **procedencia y confianza** (`[confirmado]`, `[interpretación de aficionados, no es hecho]`…). Es independiente de los
  recuerdos de la partida. «Recuperado en la última respuesta» muestra también lo del mundo.

**Preparación progresiva** (Roleplay → *Mundo*): cinco tareas con estado real (listo / pendiente / fallido): leer el mundo, conocimiento esencial, personaje principal, localizaciones, primera escena.
El progreso es «N de 5 tareas terminadas», **sin porcentajes inventados**. Se puede empezar en cuanto el mundo, el personaje y la primera escena están listos; la investigación sigue aparte. Es narrativa:
no genera imágenes.

**Novela visual básica**: las partidas de roleplay ahora se abren en la novela visual: fondo de la localización, personaje que habla destacado, panel de diálogo inferior, continuar / regenerar /
historial, acción libre siempre disponible y elecciones opcionales (leídas del final del texto si el narrador las ofrece). Vertical por defecto y disposición horizontal adaptable. **Vista clásica**
(historial, memoria, relaciones de la 0.4) accesible desde «Historial» y «Ficha». Metadatos por turno (localización, quién habla, emoción, pose, tipo de suceso, recursos usados, escena importante)
se extraen **sin modificar el texto** y **sin llamar al modelo** (reglas deterministas validadas contra personajes y lugares reales); si algo no se puede validar, se usa una alternativa segura.
Registro de recursos visuales (retratos y fondos importados, asociados a personaje/lugar/emoción). Sin imagen: alternativa neutral dibujada por la app, no una «generación».

- Base de datos **versión 4** con migración 3→4 que solo AÑADE 8 tablas (`worlds`, `world_entries`, `sources`, `research_tasks`, `world_sessions`, `prep_steps`, `visual_assets`, `scene_meta`) y la
  tabla FTS4 `world_entries_fts`. Nunca `fallbackToDestructiveMigration`.

## Estado real (lo que se verificó y lo que no)

Categorías: **Compila** · **Pruebas automáticas superadas** · **Probado en dispositivo** · **Pendiente de prueba manual** · **No implementado**.

| Elemento | Compila | Pruebas automáticas | En dispositivo | Estado |
|---|---|---|---|---|
| La 0.4 en Actions (referencia) | **Sí** (APK generado) | 180 de 181 pasaron; el fallo era de la prueba y se corrigió | No | Corregido, **pendiente de confirmar en Actions** |
| Esquema SQL v4 (27 tablas = 27 entidades) y las 158 consultas `@Query` | — | **Sí**, contra SQLite real con `tools/verify/check_schema.py` | No | **Pruebas automáticas superadas** (verificador propio, NO es Room) |
| FTS4 de entradas del mundo (sintaxis) | — | **Sí** en SQLite de Python | No | **Pendiente de prueba manual** |
| Lógica pura nueva (`world/`, `research/Net.kt`), Room, ViewModels, WorkManager, pantallas | **NO verificado**: en este entorno no hay compilador de Kotlin ni Gradle | — | No | **Pendiente**: lo compila y lo prueba GitHub Actions |
| Revisión estática de lo nuevo (llaves, imports, firmas reutilizadas) | — | **Sí** (revisión manual y script) | — | **No sustituye a compilar** |
| Pruebas nuevas: `WorldpackTest` (18), `WorldLogicTest` (34), `WorldDatabaseTest` (27) = 79 nuevas | — | **Escritas, NO ejecutadas** | — | **Pendiente**: las ejecutará Actions |
| Investigación online con una wiki real, límite de ritmo, robots.txt | — | Solo con proveedores falsos y transporte falso (en pruebas escritas) | **No** | **Pendiente de prueba manual** |
| WorkManager: reanudar tras matar la app, aplazamiento por Android | — | — | **No** | **Pendiente de prueba manual** |
| Novela visual, preparación, asistente, importar/exportar `.worldpack` en pantalla | **NO verificado** | — | **No** | **Pendiente de prueba manual** |
| PDF como fuente | — | — | — | **No implementado** (se muestra como no compatible) |
| Generación de imágenes | — | — | — | **No implementado** (0.6) |

> No afirmo que la investigación online, WorkManager o la novela visual funcionan en el teléfono: no se han probado. Si la compilación de GitHub falla, **no añadas nada**: envía `gradle-build.log`.
> Más detalle en `docs/REGISTRO_DE_PRUEBAS.md` y `docs/LIMITACIONES.md`.

## Cómo compilar la APK desde el teléfono

1. Sube **el contenido** de este ZIP a tu repositorio de GitHub (sustituye los archivos de la 0.4; incluye la carpeta oculta `.github`).
   **Conserva** la carpeta `app/schemas/` que ya tengas: no la borres.
2. Entra en **Actions**. El workflow **Compilar APK (JullAI Local)** arranca solo (o pulsa *Run workflow*). Tarda unos 20-35 minutos.
   Primero comprueba el esquema (segundos), luego compila el APK y lo sube, y después ejecuta las pruebas.
3. Descarga **JullAI-Local-debug-apk**. El APK se sube **antes** de las pruebas: lo tendrás aunque alguna falle (la ejecución saldría en rojo).
4. Instálalo **encima** de la 0.4 (misma clave de depuración): **conserva tus partidas, personajes y modelos**. La base pasa sola de la versión 3 a la 4.
5. El artefacto **registros-de-compilacion** trae `app/schemas/4.json`. **Súbelo al repositorio** (`app/schemas/`) junto a los anteriores.

Si falla, descarga **registros-de-compilacion** (`gradle-build.log`, `gradle-tests.log`, `schema-check.log`) y envíalo.

## Guía de prueba manual

Está en **`docs/PRUEBAS_MANUALES.md`** (paso a paso, en español; la sección «0.5» cubre mundos, investigación, `.worldpack` y novela visual).

## Cómo funciona la memoria (decisiones)

- **Qué llega al modelo**: solo recuerdos y sucesos *activos*. Las propuestas, lo descartado y las notas privadas no llegan.
- **Orden del contexto** (de más a menos prioritario cuando falta espacio, cae primero lo de abajo): sistema → ficha → tu personaje → escenario → reglas → conocimiento → lorebook →
  **relaciones → recuerdos → cronología** → resumen → mensajes recientes. Las secciones de memoria se incluyen **enteras o no se incluyen** (nunca cortadas a mitad de frase).
- **Puntuación de un recuerdo**: palabras clave de los últimos mensajes (el último pesa el doble; una palabra rara pesa más que una común, sin tildes ni plurales), nombres relacionados presentes,
  coincidencia de texto completo, importancia y recencia. Los fijados entran primero.
- **Presupuesto**: relaciones 25 %, recuerdos 55 % (fijados ≤ 60 % de eso), cronología ≤ 30 % de lo que quede, dentro del ~16 % del contexto.
- **Análisis con el modelo**: lee los mensajes más antiguos aún no analizados que quepan en el contexto; si quedan más, te lo dice y vuelves a pulsar. Un turno tuyo cancela el análisis.
- **Interfaz `MemoryRetriever`**: el recuperador actual (`RankedMemoryRetriever`) se puede sustituir por otro (p. ej. con embeddings en el futuro) sin tocar el resto.
- **FTS4 y no FTS5**: evaluado; ver arriba y `docs/LIMITACIONES.md`.

## Comportamientos decididos (v0.3, roleplay)

- **Partidas**: cada partida pertenece a UN personaje. Borrar el personaje borra sus partidas (el aviso lo dice). El escenario se **copia** a la partida: editar la ficha después no cambia partidas empezadas.
- **Editar un mensaje tuyo**: se descartan los mensajes posteriores y se genera una respuesta nueva (como en el chat). **Editar una respuesta del personaje**: solo cambia ese texto (la alternativa activa).
- **Regenerar** no borra: la respuesta anterior queda como alternativa (máx. 40) y se navega con ‹ ›. Solo la última respuesta tiene alternativas/regenerar/continuar.
- **Continuar** añade texto al final de la última respuesta (el texto existente se pasa al modelo como inicio de su turno).
- **Orden del contexto**: instrucciones del sistema → ficha → persona del usuario → escenario → reglas narrativas → conocimiento (secretos, hechos…) → lorebook activado → memoria recuperada (relaciones → recuerdos → cronología; v0.4) → **mundo (v0.5): reglas y continuidad, después datos recuperados** → resumen → mensajes recientes. Todo va en **un solo** mensaje de sistema.
- **Presupuesto**: cada sección tiene un tope en % del contexto (ficha 30 %, escenario 12 %, lorebook 15 %, resumen 10 %, conocimiento 12 %; sistema y reglas 10 % cada una). Si no queda espacio para al menos ~35 % del contexto en mensajes recientes, se sacrifica en este orden: ejemplos de diálogo → lorebook → resumen → recortes de ficha/escenario. El último mensaje nunca se descarta; si ni así cabe, se avisa con el motivo. Se descartan primero los mensajes más antiguos (el saludo inicial también puede salir).
- **Lorebook**: una entrada se activa si alguna clave aparece (texto literal, sin mayúsculas ni tildes) en los últimos N mensajes; las «siempre activas» entran siempre. Con poco espacio se conservan las de mayor prioridad. Nunca se envía el lorebook completo ni las fichas de otros personajes.
- **Notas privadas del creador**: el tipo de datos que llega al constructor de contexto no tiene ese campo, así que no pueden enviarse al modelo por error. (Sí van en el JSON que exportas: es tu copia.)
- **Tarjetas**: todo se trata como datos (se limpian caracteres de control, se limitan tamaños y cantidades, las claves tipo regex se usan como texto). `system_prompt` y `post_history_instructions` de una tarjeta se guardan como «instrucciones de comportamiento» de la ficha (avisándote en la vista previa); no se colocan después del historial.
- **Corte de turno**: si el texto generado contiene `\nTuNombre:` se corta ahí (opción en Ajustes).
- **Motor ocupado**: si el motor está generando para otra pantalla (p. ej. una conversación del chat), la partida avisa en vez de competir por él.

## Comportamientos del chat (v0.2, sin cambios)

- **Editar un mensaje tuyo**: se reemplaza el texto, **se descartan todos los mensajes posteriores** y se genera una respuesta nueva. No hay ramas (es la opción más simple y fiable).
- **Regenerar**: solo afecta a la **última** respuesta, que se reemplaza.
- **Guardado**: tu mensaje se guarda **antes** de generar; la respuesta parcial se guarda cada ~1,5 s. Si la app muere, el texto parcial queda marcado como interrumpido.
- **Contexto**: instrucciones del sistema + los mensajes más recientes que quepan, reservando espacio para la respuesta (máximo la mitad del contexto). Se cuentan tokens con el motor y se verifica con el prompt real ya con la plantilla del modelo. Si no cabe todo se descartan los mensajes **más antiguos** (todavía sin resumen). La conversación enviada siempre empieza por un mensaje tuyo.
- **Caché KV**: se reutiliza el prefijo común entre turnos y solo se procesan los tokens nuevos. Si el modelo no admite recortar la memoria, se limpia entera (sigue funcionando, más lento). Se puede desactivar en **Ajustes → Reutilizar la caché**. Cuando la conversación ya no cabe y se descartan mensajes antiguos, el prefijo cambia y se reprocesa todo (más lento en ese caso).
- **Modelo cargado**: se mantiene al cambiar de pantalla. Se libera con «Liberar memoria», al cerrar la app (la actividad termina) o ante presión de memoria del sistema cuando la app está en segundo plano y no genera. Cambiar el modelo, el contexto o los hilos recarga el modelo en el siguiente mensaje. Cambiar de modelo **nunca** borra conversaciones.
- **Segundo plano**: no hay servicio en primer plano todavía. Si cambias de app durante una respuesta, Android puede pausar o matar el proceso; el texto parcial se conserva.
- **Migraciones de la base de datos**: nunca destructivas (no se usa `fallbackToDestructiveMigration`).

## Estructura (0.6)
`sdengine/` — módulo nativo de imágenes (CMake, `sd_core.cpp`, JNI) · `app/.../imaging/` — motor, coordinador, cola, validación de modelos, prompts · `tools/fetch_sd.sh`, `check_sd_api.py`, `check_sd_shim.sh`, `sd-host-test/` · `docs/MOTOR_DE_IMAGENES.md`.

(Estructura anterior:)

- `app/src/main/cpp/jullai_engine.cpp` — puente JNI (sin cambios).
- `.../engine/` — `LlamaBridge`, `LlamaEngine` (hilo único), `EngineController`, `ModelStore`, `GgufHeader`, `ModelInfo`, `MemoryEstimator`.
- `.../data/` — Room: entidades, DAOs, `AppDatabase` (v4), `Migrations` (1→2, 2→3, 3→4), repositorios; **0.4**: `StoryEntities`, `StoryDaos`, `StoryRepository`, `FtsSupport`, `BibleService`.
- `.../story/` — **nuevo, Kotlin puro y probado**: `TextNorm`, `MemoryRetrieval` (recuperador), `RelationshipRules`, `Maintenance` (análisis), `Novel`, `Bible`, `BibleCodec`, `BibleMarkdown`, `ZipSafety`, `StoryModels`.
- `.../roleplay/` — tarjetas, lorebook, contexto, `RoleplayViewModel`, **0.4**: `StoryJobs` (trabajos con el modelo), `StoryViewModel`.
- `.../world/` — **0.5, Kotlin puro**: `WorldModels`, `UntrustedText`, `SourceText`, `WorldExtraction`, `WorldRetrieval`, `Worldpack`, `SceneDirector`, `Preparation`, `Choices`.
- `.../research/` — **0.5**: `Net` (política de URLs, robots.txt, HTTP educado), `Providers`, `ResearchEngine`, `ResearchWorker`/`ResearchManager` (WorkManager).
- `.../data/` también: `WorldEntities`, `WorldDaos`, `WorldRepository`, `WorldFts`, `SourceStore`. `.../roleplay/WorldViewModel`. `.../ui/`: `WorldsScreen`, `PrepScreen`, `VisualNovelScreen`.
- `.../chat/` — `ContextBuilder`, `ChatViewModel`.
- `.../ui/` — sistema visual propio (sin Material); **0.4**: `StoryPanels` (Memoria, Relaciones, Capítulos).
- `tools/verify/check_schema.py` — compara entidades y consultas con SQLite real. `tools/fetch_llama.sh` — descarga llama.cpp (no va en el ZIP). `tools/host-test/` — prueba JNI en Linux.
- `docs/` — formato `.jullai`, pruebas manuales, limitaciones y registro de pruebas.

## Diagnóstico de errores

- **Falla «Falta llama.cpp»**: el paso «Descargar llama.cpp» no se ejecutó; ejecuta `bash tools/fetch_llama.sh`.
- **Falla `assembleDebug`**: envía `gradle-build.log`. Si falla `kspDebugKotlin`, el error es de Room (consulta SQL o entidad).
- **La app se cierra al abrir tras actualizar** (o Room dice «Migration didn't properly handle»): la migración 1→2 no coincide con el esquema; envía `gradle-tests.log` (la prueba `MigrationTest` lo detalla) y el aviso exacto.
- **Una tarjeta no se importa**: la vista previa dice el motivo (JSON roto, PNG sin datos de tarjeta, versión no soportada…). Envíame el mensaje exacto.
- **Fallan las pruebas pero hay APK**: instala el APK igualmente y envía `gradle-tests.log` y `app/build/reports/tests/`.
- **La app se cierra al cargar un modelo**: casi siempre falta de memoria; baja el contexto a 1024 o usa un modelo menor.
- **«El motor no pudo leer el archivo»**: el GGUF es de una arquitectura que este llama.cpp no soporta, o está dañado.
- **Respuestas raras con «Reutilizar la caché» activada**: desactívala en Ajustes y avísame; el resultado debería ser el mismo (más lento).

- **La app se cierra al abrir tras actualizar** (o Room dice «Migration didn't properly handle»): la migración 2→3 no coincide con el esquema; envía `gradle-tests.log` (`MigrationV3Test` lo detalla) y el aviso exacto.
- **«No se pudo importar»**: el mensaje dice el motivo (versión, archivo dañado, ruta peligrosa, suma que no coincide…). No se cambió nada de tus datos.
- **El análisis con el modelo no devuelve el formato**: sale el texto en bruto para que lo corrijas; con modelos muy pequeños es normal. Prueba con un contexto mayor (Motor).

## Licencias

llama.cpp y ggml: licencia MIT (© The ggml authors), se descargan en la compilación. Los modelos tienen sus propias licencias; revísalas antes de usarlos.


## Corrección 0.6.1 (compilación)

El módulo `sdengine` ahora descarga stable-diffusion.cpp (commit fijo, `tools/fetch_sd.sh`) por sí solo desde Gradle antes de configurar CMake. Antes dependía de un paso del workflow que el workflow del repositorio (el que descomprime el ZIP) no tenía, y la compilación fallaba con «Falta stable-diffusion.cpp».

**0.6.2:** corregido un error de compilación en `VisualNovelScreen.kt` (`maxHeight` de `BoxWithConstraints` usado dentro de un `Column`; ahora se guarda antes en `maxH`).

**0.6.3:** `sd_core.cpp` adaptado a la API real de stable-diffusion.cpp (`bool generate_image(ctx, params, &imagenes, &n)`; antes se suponía que devolvía un puntero). El mock de `tools/sd-host-test` sigue la misma firma.
