package com.jullai.local.roleplay

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.AppContainer
import com.jullai.local.data.PrepStepEntity
import com.jullai.local.data.ResearchTaskEntity
import com.jullai.local.data.SceneMetaEntity
import com.jullai.local.data.SourceEntity
import com.jullai.local.data.VisualAssetEntity
import com.jullai.local.data.WorldEntity
import com.jullai.local.data.WorldEntryEntity
import com.jullai.local.data.WorldImportChoice
import com.jullai.local.data.WorldImportPlan
import com.jullai.local.data.WorldSessionEntity
import com.jullai.local.engine.ChatMessage
import com.jullai.local.engine.EngineState
import com.jullai.local.engine.FinishReason
import com.jullai.local.engine.GenEvent
import com.jullai.local.engine.GenerationParams
import com.jullai.local.research.FetchResult
import com.jullai.local.research.LocalFileProvider
import com.jullai.local.world.AssetChoice
import com.jullai.local.world.AssetResolver
import com.jullai.local.world.Confidence
import com.jullai.local.world.EntryOrigin
import com.jullai.local.world.EntryState
import com.jullai.local.world.ExtractionPrompts
import com.jullai.local.world.ModelExtractionParser
import com.jullai.local.world.NamedRef
import com.jullai.local.world.PrepReport
import com.jullai.local.world.PrepStatus
import com.jullai.local.world.Preparation
import com.jullai.local.world.SceneDirector
import com.jullai.local.world.SceneInput
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceStatus
import com.jullai.local.world.TaskStatus
import com.jullai.local.world.WorldException
import com.jullai.local.world.WorldPack
import com.jullai.local.world.WorldpackCodec
import com.jullai.local.world.WorldpackException
import com.jullai.local.world.SourceText
import com.jullai.local.world.WorldLimits
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class WorldTransfer(
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val plan: WorldImportPlan? = null,
)

/** Estado de la extracción con el modelo local de una fuente. */
class ExtractState(val busy: Boolean = false, val message: String? = null, val error: String? = null)

/** Mundos, fuentes, investigación, preparación y recursos visuales. Las acciones muestran errores en español por [notice]. */
class WorldViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.worldRepository
    val portraitStore get() = c.portraits

    val worlds: StateFlow<List<WorldEntity>> = repo.observeWorlds().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val assets: StateFlow<List<VisualAssetEntity>> = repo.observeAssets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()
    fun dismissNotice() { _notice.value = null }

    private fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) { _notice.value = e.message ?: "No se pudo completar la acción." }
        }
    }

    // ---------------- Mundo abierto ----------------
    private val _worldId = MutableStateFlow<Long?>(null)
    val worldId: StateFlow<Long?> = _worldId.asStateFlow()
    fun open(id: Long?) { _worldId.value = id }

    fun world(id: Long): Flow<WorldEntity?> = repo.observeWorld(id)
    fun entries(id: Long): Flow<List<WorldEntryEntity>> = repo.observeEntries(id)
    fun sources(id: Long): Flow<List<SourceEntity>> = repo.observeSources(id)
    fun tasks(id: Long): Flow<List<ResearchTaskEntity>> = repo.observeTasks(id)
    fun workNote(taskId: Long): Flow<String> = try { c.researchManager.workNote(taskId) } catch (e: Exception) { emptyFlow() }

    fun createWorld(w: WorldEntity, onDone: (Long) -> Unit) = act { onDone(repo.createWorld(w)) }
    fun updateWorld(w: WorldEntity) = act { repo.updateWorld(w) }
    fun deleteWorld(id: Long, then: () -> Unit = {}) = act { repo.deleteWorld(id); then() }
    fun duplicateWorld(id: Long) = act { repo.duplicateWorld(id) ?: throw WorldException("El mundo ya no existe.") }

    // ---------------- Entradas ----------------
    fun saveEntry(e: WorldEntryEntity) = act { repo.saveEntry(e) }
    fun deleteEntry(id: Long) = act { repo.deleteEntry(id) }
    fun acceptEntry(id: Long) = act { repo.setEntryState(id, EntryState.ACTIVO) }
    fun discardEntry(id: Long) = act { repo.setEntryState(id, EntryState.DESCARTADO) }

    // ---------------- Fuentes ----------------
    fun addUrl(worldId: Long, url: String) = act { repo.addSource(worldId, SourceKind.URL, url.trim()) }
    fun addWiki(worldId: Long, api: String, title: String) = act {
        if (api.isBlank() || title.isBlank()) throw WorldException("Indica la dirección de la API de la wiki y el título de la página.")
        repo.addSource(worldId, SourceKind.MEDIAWIKI, com.jullai.local.research.MediaWikiProvider.uriOf(api, title), title)
    }
    fun changeSourceUri(id: Long, uri: String) = act { repo.changeSourceUri(id, uri) }
    fun deleteSource(id: Long) = act { repo.deleteSource(id) }

    /** Importa un archivo local (TXT, Markdown, HTML) o texto pegado a mano. El texto se procesa aquí, sin red. */
    fun importFile(worldId: Long, uri: Uri, displayName: String) = act {
        val bytes = withContext(Dispatchers.IO) {
            val input = c.app.contentResolver.openInputStream(uri) ?: throw WorldException("No se pudo abrir el archivo.")
            input.use { it.readBytes() }
        }
        ingest(worldId, displayName.ifBlank { "archivo" }, SourceKind.ARCHIVO, LocalFileProvider.ingest(displayName, bytes))
    }

    fun importManualText(worldId: Long, title: String, text: String) = act {
        val clean = com.jullai.local.world.UntrustedText.sanitize(text, WorldLimits.MAX_SOURCE_CHARS)
        if (clean.length < 20) throw WorldException("El texto es demasiado corto.")
        ingest(worldId, title.ifBlank { "Texto manual" }, SourceKind.MANUAL, FetchResult.Ok(title.ifBlank { "Texto manual" }, clean, "", "Texto pegado por el usuario"))
    }

    /** Sustituye una fuente que falló por contenido pegado a mano. */
    fun replaceWithManual(sourceId: Long, text: String) = act {
        val s = repo.source(sourceId) ?: return@act
        val clean = com.jullai.local.world.UntrustedText.sanitize(text, WorldLimits.MAX_SOURCE_CHARS)
        if (clean.length < 20) throw WorldException("El texto es demasiado corto.")
        repo.markSourceProcessed(sourceId, s.title.ifBlank { s.uri }, clean, "", "Contenido importado a mano para ${s.uri}", s.taskId)
        addDraftsFor(s.worldId, sourceId, s.title.ifBlank { s.uri }, clean, s.uri, EntryState.PROPUESTO)
    }

    private suspend fun ingest(worldId: Long, name: String, kind: String, r: FetchResult) {
        when (r) {
            is FetchResult.Ok -> {
                val id = repo.addSource(worldId, kind, name)
                repo.markSourceProcessed(id, r.title, r.text, r.license, r.provenance, null)
                val n = addDraftsFor(worldId, id, r.title, r.text, name, EntryState.PROPUESTO)
                _notice.value = "Fuente importada. $n entradas propuestas: revísalas en «Entradas»."
            }
            is FetchResult.Failed -> { val id = repo.addSource(worldId, kind, name); repo.markSourceFailed(id, SourceStatus.FALLIDA, r.message, null); _notice.value = r.message }
            is FetchResult.Unsupported -> { val id = repo.addSource(worldId, kind, name); repo.markSourceFailed(id, SourceStatus.NO_COMPATIBLE, r.message, null); _notice.value = r.message }
        }
    }

    private suspend fun addDraftsFor(worldId: Long, sourceId: Long, title: String, text: String, ref: String, state: String): Int {
        val w = repo.world(worldId) ?: return 0
        val prio = w.priorityCharacters.lines().flatMap { it.split(',', ';') }.map { it.trim() }.filter { it.isNotEmpty() }
        val places = w.priorityPlaces.lines().flatMap { it.split(',', ';') }.map { it.trim() }.filter { it.isNotEmpty() }
        val drafts = com.jullai.local.world.WikiExtractor.fromPlainPage(title, text, "$title · $ref".take(300), sourceId, prio, places).map { it.copy(state = state) }
        return repo.addDrafts(worldId, drafts).created
    }

    // ---------------- Investigación (WorkManager) ----------------
    fun startResearch(worldId: Long) = act {
        val w = repo.world(worldId) ?: return@act
        if (!w.allowOnline) throw WorldException("La investigación online está desactivada para este mundo. Actívala en la configuración del mundo.")
        c.researchManager.start(worldId)
    }
    fun cancelResearch(taskId: Long) = act { c.researchManager.cancel(taskId) }

    // ---------------- Extracción con el modelo local (primer plano, validada) ----------------
    private val _extract = MutableStateFlow(ExtractState())
    val extract: StateFlow<ExtractState> = _extract.asStateFlow()
    private var extractJob: Job? = null

    /**
     * Pide al modelo local que proponga entradas a partir del texto de una fuente. La salida se valida línea a línea y las
     * citas se comprueban contra la fuente: lo no verificado queda como «confianza limitada» y PROPUESTO para que lo revises.
     * No hay conexión de red en este paso. Si el modelo es demasiado pequeño, usa la creación manual.
     */
    fun extractWithModel(sourceId: Long) {
        if (extractJob?.isActive == true) return
        if (c.controller.state.value == EngineState.GENERATING) { _extract.value = ExtractState(error = "El modelo está generando una respuesta. Espera a que termine."); return }
        _extract.value = ExtractState(busy = true, message = "Preparando el modelo…")
        extractJob = viewModelScope.launch {
            try {
                val src = repo.source(sourceId) ?: throw WorldException("La fuente ya no existe.")
                val world = repo.world(src.worldId) ?: throw WorldException("El mundo ya no existe.")
                val text = repo.sourceText(src) ?: throw WorldException("Esta fuente no tiene texto procesado. Procésala primero.")
                val models = c.registry.list()
                val model = models.firstOrNull { it.isDefault } ?: models.firstOrNull() ?: throw WorldException("No hay ningún modelo importado. Ve a Modelos e importa un archivo .gguf.")
                val st = c.settingsRepository.settings.value
                val ctx = st.rpContext
                c.controller.ensureLoaded(model, ctx, st.threads)
                val chunks = SourceText.chunks(text, ExtractionPrompts.MAX_CHUNK_CHARS).take(4)
                var created = 0; var rejected = 0
                chunks.forEachIndexed { i, chunk ->
                    _extract.value = ExtractState(busy = true, message = "Analizando trozo ${i + 1} de ${chunks.size}…")
                    val prompt = c.engine.applyTemplate(listOf(ChatMessage("system", ExtractionPrompts.system()), ChatMessage("user", ExtractionPrompts.user(world.name, chunk))))
                    if (c.engine.countTokens(prompt) > ctx - 600) throw WorldException("El trozo no cabe en el contexto (${ctx}). Sube el contexto en Ajustes.")
                    val sb = StringBuilder(); var cancelled = false
                    c.engine.generate(prompt, GenerationParams(temperature = 0.2f, topP = 0.9f, maxTokens = 500, reuseCache = false)).collect { ev ->
                        when (ev) { is GenEvent.Text -> sb.append(ev.text); is GenEvent.Finished -> if (ev.reason == FinishReason.CANCELLED) cancelled = true }
                    }
                    if (cancelled) throw CancellationException("Detenido por el usuario")
                    val r = ModelExtractionParser.parse(sb.toString(), chunk, "${src.title.ifBlank { src.uri }} · ${src.uri}", src.id)
                    created += repo.addDrafts(world.id, r.entries).created
                    rejected += r.rejected
                }
                repo.detectContradictions(world.id)
                _extract.value = ExtractState(message = if (created == 0) "El modelo no devolvió entradas válidas ($rejected líneas descartadas). Prueba con otra fuente, un modelo mayor o crea las entradas a mano." else "Propuestas $created entradas (descartadas $rejected líneas inválidas). Revísalas: nada se activa sin tu aceptación.")
            } catch (e: CancellationException) {
                _extract.value = ExtractState(message = "Extracción detenida."); throw e
            } catch (e: Exception) {
                _extract.value = ExtractState(error = e.message ?: "No se pudo extraer.")
            }
        }
    }
    fun stopExtract() { c.engine.cancel(); extractJob?.cancel() }
    fun dismissExtract() { if (extractJob?.isActive != true) _extract.value = ExtractState() }

    // ---------------- .worldpack ----------------
    private val _transfer = MutableStateFlow(WorldTransfer())
    val transfer: StateFlow<WorldTransfer> = _transfer.asStateFlow()
    private var pendingPack: WorldPack? = null
    private var transferJob: Job? = null

    fun exportWorld(worldId: Long, target: Uri) {
        if (transferJob?.isActive == true) return
        _transfer.value = WorldTransfer(busy = true, message = "Exportando…")
        transferJob = viewModelScope.launch {
            val tmp = File(c.app.cacheDir, "export-${System.nanoTime()}.worldpack")
            try {
                withContext(Dispatchers.IO) {
                    val pack = repo.buildPack(worldId) ?: throw WorldException("El mundo ya no existe.")
                    tmp.outputStream().use { WorldpackCodec.write(pack, it) }
                    val out = c.app.contentResolver.openOutputStream(target, "wt") ?: throw IllegalStateException("No se pudo abrir el destino.")
                    out.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                }
                _transfer.value = WorldTransfer(message = "Mundo exportado como .worldpack (solo datos estructurados y referencias, sin textos completos de las fuentes).")
            } catch (e: CancellationException) {
                withContext(NonCancellable) { runCatching { c.app.contentResolver.delete(target, null, null) } }
                throw e
            } catch (e: Exception) {
                _transfer.value = WorldTransfer(error = "No se pudo exportar: ${e.message}")
            } finally { tmp.delete() }
        }
    }

    /** Lee y valida el archivo SIN tocar tus datos; después muestra qué pasaría. */
    fun readWorldpack(source: Uri) {
        if (transferJob?.isActive == true) return
        pendingPack = null
        _transfer.value = WorldTransfer(busy = true, message = "Leyendo y comprobando el archivo…")
        transferJob = viewModelScope.launch {
            try {
                val pack = withContext(Dispatchers.IO) {
                    val input = c.app.contentResolver.openInputStream(source) ?: throw IllegalStateException("No se pudo abrir el archivo.")
                    input.use { WorldpackCodec.read(it) }
                }
                pendingPack = pack
                _transfer.value = WorldTransfer(plan = repo.previewImport(pack))
            } catch (e: CancellationException) {
                throw e
            } catch (e: WorldpackException) {
                _transfer.value = WorldTransfer(error = e.message)
            } catch (e: Exception) {
                _transfer.value = WorldTransfer(error = "No se pudo leer el archivo: ${e.message}")
            }
        }
    }

    fun confirmWorldpack(choice: WorldImportChoice) {
        val pack = pendingPack ?: return
        if (transferJob?.isActive == true) return
        _transfer.value = WorldTransfer(busy = true, message = "Importando…")
        transferJob = viewModelScope.launch {
            try {
                repo.importPack(pack, choice)
                pendingPack = null
                _transfer.value = WorldTransfer(message = "Mundo importado. No se borró ni sobrescribió nada de lo que ya tenías.")
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                _transfer.value = WorldTransfer(error = "No se pudo importar (no se cambió nada): ${e.message}")
            }
        }
    }
    fun dismissTransfer() { if (transferJob?.isActive != true) { pendingPack = null; _transfer.value = WorldTransfer() } }

    // ---------------- Vínculo partida ↔ mundo y preparación ----------------
    fun sessionWorld(sessionId: Long): Flow<WorldSessionEntity?> = repo.observeSessionWorld(sessionId)
    fun prepSteps(sessionId: Long): Flow<List<PrepStepEntity>> = repo.observePrep(sessionId)

    fun bindSession(sessionId: Long, world: WorldEntity, cast: String, continuity: String, spoilers: String, era: String) = act {
        repo.linkSession(sessionId, world, cast, continuity, spoilers, era)
    }
    fun unbindSession(sessionId: Long) = act { repo.unlinkSession(sessionId) }

    private val _prep = MutableStateFlow<PrepReport?>(null)
    val prep: StateFlow<PrepReport?> = _prep.asStateFlow()

    /** Evalúa los pasos con datos REALES y construye la primera escena si hace falta. No inventa porcentajes. */
    fun runPreparation(sessionId: Long) = act {
        val link = repo.sessionWorld(sessionId)
        var running = false; var failed = false
        link?.worldId?.let { wid ->
            running = repo.activeTask(wid) != null
            failed = repo.lastTask(wid)?.status.let { it == TaskStatus.FALLIDA || it == TaskStatus.SIN_RESULTADOS }
        }
        val report0 = Preparation.evaluate(repo.prepFacts(sessionId, running, failed))
        if (report0.steps.first { it.step == 5 }.status != PrepStatus.LISTO && report0.steps.first { it.step == 3 }.status == PrepStatus.LISTO) repo.buildFirstScene(sessionId)
        val report = Preparation.evaluate(repo.prepFacts(sessionId, running, failed))
        repo.savePrep(sessionId, report)
        _prep.value = report
    }

    // ---------------- Novela visual: metadatos y recursos ----------------
    fun scenes(sessionId: Long): Flow<List<SceneMetaEntity>> = repo.observeScenes(sessionId)

    /**
     * Calcula (si falta) los metadatos visuales de una respuesta, sin tocar su texto. Si algo falla devuelve null y la escena
     * se muestra con la alternativa segura: el juego nunca depende de esto.
     */
    suspend fun ensureScene(sessionId: Long, messageId: Long, text: String, characterName: String, characterAliases: List<String>): SceneMetaEntity? = try {
        run {
            val link = repo.sessionWorld(sessionId)
            val locs = link?.worldId?.let { w -> repo.locationNames(w) }.orEmpty().map { NamedRef(it, it) }
            val prev = repo.sceneBefore(sessionId, messageId)?.locationRef.orEmpty()
            val draft = SceneDirector.direct(SceneInput(text, listOf(NamedRef(characterName, characterName, characterAliases)), locs, characterName, prev))
            val infos = repo.assetInfos()
            val choice: AssetChoice = AssetResolver.choose(draft, com.jullai.local.story.TextNorm.fold(draft.speaker).trim(), draft.location, infos)
            val refs = listOfNotNull(choice.portraitId?.let { "portrait:$it" }, choice.backgroundId?.let { "background:$it" }).joinToString(",")
            repo.saveScene(sessionId, messageId, draft, refs)
            repo.sceneFor(sessionId, messageId)
        }
    } catch (e: CancellationException) { throw e } catch (e: Exception) { null }

    suspend fun assetFile(id: Long): String? = repo.asset(id)?.file

    fun importAsset(kind: String, uri: Uri, label: String, characterId: Long?, worldId: Long?, location: String, emotion: String) = act {
        val bytes = withContext(Dispatchers.IO) { c.app.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw WorldException("No se pudo abrir la imagen.") }
        val file = withContext(Dispatchers.IO) { try { c.portraits.save(bytes, if (kind == com.jullai.local.world.AssetKind.FONDO) 1280 else 768) } catch (e: IllegalArgumentException) { throw WorldException(e.message ?: "Imagen no válida.") } }
        repo.addAsset(kind, file, label, characterId, worldId, location, emotion)
    }
    fun deleteAsset(id: Long) = act { repo.deleteAsset(id)?.let { c.portraits.delete(it) } }
}
