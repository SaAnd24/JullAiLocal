package com.jullai.local.data

import androidx.room.withTransaction
import androidx.sqlite.db.SimpleSQLiteQuery
import com.jullai.local.story.TextNorm
import com.jullai.local.world.AssetInfo
import com.jullai.local.world.AssetKind
import com.jullai.local.world.CastMode
import com.jullai.local.world.Confidence
import com.jullai.local.world.Continuity
import com.jullai.local.world.Contradictions
import com.jullai.local.world.Dedup
import com.jullai.local.world.DraftEntry
import com.jullai.local.world.EntryOrigin
import com.jullai.local.world.EntryState
import com.jullai.local.world.EntryType
import com.jullai.local.world.PackEntry
import com.jullai.local.world.PackSource
import com.jullai.local.world.PackWorld
import com.jullai.local.world.PrepFacts
import com.jullai.local.world.PrepReport
import com.jullai.local.world.Preparation
import com.jullai.local.world.ResearchDepth
import com.jullai.local.world.SceneDraft
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceStatus
import com.jullai.local.world.SpoilerLevel
import com.jullai.local.world.TaskStatus
import com.jullai.local.world.UntrustedText
import com.jullai.local.world.WorldCandidates
import com.jullai.local.world.WorldException
import com.jullai.local.world.WorldItem
import com.jullai.local.world.WorldLimits
import com.jullai.local.world.WorldPack
import com.jullai.local.world.WorldSource
import com.jullai.local.world.WorldpackCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

/** Cómo resolver la importación de un mundo cuando ya existe uno con el mismo identificador. */
enum class WorldImportChoice { CREAR, COPIA, COMBINAR, USAR_EXISTENTE }

/** Qué pasaría al importar, calculado SIN tocar datos. */
class WorldImportPlan(
    val worldName: String,
    val entryCount: Int,
    val sourceCount: Int,
    val existing: WorldEntity?,
    val sameRevision: Boolean,
    val newEntriesIfMerged: Int,
) {
    val conflict: Boolean get() = existing != null
    /** Con un mundo existente y distinto, el usuario debe elegir: no hay opción por defecto. */
    val needsExplicitChoice: Boolean get() = existing != null && !sameRevision
}

class AddResult(val created: Int, val skipped: Int)

fun WorldEntryEntity.toItem() = WorldItem(
    id = id, type = type, name = name, aliases = TextNorm.lines(aliases), summary = summary, details = details, confidence = confidence,
    sourceRef = sourceRef, related = TextNorm.lines(relatedNames), spoilerLevel = spoilerLevel, eraTag = eraTag, updatedAt = updatedAt,
)

/**
 * Mundos, enciclopedia, fuentes e investigación (v0.5). Todo lo que toca varias tablas va en UNA transacción.
 * La enciclopedia (world_entries) NUNCA se modifica desde una partida: solo el usuario o una investigación la cambian.
 */
class WorldRepository(
    private val db: AppDatabase,
    private val store: SourceStore,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : WorldSource {
    companion object {
        const val SCAN_ALL_LIMIT = 600
    }

    // ============================ Mundos ============================

    fun observeWorlds(): Flow<List<WorldEntity>> = db.worlds().observeAll()
    fun observeWorld(id: Long): Flow<WorldEntity?> = db.worlds().observe(id)
    suspend fun world(id: Long): WorldEntity? = db.worlds().get(id)
    suspend fun worlds(): List<WorldEntity> = db.worlds().listAll()

    suspend fun createWorld(w: WorldEntity): Long {
        val name = UntrustedText.oneLine(w.name, WorldLimits.NAME)
        if (name.length < 2) throw WorldException("El mundo necesita un nombre.")
        val now = clock()
        return db.worlds().insert(clean(w).copy(id = 0, uuid = UUID.randomUUID().toString(), name = name, revision = 1, createdAt = now, updatedAt = now))
    }

    suspend fun updateWorld(w: WorldEntity) {
        val name = UntrustedText.oneLine(w.name, WorldLimits.NAME)
        if (name.length < 2) throw WorldException("El mundo necesita un nombre.")
        val cur = db.worlds().get(w.id) ?: throw WorldException("El mundo ya no existe.")
        db.worlds().update(clean(w).copy(uuid = cur.uuid, name = name, revision = cur.revision + 1, createdAt = cur.createdAt, updatedAt = clock()))
    }

    private fun clean(w: WorldEntity) = w.copy(
        description = UntrustedText.sanitize(w.description, WorldLimits.DESCRIPTION), language = UntrustedText.oneLine(w.language, 16).ifBlank { "es" },
        setting = UntrustedText.sanitize(w.setting, 300), era = UntrustedText.oneLine(w.era, 200),
        rules = UntrustedText.sanitize(w.rules, WorldLimits.RULES), narrativeLimits = UntrustedText.sanitize(w.narrativeLimits, WorldLimits.RULES),
        spoilerLevel = if (w.spoilerLevel in SpoilerLevel.ALL) w.spoilerLevel else SpoilerLevel.SIN,
        castMode = if (w.castMode in CastMode.ALL) w.castMode else CastMode.MIXTO,
        continuityMode = if (w.continuityMode in Continuity.ALL) w.continuityMode else Continuity.FLEXIBLE,
        researchDepth = if (w.researchDepth in ResearchDepth.ALL) w.researchDepth else ResearchDepth.BASICA,
        preferredSources = UntrustedText.sanitize(w.preferredSources, 600), priorityCharacters = UntrustedText.sanitize(w.priorityCharacters, 600),
        priorityPlaces = UntrustedText.sanitize(w.priorityPlaces, 600),
    )

    /** Borra el mundo y su enciclopedia. Las partidas que lo usaban NO se borran: pasan a «sin mundo» (worldId nulo). */
    suspend fun deleteWorld(id: Long) {
        val textFiles = db.sources().list(id).mapNotNull { it.textFile }
        db.worlds().delete(id)
        textFiles.forEach { store.delete(it) }
    }

    /** Copia independiente (nuevo uuid): entradas y fuentes (sin el texto extraído). No toca el original. */
    suspend fun duplicateWorld(id: Long): Long? = db.withTransaction {
        val w = db.worlds().get(id) ?: return@withTransaction null
        val pack = buildPackInternal(w)
        importPackInternal(pack, WorldImportChoice.COPIA, null, " (copia)")
    }

    // ============================ Entradas ============================

    fun observeEntries(worldId: Long): Flow<List<WorldEntryEntity>> = db.worldEntries().observe(worldId)
    suspend fun entry(id: Long): WorldEntryEntity? = db.worldEntries().get(id)
    suspend fun entryCount(worldId: Long): Int = db.worldEntries().countActive(worldId)
    suspend fun locationNames(worldId: Long): List<String> = db.worldEntries().listActive(worldId).filter { it.type == EntryType.LUGAR }.map { it.name }

    /**
     * Guarda una entrada escrita o editada por el usuario. Reglas de honestidad: «confirmado por la fuente» exige una fuente y una cita
     * (no se puede afirmar que una fuente lo confirma si no se indicó dónde); una invención de roleplay nunca se hace pasar por canon.
     */
    suspend fun saveEntry(e: WorldEntryEntity): Long {
        val name = UntrustedText.oneLine(e.name, WorldLimits.NAME)
        if (name.length < 2) throw WorldException("La entrada necesita un nombre.")
        if (e.type !in EntryType.ALL) throw WorldException("Tipo de entrada no válido.")
        if (e.confidence !in Confidence.ALL) throw WorldException("Nivel de confianza no válido.")
        if (e.confidence == Confidence.CONFIRMADO && (e.sourceRef.isBlank() || e.evidence.isBlank()))
            throw WorldException("Para marcar «confirmado por la fuente» indica la fuente y la cita donde lo verificaste. Si no la tienes, usa «confianza limitada».")
        val now = clock()
        val clean = e.copy(
            name = name, aliases = e.aliases.lines().map { UntrustedText.oneLine(it, 60) }.filter { it.isNotBlank() }.take(10).joinToString("\n"),
            summary = UntrustedText.sanitize(e.summary, WorldLimits.SUMMARY), details = UntrustedText.sanitize(e.details, WorldLimits.DETAILS),
            sourceRef = UntrustedText.oneLine(e.sourceRef, WorldLimits.SOURCE_REF), evidence = UntrustedText.oneLine(e.evidence, WorldLimits.EVIDENCE),
            factKey = UntrustedText.oneLine(e.factKey, WorldLimits.FACT_KEY), relatedNames = e.relatedNames.lines().map { UntrustedText.oneLine(it, 80) }.filter { it.isNotBlank() }.take(10).joinToString("\n"),
            eraTag = UntrustedText.oneLine(e.eraTag, 80), spoilerLevel = e.spoilerLevel.coerceIn(0, 3), updatedAt = now,
        )
        return db.withTransaction {
            val id: Long
            if (clean.id == 0L) {
                if (db.worldEntries().countActive(clean.worldId) >= WorldLimits.MAX_ENTRIES_PER_WORLD) throw WorldException("El mundo ya tiene el máximo de entradas.")
                id = db.worldEntries().insert(clean.copy(createdAt = now, origin = EntryOrigin.MANUAL))
            } else {
                val cur = db.worldEntries().get(clean.id) ?: throw WorldException("La entrada ya no existe.")
                val keepOrigin = cur.origin == EntryOrigin.IMPORTADO || cur.origin == EntryOrigin.FUENTE
                db.worldEntries().update(clean.copy(worldId = cur.worldId, createdAt = cur.createdAt, origin = if (keepOrigin) cur.origin else EntryOrigin.MANUAL))
                id = clean.id
            }
            touchWorld(clean.worldId)
            id
        }
    }

    suspend fun deleteEntry(id: Long) { val e = db.worldEntries().get(id) ?: return; db.worldEntries().delete(id); touchWorld(e.worldId) }

    suspend fun setEntryState(id: Long, state: String) {
        val e = db.worldEntries().get(id) ?: return
        db.worldEntries().update(e.copy(state = state, updatedAt = clock()))
    }

    private suspend fun touchWorld(worldId: Long) {
        val w = db.worlds().get(worldId) ?: return
        db.worlds().update(w.copy(revision = w.revision + 1, updatedAt = clock()))
    }

    /**
     * Añade entradas candidatas (de una investigación o de una extracción). Nunca modifica una entrada existente.
     * Se omiten los duplicados exactos (mismo tipo, nombre, clave de hecho y fuente) y lo que ya está casi igual.
     */
    suspend fun addDrafts(worldId: Long, drafts: List<DraftEntry>): AddResult = db.withTransaction {
        val existing = db.worldEntries().listAll(worldId)
        val keys = existing.map { Dedup.key(it.type, it.name, it.factKey, it.sourceId?.toString() ?: it.origin) }.toHashSet()
        var count = existing.count { it.state != EntryState.DESCARTADO }
        var created = 0
        var skipped = 0
        val now = clock()
        for (d in drafts) {
            val key = Dedup.key(d.type, d.name, d.factKey, d.sourceId?.toString() ?: d.origin)
            val near = existing.any { it.type == d.type && TextNorm.fold(it.name) == TextNorm.fold(d.name) && TextNorm.similarity(it.summary, d.summary) >= 0.8 }
            if (key in keys || near || count >= WorldLimits.MAX_ENTRIES_PER_WORLD) { skipped++; continue }
            keys.add(key)
            db.worldEntries().insert(
                WorldEntryEntity(
                    worldId = worldId, type = d.type, name = d.name, aliases = d.aliases.joinToString("\n"), summary = d.summary, details = d.details,
                    confidence = d.confidence, origin = d.origin, sourceId = d.sourceId, sourceRef = d.sourceRef, evidence = d.evidence, factKey = d.factKey,
                    relatedNames = d.related.joinToString("\n"), spoilerLevel = d.spoilerLevel, state = d.state, createdAt = now, updatedAt = now,
                ),
            )
            created++; count++
        }
        if (created > 0) touchWorld(worldId)
        AddResult(created, skipped)
    }

    /**
     * Marca como CONTRADICCIÓN los datos de fuentes distintas con el mismo tipo, nombre y clave de hecho pero valores diferentes.
     * No decide cuál es el correcto: ambos se conservan, cada uno con su fuente, y el usuario los ve como contradicción.
     */
    suspend fun detectContradictions(worldId: Long): Int = db.withTransaction {
        val facts = db.worldEntries().listAll(worldId).filter { it.state != EntryState.DESCARTADO && it.factKey.isNotBlank() }
            .map { Contradictions.Fact(it.id, it.type, it.name, it.factKey, it.summary, it.sourceId, it.origin) }
        val groups = Contradictions.detect(facts)
        val now = clock()
        for (g in groups) db.worldEntries().markContradiction(g, Contradictions.groupName(g), now)
        groups.size
    }

    // ============================ Fuentes ============================

    fun observeSources(worldId: Long): Flow<List<SourceEntity>> = db.sources().observe(worldId)
    suspend fun sourcesOf(worldId: Long): List<SourceEntity> = db.sources().list(worldId)
    suspend fun source(id: Long): SourceEntity? = db.sources().get(id)
    fun sourceText(s: SourceEntity): String? = store.read(s.textFile)

    /** Registra una fuente (si ya existe esa dirección, devuelve la existente). */
    suspend fun addSource(worldId: Long, kind: String, uri: String, title: String = "", status: String = SourceStatus.PENDIENTE, error: String = ""): Long = db.withTransaction {
        val clean = UntrustedText.oneLine(uri, 500)
        if (clean.isBlank()) throw WorldException("La dirección de la fuente está vacía.")
        db.sources().byUri(worldId, clean)?.let { return@withTransaction it.id }
        if (db.sources().list(worldId).size >= WorldLimits.MAX_SOURCES_PER_WORLD) throw WorldException("El mundo ya tiene el máximo de fuentes.")
        val now = clock()
        db.sources().insert(SourceEntity(worldId = worldId, kind = kind, uri = clean, title = UntrustedText.oneLine(title, 200), status = status, error = error, createdAt = now, updatedAt = now))
    }

    /** Guarda el resultado de procesar una fuente: texto extraído (recortado), huella y procedencia. */
    suspend fun markSourceProcessed(id: Long, title: String, text: String, license: String, provenance: String, taskId: Long?) {
        val s = db.sources().get(id) ?: return
        val clipped = if (text.length > WorldLimits.MAX_SOURCE_CHARS) text.substring(0, WorldLimits.MAX_SOURCE_CHARS) else text
        val file = withContext(Dispatchers.IO) { store.save(clipped) }
        store.delete(s.textFile)
        db.sources().update(
            s.copy(
                status = SourceStatus.PROCESADA, error = "", title = UntrustedText.oneLine(title, 200).ifBlank { s.title }, consultedAt = clock(),
                license = UntrustedText.oneLine(license, 200), provenance = UntrustedText.oneLine(provenance, 400),
                contentHash = WorldpackCodec.sha256(clipped.toByteArray(Charsets.UTF_8)), textFile = file, charCount = clipped.length,
                taskId = taskId ?: s.taskId, attempts = s.attempts + 1, updatedAt = clock(),
            ),
        )
    }

    suspend fun markSourceFailed(id: Long, status: String, error: String, taskId: Long?) {
        val s = db.sources().get(id) ?: return
        db.sources().update(s.copy(status = status, error = UntrustedText.oneLine(error, 300), consultedAt = clock(), attempts = s.attempts + 1, taskId = taskId ?: s.taskId, updatedAt = clock()))
    }

    /** Cambia la dirección de una fuente (p. ej. una URL que falló) y la deja pendiente para reintentarla. */
    suspend fun changeSourceUri(id: Long, newUri: String) {
        val s = db.sources().get(id) ?: return
        val clean = UntrustedText.oneLine(newUri, 500)
        if (clean.isBlank()) throw WorldException("La dirección está vacía.")
        val other = db.sources().byUri(s.worldId, clean)
        if (other != null && other.id != id) throw WorldException("Ya existe otra fuente con esa dirección.")
        store.delete(s.textFile)
        db.sources().update(s.copy(uri = clean, status = SourceStatus.PENDIENTE, error = "", textFile = null, charCount = 0, contentHash = "", updatedAt = clock()))
    }

    suspend fun deleteSource(id: Long) { val s = db.sources().get(id) ?: return; db.sources().delete(id); store.delete(s.textFile) }

    // ============================ Tareas de investigación ============================

    fun observeTasks(worldId: Long): Flow<List<ResearchTaskEntity>> = db.researchTasks().observeFor(worldId)
    suspend fun task(id: Long): ResearchTaskEntity? = db.researchTasks().get(id)
    suspend fun activeTask(worldId: Long): ResearchTaskEntity? = db.researchTasks().activeFor(worldId)
    suspend fun lastTask(worldId: Long): ResearchTaskEntity? = db.researchTasks().lastFor(worldId)
    suspend fun unfinishedTasks(): List<ResearchTaskEntity> = db.researchTasks().unfinished()
    suspend fun saveTask(t: ResearchTaskEntity) = db.researchTasks().update(t.copy(updatedAt = clock()))
    suspend fun createTask(worldId: Long): Long {
        val now = clock()
        return db.researchTasks().insert(ResearchTaskEntity(worldId = worldId, createdAt = now, updatedAt = now))
    }

    // ============================ Exportar / importar .worldpack ============================

    suspend fun buildPack(worldId: Long): WorldPack? = db.withTransaction { db.worlds().get(worldId)?.let { buildPackInternal(it) } }

    private suspend fun buildPackInternal(w: WorldEntity): WorldPack {
        val sources = db.sources().list(w.id)
        val idx = sources.withIndex().associate { it.value.id to it.index }
        val entries = db.worldEntries().listAll(w.id).filter { it.state == EntryState.ACTIVO }
        return WorldPack(
            appVersion = WorldpackCodec.APP_VERSION, exportedAt = clock(),
            world = PackWorld(
                w.uuid, w.name, w.description, w.language, w.setting, w.era, w.rules, w.narrativeLimits, w.spoilerLevel, w.castMode, w.continuityMode,
                w.researchDepth, w.preferredSources, w.priorityCharacters, w.priorityPlaces, w.revision,
            ),
            entries = entries.map {
                PackEntry(
                    it.type, it.name, TextNorm.lines(it.aliases), it.summary, it.details, it.confidence, it.origin, it.sourceId?.let { sid -> idx[sid] }, it.sourceRef,
                    it.evidence, it.factKey, it.contradictionGroup, TextNorm.lines(it.relatedNames), it.spoilerLevel, it.eraTag, it.state,
                )
            },
            sources = sources.map { PackSource(it.kind, it.uri, it.title, it.status, it.license, it.provenance, it.consultedAt) },
        )
    }

    /** Qué pasaría al importar [pack]: no escribe nada. */
    suspend fun previewImport(pack: WorldPack): WorldImportPlan {
        val existing = db.worlds().byUuid(pack.world.uuid)
        var fresh = pack.entries.size
        if (existing != null) {
            val keys = db.worldEntries().listAll(existing.id).map { Dedup.key(it.type, it.name, it.factKey, it.sourceId?.toString() ?: it.origin) }.toHashSet()
            fresh = pack.entries.count { Dedup.key(it.type, it.name, it.factKey, it.sourceIndex?.toString() ?: it.origin) !in keys }
        }
        return WorldImportPlan(pack.world.name, pack.entries.size, pack.sources.size, existing, existing?.revision == pack.world.revision && fresh == 0, fresh)
    }

    /** Importa. Nunca borra ni sobrescribe datos existentes. Devuelve el id del mundo resultante. */
    suspend fun importPack(pack: WorldPack, choice: WorldImportChoice): Long = db.withTransaction {
        importPackInternal(pack, choice, db.worlds().byUuid(pack.world.uuid), " (importado)")
    }

    private suspend fun importPackInternal(pack: WorldPack, choice: WorldImportChoice, existing: WorldEntity?, copySuffix: String): Long {
        val now = clock()
        if (choice == WorldImportChoice.USAR_EXISTENTE) return existing?.id ?: throw WorldException("No hay un mundo existente que usar.")
        if (choice == WorldImportChoice.COMBINAR) {
            val target = existing ?: throw WorldException("No hay un mundo existente con el que combinar.")
            val map = HashMap<Int, Long>()
            val known = db.sources().list(target.id).associateBy { it.uri }
            pack.sources.forEachIndexed { i, s -> map[i] = known[s.uri]?.id ?: db.sources().insert(sourceOf(target.id, s, now)) }
            val keys = db.worldEntries().listAll(target.id).map { Dedup.key(it.type, it.name, it.factKey, it.sourceId?.toString() ?: it.origin) }.toHashSet()
            val toAdd = pack.entries.filter { Dedup.key(it.type, it.name, it.factKey, it.sourceIndex?.toString() ?: it.origin) !in keys }
            db.worldEntries().insertAll(toAdd.map { entryOf(target.id, it, map, now) })
            touchWorld(target.id)
            return target.id
        }
        // CREAR o COPIA: mundo nuevo. Si el uuid ya existe, el nuevo recibe otro identificador y un nombre distinto.
        val uuidTaken = existing != null || choice == WorldImportChoice.COPIA
        val w = pack.world
        val newId = db.worlds().insert(
            WorldEntity(
                uuid = if (uuidTaken) UUID.randomUUID().toString() else w.uuid, name = if (uuidTaken) UntrustedText.oneLine(w.name, WorldLimits.NAME - copySuffix.length) + copySuffix else w.name,
                description = w.description, language = w.language, setting = w.setting, era = w.era, rules = w.rules, narrativeLimits = w.narrativeLimits,
                spoilerLevel = w.spoilerLevel, castMode = w.castMode, continuityMode = w.continuityMode, researchDepth = w.researchDepth,
                preferredSources = w.preferredSources, priorityCharacters = w.priorityCharacters, priorityPlaces = w.priorityPlaces,
                allowOnline = false, origin = "IMPORTADO", revision = 1, createdAt = now, updatedAt = now,
            ),
        )
        val map = HashMap<Int, Long>()
        pack.sources.forEachIndexed { i, s -> map[i] = db.sources().insert(sourceOf(newId, s, now)) }
        db.worldEntries().insertAll(pack.entries.map { entryOf(newId, it, map, now) })
        return newId
    }

    private fun sourceOf(worldId: Long, s: PackSource, now: Long) = SourceEntity(
        worldId = worldId, kind = s.kind, uri = s.uri, title = s.title, status = s.status, license = s.license, provenance = s.provenance,
        consultedAt = s.consultedAt, createdAt = now, updatedAt = now,
    )

    private fun entryOf(worldId: Long, e: PackEntry, map: Map<Int, Long>, now: Long) = WorldEntryEntity(
        worldId = worldId, type = e.type, name = e.name, aliases = e.aliases.joinToString("\n"), summary = e.summary, details = e.details, confidence = e.confidence,
        origin = e.origin, sourceId = e.sourceIndex?.let { map[it] }, sourceRef = e.sourceRef, evidence = e.evidence, factKey = e.factKey,
        contradictionGroup = e.contradictionGroup, relatedNames = e.related.joinToString("\n"), spoilerLevel = e.spoilerLevel, eraTag = e.eraTag,
        state = e.state, createdAt = now, updatedAt = now,
    )

    // ============================ Vínculo partida ↔ mundo ============================

    fun observeSessionWorld(sessionId: Long): Flow<WorldSessionEntity?> = db.worldSessions().observe(sessionId)
    suspend fun sessionWorld(sessionId: Long): WorldSessionEntity? = db.worldSessions().get(sessionId)

    suspend fun linkSession(sessionId: Long, world: WorldEntity, castMode: String, continuityMode: String, spoilerLevel: String, startEra: String) {
        val now = clock()
        val prev = db.worldSessions().get(sessionId)
        db.worldSessions().upsert(
            WorldSessionEntity(
                sessionId = sessionId, worldId = world.id, worldUuid = world.uuid, worldName = world.name,
                castMode = castMode, continuityMode = continuityMode, spoilerLevel = spoilerLevel, startEra = UntrustedText.oneLine(startEra, 200),
                visual = prev?.visual ?: true, createdAt = prev?.createdAt ?: now, updatedAt = now,
            ),
        )
    }

    suspend fun unlinkSession(sessionId: Long) = db.worldSessions().delete(sessionId)

    /** Instantánea del mundo de la partida para incrustarla en el .jullai. Null si la partida no tiene mundo (o ya no existe). */
    suspend fun snapshotFor(sessionId: Long): ByteArray? {
        val link = db.worldSessions().get(sessionId) ?: return null
        val wid = link.worldId ?: return null
        val base = buildPack(wid) ?: return null
        val pack = WorldPack(base.appVersion, base.exportedAt, base.world, base.entries, base.sources, link = com.jullai.local.world.PackLink(link.castMode, link.continuityMode, link.spoilerLevel, link.startEra))
        return WorldpackCodec.encodeSnapshot(pack)
    }

    /** Tras importar un .jullai con instantánea: resuelve el mundo según la elección EXPLÍCITA del usuario y enlaza la partida. */
    suspend fun attachSnapshot(sessionId: Long, pack: WorldPack, choice: WorldImportChoice): Long {
        val worldId = importPack(pack, choice)
        val w = db.worlds().get(worldId) ?: throw WorldException("No se pudo crear el mundo.")
        val l = pack.link
        linkSession(sessionId, w, l?.castMode ?: w.castMode, l?.continuityMode ?: w.continuityMode, l?.spoilerLevel ?: w.spoilerLevel, l?.startEra ?: w.era)
        return worldId
    }

    // ============================ Preparación ============================

    fun observePrep(sessionId: Long): Flow<List<PrepStepEntity>> = db.prepSteps().observe(sessionId)

    suspend fun prepFacts(sessionId: Long, researchRunning: Boolean, researchFailed: Boolean): PrepFacts {
        val s = db.roleSessions().get(sessionId)
        val link = db.worldSessions().get(sessionId)
        val w = link?.worldId?.let { db.worlds().get(it) }
        val ch = s?.let { db.characters().get(it.characterId) }
        val entries = if (w != null) db.worldEntries().countActive(w.id) else 0
        val places = if (w != null) db.worldEntries().countType(w.id, EntryType.LUGAR) else 0
        val firstMsg = !ch?.firstMessage.isNullOrBlank()
        return PrepFacts(
            worldExists = w != null, worldName = w?.name ?: link?.worldName.orEmpty(), activeEntries = entries, hasWorldRules = !w?.rules.isNullOrBlank(),
            researchRunning = researchRunning, researchFailed = researchFailed, characterName = ch?.name.orEmpty(),
            characterHasSheet = ch != null && (ch.personality.isNotBlank() || ch.history.isNotBlank() || ch.appearance.isNotBlank()),
            locationEntries = places, scenarioText = s?.scenarioText.orEmpty(), hasFirstMessage = firstMsg,
        )
    }

    suspend fun savePrep(sessionId: Long, report: PrepReport) {
        val now = clock()
        for (st in report.steps) db.prepSteps().upsert(PrepStepEntity(sessionId = sessionId, step = st.step, title = st.title, status = st.status, detail = st.detail, updatedAt = now))
    }

    /** Escribe la primera escena (solo si la partida no tiene ya un escenario) a partir de la configuración del mundo. */
    suspend fun buildFirstScene(sessionId: Long): Boolean = db.withTransaction {
        val s = db.roleSessions().get(sessionId) ?: return@withTransaction false
        if (s.scenarioText.isNotBlank()) return@withTransaction true
        val link = db.worldSessions().get(sessionId) ?: return@withTransaction false
        val w = link.worldId?.let { db.worlds().get(it) } ?: return@withTransaction false
        val ch = db.characters().get(s.characterId) ?: return@withTransaction false
        val place = db.worldEntries().listActive(w.id).firstOrNull { it.type == EntryType.LUGAR }?.name.orEmpty()
        val text = Preparation.composeFirstScene(w.name, w.setting, link.startEra.ifBlank { w.era }, place, ch.name, s.userName)
        db.roleSessions().update(s.copy(scenarioText = text, updatedAt = clock()))
        true
    }

    // ============================ Recursos visuales y escenas ============================

    fun observeAssets(): Flow<List<VisualAssetEntity>> = db.visualAssets().observeAll()
    suspend fun addAsset(kind: String, file: String, label: String, characterId: Long?, worldId: Long?, locationRef: String, emotion: String): Long =
        db.visualAssets().insert(VisualAssetEntity(kind = kind, file = file, label = UntrustedText.oneLine(label, 80), characterId = characterId, worldId = worldId, locationRef = UntrustedText.oneLine(locationRef, 120), emotion = emotion, createdAt = clock()))
    suspend fun deleteAsset(id: Long): String? { val a = db.visualAssets().get(id) ?: return null; db.visualAssets().delete(id); return a.file }
    suspend fun asset(id: Long): VisualAssetEntity? = db.visualAssets().get(id)

    suspend fun assetInfos(): List<AssetInfo> {
        val chars = db.characters().all().associateBy { it.id }
        return db.visualAssets().listAll().map { AssetInfo(it.id, it.kind, it.characterId?.let { id -> chars[id]?.name }?.let { n -> TextNorm.fold(n).trim() }.orEmpty(), it.locationRef, it.emotion, it.label) }
    }

    fun observeScenes(sessionId: Long): Flow<List<SceneMetaEntity>> = db.sceneMeta().observe(sessionId)
    suspend fun sceneFor(sessionId: Long, messageId: Long): SceneMetaEntity? = db.sceneMeta().forMessage(sessionId, messageId)
    suspend fun lastScene(sessionId: Long): SceneMetaEntity? = db.sceneMeta().recent(sessionId, 1).firstOrNull()
    suspend fun sceneBefore(sessionId: Long, messageId: Long): SceneMetaEntity? = db.sceneMeta().before(sessionId, messageId)

    suspend fun saveScene(sessionId: Long, messageId: Long, d: SceneDraft, assetRefs: String) {
        db.sceneMeta().upsert(
            SceneMetaEntity(
                sessionId = sessionId, messageId = messageId, locationRef = d.location, speaker = d.speaker, emotion = d.emotion, pose = d.pose,
                eventType = d.eventType, assetRefs = assetRefs, important = d.important, valid = d.valid, createdAt = clock(),
            ),
        )
    }

    // ============================ WorldSource (recuperador) ============================

    override suspend fun candidates(worldId: Long, queryTokens: List<String>): WorldCandidates {
        val total = db.worldEntries().countActive(worldId)
        val fts = if (WorldFts.available) ftsIds(worldId, queryTokens) else null
        val backend = if (fts != null) "texto completo (FTS4) + palabras clave" else "palabras clave (FTS4 no disponible)"
        if (total <= SCAN_ALL_LIMIT) return WorldCandidates(db.worldEntries().listActive(worldId).map { it.toItem() }, fts, backend)
        val picked = LinkedHashMap<Long, WorldEntryEntity>()
        val ids = fts?.toList().orEmpty()
        if (ids.isNotEmpty()) db.worldEntries().activeByIds(worldId, ids.take(300)).forEach { picked[it.id] = it }
        else for (t in queryTokens.take(8)) db.worldEntries().searchLike(worldId, "%" + escapeLike(t) + "%", 40).forEach { picked[it.id] = it }
        return WorldCandidates(picked.values.map { it.toItem() }, fts, "$backend · preselección ($total entradas)")
    }

    /** Búsqueda que ve el usuario en la enciclopedia: FTS4 si hay, si no LIKE. */
    suspend fun searchEntries(worldId: Long, query: String, limit: Int = 50): List<WorldEntryEntity> {
        val tokens = TextNorm.tokens(query)
        if (tokens.isEmpty()) return emptyList()
        val ids = if (WorldFts.available) ftsIds(worldId, tokens) else null
        if (ids != null) return db.worldEntries().activeByIds(worldId, ids.take(limit))
        val out = LinkedHashMap<Long, WorldEntryEntity>()
        for (t in tokens.take(6)) db.worldEntries().searchLike(worldId, "%" + escapeLike(t) + "%", limit).forEach { out[it.id] = it }
        return out.values.toList().take(limit)
    }

    private suspend fun ftsIds(worldId: Long, tokens: List<String>): Set<Long>? = withContext(Dispatchers.IO) {
        val expr = FtsSupport.matchExpression(tokens.flatMap { TextNorm.keys(it) }) ?: return@withContext emptySet<Long>()
        try {
            val out = HashSet<Long>()
            db.query(
                SimpleSQLiteQuery(
                    "SELECT e.id FROM world_entries e WHERE e.worldId = ? AND e.state = 'ACTIVO' AND e.id IN " +
                        "(SELECT docid FROM ${WorldFts.TABLE} WHERE ${WorldFts.TABLE} MATCH ?)",
                    arrayOf<Any>(worldId, expr),
                ),
            ).use { c -> while (c.moveToNext()) out.add(c.getLong(0)) }
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun escapeLike(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}
