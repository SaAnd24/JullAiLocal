package com.jullai.local.world

/**
 * Constantes y reglas puras del módulo de mundos (v0.5). Nada aquí depende de Android ni de Room: se prueba con JUnit.
 */

/** Nivel de confianza de cada dato. Se guarda como texto en world_entries.confidence. */
object Confidence {
    const val CONFIRMADO = "CONFIRMADO_POR_FUENTE"
    const val LIMITADA = "CONFIANZA_LIMITADA"
    const val CONTRADICCION = "CONTRADICCION"
    const val AFICIONADOS = "INTERPRETACION_DE_AFICIONADOS"
    const val INVENCION = "INVENCION_DE_ROLEPLAY"
    val ALL = listOf(CONFIRMADO, LIMITADA, CONTRADICCION, AFICIONADOS, INVENCION)

    fun label(c: String) = when (c) {
        CONFIRMADO -> "Confirmado por la fuente"
        LIMITADA -> "Confianza limitada"
        CONTRADICCION -> "Contradicción entre fuentes"
        AFICIONADOS -> "Interpretación de aficionados"
        INVENCION -> "Invención de roleplay"
        else -> c
    }

    /** Texto corto que acompaña al dato cuando se envía al modelo, para que no convierta una interpretación en un hecho. */
    fun promptTag(c: String) = when (c) {
        CONFIRMADO -> "confirmado"
        LIMITADA -> "poco fiable"
        CONTRADICCION -> "fuentes en contradicción"
        AFICIONADOS -> "interpretación de aficionados, no es hecho"
        INVENCION -> "invención de esta ficción, no es canon"
        else -> "sin clasificar"
    }
}

object EntryType {
    const val PERSONAJE = "PERSONAJE"
    const val ALIAS = "ALIAS"
    const val RELACION = "RELACION"
    const val LUGAR = "LUGAR"
    const val OBJETO = "OBJETO"
    const val CRIATURA = "CRIATURA"
    const val CONCEPTO = "CONCEPTO"
    const val REGLA = "REGLA"
    const val ACONTECIMIENTO = "ACONTECIMIENTO"
    const val SECRETO = "SECRETO"
    const val CONFLICTO = "CONFLICTO"
    const val OTRO = "OTRO"
    val ALL = listOf(PERSONAJE, ALIAS, RELACION, LUGAR, OBJETO, CRIATURA, CONCEPTO, REGLA, ACONTECIMIENTO, SECRETO, CONFLICTO, OTRO)

    fun label(t: String) = when (t) {
        PERSONAJE -> "Personaje"; ALIAS -> "Alias"; RELACION -> "Relación"; LUGAR -> "Lugar"; OBJETO -> "Objeto"
        CRIATURA -> "Criatura"; CONCEPTO -> "Concepto"; REGLA -> "Regla"; ACONTECIMIENTO -> "Acontecimiento"
        SECRETO -> "Secreto"; CONFLICTO -> "Conflicto"; else -> "Otro"
    }
}

/** De dónde salió la entrada. */
object EntryOrigin {
    const val FUENTE = "FUENTE"          // extraída de una fuente (texto de la fuente o extracción verificada)
    const val MODELO = "MODELO"          // propuesta por el modelo local sin verificación en la fuente
    const val MANUAL = "MANUAL"          // escrita o editada por el usuario
    const val IMPORTADO = "IMPORTADO"    // viene de un .worldpack
    val ALL = listOf(FUENTE, MODELO, MANUAL, IMPORTADO)
}

object EntryState {
    const val ACTIVO = "ACTIVO"
    const val PROPUESTO = "PROPUESTO"
    const val DESCARTADO = "DESCARTADO"
}

object Continuity {
    const val ESTRICTA = "ESTRICTA"
    const val FLEXIBLE = "FLEXIBLE"
    const val AU = "AU"
    val ALL = listOf(ESTRICTA, FLEXIBLE, AU)

    fun label(c: String) = when (c) {
        ESTRICTA -> "Estricta"; FLEXIBLE -> "Flexible"; AU -> "Universo alternativo (AU)"; else -> c
    }

    /** Instrucción que el modelo recibe según la continuidad. Los hitos canónicos son datos del mundo, no órdenes de la fuente. */
    fun rule(c: String) = when (c) {
        ESTRICTA -> "Continuidad ESTRICTA: intenta respetar los hitos canónicos del mundo; si una acción del jugador los contradice, narra la dificultad en lugar de ignorar el canon."
        FLEXIBLE -> "Continuidad FLEXIBLE: las decisiones del jugador pueden cambiar los sucesos posteriores; adapta el mundo a esos cambios y a lo ya ocurrido en la partida."
        AU -> "UNIVERSO ALTERNATIVO: el mundo sirve solo como referencia de personajes, lugares y reglas; NO fuerces los acontecimientos originales."
        else -> ""
    }
}

object CastMode {
    const val CANONICO = "CANONICO"
    const val ORIGINAL = "ORIGINAL"
    const val MIXTO = "MIXTO"
    val ALL = listOf(CANONICO, ORIGINAL, MIXTO)

    fun label(c: String) = when (c) {
        CANONICO -> "Personajes canónicos"; ORIGINAL -> "Personajes originales"; MIXTO -> "Mixto"; else -> c
    }
}

object SpoilerLevel {
    const val SIN = "SIN_SPOILERS"
    const val MODERADO = "MODERADO"
    const val COMPLETO = "COMPLETO"
    val ALL = listOf(SIN, MODERADO, COMPLETO)

    fun label(l: String) = when (l) {
        SIN -> "Sin spoilers"; MODERADO -> "Spoilers moderados"; COMPLETO -> "Spoilers completos"; else -> l
    }

    /** Nivel numérico máximo de spoiler de una entrada que se puede enviar al modelo (0 = sin spoiler, 3 = secreto central). */
    fun maxEntryLevel(l: String) = when (l) { SIN -> 0; MODERADO -> 1; else -> 3 }
}

object ResearchDepth {
    const val BASICA = "BASICA"
    const val MEDIA = "MEDIA"
    const val PROFUNDA = "PROFUNDA"
    val ALL = listOf(BASICA, MEDIA, PROFUNDA)

    fun label(d: String) = when (d) { BASICA -> "Básica"; MEDIA -> "Media"; PROFUNDA -> "Profunda"; else -> d }

    /** Páginas máximas que una investigación consulta por proveedor. */
    fun maxPages(d: String) = when (d) { BASICA -> 5; MEDIA -> 15; PROFUNDA -> 40; else -> 5 }
}

object SourceKind {
    const val MEDIAWIKI = "MEDIAWIKI"
    const val URL = "URL"
    const val ARCHIVO = "ARCHIVO"
    const val MANUAL = "MANUAL"
}

object SourceStatus {
    const val PENDIENTE = "PENDIENTE"
    const val PROCESADA = "PROCESADA"
    const val FALLIDA = "FALLIDA"
    const val NO_COMPATIBLE = "NO_COMPATIBLE"

    fun label(s: String) = when (s) {
        PENDIENTE -> "Pendiente"; PROCESADA -> "Procesada"; FALLIDA -> "Fallida"; NO_COMPATIBLE -> "No compatible"; else -> s
    }
}

object TaskStatus {
    const val PENDIENTE = "PENDIENTE"
    const val EN_CURSO = "EN_CURSO"
    const val COMPLETADA = "COMPLETADA"
    const val SIN_RESULTADOS = "SIN_RESULTADOS"   // terminó, pero no obtuvo fuentes y entradas válidas: NO es un éxito
    const val FALLIDA = "FALLIDA"
    const val CANCELADA = "CANCELADA"

    fun label(s: String) = when (s) {
        PENDIENTE -> "Pendiente (esperando a Android)"; EN_CURSO -> "En curso"; COMPLETADA -> "Completada"
        SIN_RESULTADOS -> "Terminó sin resultados válidos"; FALLIDA -> "Fallida"; CANCELADA -> "Cancelada"; else -> s
    }

    fun isFinal(s: String) = s == COMPLETADA || s == SIN_RESULTADOS || s == FALLIDA || s == CANCELADA
}

object ResearchPhase {
    const val PENDIENTE = "PENDIENTE"
    const val BUSCANDO = "BUSCANDO_PAGINAS"
    const val DESCARGANDO = "DESCARGANDO_FUENTES"
    const val EXTRAYENDO = "EXTRAYENDO_ENTRADAS"
    const val CONTRADICCIONES = "COMPROBANDO_CONTRADICCIONES"
    const val FIN = "FINALIZADA"

    fun label(p: String) = when (p) {
        PENDIENTE -> "Preparando"; BUSCANDO -> "Buscando páginas"; DESCARGANDO -> "Descargando fuentes"
        EXTRAYENDO -> "Extrayendo entradas"; CONTRADICCIONES -> "Comprobando contradicciones"; FIN -> "Finalizada"; else -> p
    }
}

object AssetKind {
    const val RETRATO = "RETRATO"
    const val FONDO = "FONDO"
    // v0.6: recursos que genera o importa el estudio de imágenes
    const val EXPRESION = "EXPRESION"
    const val POSE = "POSE"
    const val ILUSTRACION = "ILUSTRACION"
    val ALL = listOf(RETRATO, EXPRESION, POSE, FONDO, ILUSTRACION)

    fun label(k: String) = when (k) {
        RETRATO -> "Retrato"; EXPRESION -> "Expresión"; POSE -> "Pose"; FONDO -> "Fondo"; ILUSTRACION -> "Ilustración"; else -> k
    }
}

object VisualEvent {
    const val DIALOGO = "DIALOGO"
    const val NARRACION = "NARRACION"
    const val CAMBIO_LUGAR = "CAMBIO_DE_LUGAR"
    const val ENTRADA = "ENTRADA_PERSONAJE"
    const val SALIDA = "SALIDA_PERSONAJE"
    const val IMPORTANTE = "ESCENA_IMPORTANTE"
    val ALL = listOf(DIALOGO, NARRACION, CAMBIO_LUGAR, ENTRADA, SALIDA, IMPORTANTE)
}

/** Límites de todo lo que entra al sistema desde el exterior (fuentes, archivos, modelo, paquetes). */
object WorldLimits {
    const val NAME = 120
    const val ALIASES = 400
    const val SUMMARY = 500
    const val DETAILS = 1600
    const val EVIDENCE = 240
    const val SOURCE_REF = 300
    const val FACT_KEY = 80
    const val RELATED = 300
    const val DESCRIPTION = 2000
    const val RULES = 4000
    const val MAX_ENTRIES_PER_WORLD = 5000
    const val MAX_SOURCES_PER_WORLD = 300
    /** Texto de una fuente que se conserva (el resto se descarta): no se almacenan libros completos. */
    const val MAX_SOURCE_CHARS = 60_000
}

class WorldException(message: String) : Exception(message)
