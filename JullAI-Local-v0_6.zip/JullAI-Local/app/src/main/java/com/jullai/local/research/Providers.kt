package com.jullai.local.research

import com.jullai.local.data.SourceEntity
import com.jullai.local.data.WorldEntity
import com.jullai.local.world.PrepStatus
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceText
import com.jullai.local.world.UntrustedText
import com.jullai.local.world.WikiParse
import com.jullai.local.world.WorldLimits
import java.net.URLEncoder

/** Resultado de pedir una fuente. */
sealed class FetchResult {
    class Ok(val title: String, val text: String, val license: String, val provenance: String) : FetchResult()
    class Failed(val message: String, val retryable: Boolean) : FetchResult()
    class Unsupported(val message: String) : FetchResult()
}

/**
 * Proveedor modular de fuentes (v0.5). Cada proveedor decide si entiende una fuente y la obtiene respetando sus condiciones.
 * Nunca se hace scraping de buscadores ni se saltan controles de acceso.
 */
interface SourceProvider {
    val id: String
    fun canHandle(source: SourceEntity): Boolean
    suspend fun fetch(source: SourceEntity): FetchResult
}

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

/** APIs públicas de MediaWiki (Wikipedia, Fandom y wikis comunitarias que las expongan). La fuente se guarda como «mw:<api>#<Título>». */
class MediaWikiProvider(private val http: PoliteHttp) : SourceProvider {
    override val id = "mediawiki"
    override fun canHandle(source: SourceEntity) = source.kind == SourceKind.MEDIAWIKI && source.uri.startsWith(PREFIX)

    companion object {
        const val PREFIX = "mw:"
        fun uriOf(api: String, title: String) = "$PREFIX${api.trim()}#${title.trim()}"
        fun split(uri: String): Pair<String, String>? {
            if (!uri.startsWith(PREFIX)) return null
            val body = uri.removePrefix(PREFIX)
            val i = body.indexOf('#')
            if (i <= 0 || i >= body.length - 1) return null
            return body.substring(0, i) to body.substring(i + 1)
        }
    }

    override suspend fun fetch(source: SourceEntity): FetchResult {
        val (api, title) = split(source.uri) ?: return FetchResult.Unsupported("Dirección de wiki no válida. Usa «mw:<api.php>#<Título>».")
        return try {
            var license = ""
            var site = ""
            try {
                val info = WikiParse.siteInfo(json(api, "action=query&meta=siteinfo&siprop=general%7Crightsinfo&format=json&formatversion=2"))
                if (info != null) { license = info.rightsText + (if (info.rightsUrl.isNotBlank()) " (${info.rightsUrl})" else ""); site = info.siteName }
            } catch (e: HttpFailure) { if (!e.retryable) throw e }
            val extracts = json(api, "action=query&prop=extracts%7Cinfo%7Crevisions&explaintext=1&exsectionformat=wiki&inprop=url&rvprop=ids&redirects=1&maxlag=5&titles=${enc(title)}&format=json&formatversion=2")
            WikiParse.apiError(extracts)?.let { return FetchResult.Failed("La wiki respondió con un error: $it", it.contains("lag", true)) }
            var page = WikiParse.extractPages(extracts).firstOrNull()
            if (page == null || page.text.length < 40) {
                val parsed = json(api, "action=parse&page=${enc(title)}&prop=text&redirects=1&disabletoc=1&maxlag=5&format=json&formatversion=2")
                page = WikiParse.parsePage(parsed, title) ?: return FetchResult.Failed("La página «$title» no existe o está vacía en esa wiki. Puedes cambiar el título.", false)
            }
            val prov = "API MediaWiki: $api · página «${page.title}»" + (if (page.revisionId > 0) " · revisión ${page.revisionId}" else "") + (if (site.isNotBlank()) " · $site" else "")
            FetchResult.Ok(page.title, page.text, license, prov)
        } catch (e: HttpFailure) {
            FetchResult.Failed(e.message ?: "Error de red.", e.retryable)
        }
    }

    /** Busca páginas relacionadas con [terms] en la wiki [api]. Devuelve títulos (como mucho [max]). */
    suspend fun discover(api: String, terms: List<String>, max: Int): List<String> {
        val out = LinkedHashSet<String>()
        for (t in terms.filter { it.isNotBlank() }) {
            if (out.size >= max) break
            val perTerm = (max - out.size).coerceAtMost(5)
            val j = try { json(api, "action=query&list=search&srsearch=${enc(t)}&srlimit=$perTerm&srnamespace=0&maxlag=5&format=json&formatversion=2") } catch (e: HttpFailure) { if (e.retryable) throw e else continue }
            if (WikiParse.apiError(j) != null) continue
            for (title in WikiParse.searchTitles(j)) { out.add(title); if (out.size >= max) break }
        }
        return out.toList()
    }

    private suspend fun json(api: String, query: String): String {
        val sep = if (api.contains('?')) "&" else "?"
        val r = http.get(api + sep + query, 1_500_000, "application/json")
        return String(r.body, Charsets.UTF_8)
    }
}

/** URLs proporcionadas por el usuario (HTML, texto o Markdown). Respeta robots.txt. PDF no está soportado en esta versión. */
class UrlProvider(private val http: PoliteHttp) : SourceProvider {
    override val id = "url"
    override fun canHandle(source: SourceEntity) = source.kind == SourceKind.URL

    override suspend fun fetch(source: SourceEntity): FetchResult {
        UrlPolicy.reject(source.uri)?.let { return FetchResult.Failed(it, false) }
        return try {
            if (!http.robotsAllows(source.uri)) return FetchResult.Failed("El robots.txt del sitio no permite el acceso automático. Importa el contenido a mano si quieres usarlo.", false)
            val r = http.get(source.uri)
            val head = String(r.body.copyOfRange(0, minOf(r.body.size, 8)), Charsets.ISO_8859_1)
            val type = (r.headers["content-type"] ?: "").lowercase()
            if (type.contains("pdf") || head.startsWith("%PDF") || source.uri.substringBefore('?').lowercase().endsWith(".pdf"))
                return FetchResult.Unsupported("PDF no compatible en esta versión (no hay una dependencia verificable para leerlos). Exporta el texto a TXT o Markdown e impórtalo.")
            if (type.isNotEmpty() && !(type.startsWith("text/") || type.contains("html") || type.contains("xml") || type.contains("markdown")))
                return FetchResult.Unsupported("Tipo de contenido no compatible («${type.substringBefore(';')}»).")
            val body = String(r.body, charsetOf(type))
            val text = if (type.contains("html") || body.trimStart().startsWith("<")) SourceText.htmlToText(body) else if (type.contains("markdown") || source.uri.lowercase().endsWith(".md")) SourceText.markdownToText(body) else SourceText.plainToText(body)
            val clean = UntrustedText.sanitize(text, WorldLimits.MAX_SOURCE_CHARS)
            if (clean.length < 40) return FetchResult.Failed("La página no tiene texto aprovechable (¿se carga con JavaScript?). Importa el contenido a mano.", false)
            val title = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(body)?.groupValues?.get(1)?.let { SourceText.decodeEntities(it) }.orEmpty()
            FetchResult.Ok(UntrustedText.oneLine(title, 200).ifBlank { source.uri.substringAfter("://").take(80) }, clean, "", "URL del usuario: ${source.uri}" + (if (r.truncated) " · contenido recortado por tamaño" else ""))
        } catch (e: HttpFailure) {
            FetchResult.Failed(e.message ?: "Error de red.", e.retryable)
        }
    }

    private fun charsetOf(contentType: String): java.nio.charset.Charset {
        val m = Regex("charset=([\\w-]+)").find(contentType)?.groupValues?.get(1) ?: return Charsets.UTF_8
        return try { java.nio.charset.Charset.forName(m) } catch (e: Exception) { Charsets.UTF_8 }
    }
}

/** Archivos locales TXT, Markdown y HTML elegidos con el selector del sistema. No usa red: se procesan al importarlos. */
object LocalFileProvider {
    const val MAX_FILE_BYTES = 3_000_000

    fun ingest(fileName: String, bytes: ByteArray): FetchResult {
        if (bytes.size > MAX_FILE_BYTES) return FetchResult.Failed("El archivo es demasiado grande (máximo ${MAX_FILE_BYTES / 1_000_000} MB).", false)
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "pdf" || (bytes.size >= 4 && String(bytes, 0, 4, Charsets.ISO_8859_1) == "%PDF"))
            return FetchResult.Unsupported("PDF no compatible en esta versión. Exporta el texto a TXT o Markdown e impórtalo.")
        val content = String(bytes, Charsets.UTF_8)
        val text = SourceText.byExtension(fileName, content) ?: return FetchResult.Unsupported("Formato «.$ext» no compatible. Usa TXT, Markdown (.md) o HTML.")
        val clean = UntrustedText.sanitize(text, WorldLimits.MAX_SOURCE_CHARS)
        if (clean.length < 20) return FetchResult.Failed("El archivo no contiene texto aprovechable.", false)
        return FetchResult.Ok(UntrustedText.oneLine(fileName.substringBeforeLast('.'), 200), clean, "", "Archivo local: $fileName")
    }
}
