package com.jullai.local.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WorldDao {
    @Insert
    suspend fun insert(w: WorldEntity): Long

    @Update
    suspend fun update(w: WorldEntity)

    @Query("DELETE FROM worlds WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM worlds WHERE id = :id")
    suspend fun get(id: Long): WorldEntity?

    @Query("SELECT * FROM worlds WHERE id = :id")
    fun observe(id: Long): Flow<WorldEntity?>

    @Query("SELECT * FROM worlds WHERE uuid = :uuid")
    suspend fun byUuid(uuid: String): WorldEntity?

    @Query("SELECT * FROM worlds ORDER BY updatedAt DESC, id DESC")
    fun observeAll(): Flow<List<WorldEntity>>

    @Query("SELECT * FROM worlds ORDER BY updatedAt DESC, id DESC")
    suspend fun listAll(): List<WorldEntity>

    @Query("SELECT COUNT(*) FROM world_sessions WHERE worldId = :worldId")
    suspend fun sessionCount(worldId: Long): Int
}

@Dao
interface WorldEntryDao {
    @Insert
    suspend fun insert(e: WorldEntryEntity): Long

    @Insert
    suspend fun insertAll(list: List<WorldEntryEntity>)

    @Update
    suspend fun update(e: WorldEntryEntity)

    @Query("DELETE FROM world_entries WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM world_entries WHERE id = :id")
    suspend fun get(id: Long): WorldEntryEntity?

    @Query("SELECT * FROM world_entries WHERE worldId = :worldId AND state != 'DESCARTADO' ORDER BY type ASC, name COLLATE NOCASE ASC")
    fun observe(worldId: Long): Flow<List<WorldEntryEntity>>

    @Query("SELECT * FROM world_entries WHERE worldId = :worldId ORDER BY id ASC")
    suspend fun listAll(worldId: Long): List<WorldEntryEntity>

    @Query("SELECT * FROM world_entries WHERE worldId = :worldId AND state = 'ACTIVO' ORDER BY id ASC")
    suspend fun listActive(worldId: Long): List<WorldEntryEntity>

    @Query("SELECT COUNT(*) FROM world_entries WHERE worldId = :worldId AND state = 'ACTIVO'")
    suspend fun countActive(worldId: Long): Int

    @Query("SELECT COUNT(*) FROM world_entries WHERE worldId = :worldId AND state = 'ACTIVO' AND type = :type")
    suspend fun countType(worldId: Long, type: String): Int

    @Query("SELECT * FROM world_entries WHERE worldId = :worldId AND state = 'ACTIVO' AND id IN (:ids)")
    suspend fun activeByIds(worldId: Long, ids: List<Long>): List<WorldEntryEntity>

    @Query("SELECT * FROM world_entries WHERE worldId = :worldId AND state = 'ACTIVO' AND (name LIKE :pattern ESCAPE '\\' OR aliases LIKE :pattern ESCAPE '\\' OR summary LIKE :pattern ESCAPE '\\' OR details LIKE :pattern ESCAPE '\\' OR relatedNames LIKE :pattern ESCAPE '\\') LIMIT :limit")
    suspend fun searchLike(worldId: Long, pattern: String, limit: Int): List<WorldEntryEntity>

    @Query("UPDATE world_entries SET contradictionGroup = :group, confidence = 'CONTRADICCION', updatedAt = :now WHERE id IN (:ids)")
    suspend fun markContradiction(ids: List<Long>, group: String, now: Long)
}

@Dao
interface SourceDao {
    @Insert
    suspend fun insert(s: SourceEntity): Long

    @Update
    suspend fun update(s: SourceEntity)

    @Query("DELETE FROM sources WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM sources WHERE id = :id")
    suspend fun get(id: Long): SourceEntity?

    @Query("SELECT * FROM sources WHERE worldId = :worldId AND uri = :uri")
    suspend fun byUri(worldId: Long, uri: String): SourceEntity?

    @Query("SELECT * FROM sources WHERE worldId = :worldId ORDER BY id ASC")
    fun observe(worldId: Long): Flow<List<SourceEntity>>

    @Query("SELECT * FROM sources WHERE worldId = :worldId ORDER BY id ASC")
    suspend fun list(worldId: Long): List<SourceEntity>

    @Query("SELECT * FROM sources WHERE worldId = :worldId AND status = 'PENDIENTE' ORDER BY id ASC")
    suspend fun pending(worldId: Long): List<SourceEntity>
}

@Dao
interface ResearchTaskDao {
    @Insert
    suspend fun insert(t: ResearchTaskEntity): Long

    @Update
    suspend fun update(t: ResearchTaskEntity)

    @Query("SELECT * FROM research_tasks WHERE id = :id")
    suspend fun get(id: Long): ResearchTaskEntity?

    @Query("SELECT * FROM research_tasks WHERE id = :id")
    fun observe(id: Long): Flow<ResearchTaskEntity?>

    @Query("SELECT * FROM research_tasks WHERE worldId = :worldId ORDER BY id DESC")
    fun observeFor(worldId: Long): Flow<List<ResearchTaskEntity>>

    @Query("SELECT * FROM research_tasks WHERE status IN ('PENDIENTE', 'EN_CURSO') ORDER BY id ASC")
    suspend fun unfinished(): List<ResearchTaskEntity>

    @Query("SELECT * FROM research_tasks WHERE worldId = :worldId AND status IN ('PENDIENTE', 'EN_CURSO') ORDER BY id DESC LIMIT 1")
    suspend fun activeFor(worldId: Long): ResearchTaskEntity?

    @Query("SELECT * FROM research_tasks WHERE worldId = :worldId ORDER BY id DESC LIMIT 1")
    suspend fun lastFor(worldId: Long): ResearchTaskEntity?
}

@Dao
interface WorldSessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(w: WorldSessionEntity)

    @Query("SELECT * FROM world_sessions WHERE sessionId = :sessionId")
    suspend fun get(sessionId: Long): WorldSessionEntity?

    @Query("SELECT * FROM world_sessions WHERE sessionId = :sessionId")
    fun observe(sessionId: Long): Flow<WorldSessionEntity?>

    @Query("DELETE FROM world_sessions WHERE sessionId = :sessionId")
    suspend fun delete(sessionId: Long)

    @Query("SELECT * FROM world_sessions WHERE worldUuid = :uuid")
    suspend fun byWorldUuid(uuid: String): List<WorldSessionEntity>
}

@Dao
interface PrepStepDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: PrepStepEntity)

    @Query("SELECT * FROM prep_steps WHERE sessionId = :sessionId ORDER BY step ASC")
    fun observe(sessionId: Long): Flow<List<PrepStepEntity>>

    @Query("SELECT * FROM prep_steps WHERE sessionId = :sessionId ORDER BY step ASC")
    suspend fun list(sessionId: Long): List<PrepStepEntity>

    @Query("DELETE FROM prep_steps WHERE sessionId = :sessionId")
    suspend fun clear(sessionId: Long)
}

@Dao
interface VisualAssetDao {
    @Insert
    suspend fun insert(a: VisualAssetEntity): Long

    @Update
    suspend fun update(a: VisualAssetEntity)

    @Query("DELETE FROM visual_assets WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM visual_assets WHERE id = :id")
    suspend fun get(id: Long): VisualAssetEntity?

    @Query("SELECT * FROM visual_assets ORDER BY kind ASC, id ASC")
    fun observeAll(): Flow<List<VisualAssetEntity>>

    @Query("SELECT * FROM visual_assets ORDER BY kind ASC, id ASC")
    suspend fun listAll(): List<VisualAssetEntity>
}

@Dao
interface SceneMetaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(m: SceneMetaEntity)

    @Query("SELECT * FROM scene_meta WHERE sessionId = :sessionId AND messageId = :messageId")
    suspend fun forMessage(sessionId: Long, messageId: Long): SceneMetaEntity?

    @Query("SELECT * FROM scene_meta WHERE sessionId = :sessionId AND messageId < :messageId ORDER BY messageId DESC LIMIT 1")
    suspend fun before(sessionId: Long, messageId: Long): SceneMetaEntity?

    @Query("SELECT * FROM scene_meta WHERE sessionId = :sessionId ORDER BY messageId DESC LIMIT :limit")
    suspend fun recent(sessionId: Long, limit: Int): List<SceneMetaEntity>

    @Query("SELECT * FROM scene_meta WHERE sessionId = :sessionId ORDER BY messageId ASC")
    fun observe(sessionId: Long): Flow<List<SceneMetaEntity>>
}
