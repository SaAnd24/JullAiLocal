package com.jullai.local.research

import com.jullai.local.data.ResearchTaskEntity
import com.jullai.local.data.SourceEntity
import com.jullai.local.data.WorldRepository
import com.jullai.local.world.DraftEntry
import com.jullai.local.world.EntryState
import com.jullai.local.world.ResearchDepth
import com.jullai.local.world.ResearchPhase
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceStatus
import com.jullai.local.world.TaskStatus
import com.jullai.local.world.WikiExtractor
import kotlinx.coroutines.CancellationException

/** Resultado de ejecutar una tarea. [retry] pide al planificador volver a intentarlo más tarde (reintentos limitados). */
class EngineOutcome(val status: String, val retry: Boolean, val message: String)

/**
 * Investigación de un mundo. Persiste CADA paso en research_tasks y sources: si Android mata el proceso, la tarea se reanuda
 * donde estaba (las fuentes ya procesadas no se vuelven a pedir). Solo cuenta como éxito si hay fuentes procesadas Y entradas válidas.
 * La extracción es determinista (texto de la fuente, recortado): el modelo local es un paso aparte, en primer plano.
 */
class ResearchEngine(
    private val repo: WorldRepository,
    private val providers: List<SourceProvider>,
    private val wiki: MediaWikiProvider?,
) {
    suspend fun run(taskId: Long): EngineOutcome {
        var task = repo.task(taskId) ?: return EngineOutcome(TaskStatus.FALLIDA, false, "La tarea ya no existe.")
        if (TaskStatus.isFinal(task.status)) return EngineOutcome(task.status, false, TaskStatus.label(task.status))
        val world = repo.world(task.worldId)
        if (world == null) { save(task.copy(status = TaskStatus.FALLIDA, phase = ResearchPhase.FIN, lastError = "El mundo ya no existe.", finishedAt = System.currentTimeMillis())); return EngineOutcome(TaskStatus.FALLIDA, false, "El mundo ya no existe.") }
        task = save(task.copy(status = TaskStatus.EN_CURSO, attempts = task.attempts + 1, note = ""))
        var retryable = false
        try {
            // ---- fase 1: descubrir páginas (solo wikis configuradas por el usuario; nada de buscadores) ----
            if (task.phase == ResearchPhase.PENDIENTE || task.phase == ResearchPhase.BUSCANDO) {
                task = save(task.copy(phase = ResearchPhase.BUSCANDO))
                val apis = wikiApis(world.preferredSources)
                val max = ResearchDepth.maxPages(world.researchDepth)
                if (wiki != null && apis.isNotEmpty() && world.allowOnline) {
                    val terms = (listOf(world.name) + split(world.priorityCharacters) + split(world.priorityPlaces)).distinct()
                    val known = repo.sourcesOf(world.id).map { it.uri }.toSet()
                    var added = 0
                    for (api in apis) {
                        if (added >= max) break
                        val titles = try { wiki.discover(api, terms, max - added) } catch (e: HttpFailure) { retryable = retryable || e.retryable; emptyList() }
                        for (t in titles) { val uri = MediaWikiProvider.uriOf(api, t); if (uri !in known && added < max) { repo.addSource(world.id, SourceKind.MEDIAWIKI, uri, t); added++ } }
                    }
                }
                task = save(task.copy(phase = ResearchPhase.DESCARGANDO))
            }

            // ---- fase 2: descargar y extraer, fuente por fuente ----
            val allSources = repo.sourcesOf(world.id)
            val todo = allSources.filter { it.status == SourceStatus.PENDIENTE || (it.status == SourceStatus.FALLIDA && retryableStatus(it) && it.attempts < task.maxAttempts) }
            task = save(task.copy(progressTotal = task.progressDone + todo.size, phase = ResearchPhase.DESCARGANDO))
            val prio = split(world.priorityCharacters)
            val places = split(world.priorityPlaces)
            for (src in todo) {
                if (cancelled(taskId)) return EngineOutcome(TaskStatus.CANCELADA, false, "Cancelada por el usuario.")
                val provider = providers.firstOrNull { it.canHandle(src) }
                if (provider == null) { repo.markSourceFailed(src.id, SourceStatus.NO_COMPATIBLE, "Ningún proveedor entiende esta fuente.", taskId); task = bump(taskId, failed = 1); continue }
                when (val r = provider.fetch(src)) {
                    is FetchResult.Ok -> {
                        repo.markSourceProcessed(src.id, r.title, r.text, r.license, r.provenance, taskId)
                        val state = if (src.kind == SourceKind.MEDIAWIKI) EntryState.ACTIVO else EntryState.PROPUESTO
                        val drafts = WikiExtractor.fromPlainPage(r.title, r.text, "${r.title} · ${src.uri}".take(300), src.id, prio, places).map { it.withState(state) }
                        val added = repo.addDrafts(world.id, drafts)
                        task = bump(taskId, ok = 1, entries = added.created)
                    }
                    is FetchResult.Failed -> { repo.markSourceFailed(src.id, SourceStatus.FALLIDA, r.message, taskId); retryable = retryable || r.retryable; task = bump(taskId, failed = 1, error = "${src.title.ifBlank { src.uri }}: ${r.message}") }
                    is FetchResult.Unsupported -> { repo.markSourceFailed(src.id, SourceStatus.NO_COMPATIBLE, r.message, taskId); task = bump(taskId, failed = 1) }
                }
            }

            // ---- fase 3: contradicciones (se muestran, nunca se resuelven solas) ----
            task = save(repo.task(taskId)!!.copy(phase = ResearchPhase.CONTRADICCIONES))
            repo.detectContradictions(world.id)

            // ---- final: éxito solo con fuentes y entradas válidas ----
            val fin = repo.task(taskId)!!
            val sources = repo.sourcesOf(world.id)
            val okSources = sources.count { it.status == SourceStatus.PROCESADA }
            val entries = repo.entryCount(world.id)
            val (status, msg) = when {
                sources.isEmpty() -> TaskStatus.SIN_RESULTADOS to "No había fuentes que consultar. Añade una wiki en «fuentes preferidas», una URL o un archivo."
                okSources == 0 -> TaskStatus.FALLIDA to "Ninguna fuente se pudo procesar. Revisa los errores por fuente."
                fin.entriesCreated == 0 && entries == 0 -> TaskStatus.SIN_RESULTADOS to "Se leyeron fuentes pero no se obtuvo ninguna entrada válida."
                else -> TaskStatus.COMPLETADA to "Terminada: $okSources fuentes procesadas, ${fin.entriesCreated} entradas nuevas."
            }
            // Con algún fallo temporal pendiente se reintenta (aunque otras fuentes ya se procesaran), hasta el límite de intentos.
            val willRetry = retryable && fin.attempts < fin.maxAttempts
            if (willRetry) {
                save(fin.copy(status = TaskStatus.PENDIENTE, phase = ResearchPhase.DESCARGANDO, note = "Falló algo temporal; se reintentará (intento ${fin.attempts} de ${fin.maxAttempts}).", lastError = msg))
                return EngineOutcome(TaskStatus.PENDIENTE, true, "Reintento programado.")
            }
            save(fin.copy(status = status, phase = ResearchPhase.FIN, lastError = if (status == TaskStatus.COMPLETADA) fin.lastError else msg, note = msg, finishedAt = System.currentTimeMillis()))
            return EngineOutcome(status, false, msg)
        } catch (e: CancellationException) {
            // El proceso o el trabajo se interrumpió: la tarea queda PENDIENTE y se reanudará sin repetir lo ya procesado.
            repo.task(taskId)?.let { t -> if (!TaskStatus.isFinal(t.status)) save(t.copy(status = TaskStatus.PENDIENTE, note = "Interrumpida; se reanudará donde se quedó.")) }
            throw e
        } catch (e: Exception) {
            val t = repo.task(taskId)
            if (t != null) save(t.copy(status = TaskStatus.FALLIDA, phase = ResearchPhase.FIN, lastError = e.message ?: "Error inesperado", finishedAt = System.currentTimeMillis()))
            return EngineOutcome(TaskStatus.FALLIDA, false, "Error inesperado: ${e.message}")
        }
    }

    private fun DraftEntry.withState(state: String) = copy(state = state)

    private suspend fun save(t: ResearchTaskEntity): ResearchTaskEntity { repo.saveTask(t); return repo.task(t.id) ?: t }

    private suspend fun cancelled(taskId: Long) = repo.task(taskId)?.status == TaskStatus.CANCELADA

    private suspend fun bump(taskId: Long, ok: Int = 0, failed: Int = 0, entries: Int = 0, error: String = ""): ResearchTaskEntity {
        val t = repo.task(taskId)!!
        return save(t.copy(progressDone = t.progressDone + ok + failed, sourcesOk = t.sourcesOk + ok, sourcesFailed = t.sourcesFailed + failed, entriesCreated = t.entriesCreated + entries, lastError = if (error.isNotBlank()) error.take(300) else t.lastError))
    }

    /** Un fallo es reintentable salvo los definitivos (sin acceso, no existe...): se distingue por el texto guardado. */
    private fun retryableStatus(s: SourceEntity) = s.error.contains("saturado") || s.error.contains("Error de red") || s.error.contains("tardó") || s.error.contains("conexión") || s.error.contains("lag")

    private fun split(s: String) = s.lines().flatMap { it.split(',', ';') }.map { it.trim() }.filter { it.isNotEmpty() }

    /** Direcciones de API de «fuentes preferidas»: líneas que empiezan por http(s):// y terminan en api.php (o llevan «wiki:»). */
    private fun wikiApis(preferred: String) = preferred.lines().map { it.trim().removePrefix("wiki:").trim() }.filter { (it.startsWith("https://") || it.startsWith("http://")) && it.contains("api.php") }.distinct().take(3)
}
