package com.jullai.local.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.jullai.local.ModelsViewModel
import com.jullai.local.SettingsViewModel
import com.jullai.local.chat.ChatViewModel
import com.jullai.local.imaging.ImagingViewModel
import com.jullai.local.roleplay.CharactersViewModel
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.StoryViewModel
import com.jullai.local.roleplay.WorldViewModel
import androidx.compose.runtime.collectAsState

private const val LIBRARY = "library"
private const val MODELS = "models"
private const val SETTINGS = "settings"
private const val CHAT_PREFIX = "chat:"
private const val CHARACTERS = "characters"
private const val EDIT_PREFIX = "charedit:"
private const val LORE_PREFIX = "lore:"
private const val RP_PREFIX = "rp:"
private const val RPH_PREFIX = "rph:"          // vista clásica del roleplay (historial, memoria, relaciones)
private const val WORLDS = "worlds"
private const val WORLD_NEW = "worldnew"
private const val WORLD_PREFIX = "world:"
private const val PREP_PREFIX = "prep:"
private const val STUDIO = "studio"
private const val GALLERY = "gallery"

/**
 * Navegación mínima: Biblioteca (inicio) → Chat / Roleplay (Personajes → Ficha → Lorebook) / Modelos / Ajustes.
 * La ruta se guarda para sobrevivir a giros de pantalla.
 */
@Composable
fun AppRoot(
    chatVm: ChatViewModel,
    modelsVm: ModelsViewModel,
    settingsVm: SettingsViewModel,
    charactersVm: CharactersViewModel,
    rpVm: RoleplayViewModel,
    storyVm: StoryViewModel,
    worldVm: WorldViewModel,
    imagingVm: ImagingViewModel,
    onPickModel: () -> Unit,
) {
    var route by rememberSaveable { mutableStateOf(LIBRARY) }
    /** «Atrás»: del lorebook vuelve a la ficha (conserva lo escrito); de la ficha vuelve a Personajes (descarta); el resto, a la Biblioteca. */
    fun goBack() {
        route = when {
            route.startsWith(PREP_PREFIX) -> RP_PREFIX + route.removePrefix(PREP_PREFIX)
            route.startsWith(RPH_PREFIX) -> RP_PREFIX + route.removePrefix(RPH_PREFIX)
            route == WORLD_NEW || route.startsWith(WORLD_PREFIX) -> WORLDS
            route == GALLERY -> STUDIO
            route.startsWith(LORE_PREFIX) -> EDIT_PREFIX + (charactersVm.draft.value?.id ?: 0L)
            route.startsWith(EDIT_PREFIX) -> { charactersVm.discardDraft(); CHARACTERS }
            else -> LIBRARY
        }
    }
    BackHandler(enabled = route != LIBRARY) { goBack() }
    val settings by settingsVm.settings.collectAsState()

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink.Tinta)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        when {
            route == STUDIO -> ImageStudioScreen(imagingVm, onBack = { route = LIBRARY }, onGallery = { route = GALLERY })
            route == GALLERY -> ImageGalleryScreen(imagingVm, onBack = { route = STUDIO }, onStudio = { route = STUDIO })
            route == MODELS -> ModelsScreen(modelsVm, onPickModel, onBack = { route = LIBRARY })
            route == SETTINGS -> SettingsScreen(settingsVm, onBack = { route = LIBRARY })
            route == CHARACTERS -> CharactersScreen(
                vm = charactersVm, settingsUserName = settings.rpLastUserName,
                onBack = { route = LIBRARY },
                onEdit = { route = EDIT_PREFIX + it },
                onOpenSession = { route = RP_PREFIX + it },
            )
            route.startsWith(EDIT_PREFIX) -> {
                val id = route.removePrefix(EDIT_PREFIX).toLongOrNull() ?: 0L
                key(id) { CharacterEditorScreen(charactersVm, id, onBack = { route = CHARACTERS }, onOpenLorebook = { route = LORE_PREFIX + it }) }
            }
            route.startsWith(LORE_PREFIX) -> {
                val id = route.removePrefix(LORE_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = CHARACTERS }
                else key(id) { LorebookScreen(charactersVm, id, onBack = { goBack() }) }
            }
            route == WORLDS -> WorldsScreen(worldVm, onBack = { route = LIBRARY }, onOpen = { route = WORLD_PREFIX + it }, onNew = { route = WORLD_NEW })
            route == WORLD_NEW -> WorldWizardScreen(worldVm, onBack = { route = WORLDS }, onCreated = { route = WORLD_PREFIX + it })
            route.startsWith(WORLD_PREFIX) -> {
                val id = route.removePrefix(WORLD_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = WORLDS } else key(id) { WorldDetailScreen(worldVm, id, onBack = { route = WORLDS }) }
            }
            route.startsWith(PREP_PREFIX) -> {
                val id = route.removePrefix(PREP_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = LIBRARY }
                else key(id) { PrepScreen(worldVm, rpVm, imagingVm, id, onBack = { route = RP_PREFIX + id }, onPlay = { route = RP_PREFIX + id }, onOpenWorld = { route = WORLD_PREFIX + it }, onStudio = { route = STUDIO }) }
            }
            route.startsWith(RPH_PREFIX) -> {
                val id = route.removePrefix(RPH_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = LIBRARY }
                else key(id) { RoleplayScreen(rpVm, storyVm, id, onBack = { route = RP_PREFIX + id }) }
            }
            route.startsWith(RP_PREFIX) -> {
                // v0.5: las partidas de roleplay usan la novela visual. El historial original sigue accesible en «vista clásica».
                val id = route.removePrefix(RP_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = LIBRARY }
                else key(id) { VisualNovelScreen(rpVm, storyVm, worldVm, imagingVm, id, onBack = { route = LIBRARY }, onClassic = { route = RPH_PREFIX + id }, onPrep = { route = PREP_PREFIX + id }, onStudio = { route = STUDIO }) }
            }
            route.startsWith(CHAT_PREFIX) -> {
                val id = route.removePrefix(CHAT_PREFIX).toLongOrNull()
                if (id == null) {
                    LaunchedEffect(Unit) { route = LIBRARY }
                } else {
                    key(id) { ChatScreen(chatVm, id, onBack = { route = LIBRARY }) }
                }
            }
            else -> LibraryScreen(
                vm = chatVm,
                rpVm = rpVm,
                storyVm = storyVm,
                onOpenChat = { route = CHAT_PREFIX + it },
                onOpenModels = { route = MODELS },
                onOpenSettings = { route = SETTINGS },
                onOpenCharacters = { route = CHARACTERS },
                onOpenWorlds = { route = WORLDS },
                onOpenImages = { route = STUDIO },
                onOpenSession = { route = RP_PREFIX + it },
            )
        }
    }
}
