plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

// Módulo SEPARADO que solo contiene el motor nativo de imágenes (stable-diffusion.cpp). Aislarlo en su propio módulo/CMake evita
// que sus destinos ggml choquen con los de llama.cpp (jullai_engine) en el mismo árbol de compilación.
android {
    namespace = "com.jullai.local.imaging.nativebridge"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        minSdk = 26
        ndk { abiFilters += "arm64-v8a" }
        externalNativeBuild {
            cmake { arguments += listOf("-DCMAKE_BUILD_TYPE=Release", "-DANDROID_STL=c++_static") }
        }
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
