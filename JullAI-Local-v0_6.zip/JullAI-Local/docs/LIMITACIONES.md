# Limitaciones conocidas (v0.4)

**Verificación**
- La compilación de Android (Kotlin/Compose/Gradle), el APK y las pruebas Room/Robolectric **no se pudieron ejecutar** en el entorno de desarrollo (sin Android SDK ni acceso a Gradle/Google). La primera compilación real es la de GitHub Actions.
- Las pantallas nuevas no se han visto en pantalla. Nada se ha probado en un dispositivo.
- La búsqueda FTS4 se probó en el SQLite de Python; el SQLite de Android puede comportarse distinto. Si FTS4 no estuviera disponible, la app lo detecta y usa un método más lento (comparación de palabras + `LIKE`), con el mismo resultado.

**Memoria**
- **FTS4, no FTS5**: Room solo admite FTS3/FTS4 y FTS5 no está garantizado desde Android 8 (nuestro mínimo). No se promete FTS5.
- El análisis con el modelo es una inferencia pesada y la calidad depende del modelo: los modelos pequeños pueden devolver formato roto, resúmenes pobres o inventar. Por eso todo es propuesta editable y el resumen se puede escribir a mano.
- El recuperador usa palabras (con tildes y plurales normalizados), no significado: una pregunta con otras palabras puede no recuperar un recuerdo. Los recuerdos fijados siempre entran. Hay una interfaz `MemoryRetriever` para sustituirlo en el futuro (p. ej. embeddings).
- Con más de 400 recuerdos se preselecciona con búsqueda de texto antes de puntuar.
- El análisis procesa un tramo por pasada; con historias muy largas hay que pulsar el botón varias veces.
- Un modelo no garantiza respetar secretos ni relaciones: la app solo entrega los datos con etiquetas y dentro del presupuesto.

**Relaciones**
- Solo se proponen cambios entre personas que ya tienen una relación creada en la partida (la primera, personaje → tú, se crea sola).

**Capítulos y volúmenes**
- El texto novelado lo escribe el modelo por partes; la unión entre partes puede notarse. Es una copia aparte, siempre editable.
- Solo se puede reabrir el último capítulo, y solo se deshace el cierre del último volumen mientras el siguiente esté vacío.

**Exportar / importar**
- Un `.jullai` no incluye el modelo ni los retratos de otros personajes. La importación crea siempre una partida nueva (no fusiona con una existente).
- El perfil global del jugador se copia a cada partida al empezarla; cambiarlo después no actualiza partidas ya creadas.



## Limitaciones de la 0.5

**Verificación**
- En el entorno donde se escribió la 0.5 NO había compilador de Kotlin ni Gradle: el código nuevo no se ha compilado ni ejecutado fuera de la revisión estática. Puede haber errores de compilación que Actions revelará. Las 79 pruebas nuevas están escritas y sin ejecutar.
- Lo único ejecutado: el verificador de esquema (27 tablas, 158 consultas, FTS4 en SQLite de Python). Es un verificador propio, no Room.
- Investigación online, WorkManager y novela visual **no se han probado** en un teléfono ni contra una wiki real.

**Investigación online**
- Requiere conexión; sin ella el botón sigue disponible pero la tarea espera (WorkManager) y la pantalla lo indica. Android puede aplazarla (ahorro de batería, Doze) y no es un servicio en primer plano: con tareas largas, mantener la app abierta ayuda.
- **PDF no compatible.** No hay una dependencia verificable para leerlos; exporta el texto a TXT/Markdown. Tampoco se leen páginas que se rellenan con JavaScript.
- Las wikis se indican por la dirección de su `api.php` (p. ej. `https://es.wikipedia.org/w/api.php`) en «fuentes preferidas»; la app no adivina la wiki de un universo. Fandom y otras no siempre ofrecen `extracts`: se usa `action=parse` como respaldo. No se prueba contra cada wiki.
- La comprobación de red local se hace al conectar (IP resuelta) y en la dirección; no cubre un cambio de DNS entre la comprobación y la conexión (TOCTOU).
- `robots.txt` se lee con las reglas estándar (Allow/Disallow, `*`, `$`, la más larga gana); no se interpretan `Crawl-delay` ni `Sitemap`. El ritmo fijo es ≤ 1 petición por segundo y servidor.
- La extracción **determinista** copia un extracto corto de la fuente (≤ 500 caracteres de resumen); no «entiende» el texto: el tipo de entrada se deduce de títulos de sección y de tus listas prioritarias. Revisa lo importado desde URL (queda como propuesta).
- La extracción con el **modelo local** depende del tamaño del modelo: con modelos pequeños puede no seguir el formato (se descartan las líneas inválidas y se te dice cuántas). Verifica la cita contra la fuente, no que el resumen sea correcto: un resumen puede ser impreciso aunque la cita exista.
- La detección de contradicciones necesita una **clave del hecho** (p. ej. «Aria|edad») en ambas entradas; sin ella, dos entradas de fuentes distintas se conservan pero no se marcan como contradicción.
- Los mundos importados nacen con la investigación online desactivada y sus reglas se envían al modelo marcadas como información.

**Mundos y `.worldpack`**
- No se redistribuyen textos de las fuentes: las fuentes de archivo/URL exportan solo referencias (el texto extraído no viaja). Al importar, esas fuentes quedan sin texto.
- Hay un máximo de 5000 entradas y 300 fuentes por mundo; 16 archivos, 8 MB por archivo y 24 MB en total en un `.worldpack`.
- La instantánea de mundo dentro de un `.jullai` hace que un `.jullai` con mundo **no lo abra la 0.4** (rechaza el elemento `data/mundo.json`). Un `.jullai` sin mundo es idéntico al de la 0.4.
- Un solo mundo por partida. La continuidad por época es una instrucción al modelo y una etiqueta opcional de entrada; no hay línea temporal automática ni «hitos» ejecutables.

**Novela visual**
- Los metadatos visuales (quién habla, emoción, pose, localización) se deducen con reglas simples del texto, sin el modelo: aciertan en diálogos claros y fallan en texto ambiguo (entonces se usa narrador / mismo lugar / retrato por defecto). Solo conoce al personaje principal de la partida y los lugares de la enciclopedia.
- El retrato por emoción y el fondo por lugar solo existen si los importas y los nombras exactamente igual que el personaje o el lugar. No hay poses distintas ni animaciones.
- La disposición horizontal es adaptable pero no se ha probado en pantallas reales.

**Fuera de alcance de la 0.5**: generación de imágenes (0.6), PDF, grupos de personajes, servicio en primer plano para investigaciones, varios idiomas de interfaz.

## Limitaciones de la 0.6
- **Sin verificar en dispositivo.** No se compiló el APK ni `libjullai_sd.so`; no se generó ninguna imagen; no hay tiempos, consumo de RAM ni temperaturas medidos. Las cifras de memoria del coordinador son **heurísticas**.
- **API de stable-diffusion.cpp cambiante.** Si el commit fijado no coincide con lo que `sd_core.cpp` espera, la compilación fallará con un diagnóstico (`check_sd_api.py`, `check_sd_shim.sh`) y habrá que ajustar ese archivo. Cada función opcional se activa solo si compila; si no, desaparece de la interfaz.
- **Solo CPU.** La Mali-G57 no tiene aceleración soportada por este motor. En un Helio G100 (2 núcleos grandes + 6 pequeños) la generación puede ser lenta; el modo de bajo consumo y LCM existen para eso, pero **no hay medición**.
- **Memoria de 8 GB compartida con Android.** El modelo de texto se libera antes de generar y se recarga al enviar (tarda). Un checkpoint F32 (~4 GB) es arriesgado: usa F16 o cuantizado. Con poca memoria la imagen se aplaza o cancela, nunca bloquea la conversación.
- **Formatos:** solo SD 1.x en un archivo con VAE. Sin conversión, sin SDXL/SD 2.x/inpainting/diffusers/.ckpt.
- **LoRA LCM:** la app no puede comprobar que encaje con tu checkpoint hasta aplicarla; la calidad se juzga a ojo. Solo se aplica con preajustes LCM.
- **Identidad visual:** no se garantiza el mismo rostro, vestuario ni proporciones. Image-to-image desde la referencia ayuda (si el motor lo expone) pero no está probado. Los personajes conocidos se describen por rasgos; el nombre no basta.
- **Prompts:** SD 1.5 entiende mejor el inglés y ~77 tokens; los prompts de escena se resumen automáticamente del texto narrativo en español y conviene editarlos.
- **Cancelar:** depende de `sd_cancel_generation`; si el commit fijado no la exponía, la interfaz lo dice y una acción de texto espera a que la imagen termine (o avisa tras 45 s sin cargar el texto encima).
- **Cola:** una tarea a la vez; una interrumpida se reintenta desde cero. Sin servicio en primer plano ni trabajo en segundo plano: solo corre con la app abierta.
- **Preparación visual:** el resolutor de escenas solo conoce al personaje de la partida; los demás personajes de un mundo no tienen retrato asociable automáticamente.
- **Metadatos de turno opcionales** (`[[escena: …]]`): se ocultan y validan, pero no se fusionan con la escena ni se pide al modelo que los escriba.
- **Exportación:** `.jullai` y `.worldpack` no incluyen imágenes (igual que en la 0.5); las ilustraciones y su historial viven en la base de datos de la app.
- **Control térmico:** solo desde Android 10 (API 29); antes solo se vigila la memoria.
