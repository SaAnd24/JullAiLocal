#!/usr/bin/env python3
"""Comprueba el esquema de Room SIN Android: lee las entidades de Kotlin (v1..v4) y las compara con lo que crean las migraciones.

Para cada versión nueva construye la base de datos con el SQL de Migrations.kt en SQLite real y compara, tabla por tabla,
columnas (nombre, tipo, NOT NULL, clave primaria), claves foráneas e índices con lo que declaran las entidades.
También valida cada @Query de los DAO contra ese esquema (Room lo hace al compilar; aquí se adelanta).
Uso: python3 -I tools/verify/check_schema.py   (desde la raíz del proyecto)
"""
import re, sqlite3, sys, pathlib

root = pathlib.Path(__file__).resolve().parents[2]
data = root / "app/src/main/java/com/jullai/local/data"
errors = []

def read(name): return (data / name).read_text(encoding="utf-8")

# ---------- 1) Entidades de Kotlin ----------
def split_top(s, sep=','):
    out, depth, cur, q = [], 0, '', False
    for ch in s:
        if ch == '"': q = not q
        if not q:
            if ch in '([<': depth += 1
            if ch in ')]>': depth -= 1
            if ch == sep and depth == 0:
                out.append(cur); cur = ''; continue
        cur += ch
    if cur.strip(): out.append(cur)
    return out

def strip_comments(t):
    t = re.sub(r'/\*.*?\*/', '', t, flags=re.S)
    return re.sub(r'//[^\n]*', '', t)

entities = {}
for f in ["Entities.kt", "RoleplayEntities.kt", "StoryEntities.kt", "WorldEntities.kt", "ImageEntities.kt"]:
    src = strip_comments(read(f))
    for m in re.finditer(r'@Entity\((.*?)\)\s*data class (\w+)\((.*?)\n\)', src, flags=re.S):
        ann, cls, body = m.groups()
        table = re.search(r'tableName\s*=\s*"(\w+)"', ann).group(1)
        fks = []
        for fk in re.finditer(r'ForeignKey\(\s*entity = (\w+)::class,\s*parentColumns = \["(\w+)"\],\s*childColumns = \["(\w+)"\],\s*onDelete = ForeignKey\.(\w+),?\s*\)', ann):
            fks.append(fk.groups())
        idx = []
        for ix in re.finditer(r'Index\(value = \[([^\]]*)\](?:, unique = (true))?\)', ann):
            cols = re.findall(r'"(\w+)"', ix.group(1)); idx.append((cols, bool(ix.group(2))))
        cols = []
        pk = None
        for part in split_top(body):
            part = part.strip()
            if not part: continue
            auto = '@PrimaryKey(autoGenerate = true)' in part
            isPk = '@PrimaryKey' in part
            part = re.sub(r'@PrimaryKey(\([^)]*\))?', '', part).strip()
            mm = re.match(r'(?:val|var)\s+(\w+)\s*:\s*([\w?]+)', part)
            if not mm: continue
            name, typ = mm.groups()
            nullable = typ.endswith('?')
            t = typ.rstrip('?')
            affinity = 'INTEGER' if t in ('Long', 'Int', 'Boolean') else 'REAL' if t in ('Float', 'Double') else 'TEXT'
            cols.append((name, affinity, not nullable))
            if isPk: pk = name
        entities[table] = dict(cls=cls, cols=cols, pk=pk, fks=fks, idx=idx)

cls2table = {e['cls']: t for t, e in entities.items()}

# ---------- 2) Base de datos según las migraciones ----------
mig = read("Migrations.kt")
def kotlin_strings(block):
    # une los literales "..." + "..." de cada execSQL / elemento de lista
    stmts = []
    for m in re.finditer(r'"((?:[^"\\]|\\.)*)"(?:\s*\+\s*"((?:[^"\\]|\\.)*)")*', block):
        pass
    return stmts

def concat_literals(text):
    res = []
    for m in re.finditer(r'((?:"(?:[^"\\]|\\.)*"\s*\+?\s*)+)', text):
        lits = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1))
        s = ''.join(lits).replace('\\"', '"').replace('\\\\', '\\')
        if s.upper().startswith(('CREATE', 'INSERT')): res.append(s)
    return res

m12 = re.search(r'MIGRATION_1_2 = .*?(?=\n    /\*\*|\n    val STORY|\Z)', mig, flags=re.S).group(0)
sql12 = concat_literals(m12)
sql_story = concat_literals(mig[mig.index('val STORY_TABLES_SQL'):])

# Tablas de la v1 (la 0.2): se declaran aquí porque la migración 1→2 parte de ellas
v1 = [
 "CREATE TABLE `models` (`fileName` TEXT NOT NULL, `displayName` TEXT NOT NULL, `sizeBytes` INTEGER NOT NULL, `sha256` TEXT NOT NULL, `importedAt` INTEGER NOT NULL, `isDefault` INTEGER NOT NULL, PRIMARY KEY(`fileName`))",
 "CREATE UNIQUE INDEX `index_models_sha256` ON `models` (`sha256`)",
 "CREATE TABLE `conversations` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `modelFileName` TEXT, `systemPrompt` TEXT NOT NULL, `temperature` REAL NOT NULL, `topP` REAL NOT NULL, `maxTokens` INTEGER NOT NULL, `contextLength` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)",
 "CREATE INDEX `index_conversations_updatedAt` ON `conversations` (`updatedAt`)",
 "CREATE TABLE `messages` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `conversationId` INTEGER NOT NULL, `role` TEXT NOT NULL, `content` TEXT NOT NULL, `orderIndex` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `state` TEXT NOT NULL, FOREIGN KEY(`conversationId`) REFERENCES `conversations`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
 "CREATE UNIQUE INDEX `index_messages_conversationId_orderIndex` ON `messages` (`conversationId`, `orderIndex`)",
 "CREATE TABLE `settings` (`settingKey` TEXT NOT NULL, `settingValue` TEXT NOT NULL, PRIMARY KEY(`settingKey`))",
]

con = sqlite3.connect(":memory:")
con.execute("PRAGMA foreign_keys=ON")
for s in v1 + sql12 + sql_story:
    try: con.execute(s)
    except Exception as e: errors.append(f"SQL de migración inválido: {e}\n  {s[:120]}")

# ---------- 3) Comparación ----------
db_tables = {r[0] for r in con.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'")}
if db_tables != set(entities): errors.append(f"Tablas distintas. Solo en la base: {db_tables - set(entities)}; solo en entidades: {set(entities) - db_tables}")
for t, e in entities.items():
    if t not in db_tables: continue
    info = con.execute(f"pragma table_info('{t}')").fetchall()   # cid,name,type,notnull,dflt,pk
    got = [(r[1], r[2].upper(), bool(r[3]) or bool(r[5]) and r[2].upper() == 'INTEGER' and False) for r in info]
    want = [(n, a, nn) for n, a, nn in e['cols']]
    gcols = [(r[1], r[2].upper(), bool(r[3])) for r in info]
    if [c[:2] for c in gcols] != [w[:2] for w in want]:
        errors.append(f"{t}: columnas distintas\n  base:     {gcols}\n  entidad:  {want}")
    for (gn, gt, gnn), (wn, wt, wnn) in zip(gcols, want):
        if gn == wn and gn != e['pk'] and gnn != wnn: errors.append(f"{t}.{gn}: NOT NULL distinto (base {gnn}, entidad {wnn})")
    pks = [r[1] for r in sorted(info, key=lambda r: r[5]) if r[5] > 0]
    if pks != [e['pk']]: errors.append(f"{t}: clave primaria distinta {pks} vs {e['pk']}")
    fk_db = sorted((r[2], r[3], r[4], r[6]) for r in con.execute(f"pragma foreign_key_list('{t}')"))
    fk_en = sorted((cls2table[c], ch, pc, od.replace('_', ' ')) for c, pc, ch, od in e['fks'])
    fk_db = [(a, b, c, d) for a, b, c, d in fk_db]
    if fk_db != fk_en: errors.append(f"{t}: claves foráneas distintas\n  base:    {fk_db}\n  entidad: {fk_en}")
    ix_db = []
    for r in con.execute(f"pragma index_list('{t}')"):
        if r[3] == 'pk' or r[1].startswith('sqlite_autoindex'): continue
        cols = [c[2] for c in con.execute(f"pragma index_info('{r[1]}')")]
        want_name = f"index_{t}_" + "_".join(cols)
        if r[1] != want_name: errors.append(f"{t}: nombre de índice {r[1]} (Room espera {want_name})")
        ix_db.append((cols, bool(r[2])))
    if sorted(ix_db) != sorted(e['idx']): errors.append(f"{t}: índices distintos\n  base:    {sorted(ix_db)}\n  entidad: {sorted(e['idx'])}")

# ---------- 4) @Query de los DAO ----------
fts_ok = True
try:
    con.execute("CREATE VIRTUAL TABLE memories_fts USING fts4(content=\"memories\", content, relatedNames, tokenize=unicode61)")
except Exception as ex:
    fts_ok = False; errors.append(f"FTS4 no disponible en este SQLite: {ex}")
try:
    con.execute("CREATE VIRTUAL TABLE world_entries_fts USING fts4(content=\"world_entries\", name, aliases, summary, details, relatedNames, tokenize=unicode61)")
except Exception as ex:
    fts_ok = False; errors.append(f"FTS4 (mundos) no disponible: {ex}")
n_q = 0
for f in ["Daos.kt", "RoleplayDaos.kt", "StoryDaos.kt", "WorldDaos.kt", "ImageDaos.kt"]:
    src = read(f)
    for m in re.finditer(r'@Query\(\s*((?:"(?:[^"\\]|\\.)*"\s*\+?\s*)+)\)', src):
        q = ''.join(re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1))).replace('\\\\', '\\')
        q2 = re.sub(r':\w+', '1', q)
        q2 = re.sub(r'IN \(1\)', 'IN (1)', q2)
        n_q += 1
        try: con.execute("EXPLAIN " + q2)
        except Exception as ex: errors.append(f"{f}: consulta inválida: {ex}\n  {q}")

print(f"Entidades: {len(entities)} · tablas en la base: {len(db_tables)} · consultas revisadas: {n_q} · FTS4: {'sí' if fts_ok else 'NO'}")
if errors:
    print("\nERRORES:"); [print(" -", e) for e in errors]; sys.exit(1)
print("OK: el esquema de las migraciones coincide con las entidades y todas las consultas son válidas.")
