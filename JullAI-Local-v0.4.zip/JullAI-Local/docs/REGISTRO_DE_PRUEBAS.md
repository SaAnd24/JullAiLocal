# Registro de pruebas — v0.4

Entorno de desarrollo: Linux sin Android SDK. Kotlin 2.0.21 (el compilador que trae Gradle) + JUnit 4.13.2. Fecha de esta ejecución: 24-10-2026.

## 1) Pruebas de Kotlin puro — EJECUTADAS, 117 pasan

| Clase | Pruebas | Qué cubre |
|---|---|---|
| `story.TextNormTest` | 5 | normalización (tildes, plurales), palabras clave, similitud |
| `story.RelationshipRulesTest` | 9 | límites por medida y total, rango 1-100, motivo obligatorio, corrección manual |
| `story.MemoryRetrievalTest` | 14 | puntuación, presupuesto, fijados sin desbordar, cronología, relaciones, orden de secciones, el resultado cabe en el contexto de roleplay y el constructor descarta elementos enteros (nunca corta uno) |
| `story.MaintenanceTest` | 10 | lector del formato del modelo (líneas rotas, límites), duplicados, política automática, prompt por tramos |
| `story.NovelTest` | 6 | partes por presupuesto, continuidad entre partes, borrador de continuidad con relaciones escritas por la app |
| `story.BibleCodecTest` | 18 | ida y vuelta, versión, ZIP-slip, rutas absolutas, duplicados, bomba de compresión, suma SHA-256, recuentos, referencias, rangos |
| `data.AppSettingsTest` | 6 | ajustes (incluye memoria y perfil) |
| `chat.ContextBuilderTest` | 8 | contexto del chat (0.2) |
| `roleplay.CardParserTest` | 23 | tarjetas (0.3) |
| `roleplay.RoleplayContextTest` | 18 | contexto de roleplay (0.3), presión de contexto |

Comando: compilar con el compilador de Kotlin de Gradle y lanzar `org.junit.runner.JUnitCore` → `OK (117 tests)`.

## 2) Verificador de esquema (`tools/verify/check_schema.py`) — EJECUTADO, pasa

Construye una base SQLite real con las sentencias de `Migrations.kt` y comprueba: 19 entidades = 19 tablas (columnas, tipos, NOT NULL, claves primarias, índices, claves foráneas),
y que las 115 consultas `@Query` son válidas. FTS4 disponible: sí. **No es Room**; detecta los errores más probables de la migración escrita a mano.
También se ejecuta en GitHub Actions (`schema-check.log`).

## 3) Comprobación de tipos con piezas simuladas — EJECUTADA, sin errores propios

Capa de datos, repositorios, `StoryJobs`, ViewModels, `AppContainer` y las pruebas Room nuevas compilan contra piezas simuladas de Android/Room. No son las librerías reales.

## 4) Escritas y NO ejecutadas (requieren Android/Room/Robolectric)

| Clase | Pruebas | Qué cubre |
|---|---|---|
| `data.StoryDatabaseTest` | 20 | recuerdos (CRUD, fijados, propuestas), persistencia al reabrir, recuperación en una escena posterior, cambio de modelo, relaciones por partida y validadas, resúmenes con versiones, ciclo de capítulos/volúmenes, exportar/importar |
| `data.MigrationV3Test` | 3 | migración 2→3 desde una base realista de la 0.3 escrita a mano; migración 1→2→3; FTS |
| `data.MigrationTest` | 1 | migración 1→2 (ahora con la 2→3 en la cadena) |
| `data.DatabaseTest`, `data.RoleplayDatabaseTest` | 15 + 14 | anteriores (0.2/0.3) |

## 5) Pendiente de dispositivo

Todo lo de `docs/PRUEBAS_MANUALES.md`.
