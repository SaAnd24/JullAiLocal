# Formato `.jullai` (versión 1)

Un `.jullai` es un archivo ZIP que guarda **una partida completa** para llevarla a otro teléfono o guardarla como copia.
**No incluye el modelo GGUF.** Formato interno: `jullai-biblia`, versión `1`.

## Contenido

| Archivo | Para qué sirve | ¿Se lee al importar? |
|---|---|---|
| `manifest.json` | formato, versión, versión de la app, fecha, recuentos y la lista de recursos con su SHA-256 | Sí |
| `biblia.md` | la biblia de la partida **para leer** (personaje, escenario, resumen, recuerdos, relaciones, cronología, capítulos). No incluye notas privadas del creador | **No** (solo lectura) |
| `data/personaje.json` | ficha del personaje y su lorebook | Sí |
| `data/partida.json` | escenario, nombres, reglas, resumen vigente, parámetros (sin modelo) | Sí |
| `data/mensajes.json` | el registro original de mensajes, con sus alternativas | Sí |
| `data/conocimiento.json` | «Saber»: hechos, secretos… | Sí |
| `data/memoria.json` | recuerdos (con confianza, fijado y estado), versiones del resumen, cronología | Sí |
| `data/relaciones.json` | relaciones, su historial y las propuestas pendientes | Sí |
| `data/estructura.json` | volúmenes y capítulos (incluido el texto novelado) | Sí |
| `assets/<id>.png/.jpg/.webp` | retrato ya reducido | Sí (con comprobación de SHA-256) |

Los identificadores del archivo son solo para enlazar entre sí los elementos del propio archivo; al importar se crean identificadores nuevos.

## Validación al importar (antes de tocar tus datos)

1. **Nombres**: lista cerrada. Se rechazan rutas absolutas, `..`, barras invertidas, unidades (`C:`), nombres repetidos (también con otras mayúsculas) y cualquier archivo inesperado.
2. **Tamaños contados al leer**: límite de entradas, de cada archivo y del total (una bomba de compresión se corta, no se confía en el tamaño que declara el ZIP).
3. **Versión y formato**: formato y versión conocidos (una versión mayor se rechaza con un mensaje claro).
4. **Contenido**: tipos, rangos (p. ej. relaciones 1-100), listas de valores (estados, orígenes), identificadores únicos, referencias que existan y recuentos iguales a los del manifiesto.
5. **Recursos**: la suma SHA-256 de cada imagen debe coincidir con el manifiesto.

Si algo falla, **no se escribe nada** y la app explica el motivo. Si todo es correcto se muestra una **vista previa** y, al confirmar, se importa dentro de **una sola transacción**
como partida **nueva** (con su propio personaje; el título añade «(importada)» si ya hay otra igual). Nunca se sobrescribe ni se borra nada por coincidir un nombre. La partida importada
no trae modelo: elige uno en Motor.

## Compatibilidad futura

Esta versión rechaza archivos de una versión del formato mayor que la que conoce, con un mensaje claro. Un `.jullai` antiguo al que le falten archivos opcionales se sigue pudiendo importar.
