# Guía de prueba manual — v0.4 (paso a paso)

Antes: compila con GitHub Actions (ver README) e instala el APK **encima** de la 0.3. Necesitas un modelo `.gguf` ya importado.
Si algo falla, anota el paso y copia el mensaje exacto (y **Modelos → Diagnóstico** si es del motor).

## A. Que lo anterior sigue vivo
1. Abre la app. Deben estar tus conversaciones del chat, tus modelos, tus personajes y tus partidas. Si falta algo, **para aquí** y avísame.
2. Abre una partida antigua (de la 0.3): debe cargar sus mensajes. Pulsa **Ficha ▸**: ahora hay pestañas **Ficha · Escena · Memoria · Relaciones · Capítulos · Saber · Motor** (la fila se desliza hacia los lados).
3. Pestaña **Escena**: si ya tenías un resumen escrito, debe seguir ahí.

## B. Recuerdos
4. **Memoria** → «Añadir un recuerdo»: escribe «Aria guarda el mapa en la torre norte.», importancia 4, personajes «Aria», marca **Fijar** → **Guardar recuerdo**. Debe salir con 📌 y «Confirmado por ti».
5. Prueba **Editar**, **Desfijar** y **Borrar** en otro recuerdo de ejemplo.
6. Escribe en el buscador «torre» → **Buscar**. Debe encontrarlo (también con «TORRE» o sin tildes).

## C. La memoria llega al modelo
7. Juega unos mensajes y, mucho después (o cambiando de escena), pregunta por el mapa. En **Memoria → Recuperado en la última respuesta** debe verse el recuerdo, el motivo y los que no cupieron.
8. En **Motor → Último contexto enviado** aparece la memoria como sección con sus tokens. Con pocos tokens de contexto (p. ej. 1024) comprueba que la app **no falla**: los fijados no desbordan el contexto.
9. Ajustes → apaga **Usar la memoria al generar respuestas**: «Recuperado…» debe decir que está desactivada. Vuelve a encenderla.

## D. Análisis con el modelo (propuestas)
10. Juega ≥ 6 mensajes. **Memoria → Analizar la historia con el modelo**. Verás «Trabajando con el modelo…» con **Detener**. Al acabar: recuerdos/sucesos/cambios **propuestos** y un **borrador de resumen**.
11. En «Propuestas por revisar»: **Aceptar** uno (pasa a «Confirmado por ti»), **Editar** otro, **Descartar** otro. Un «Inferido por el modelo» **no** debe aparecer entre los recuerdos activos hasta que lo aceptes.
12. Borrador de resumen: edítalo y **Guardar como resumen**. En «Versiones del resumen» debe haber una versión nueva; **Restaurar** una antigua crea otra versión.
13. Pulsa Analizar y **a la vez** escribe un mensaje al personaje: el análisis debe detenerse («Detenido. No se guardó nada…») y la respuesta continuar con normalidad.
14. Si el modelo no sigue el formato, debe aparecer su texto en bruto, marcado en rojo, para corregirlo a mano.
15. Ajustes → **Memoria narrativa**: prueba «Cada cierto número de turnos» (3 turnos) y comprueba que el análisis se lanza solo tras tus turnos, sin guardar nada sin tu aceptación. Vuelve a «Solo cuando yo lo pida».

## E. Relaciones
16. **Relaciones**: debe existir «personaje → tú» con valores iniciales. **Corregir**: cambia confianza a 80 con un motivo → debe guardarse y aparecer en el historial.
17. Tras un análisis, pueden aparecer «Cambios propuestos» (pequeños, con motivo). **Aceptar** aplica el cambio; **Rechazar** lo descarta.
18. **Añadir una relación** entre dos nombres distintos; intenta dos nombres iguales (debe rechazarlo).
19. Abre **otra** partida: sus relaciones son independientes.

## F. Perfil global del jugador
20. Ajustes → **Perfil global del jugador**: escribe nombre y descripción → **Guardar perfil**.
21. Personajes → **Jugar**: aparece «Tu perfil global» con **Usarlo / Adaptarlo / Independiente**. «Usarlo» rellena y bloquea los campos; «Adaptarlo» los rellena editables. Cambia el perfil después: la partida creada **no** cambia.

## G. Capítulos y volúmenes
22. **Capítulos**: hay Volumen 1 con Capítulo 1 abierto. **Cerrar y abrir siguiente** → Capítulo 1 queda cerrado y aparece el 2.
23. En el capítulo cerrado: **Título**, **Resumen** (a mano) y **Resumir con modelo**. Luego **Novelar con modelo**: avisa «parte i de n»; después **Editar novela**. Comprueba que los mensajes originales del chat **no cambiaron**.
24. Prueba **Reabrir para seguir escribiendo** en el último capítulo cerrado.
25. **Cerrar volumen…** → «Con el modelo» o «Borrador manual». Revisa el resumen de continuidad (con bloque de relaciones), edítalo y **Cerrar el volumen**. Debe aparecer el Volumen 2 abierto; los recuerdos, relaciones y mensajes siguen ahí.
26. En el volumen archivado: **Deshacer el cierre** solo funciona mientras el Volumen 2 no tenga mensajes.

## H. Exportar e importar `.jullai`
27. **Capítulos → Exportar .jullai**: elige dónde guardarlo. Debe decir «Exportada la partida completa (sin el modelo GGUF)». Prueba **Cancelar** durante la exportación (no debe quedar un archivo a medias).
28. Abre el archivo con un gestor de archivos como ZIP (renombra una copia a `.zip`): verás `manifest.json`, `biblia.md`, `data/…` y el retrato. `biblia.md` es legible y **no** incluye notas privadas.
29. Biblioteca → Roleplay → **Importar partida (.jullai)** → elige el archivo. Sale una **vista previa** con recuentos. **Importar**: se crea una partida **nueva** (título con «(importada)» si ya había una igual) y se abre. La original no cambia.
30. Importa un archivo cualquiera que **no** sea `.jullai` (una foto, un PDF): debe decir el motivo y **no cambiar nada**.
31. Importa el mismo `.jullai` dos veces: salen dos partidas; ninguna sobrescribe a otra.
32. Comprueba que en la partida importada no hay modelo asignado (elige uno en **Motor**) y que recuerdos, relaciones, resumen y capítulos están.

## I. Robustez
33. Cierra la app a la fuerza durante una respuesta y vuelve: el texto parcial queda marcado como interrumpido; los recuerdos siguen.
34. Cambia de modelo en **Motor**: los recuerdos y relaciones **siguen** (pertenecen a la partida, no al modelo).
35. **Eliminar la partida**: se borran también sus recuerdos, relaciones y capítulos; el resto de partidas queda intacto.

Al terminar, cuéntame qué pasos fallaron y el texto exacto del error. Recuerda subir `app/schemas/3.json` al repositorio tras la primera compilación.
