# Limitaciones conocidas (v0.4)

**Verificación**
- La compilación de Android (Kotlin/Compose/Gradle), el APK y las pruebas Room/Robolectric **no se pudieron ejecutar** en el entorno de desarrollo (sin Android SDK ni acceso a Gradle/Google). La primera compilación real es la de GitHub Actions.
- Las pantallas nuevas no se han visto en pantalla. Nada se ha probado en un dispositivo.
- La búsqueda FTS4 se probó en el SQLite de Python; el SQLite de Android puede comportarse distinto. Si FTS4 no estuviera disponible, la app lo detecta y usa un método más lento (comparación de palabras + `LIKE`), con el mismo resultado.

**Memoria**
- **FTS4, no FTS5**: Room solo admite FTS3/FTS4 y FTS5 no está garantizado desde Android 8 (nuestro mínimo). No se promete FTS5.
- El análisis con el modelo es una inferencia pesada y la calidad depende del modelo: los modelos pequeños pueden devolver formato roto, resúmenes pobres o inventar. Por eso todo es propuesta editable y el resumen se puede escribir a mano.
- El recuperador usa palabras (con tildes y plurales normalizados), no significado: una pregunta con otras palabras puede no recuperar un recuerdo. Los recuerdos fijados siempre entran. Hay una interfaz `MemoryRetriever` para sustituirlo en el futuro (p. ej. embeddings).
- Con más de 400 recuerdos se preselecciona con búsqueda de texto antes de puntuar.
- El análisis procesa un tramo por pasada; con historias muy largas hay que pulsar el botón varias veces.
- Un modelo no garantiza respetar secretos ni relaciones: la app solo entrega los datos con etiquetas y dentro del presupuesto.

**Relaciones**
- Solo se proponen cambios entre personas que ya tienen una relación creada en la partida (la primera, personaje → tú, se crea sola).

**Capítulos y volúmenes**
- El texto novelado lo escribe el modelo por partes; la unión entre partes puede notarse. Es una copia aparte, siempre editable.
- Solo se puede reabrir el último capítulo, y solo se deshace el cierre del último volumen mientras el siguiente esté vacío.

**Exportar / importar**
- Un `.jullai` no incluye el modelo ni los retratos de otros personajes. La importación crea siempre una partida nueva (no fusiona con una existente).
- El perfil global del jugador se copia a cada partida al empezarla; cambiarlo después no actualiza partidas ya creadas.

**Fuera de alcance de la 0.4**: biblioteca de mundos (v0.5), investigación por Internet, generación de imágenes (v0.6), grupos de personajes, servicio en segundo plano.
