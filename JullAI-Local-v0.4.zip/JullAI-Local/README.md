# JullAI Local — v0.4: memoria narrativa, relaciones y biblia de partida

App Android de IA local. **Este ZIP contiene la versión 0.4**, construida ENCIMA de la 0.3 (no se recreó la app, no se cambió Room por otra cosa
y el motor nativo/JNI **no cambió**). Novedades: **memoria narrativa persistente, relaciones, capítulos y volúmenes, y exportar/importar la partida (`.jullai`)**.

Los mundos (v0.5), la investigación por Internet y la generación de imágenes (v0.6) **no están implementados**.

- Sin Internet (la app no declara el permiso de red), sin cuentas, sin analítica, sin anuncios.
- Sin permisos de almacenamiento: modelos, tarjetas, imágenes y archivos `.jullai` se eligen con el selector de archivos del sistema.
- Los modelos NO van dentro del APK ni dentro de un `.jullai`.

## Qué hay de nuevo en la 0.4

**Memoria narrativa (por partida)**
- **Recuerdos permanentes** con importancia (1-5), momento de la historia, personajes relacionados y **fijado** (📌). Tres niveles de confianza:
  *confirmado por ti*, *extraído automáticamente* e *inferido por el modelo*.
- **Propuestas**: el análisis con el modelo solo PROPONE recuerdos, sucesos de la cronología, cambios de relación y un borrador de resumen.
  Tú los **aceptas, editas o descartas**. Una inferencia **nunca** pasa a permanente sin tu decisión; lo automático **nunca** modifica ni borra
  un recuerdo existente (y menos uno fijado). Lo descartado no se vuelve a proponer.
- **Cronología** de sucesos (editable) y **resumen con versiones**: cada cambio guarda una versión; restaurar crea una versión nueva con el texto antiguo.
  Si el modelo falla con el formato, ves su texto en bruto y lo corriges a mano.
- **Análisis configurable** (Ajustes → Memoria narrativa): *solo cuando yo lo pida* (por defecto), *cada N turnos* o *al cerrar un capítulo*.
  Es UNA inferencia por pasada sobre los mensajes aún no analizados; si empiezas a escribir, se detiene y no se guarda nada a medias.
- **Recuperación en el contexto**: antes de cada respuesta se eligen los recuerdos relevantes (fijados, palabras clave con peso por rareza, nombres relacionados,
  búsqueda de texto completo, importancia y recencia), la cronología y las relaciones, dentro de un **presupuesto de tokens** (~16 % del contexto). Los recuerdos fijados
  **no pueden desbordar el contexto** (tope del 60 % de la parte de recuerdos). El orden de prioridad del constructor de contexto de la 0.3 se respeta.
  La pestaña **Memoria → «Recuperado en la última respuesta»** muestra qué entró, por qué y qué no cupo.
- **Búsqueda de texto completo**: se usa **FTS4** (no FTS5: Room solo soporta FTS3/4 y FTS5 no está garantizado desde Android 8). Sin FTS, la app sigue funcionando con comparación de palabras en Kotlin + SQL `LIKE`.

**Relaciones**
- Cuatro medidas **independientes** de 1 a 100: confianza, afecto, respeto e interés romántico. Estado por partida.
- El modelo solo propone cambios pequeños (máx. ±6 por medida, ±3 romántico, ≤10 en total, máx. 2 medidas por evento, con motivo obligatorio);
  la app los **valida y recorta**, y se aplican solo si los aceptas. Historial completo de cambios y **corrección manual** libre por tu parte.
- **Perfil global del jugador** (Ajustes) reutilizable: al empezar una partida lo **usas**, lo **adaptas** o eres **independiente**. Cada partida guarda su copia.

**Capítulos y volúmenes**
- Tu **registro original de mensajes nunca se modifica**. Cierras capítulos; cada uno admite un título, un resumen (a mano o con el modelo) y un **texto novelado**
  generado por partes (editable, guardado aparte). Puedes reabrir el último capítulo.
- **Cerrar volumen**: borrador de **resumen de continuidad** (con el modelo o manual; el bloque de relaciones lo escribe la app, no el modelo) que revisas antes de confirmar.
  El volumen nuevo **conserva** recuerdos, relaciones y mensajes. El cierre se puede deshacer mientras el volumen siguiente esté vacío.

**Exportar / importar (`.jullai`)**
- Un ZIP con manifiesto, una **biblia legible** (`biblia.md`), los datos estructurados y el retrato reducido. **Sin modelo GGUF.** Formato en `docs/FORMATO_JULLAI.md`.
- Importar **valida todo antes de tocar tus datos** (versión, tipos, rangos, referencias, recuentos, sumas SHA-256, rutas peligrosas, entradas duplicadas, bombas de compresión),
  muestra una **vista previa**, es **cancelable** y **transaccional**. Siempre crea una partida **nueva**: nunca sobrescribe ni borra por coincidencia de nombre.

- Base de datos **versión 3** con migración 2→3 que solo AÑADE tablas (no se usa `fallbackToDestructiveMigration`).

## Estado real (lo que se verificó y lo que no)

Categorías: **Compila** · **Pruebas automáticas superadas** · **Probado en dispositivo** · **Pendiente de prueba manual** · **No implementado**.

| Elemento | Compila | Pruebas automáticas | En dispositivo | Estado |
|---|---|---|---|---|
| Código nativo (JNI + llama.cpp) | sin cambios | sin cambios desde la 0.2 | — | **Sin cambios** |
| Lógica pura nueva (`story/`): normalización de texto, recuperador, reglas de relaciones, mantenimiento, novela, códec `.jullai`, seguridad ZIP | **Sí** (Kotlin 2.0.21) | **Sí: 117 pruebas pasan** (64 nuevas de la 0.4 + 53 anteriores) | No | **Pruebas automáticas superadas** |
| Esquema SQL de la 0.4 y las 115 consultas `@Query` | — | **Sí**, contra SQLite real con `tools/verify/check_schema.py` (19 tablas = 19 entidades) | No | **Pruebas automáticas superadas** (verificador propio, NO es Room) |
| FTS4 (triggers, prefijos, sin tildes) | — | **Sí** en SQLite de Python | No (el SQLite de Android puede diferir) | **Pendiente de prueba manual** |
| Capa de datos, repositorios, `StoryJobs`, ViewModels | **Parcial**: tipos comprobados contra piezas simuladas de Android/Room | — | No | **Pendiente**: la compilación real es la de GitHub Actions |
| Pruebas Room/Robolectric nuevas (`StoryDatabaseTest` 20, `MigrationV3Test` 3, `MigrationTest` ajustada) | Tipos comprobados con piezas simuladas | **Escritas, NO ejecutadas** | No | **Pendiente**: las ejecutará Actions |
| Pantallas Compose nuevas (Memoria, Relaciones, Capítulos, ajustes, perfil, importar) | **NO verificado** | — | No | **Pendiente**: pueden aparecer errores de compilación que se corrigen con el log |
| APK / Gradle / NDK | **NO verificado** (aquí no hay Android SDK ni acceso a Gradle/Google) | — | No | **Pendiente** |
| Memoria con un modelo real, calidad del análisis, velocidad en tu teléfono | — | — | **No** | **Pendiente de prueba manual** |
| Mundos (v0.5), Internet, imágenes generadas | — | — | — | **No implementado** |

> No afirmo que algo funciona si no se ejecutó. Si la compilación de GitHub falla, **no añadas nada**: envía `gradle-build.log` y se corrige primero con el error real.
> Más detalle en `docs/REGISTRO_DE_PRUEBAS.md` y `docs/LIMITACIONES.md`.

## Cómo compilar la APK desde el teléfono

1. Sube **el contenido** de este ZIP a tu repositorio de GitHub (sustituye los archivos de la 0.3; incluye la carpeta oculta `.github`).
   **Conserva** la carpeta `app/schemas/` que ya tengas: no la borres.
2. Entra en **Actions**. El workflow **Compilar APK (JullAI Local)** arranca solo (o pulsa *Run workflow*). Tarda unos 20-35 minutos.
   Primero comprueba el esquema (segundos), luego compila el APK y lo sube, y después ejecuta las pruebas.
3. Descarga **JullAI-Local-debug-apk**. El APK se sube **antes** de las pruebas: lo tendrás aunque alguna falle (la ejecución saldría en rojo).
4. Instálalo **encima** de la 0.3 (misma clave de depuración): **conserva tus partidas, personajes y modelos**. La base pasa sola de la versión 2 a la 3.
5. El artefacto **registros-de-compilacion** trae `app/schemas/3.json`. **Súbelo al repositorio** (`app/schemas/`) junto a los anteriores.

Si falla, descarga **registros-de-compilacion** (`gradle-build.log`, `gradle-tests.log`, `schema-check.log`) y envíalo.

## Guía de prueba manual

Está en **`docs/PRUEBAS_MANUALES.md`** (paso a paso, en español).

## Cómo funciona la memoria (decisiones)

- **Qué llega al modelo**: solo recuerdos y sucesos *activos*. Las propuestas, lo descartado y las notas privadas no llegan.
- **Orden del contexto** (de más a menos prioritario cuando falta espacio, cae primero lo de abajo): sistema → ficha → tu personaje → escenario → reglas → conocimiento → lorebook →
  **relaciones → recuerdos → cronología** → resumen → mensajes recientes. Las secciones de memoria se incluyen **enteras o no se incluyen** (nunca cortadas a mitad de frase).
- **Puntuación de un recuerdo**: palabras clave de los últimos mensajes (el último pesa el doble; una palabra rara pesa más que una común, sin tildes ni plurales), nombres relacionados presentes,
  coincidencia de texto completo, importancia y recencia. Los fijados entran primero.
- **Presupuesto**: relaciones 25 %, recuerdos 55 % (fijados ≤ 60 % de eso), cronología ≤ 30 % de lo que quede, dentro del ~16 % del contexto.
- **Análisis con el modelo**: lee los mensajes más antiguos aún no analizados que quepan en el contexto; si quedan más, te lo dice y vuelves a pulsar. Un turno tuyo cancela el análisis.
- **Interfaz `MemoryRetriever`**: el recuperador actual (`RankedMemoryRetriever`) se puede sustituir por otro (p. ej. con embeddings en el futuro) sin tocar el resto.
- **FTS4 y no FTS5**: evaluado; ver arriba y `docs/LIMITACIONES.md`.

## Comportamientos decididos (v0.3, roleplay)

- **Partidas**: cada partida pertenece a UN personaje. Borrar el personaje borra sus partidas (el aviso lo dice). El escenario se **copia** a la partida: editar la ficha después no cambia partidas empezadas.
- **Editar un mensaje tuyo**: se descartan los mensajes posteriores y se genera una respuesta nueva (como en el chat). **Editar una respuesta del personaje**: solo cambia ese texto (la alternativa activa).
- **Regenerar** no borra: la respuesta anterior queda como alternativa (máx. 40) y se navega con ‹ ›. Solo la última respuesta tiene alternativas/regenerar/continuar.
- **Continuar** añade texto al final de la última respuesta (el texto existente se pasa al modelo como inicio de su turno).
- **Orden del contexto**: instrucciones del sistema → ficha → persona del usuario → escenario → reglas narrativas → conocimiento (secretos, hechos…) → lorebook activado → memoria recuperada (relaciones → recuerdos → cronología; v0.4) → (hueco para mundo v0.5) → resumen → mensajes recientes. Todo va en **un solo** mensaje de sistema.
- **Presupuesto**: cada sección tiene un tope en % del contexto (ficha 30 %, escenario 12 %, lorebook 15 %, resumen 10 %, conocimiento 12 %; sistema y reglas 10 % cada una). Si no queda espacio para al menos ~35 % del contexto en mensajes recientes, se sacrifica en este orden: ejemplos de diálogo → lorebook → resumen → recortes de ficha/escenario. El último mensaje nunca se descarta; si ni así cabe, se avisa con el motivo. Se descartan primero los mensajes más antiguos (el saludo inicial también puede salir).
- **Lorebook**: una entrada se activa si alguna clave aparece (texto literal, sin mayúsculas ni tildes) en los últimos N mensajes; las «siempre activas» entran siempre. Con poco espacio se conservan las de mayor prioridad. Nunca se envía el lorebook completo ni las fichas de otros personajes.
- **Notas privadas del creador**: el tipo de datos que llega al constructor de contexto no tiene ese campo, así que no pueden enviarse al modelo por error. (Sí van en el JSON que exportas: es tu copia.)
- **Tarjetas**: todo se trata como datos (se limpian caracteres de control, se limitan tamaños y cantidades, las claves tipo regex se usan como texto). `system_prompt` y `post_history_instructions` de una tarjeta se guardan como «instrucciones de comportamiento» de la ficha (avisándote en la vista previa); no se colocan después del historial.
- **Corte de turno**: si el texto generado contiene `\nTuNombre:` se corta ahí (opción en Ajustes).
- **Motor ocupado**: si el motor está generando para otra pantalla (p. ej. una conversación del chat), la partida avisa en vez de competir por él.

## Comportamientos del chat (v0.2, sin cambios)

- **Editar un mensaje tuyo**: se reemplaza el texto, **se descartan todos los mensajes posteriores** y se genera una respuesta nueva. No hay ramas (es la opción más simple y fiable).
- **Regenerar**: solo afecta a la **última** respuesta, que se reemplaza.
- **Guardado**: tu mensaje se guarda **antes** de generar; la respuesta parcial se guarda cada ~1,5 s. Si la app muere, el texto parcial queda marcado como interrumpido.
- **Contexto**: instrucciones del sistema + los mensajes más recientes que quepan, reservando espacio para la respuesta (máximo la mitad del contexto). Se cuentan tokens con el motor y se verifica con el prompt real ya con la plantilla del modelo. Si no cabe todo se descartan los mensajes **más antiguos** (todavía sin resumen). La conversación enviada siempre empieza por un mensaje tuyo.
- **Caché KV**: se reutiliza el prefijo común entre turnos y solo se procesan los tokens nuevos. Si el modelo no admite recortar la memoria, se limpia entera (sigue funcionando, más lento). Se puede desactivar en **Ajustes → Reutilizar la caché**. Cuando la conversación ya no cabe y se descartan mensajes antiguos, el prefijo cambia y se reprocesa todo (más lento en ese caso).
- **Modelo cargado**: se mantiene al cambiar de pantalla. Se libera con «Liberar memoria», al cerrar la app (la actividad termina) o ante presión de memoria del sistema cuando la app está en segundo plano y no genera. Cambiar el modelo, el contexto o los hilos recarga el modelo en el siguiente mensaje. Cambiar de modelo **nunca** borra conversaciones.
- **Segundo plano**: no hay servicio en primer plano todavía. Si cambias de app durante una respuesta, Android puede pausar o matar el proceso; el texto parcial se conserva.
- **Migraciones de la base de datos**: nunca destructivas (no se usa `fallbackToDestructiveMigration`).

## Estructura

- `app/src/main/cpp/jullai_engine.cpp` — puente JNI (sin cambios).
- `.../engine/` — `LlamaBridge`, `LlamaEngine` (hilo único), `EngineController`, `ModelStore`, `GgufHeader`, `ModelInfo`, `MemoryEstimator`.
- `.../data/` — Room: entidades, DAOs, `AppDatabase` (v3), `Migrations` (1→2, 2→3), repositorios; **0.4**: `StoryEntities`, `StoryDaos`, `StoryRepository`, `FtsSupport`, `BibleService`.
- `.../story/` — **nuevo, Kotlin puro y probado**: `TextNorm`, `MemoryRetrieval` (recuperador), `RelationshipRules`, `Maintenance` (análisis), `Novel`, `Bible`, `BibleCodec`, `BibleMarkdown`, `ZipSafety`, `StoryModels`.
- `.../roleplay/` — tarjetas, lorebook, contexto, `RoleplayViewModel`, **0.4**: `StoryJobs` (trabajos con el modelo), `StoryViewModel`.
- `.../chat/` — `ContextBuilder`, `ChatViewModel`.
- `.../ui/` — sistema visual propio (sin Material); **0.4**: `StoryPanels` (Memoria, Relaciones, Capítulos).
- `tools/verify/check_schema.py` — compara entidades y consultas con SQLite real. `tools/fetch_llama.sh` — descarga llama.cpp (no va en el ZIP). `tools/host-test/` — prueba JNI en Linux.
- `docs/` — formato `.jullai`, pruebas manuales, limitaciones y registro de pruebas.

## Diagnóstico de errores

- **Falla «Falta llama.cpp»**: el paso «Descargar llama.cpp» no se ejecutó; ejecuta `bash tools/fetch_llama.sh`.
- **Falla `assembleDebug`**: envía `gradle-build.log`. Si falla `kspDebugKotlin`, el error es de Room (consulta SQL o entidad).
- **La app se cierra al abrir tras actualizar** (o Room dice «Migration didn't properly handle»): la migración 1→2 no coincide con el esquema; envía `gradle-tests.log` (la prueba `MigrationTest` lo detalla) y el aviso exacto.
- **Una tarjeta no se importa**: la vista previa dice el motivo (JSON roto, PNG sin datos de tarjeta, versión no soportada…). Envíame el mensaje exacto.
- **Fallan las pruebas pero hay APK**: instala el APK igualmente y envía `gradle-tests.log` y `app/build/reports/tests/`.
- **La app se cierra al cargar un modelo**: casi siempre falta de memoria; baja el contexto a 1024 o usa un modelo menor.
- **«El motor no pudo leer el archivo»**: el GGUF es de una arquitectura que este llama.cpp no soporta, o está dañado.
- **Respuestas raras con «Reutilizar la caché» activada**: desactívala en Ajustes y avísame; el resultado debería ser el mismo (más lento).

- **La app se cierra al abrir tras actualizar** (o Room dice «Migration didn't properly handle»): la migración 2→3 no coincide con el esquema; envía `gradle-tests.log` (`MigrationV3Test` lo detalla) y el aviso exacto.
- **«No se pudo importar»**: el mensaje dice el motivo (versión, archivo dañado, ruta peligrosa, suma que no coincide…). No se cambió nada de tus datos.
- **El análisis con el modelo no devuelve el formato**: sale el texto en bruto para que lo corrijas; con modelos muy pequeños es normal. Prueba con un contexto mayor (Motor).

## Licencias

llama.cpp y ggml: licencia MIT (© The ggml authors), se descargan en la compilación. Los modelos tienen sus propias licencias; revísalas antes de usarlos.
