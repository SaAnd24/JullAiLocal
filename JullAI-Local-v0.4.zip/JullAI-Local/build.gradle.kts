plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    // KSP: procesador que genera el código de Room. La versión empieza por la de Kotlin (2.0.21).
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
}
