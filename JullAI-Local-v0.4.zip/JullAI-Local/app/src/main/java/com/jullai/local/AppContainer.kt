package com.jullai.local

import android.app.Application
import android.content.ComponentCallbacks2
import com.jullai.local.data.AppDatabase
import com.jullai.local.data.ChatRepository
import com.jullai.local.data.ModelRegistry
import com.jullai.local.data.PortraitStore
import com.jullai.local.data.RoleplayRepository
import com.jullai.local.data.StoryRepository
import com.jullai.local.data.BibleService
import com.jullai.local.roleplay.StoryJobs
import com.jullai.local.data.SettingsRepository
import com.jullai.local.engine.EngineController
import com.jullai.local.engine.LlamaEngine
import com.jullai.local.engine.ModelStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Objetos de vida larga (los comparten todas las pantallas). Viven mientras viva el proceso, de modo que
 * el modelo cargado se mantiene al cambiar de pantalla o al girar el teléfono.
 */
class AppContainer(val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val db: AppDatabase = AppDatabase.build(app)
    val registry = ModelRegistry(db)
    val chatRepository = ChatRepository(db)
    val roleplayRepository = RoleplayRepository(db)
    val storyRepository = StoryRepository(db)
    val bibleService = BibleService(db)
    val portraits = PortraitStore(app)
    val settingsRepository = SettingsRepository(db, scope)

    val engine = LlamaEngine()
    val store = ModelStore(app, registry)
    val controller = EngineController(engine, store)
    val storyJobs by lazy { StoryJobs(this) }
    /** Trabajo de memoria con el modelo (mantenimiento, novela...) en curso. Un envío del usuario lo cancela: el juego manda. */
    @Volatile var storyJob: Job? = null

    init {
        scope.launch {
            // Respuestas que quedaron "generándose" por un cierre inesperado → "interrumpidas" (el texto se conserva).
            runCatching { chatRepository.markInterruptedOnStart() }
            runCatching { roleplayRepository.markInterruptedOnStart() }
            // Registro de modelos del Hito 1 (registry.json) → Room, sin perder modelos ya importados.
            runCatching { registry.migrateLegacyRegistry(store.directory) }
        }
    }

    /** Presión de memoria del sistema: si la app ya no está en primer plano y no genera, se libera el modelo. */
    @Suppress("DEPRECATION")
    fun onTrimMemory(level: Int) {
        val critical = level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
        if (critical) scope.launch { controller.unloadIfIdle() }
    }

    /** Al cerrar la app (la actividad termina de verdad): se detiene la generación y se liberan los recursos nativos. */
    fun releaseNative() {
        engine.cancel()
        scope.launch { controller.unload() }
    }
}
