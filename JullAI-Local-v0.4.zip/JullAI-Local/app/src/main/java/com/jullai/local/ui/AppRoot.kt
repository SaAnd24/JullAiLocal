package com.jullai.local.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.jullai.local.ModelsViewModel
import com.jullai.local.SettingsViewModel
import com.jullai.local.chat.ChatViewModel
import com.jullai.local.roleplay.CharactersViewModel
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.StoryViewModel
import androidx.compose.runtime.collectAsState

private const val LIBRARY = "library"
private const val MODELS = "models"
private const val SETTINGS = "settings"
private const val CHAT_PREFIX = "chat:"
private const val CHARACTERS = "characters"
private const val EDIT_PREFIX = "charedit:"
private const val LORE_PREFIX = "lore:"
private const val RP_PREFIX = "rp:"

/**
 * Navegación mínima: Biblioteca (inicio) → Chat / Roleplay (Personajes → Ficha → Lorebook) / Modelos / Ajustes.
 * La ruta se guarda para sobrevivir a giros de pantalla.
 */
@Composable
fun AppRoot(
    chatVm: ChatViewModel,
    modelsVm: ModelsViewModel,
    settingsVm: SettingsViewModel,
    charactersVm: CharactersViewModel,
    rpVm: RoleplayViewModel,
    storyVm: StoryViewModel,
    onPickModel: () -> Unit,
) {
    var route by rememberSaveable { mutableStateOf(LIBRARY) }
    /** «Atrás»: del lorebook vuelve a la ficha (conserva lo escrito); de la ficha vuelve a Personajes (descarta); el resto, a la Biblioteca. */
    fun goBack() {
        route = when {
            route.startsWith(LORE_PREFIX) -> EDIT_PREFIX + (charactersVm.draft.value?.id ?: 0L)
            route.startsWith(EDIT_PREFIX) -> { charactersVm.discardDraft(); CHARACTERS }
            else -> LIBRARY
        }
    }
    BackHandler(enabled = route != LIBRARY) { goBack() }
    val settings by settingsVm.settings.collectAsState()

    Box(
        Modifier
            .fillMaxSize()
            .background(Ink.Tinta)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        when {
            route == MODELS -> ModelsScreen(modelsVm, onPickModel, onBack = { route = LIBRARY })
            route == SETTINGS -> SettingsScreen(settingsVm, onBack = { route = LIBRARY })
            route == CHARACTERS -> CharactersScreen(
                vm = charactersVm, settingsUserName = settings.rpLastUserName,
                onBack = { route = LIBRARY },
                onEdit = { route = EDIT_PREFIX + it },
                onOpenSession = { route = RP_PREFIX + it },
            )
            route.startsWith(EDIT_PREFIX) -> {
                val id = route.removePrefix(EDIT_PREFIX).toLongOrNull() ?: 0L
                key(id) { CharacterEditorScreen(charactersVm, id, onBack = { route = CHARACTERS }, onOpenLorebook = { route = LORE_PREFIX + it }) }
            }
            route.startsWith(LORE_PREFIX) -> {
                val id = route.removePrefix(LORE_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = CHARACTERS }
                else key(id) { LorebookScreen(charactersVm, id, onBack = { goBack() }) }
            }
            route.startsWith(RP_PREFIX) -> {
                val id = route.removePrefix(RP_PREFIX).toLongOrNull()
                if (id == null) LaunchedEffect(Unit) { route = LIBRARY }
                else key(id) { RoleplayScreen(rpVm, storyVm, id, onBack = { route = LIBRARY }) }
            }
            route.startsWith(CHAT_PREFIX) -> {
                val id = route.removePrefix(CHAT_PREFIX).toLongOrNull()
                if (id == null) {
                    LaunchedEffect(Unit) { route = LIBRARY }
                } else {
                    key(id) { ChatScreen(chatVm, id, onBack = { route = LIBRARY }) }
                }
            }
            else -> LibraryScreen(
                vm = chatVm,
                rpVm = rpVm,
                storyVm = storyVm,
                onOpenChat = { route = CHAT_PREFIX + it },
                onOpenModels = { route = MODELS },
                onOpenSettings = { route = SETTINGS },
                onOpenCharacters = { route = CHARACTERS },
                onOpenSession = { route = RP_PREFIX + it },
            )
        }
    }
}
