package com.jullai.local.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Migraciones de la base de datos. NUNCA destructivas: solo se AÑADEN tablas, sin tocar las existentes
 * (conversaciones, mensajes, modelos y ajustes de la v0.2 quedan intactos).
 *
 * El SQL reproduce EXACTAMENTE lo que Room espera para las entidades de RoleplayEntities.kt
 * (nombres de columna, tipos, NOT NULL, claves foráneas e índices); si una entidad cambia hay que cambiar esto
 * y subir la versión con una migración nueva.
 */
object Migrations {
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `lorebooks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, " +
                    "`description` TEXT NOT NULL, `scanDepth` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)",
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `lorebook_entries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `lorebookId` INTEGER NOT NULL, " +
                    "`name` TEXT NOT NULL, `keys` TEXT NOT NULL, `secondaryKeys` TEXT NOT NULL, `content` TEXT NOT NULL, `enabled` INTEGER NOT NULL, " +
                    "`constant` INTEGER NOT NULL, `selective` INTEGER NOT NULL, `caseSensitive` INTEGER NOT NULL, `priority` INTEGER NOT NULL, " +
                    "`insertionOrder` INTEGER NOT NULL, FOREIGN KEY(`lorebookId`) REFERENCES `lorebooks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_lorebook_entries_lorebookId` ON `lorebook_entries` (`lorebookId`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `characters` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `aliases` TEXT NOT NULL, " +
                    "`portraitFile` TEXT, `appearance` TEXT NOT NULL, `personality` TEXT NOT NULL, `speechStyle` TEXT NOT NULL, `history` TEXT NOT NULL, " +
                    "`motivations` TEXT NOT NULL, `likesDislikes` TEXT NOT NULL, `behaviorInstructions` TEXT NOT NULL, `initialRelationship` TEXT NOT NULL, " +
                    "`scenario` TEXT NOT NULL, `firstMessage` TEXT NOT NULL, `alternateGreetings` TEXT NOT NULL, `dialogueExamples` TEXT NOT NULL, " +
                    "`worldId` INTEGER, `lorebookId` INTEGER, `privateNotes` TEXT NOT NULL, `tags` TEXT NOT NULL, `creator` TEXT NOT NULL, " +
                    "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`lorebookId`) REFERENCES `lorebooks`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_characters_lorebookId` ON `characters` (`lorebookId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_characters_name` ON `characters` (`name`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `scenarios` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `characterId` INTEGER NOT NULL, " +
                    "`title` TEXT NOT NULL, `text` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`characterId`) REFERENCES `characters`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_scenarios_characterId` ON `scenarios` (`characterId`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `role_sessions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `characterId` INTEGER NOT NULL, " +
                    "`title` TEXT NOT NULL, `scenarioText` TEXT NOT NULL, `userName` TEXT NOT NULL, `userPersona` TEXT NOT NULL, " +
                    "`narrativeRules` TEXT NOT NULL, `summary` TEXT NOT NULL, `modelFileName` TEXT, `temperature` REAL NOT NULL, `topP` REAL NOT NULL, " +
                    "`maxTokens` INTEGER NOT NULL, `contextLength` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`characterId`) REFERENCES `characters`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_role_sessions_characterId` ON `role_sessions` (`characterId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_role_sessions_updatedAt` ON `role_sessions` (`updatedAt`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `role_messages` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, " +
                    "`role` TEXT NOT NULL, `content` TEXT NOT NULL, `orderIndex` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `state` TEXT NOT NULL, " +
                    "`swipes` TEXT NOT NULL, `swipeIndex` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_role_messages_sessionId_orderIndex` ON `role_messages` (`sessionId`, `orderIndex`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `knowledge_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, " +
                    "`scope` TEXT NOT NULL, `text` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_knowledge_items_sessionId` ON `knowledge_items` (`sessionId`)")
        }
    }

    /**
     * v0.4: memoria narrativa, relaciones, capítulos y volúmenes. SOLO añade tablas (no toca nada de la 0.3).
     * Igual que con la 1→2, el SQL reproduce lo que Room espera para StoryEntities.kt; la prueba MigrationTest lo valida.
     */
    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            for (sql in STORY_TABLES_SQL) db.execSQL(sql)
            // Búsqueda de texto completo (FTS4): es opcional. Si el sistema no la admite, la app usa un respaldo.
            FtsSupport.ensure(db)
        }
    }

    /** Un único origen de verdad para el esquema v3: lo usan la migración y las pruebas. */
    val STORY_TABLES_SQL: List<String> = listOf(
        "CREATE TABLE IF NOT EXISTS `memories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `content` TEXT NOT NULL, " +
            "`importance` INTEGER NOT NULL, `narrativeDate` TEXT NOT NULL, `origin` TEXT NOT NULL, `verification` TEXT NOT NULL, `state` TEXT NOT NULL, " +
            "`pinned` INTEGER NOT NULL, `relatedNames` TEXT NOT NULL, `sourceMessageId` INTEGER, `sourceNote` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
            "`updatedAt` INTEGER NOT NULL, FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_memories_sessionId` ON `memories` (`sessionId`)",
        "CREATE INDEX IF NOT EXISTS `index_memories_sessionId_state` ON `memories` (`sessionId`, `state`)",
        "CREATE TABLE IF NOT EXISTS `summaries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `version` INTEGER NOT NULL, " +
            "`text` TEXT NOT NULL, `source` TEXT NOT NULL, `coversUpToOrder` INTEGER NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_summaries_sessionId_version` ON `summaries` (`sessionId`, `version`)",
        "CREATE TABLE IF NOT EXISTS `timeline_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `text` TEXT NOT NULL, " +
            "`narrativeDate` TEXT NOT NULL, `orderKey` INTEGER NOT NULL, `characterNames` TEXT NOT NULL, `origin` TEXT NOT NULL, `state` TEXT NOT NULL, " +
            "`sourceMessageId` INTEGER, `createdAt` INTEGER NOT NULL, FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_timeline_events_sessionId_orderKey` ON `timeline_events` (`sessionId`, `orderKey`)",
        "CREATE TABLE IF NOT EXISTS `relationships` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `aName` TEXT NOT NULL, " +
            "`bName` TEXT NOT NULL, `trust` INTEGER NOT NULL, `affection` INTEGER NOT NULL, `respect` INTEGER NOT NULL, `romantic` INTEGER NOT NULL, " +
            "`status` TEXT NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_relationships_sessionId` ON `relationships` (`sessionId`)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_relationships_sessionId_aName_bName` ON `relationships` (`sessionId`, `aName`, `bName`)",
        "CREATE TABLE IF NOT EXISTS `relationship_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `relationshipId` INTEGER NOT NULL, `sessionId` INTEGER NOT NULL, " +
            "`state` TEXT NOT NULL, `origin` TEXT NOT NULL, `reason` TEXT NOT NULL, `dTrust` INTEGER NOT NULL, `dAffection` INTEGER NOT NULL, `dRespect` INTEGER NOT NULL, " +
            "`dRomantic` INTEGER NOT NULL, `trustAfter` INTEGER, `affectionAfter` INTEGER, `respectAfter` INTEGER, `romanticAfter` INTEGER, `sourceMessageId` INTEGER, " +
            "`createdAt` INTEGER NOT NULL, FOREIGN KEY(`relationshipId`) REFERENCES `relationships`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_relationship_events_relationshipId` ON `relationship_events` (`relationshipId`)",
        "CREATE INDEX IF NOT EXISTS `index_relationship_events_sessionId` ON `relationship_events` (`sessionId`)",
        "CREATE TABLE IF NOT EXISTS `volumes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `number` INTEGER NOT NULL, `title` TEXT NOT NULL, " +
            "`state` TEXT NOT NULL, `continuitySummary` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `closedAt` INTEGER, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_volumes_sessionId_number` ON `volumes` (`sessionId`, `number`)",
        "CREATE TABLE IF NOT EXISTS `chapters` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `volumeId` INTEGER NOT NULL, `number` INTEGER NOT NULL, " +
            "`title` TEXT NOT NULL, `state` TEXT NOT NULL, `startOrder` INTEGER NOT NULL, `endOrder` INTEGER, `summary` TEXT NOT NULL, `novelText` TEXT NOT NULL, " +
            "`novelState` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `closedAt` INTEGER, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , " +
            "FOREIGN KEY(`volumeId`) REFERENCES `volumes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_chapters_volumeId` ON `chapters` (`volumeId`)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_chapters_sessionId_number` ON `chapters` (`sessionId`, `number`)",
        "CREATE TABLE IF NOT EXISTS `memory_progress` (`sessionId` INTEGER NOT NULL, `coveredOrder` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`sessionId`), " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
    )
}
