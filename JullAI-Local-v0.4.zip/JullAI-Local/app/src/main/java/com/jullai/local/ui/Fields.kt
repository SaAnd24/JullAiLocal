package com.jullai.local.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.jullai.local.data.PortraitStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Campo con etiqueta (y una nota opcional) para formularios largos. */
@Composable
fun LabeledField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    hint: String? = null,
    minHeight: Int = 44,
    maxHeight: Int = 220,
    enabled: Boolean = true,
) {
    Column(modifier.fillMaxWidth().padding(top = 12.dp)) {
        BasicText(label, style = Type.Nota.copy(color = Ink.Oro))
        if (hint != null) BasicText(hint, style = Type.Nota.copy(color = Ink.MarfilTenue.copy(alpha = 0.8f)))
        Spacer(Modifier.height(4.dp))
        InkField(value, onChange, placeholder, Modifier.fillMaxWidth(), minHeight = minHeight, enabled = enabled, maxHeight = maxHeight)
    }
}

/** Opción seleccionable tipo «etiqueta». */
@Composable
fun InkChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .background(if (selected) Ink.Oro else Ink.Pizarra, shape)
            .border(1.dp, if (selected) Ink.Oro else Ink.Linea, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        BasicText(text, style = Type.Nota.copy(color = if (selected) Ink.Tinta else Ink.Marfil))
    }
}

/** Retrato del personaje (recortado). Sin imagen muestra la inicial del nombre. */
@Composable
fun PortraitImage(store: PortraitStore, file: String?, name: String, modifier: Modifier = Modifier, maxSide: Int = 256) {
    val bmp by produceState<ImageBitmap?>(initialValue = null, file, maxSide) {
        value = if (file == null) null else withContext(Dispatchers.IO) { runCatching { store.load(file, maxSide)?.asImageBitmap() }.getOrNull() }
    }
    val b = bmp
    Box(modifier.clip(RoundedCornerShape(8.dp)).background(Ink.Pizarra), contentAlignment = Alignment.Center) {
        if (b != null) {
            Image(bitmap = b, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            BasicText(name.trim().take(1).uppercase(), style = Type.Titulo.copy(color = Ink.Oro))
        }
    }
}
