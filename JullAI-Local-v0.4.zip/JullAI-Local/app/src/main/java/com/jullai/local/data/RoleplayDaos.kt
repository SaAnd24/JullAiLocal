package com.jullai.local.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LorebookDao {
    @Query("SELECT * FROM lorebooks ORDER BY name COLLATE NOCASE ASC")
    fun observeAll(): Flow<List<LorebookEntity>>

    @Query("SELECT * FROM lorebooks WHERE id = :id")
    suspend fun get(id: Long): LorebookEntity?

    @Query("SELECT * FROM lorebooks WHERE id = :id")
    fun observe(id: Long): Flow<LorebookEntity?>

    @Insert
    suspend fun insert(book: LorebookEntity): Long

    @Update
    suspend fun update(book: LorebookEntity)

    @Query("DELETE FROM lorebooks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM characters WHERE lorebookId = :id")
    suspend fun usersOf(id: Long): Int

    @Query("SELECT COUNT(*) FROM lorebook_entries WHERE lorebookId = :id")
    fun observeEntryCount(id: Long): Flow<Int>
}

@Dao
interface LoreEntryDao {
    @Query("SELECT * FROM lorebook_entries WHERE lorebookId = :bookId ORDER BY insertionOrder ASC, id ASC")
    fun observe(bookId: Long): Flow<List<LoreEntryEntity>>

    @Query("SELECT * FROM lorebook_entries WHERE lorebookId = :bookId ORDER BY insertionOrder ASC, id ASC")
    suspend fun list(bookId: Long): List<LoreEntryEntity>

    @Insert
    suspend fun insert(entry: LoreEntryEntity): Long

    @Insert
    suspend fun insertAll(entries: List<LoreEntryEntity>)

    @Update
    suspend fun update(entry: LoreEntryEntity)

    @Query("DELETE FROM lorebook_entries WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface CharacterDao {
    @Query("SELECT * FROM characters ORDER BY name COLLATE NOCASE ASC, id ASC")
    fun observeAll(): Flow<List<CharacterEntity>>

    @Query("SELECT * FROM characters WHERE id = :id")
    suspend fun get(id: Long): CharacterEntity?

    @Insert
    suspend fun insert(character: CharacterEntity): Long

    @Update
    suspend fun update(character: CharacterEntity)

    @Query("DELETE FROM characters WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM role_sessions WHERE characterId = :id")
    suspend fun sessionCount(id: Long): Int
}

@Dao
interface ScenarioDao {
    @Query("SELECT * FROM scenarios WHERE characterId = :characterId ORDER BY id ASC")
    suspend fun forCharacter(characterId: Long): List<ScenarioEntity>

    @Query("SELECT * FROM scenarios WHERE characterId = :characterId ORDER BY id ASC")
    fun observeFor(characterId: Long): Flow<List<ScenarioEntity>>

    @Insert
    suspend fun insert(s: ScenarioEntity): Long

    @Query("DELETE FROM scenarios WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface RoleSessionDao {
    @Query(
        "SELECT s.*, c.name AS characterName, c.portraitFile AS portraitFile " +
            "FROM role_sessions s INNER JOIN characters c ON c.id = s.characterId " +
            "ORDER BY s.updatedAt DESC, s.id DESC",
    )
    fun observeList(): Flow<List<SessionListItem>>

    @Query("SELECT * FROM role_sessions WHERE id = :id")
    fun observe(id: Long): Flow<RoleSessionEntity?>

    @Query("SELECT * FROM role_sessions WHERE id = :id")
    suspend fun get(id: Long): RoleSessionEntity?

    @Insert
    suspend fun insert(s: RoleSessionEntity): Long

    @Update
    suspend fun update(s: RoleSessionEntity)

    @Query("DELETE FROM role_sessions WHERE id = :id")
    suspend fun delete(id: Long)

    /** Solo la columna del resumen: así guardar un resumen nunca pisa otros cambios de la escena. */
    @Query("UPDATE role_sessions SET summary = :summary, updatedAt = :now WHERE id = :id")
    suspend fun setSummary(id: Long, summary: String, now: Long)

    @Query("UPDATE role_sessions SET title = :title, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: Long, title: String, now: Long)

    @Query("UPDATE role_sessions SET updatedAt = :now WHERE id = :id")
    suspend fun touch(id: Long, now: Long)

    @Query("UPDATE role_sessions SET modelFileName = NULL WHERE modelFileName = :fileName")
    suspend fun clearModel(fileName: String)
}

@Dao
interface RoleMessageDao {
    @Query("SELECT * FROM role_messages WHERE sessionId = :sessionId ORDER BY orderIndex ASC")
    fun observe(sessionId: Long): Flow<List<RoleMessageEntity>>

    @Query("SELECT * FROM role_messages WHERE sessionId = :sessionId ORDER BY orderIndex ASC")
    suspend fun list(sessionId: Long): List<RoleMessageEntity>

    @Query("SELECT * FROM role_messages WHERE id = :id")
    suspend fun get(id: Long): RoleMessageEntity?

    @Query("SELECT COALESCE(MAX(orderIndex), -1) FROM role_messages WHERE sessionId = :sessionId")
    suspend fun maxOrder(sessionId: Long): Int

    @Insert
    suspend fun insert(m: RoleMessageEntity): Long

    @Query("UPDATE role_messages SET content = :content WHERE id = :id")
    suspend fun updateContent(id: Long, content: String)

    @Query("UPDATE role_messages SET content = :content, state = :state, swipes = :swipes, swipeIndex = :swipeIndex WHERE id = :id")
    suspend fun updateAll(id: Long, content: String, state: String, swipes: String, swipeIndex: Int)

    @Query("DELETE FROM role_messages WHERE sessionId = :sessionId AND orderIndex > :orderIndex")
    suspend fun deleteAfter(sessionId: Long, orderIndex: Int)

    @Query("DELETE FROM role_messages WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE role_messages SET state = 'INTERRUPTED' WHERE state = 'GENERATING'")
    suspend fun markGeneratingAsInterrupted(): Int
}

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM knowledge_items WHERE sessionId = :sessionId ORDER BY id ASC")
    fun observe(sessionId: Long): Flow<List<KnowledgeItemEntity>>

    @Query("SELECT * FROM knowledge_items WHERE sessionId = :sessionId ORDER BY id ASC")
    suspend fun list(sessionId: Long): List<KnowledgeItemEntity>

    @Insert
    suspend fun insert(item: KnowledgeItemEntity): Long

    @Query("DELETE FROM knowledge_items WHERE id = :id")
    suspend fun delete(id: Long)
}
