package com.jullai.local.roleplay

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.AppContainer
import com.jullai.local.chat.GenState
import com.jullai.local.chat.StreamText
import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.KnowledgeItemEntity
import com.jullai.local.data.MessageRole
import com.jullai.local.data.MessageState
import com.jullai.local.data.RoleMessageEntity
import com.jullai.local.data.RoleSessionEntity
import com.jullai.local.data.SessionListItem
import com.jullai.local.data.toLore
import com.jullai.local.data.toRp
import com.jullai.local.engine.ChatMessage
import com.jullai.local.engine.EngineState
import com.jullai.local.engine.FinishReason
import com.jullai.local.engine.GenEvent
import com.jullai.local.engine.GenerationParams
import com.jullai.local.engine.LoadedModel
import com.jullai.local.engine.StoredModel
import com.jullai.local.story.RankedMemoryRetriever
import com.jullai.local.story.RetrievalRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Partidas de roleplay: lista, juego, generación y panel de la escena. Independiente del chat general. */
@OptIn(ExperimentalCoroutinesApi::class)
class RoleplayViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.roleplayRepository
    private val controller = c.controller
    private val engine = c.engine
    val portraitStore get() = c.portraits

    val sessions: StateFlow<List<SessionListItem>> =
        repo.sessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val models: StateFlow<List<StoredModel>> =
        c.registry.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentId = MutableStateFlow<Long?>(null)

    val session: StateFlow<RoleSessionEntity?> = _currentId
        .flatMapLatest { id -> if (id == null) flowOf(null) else repo.session(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val character: StateFlow<CharacterEntity?> = combine(session, repo.characters()) { s, list ->
        s?.let { x -> list.firstOrNull { it.id == x.characterId } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val messages: StateFlow<List<RoleMessageEntity>> = _currentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val knowledge: StateFlow<List<KnowledgeItemEntity>> = _currentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.knowledge(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _gen = MutableStateFlow(GenState())
    val gen: StateFlow<GenState> = _gen.asStateFlow()

    private val _stream = MutableStateFlow<StreamText?>(null)
    val stream: StateFlow<StreamText?> = _stream.asStateFlow()

    private val _editing = MutableStateFlow<RoleMessageEntity?>(null)
    val editing: StateFlow<RoleMessageEntity?> = _editing.asStateFlow()

    private val _recalled = MutableStateFlow("Aún no se ha recuperado memoria en esta sesión.")
    /** Qué recuerdos, relaciones y sucesos entraron (y cuáles no) en la última respuesta. */
    val recalled: StateFlow<String> = _recalled.asStateFlow()

    private val _report = MutableStateFlow("Aún no se ha generado ninguna respuesta en esta sesión.")
    val report: StateFlow<String> = _report.asStateFlow()

    val engineState: StateFlow<EngineState> = controller.state
    val loaded: StateFlow<LoadedModel?> = controller.loaded
    val busyLoading: StateFlow<String?> = controller.busy
    val settings = c.settingsRepository.settings

    private val savedScroll = HashMap<Long, Pair<Int, Int>>()
    fun scrollFor(id: Long): Pair<Int, Int> = savedScroll[id] ?: (0 to 0)
    fun saveScroll(id: Long, index: Int, offset: Int) { savedScroll[id] = index to offset }

    private var genJob: Job? = null
    private val updateMutex = Mutex()

    private fun isBusy() = _gen.value.messageId != null

    // ---------------- Partidas ----------------

    fun open(id: Long) {
        if (_currentId.value != id) {
            _editing.value = null
            if (!isBusy()) _gen.value = GenState()
        }
        _currentId.value = id
    }

    fun rename(id: Long, title: String) { viewModelScope.launch { repo.renameSession(id, title) } }

    fun delete(id: Long, then: () -> Unit = {}) {
        viewModelScope.launch {
            if (_currentId.value == id) {
                if (isBusy()) { stop(); genJob?.join() }
                _currentId.value = null
                _editing.value = null
            }
            repo.deleteSession(id)
            then()
        }
    }

    /** Cambios en la escena y en los parámetros; se aplican de una en una. */
    fun updateSession(change: (RoleSessionEntity) -> RoleSessionEntity) {
        val id = _currentId.value ?: return
        viewModelScope.launch {
            updateMutex.withLock {
                val cur = repo.getSession(id) ?: return@withLock
                repo.updateSession(change(cur))
            }
        }
    }

    /** Guarda la escena y, si cambió, el resumen (con versión) en orden, para que nada se pisen. */
    fun saveScene(newSummary: String?, change: (RoleSessionEntity) -> RoleSessionEntity) {
        val id = _currentId.value ?: return
        viewModelScope.launch {
            updateMutex.withLock {
                val cur = repo.getSession(id) ?: return@withLock
                repo.updateSession(change(cur))
                if (newSummary != null && newSummary != cur.summary) {
                    try { c.storyRepository.saveSummary(id, newSummary, com.jullai.local.story.Origin.USUARIO) }
                    catch (e: Exception) { _gen.update { it.copy(error = "No se pudo guardar el resumen: ${e.message}") } }
                }
            }
        }
    }

    fun addKnowledge(scope: String, text: String) {
        val id = _currentId.value ?: return
        if (text.isBlank()) return
        viewModelScope.launch { repo.addKnowledge(id, scope, text) }
    }

    fun deleteKnowledge(itemId: Long) { viewModelScope.launch { repo.deleteKnowledge(itemId) } }

    // ---------------- Turnos ----------------

    private fun storyJobActive() = c.storyJob?.isActive == true

    /** Si hay un trabajo de memoria con el modelo, se cancela y se espera a que suelte el motor. */
    private suspend fun yieldToPlay() {
        val j = c.storyJob ?: return
        if (j.isActive) { j.cancel(); engine.cancel() }
        j.join()
    }

    private fun otherJobBusy(): Boolean {
        if (storyJobActive()) return false
        val st = engine.state.value
        return st == EngineState.GENERATING || st == EngineState.LOADING || controller.busy.value != null
    }

    private fun guard(): Boolean {
        if (isBusy()) return false
        if (otherJobBusy()) {
            _gen.value = GenState(error = "El motor está ocupado con otra generación (¿una conversación del chat?). Espera a que termine o deténla allí.")
            return false
        }
        return true
    }

    fun send(text: String) {
        val s = session.value ?: return
        val clean = text.trim()
        if (clean.isEmpty() || !guard()) return
        val editingMsg = _editing.value
        _editing.value = null
        _gen.value = GenState(messageId = PREPARING, phase = "Preparando…")
        genJob = viewModelScope.launch {
            yieldToPlay()
            val assistantId = try {
                if (editingMsg != null) repo.editUserMessage(editingMsg.id, clean) else repo.appendUserTurn(s.id, clean).second
            } catch (e: CancellationException) {
                _gen.value = GenState(); throw e
            } catch (e: Exception) {
                _gen.value = GenState(error = "No se pudo guardar el mensaje: ${e.message}")
                null
            }
            if (assistantId != null) generate(s.id, assistantId, null)
            else if (_gen.value.error == null) _gen.value = GenState()
        }
    }

    private fun lastAssistantWithUserBefore(): RoleMessageEntity? {
        val list = messages.value
        val last = list.lastOrNull() ?: return null
        if (last.role != MessageRole.ASSISTANT) return null
        if (list.none { it.role == MessageRole.USER }) return null
        return last
    }

    /** Regenerar: la respuesta actual se conserva como alternativa y se genera otra. */
    fun regenerate() {
        val s = session.value ?: return
        val last = lastAssistantWithUserBefore() ?: return
        if (!guard()) return
        _gen.value = GenState(messageId = PREPARING, phase = "Preparando…")
        genJob = viewModelScope.launch {
            yieldToPlay()
            if (repo.prepareNewSwipe(last.id)) generate(s.id, last.id, null) else _gen.value = GenState()
        }
    }

    /** Continuar la última respuesta desde donde quedó. */
    fun continueReply() {
        val s = session.value ?: return
        val last = lastAssistantWithUserBefore() ?: return
        if (!guard()) return
        _gen.value = GenState(messageId = PREPARING, phase = "Preparando…")
        genJob = viewModelScope.launch {
            yieldToPlay()
            val existing = repo.prepareContinuation(last.id)
            if (existing != null) generate(s.id, last.id, existing) else _gen.value = GenState()
        }
    }

    fun swipe(delta: Int) {
        if (isBusy()) return
        val last = messages.value.lastOrNull() ?: return
        viewModelScope.launch { repo.selectSwipe(last.id, delta) }
    }

    fun startEdit(m: RoleMessageEntity) {
        if (isBusy() || m.role != MessageRole.USER) return
        _editing.value = m
    }

    fun cancelEdit() { _editing.value = null }

    fun editAssistant(m: RoleMessageEntity, text: String) {
        if (isBusy() || text.isBlank()) return
        viewModelScope.launch { repo.editAssistantMessage(m.id, text.trim()) }
    }

    fun deleteLast() {
        val id = _currentId.value ?: return
        if (isBusy()) return
        viewModelScope.launch { repo.deleteLastMessage(id) }
    }

    fun stop() {
        if (engine.state.value == EngineState.GENERATING) engine.cancel() else genJob?.cancel()
    }

    fun dismissError() { _gen.update { it.copy(error = null) } }

    private suspend fun resolveModel(s: RoleSessionEntity): StoredModel? {
        val all = c.registry.list()
        return s.modelFileName?.let { f -> all.firstOrNull { it.fileName == f } }
            ?: all.firstOrNull { it.isDefault }
            ?: all.firstOrNull()
    }

    private suspend fun generate(sessionId: Long, assistantId: Long, continuation: String?) {
        val sb = StringBuilder(continuation ?: "")
        val baseLen = sb.length
        var state = MessageState.COMPLETE
        var cancelled = false
        var errorText: String? = null
        var statsText = ""
        var lastSave = System.nanoTime()
        var stoppedByRule = false
        try {
            val s = repo.getSession(sessionId) ?: throw IllegalStateException("La partida ya no existe.")
            val ch = repo.character(s.characterId) ?: throw IllegalStateException("El personaje de esta partida ya no existe.")
            val model = resolveModel(s)
                ?: throw IllegalStateException("No hay ningún modelo importado. Ve a Modelos e importa un archivo .gguf.")
            val st = settings.value
            _gen.value = GenState(messageId = assistantId, phase = "Cargando el modelo si hace falta…")
            controller.ensureLoaded(model, s.contextLength, st.threads)

            val rows = repo.history(sessionId)
            val target = rows.firstOrNull { it.id == assistantId } ?: throw IllegalStateException("No se encontró la respuesta a generar.")
            val history = rows.filter { it.orderIndex < target.orderIndex && it.content.isNotBlank() }.map { ChatMessage(it.role, it.content) }
            if (history.none { it.role == MessageRole.USER }) throw IllegalStateException("Escribe primero un mensaje: no hay nada a lo que responder.")

            val lore = ch.lorebookId?.let { repo.loreEntriesList(it).map { e -> e.toLore() } } ?: emptyList()
            val scanDepth = ch.lorebookId?.let { repo.lorebookOnce(it)?.scanDepth } ?: 4
            val knowledgeItems = repo.knowledgeList(sessionId)

            _gen.update { it.copy(phase = "Preparando el contexto…") }
            var extra = emptyList<PromptSection>()
            if (st.memEnabled) {
                try {
                    c.storyRepository.ensureDefaultRelationship(sessionId, ch.name, s.userName)
                    val recent = history.takeLast(4).map { Macros.apply(it.content, ch.name, s.userName) }
                    val r = RankedMemoryRetriever(c.storyRepository).retrieve(
                        RetrievalRequest(sessionId, recent, listOf(ch.name, s.userName), (s.contextLength * 0.16).toInt().coerceIn(120, 1500)),
                    ) { engine.countTokens(it) }
                    extra = r.toSections()
                    _recalled.value = r.describe()
                } catch (e: CancellationException) { throw e } catch (e: Exception) {
                    // La memoria nunca debe impedir jugar.
                    _recalled.value = "La memoria falló y se omitió en esta respuesta: ${e.message}"
                }
            } else _recalled.value = "La memoria está desactivada en Ajustes."
            val ctx = RoleplayContextBuilder.build(
                RpInput(
                    systemPrompt = st.rpSystemPrompt,
                    character = ch.toRp(),
                    scene = RpScene(s.userName, s.userPersona, s.scenarioText, s.narrativeRules, s.summary),
                    knowledge = knowledgeItems, lore = lore, loreScanDepth = scanDepth,
                    history = history, contextLength = s.contextLength, maxResponseTokens = s.maxTokens,
                    extra = extra, continuation = continuation,
                ),
                count = { engine.countTokens(it) },
                applyTemplate = { engine.applyTemplate(it) },
            )
            _report.value = formatReport(ctx, s.contextLength)
            _gen.update { it.copy(phase = if (ctx.droppedMessages > 0) "Generando… (${ctx.droppedMessages} mensajes antiguos fuera del contexto)" else "Generando…") }

            val stop = if (st.rpStopOnUserTurn) UserTurnStop(s.userName) else null
            val params = GenerationParams(temperature = s.temperature, topP = s.topP, maxTokens = s.maxTokens, reuseCache = st.reuseKvCache)
            engine.generate(ctx.prompt, params).collect { ev ->
                when (ev) {
                    is GenEvent.Text -> {
                        if (stoppedByRule) return@collect
                        sb.append(ev.text)
                        val cut = stop?.cutIndex(sb.substring(baseLen)) ?: -1
                        if (cut >= 0) {
                            sb.setLength(baseLen + cut)
                            stoppedByRule = true
                            engine.cancel()
                        }
                        _stream.value = StreamText(assistantId, sb.toString())
                        val now = System.nanoTime()
                        if (now - lastSave > SAVE_EVERY_NANOS) {
                            lastSave = now
                            repo.savePartial(assistantId, sb.toString())
                        }
                    }
                    is GenEvent.Finished -> {
                        val secs = ev.millis / 1000.0
                        val tps = if (secs > 0) ev.tokens / secs else 0.0
                        val why = when {
                            stoppedByRule -> " · cortada: el modelo empezó a escribir por ti"
                            ev.reason == FinishReason.MAX_TOKENS -> " · límite de tokens de respuesta"
                            ev.reason == FinishReason.CANCELLED -> " · detenida"
                            ev.reason == FinishReason.CONTEXT_FULL -> " · contexto lleno"
                            else -> ""
                        }
                        statsText = "%d tokens en %.1f s (%.1f tok/s) · prompt %d tokens (%d reutilizados)%s"
                            .format(ev.tokens, secs, tps, ctx.promptTokens, engine.lastReusedTokens(), why)
                    }
                }
            }
        } catch (e: CancellationException) {
            cancelled = true
            throw e
        } catch (e: Exception) {
            state = MessageState.ERROR
            errorText = e.message ?: "Error durante la generación."
        } finally {
            withContext(NonCancellable) {
                val finalText = if (continuation == null) sb.toString().trim() else sb.toString().trimEnd()
                val finalState = when {
                    cancelled && continuation != null && sb.length == baseLen -> MessageState.COMPLETE   // la continuación no llegó a empezar: el texto está intacto
                    cancelled -> MessageState.INTERRUPTED
                    else -> state
                }
                runCatching { repo.finish(assistantId, finalText, finalState) }
                _stream.value = null
                _gen.value = GenState(stats = statsText, error = errorText)
                if (finalState == MessageState.COMPLETE && errorText == null && !cancelled) c.storyJobs.autoCheck(sessionId)
            }
        }
    }

    private fun formatReport(r: RpContextResult, ctxLen: Int): String = buildString {
        append("Prompt: ${r.promptTokens} de $ctxLen tokens")
        if (r.pressureStep > 0) append(" · falta espacio: se recortaron secciones opcionales (nivel ${r.pressureStep})")
        append("\n")
        for (x in r.report) {
            append("• ${x.title}: ${x.tokens} tok")
            if (x.note.isNotBlank()) append(" (${x.note})")
            append("\n")
        }
        if (r.loreUsed.isNotEmpty()) append("Lorebook activado: ${r.loreUsed.joinToString(", ")}\n")
        if (r.loreSkipped > 0) append("Entradas activadas que no cupieron: ${r.loreSkipped}\n")
        if (r.droppedMessages > 0) append("Mensajes antiguos fuera del contexto: ${r.droppedMessages}\n")
    }.trimEnd()

    companion object {
        private const val PREPARING = -1L
        private const val SAVE_EVERY_NANOS = 1_500_000_000L
    }
}
