package com.jullai.local.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Base de datos de la app. REGLAS (no negociables):
 *  - exportSchema = true: el esquema de cada versión queda en app/schemas y debe subirse al repositorio.
 *  - NUNCA usar fallbackToDestructiveMigration(). Cada cambio de versión necesita una Migration explícita
 *    que conserve los datos del usuario.
 */
@Database(
    entities = [
        ModelEntity::class, ConversationEntity::class, MessageEntity::class, SettingEntity::class,
        // v0.3: roleplay
        LorebookEntity::class, LoreEntryEntity::class, CharacterEntity::class, ScenarioEntity::class,
        RoleSessionEntity::class, RoleMessageEntity::class, KnowledgeItemEntity::class,
        // v0.4: memoria narrativa, relaciones, capítulos y volúmenes
        MemoryEntity::class, SummaryEntity::class, TimelineEventEntity::class, RelationshipEntity::class,
        RelationshipEventEntity::class, VolumeEntity::class, ChapterEntity::class, MemoryProgressEntity::class,
    ],
    version = 3,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun models(): ModelDao
    abstract fun conversations(): ConversationDao
    abstract fun messages(): MessageDao
    abstract fun settings(): SettingsDao
    abstract fun lorebooks(): LorebookDao
    abstract fun loreEntries(): LoreEntryDao
    abstract fun characters(): CharacterDao
    abstract fun scenarios(): ScenarioDao
    abstract fun roleSessions(): RoleSessionDao
    abstract fun roleMessages(): RoleMessageDao
    abstract fun knowledge(): KnowledgeDao
    abstract fun memories(): MemoryDao
    abstract fun summaries(): SummaryDao
    abstract fun timeline(): TimelineDao
    abstract fun relationships(): RelationshipDao
    abstract fun relationshipEvents(): RelationshipEventDao
    abstract fun volumes(): VolumeDao
    abstract fun chapters(): ChapterDao
    abstract fun memoryProgress(): MemoryProgressDao
    abstract fun messageRange(): MessageRangeDao
    abstract fun sessionLookup(): SessionLookupDao

    companion object {
        const val FILE_NAME = "jullai.db"

        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, FILE_NAME)
                // Migraciones explícitas y NO destructivas (ver Migrations.kt). Jamás borrar datos.
                .addMigrations(Migrations.MIGRATION_1_2, Migrations.MIGRATION_2_3)
                .addCallback(object : RoomDatabase.Callback() {
                    // En cada apertura se comprueba la búsqueda de texto completo (idempotente; nunca lanza).
                    override fun onOpen(db: SupportSQLiteDatabase) { FtsSupport.ensure(db) }
                })
                .build()
    }
}
