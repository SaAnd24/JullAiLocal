package com.jullai.local.story

import com.jullai.local.roleplay.J
import com.jullai.local.roleplay.JArr
import com.jullai.local.roleplay.JBool
import com.jullai.local.roleplay.JNull
import com.jullai.local.roleplay.JNum
import com.jullai.local.roleplay.JObj
import com.jullai.local.roleplay.JStr
import com.jullai.local.roleplay.JsonException
import com.jullai.local.roleplay.MiniJson
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Lectura y escritura de «.jullai» (ZIP versionado). Formato descrito en docs/FORMATO_JULLAI.md.
 *
 *   manifest.json           versión del formato, recuentos, lista de recursos con SHA-256
 *   biblia.md               versión legible (SOLO LECTURA: al importar no se lee)
 *   data/NOMBRE.json             datos estructurados: lo ÚNICO que se importa
 *   assets/<id>.<ext>       retratos ya reducidos
 *
 * Al leer se valida todo (versión, tipos, rangos, listas de valores, identificadores únicos, referencias, recuentos y
 * sumas SHA-256) ANTES de que la app toque la base de datos.
 */
object BibleCodec {
    const val APP_VERSION = "0.4.0"

    // ===================== ESCRITURA =====================

    fun write(bible: Bible, out: OutputStream) {
        val files = encode(bible)
        ZipOutputStream(out).use { z ->
            z.setLevel(6)
            for ((name, bytes) in files) {
                val e = ZipEntry(name)
                e.time = bible.manifest.exportedAt
                z.putNextEntry(e)
                z.write(bytes)
                z.closeEntry()
            }
        }
    }

    /** Todos los archivos del contenedor, en orden. El manifiesto se calcula a partir del contenido real. */
    fun encode(b: Bible): LinkedHashMap<String, ByteArray> {
        val files = LinkedHashMap<String, ByteArray>()
        val refs = ArrayList<BibleAssetRef>()
        val assetFiles = LinkedHashMap<String, ByteArray>()
        for ((id, bytes) in b.assets) {
            require(Regex("[A-Za-z0-9_-]{1,64}").matches(id)) { "Identificador de recurso no válido: $id" }
            val path = "assets/$id.${extensionOf(bytes)}"
            refs.add(BibleAssetRef(id, path, "retrato", bytes.size, sha256(bytes)))
            assetFiles[path] = bytes
        }
        val counts = linkedMapOf(
            "mensajes" to b.messages.size, "conocimiento" to b.knowledge.size, "recuerdos" to b.memories.size,
            "resumenes" to b.summaries.size, "cronologia" to b.timeline.size, "relaciones" to b.relationships.size,
            "eventosRelacion" to b.relEvents.size, "volumenes" to b.volumes.size, "capitulos" to b.chapters.size,
            "entradasLorebook" to (b.lorebook?.entries?.size ?: 0),
        )
        val m = b.manifest.copy(counts = counts, assets = refs)
        files[ZipSafety.MANIFEST] = text(manifestJson(m))
        files[ZipSafety.READABLE] = BibleMarkdown.render(b).toByteArray(Charsets.UTF_8)
        files[ZipSafety.dataPath("personaje")] = text(obj("personaje" to characterJson(b.character), "lorebook" to (b.lorebook?.let { lorebookJson(it) } ?: JNull)))
        files[ZipSafety.dataPath("partida")] = text(sessionJson(b.session))
        files[ZipSafety.dataPath("mensajes")] = text(obj("mensajes" to arr(b.messages.map { messageJson(it) })))
        files[ZipSafety.dataPath("conocimiento")] = text(obj("conocimiento" to arr(b.knowledge.map { obj("scope" to s(it.scope), "text" to s(it.text), "createdAt" to n(it.createdAt)) })))
        files[ZipSafety.dataPath("memoria")] = text(
            obj(
                "recuerdos" to arr(b.memories.map { memoryJson(it) }),
                "resumenes" to arr(b.summaries.map { summaryJson(it) }),
                "cronologia" to arr(b.timeline.map { timelineJson(it) }),
            ),
        )
        files[ZipSafety.dataPath("relaciones")] = text(obj("relaciones" to arr(b.relationships.map { relationshipJson(it) }), "eventos" to arr(b.relEvents.map { relEventJson(it) })))
        files[ZipSafety.dataPath("estructura")] = text(obj("volumenes" to arr(b.volumes.map { volumeJson(it) }), "capitulos" to arr(b.chapters.map { chapterJson(it) })))
        files.putAll(assetFiles)
        return files
    }

    private fun text(j: J) = MiniJson.write(j, pretty = true).toByteArray(Charsets.UTF_8)
    private fun s(v: String): J = JStr(v)
    private fun n(v: Long): J = JNum(v.toDouble())
    private fun n(v: Int): J = JNum(v.toDouble())
    private fun n(v: Float): J = JNum(v.toDouble())
    private fun bo(v: Boolean): J = JBool(v)
    private fun nn(v: Long?): J = if (v == null) JNull else n(v)
    private fun nn(v: Int?): J = if (v == null) JNull else n(v)
    private fun sl(l: List<String>): J = JArr(l.map { JStr(it) })
    private fun arr(l: List<J>): J = JArr(l)
    private fun obj(vararg p: Pair<String, J>): JObj = JObj(linkedMapOf(*p))

    private fun manifestJson(m: BibleManifest) = obj(
        "format" to s(m.format), "formatVersion" to n(m.formatVersion), "minReaderFormat" to n(m.minReaderFormat),
        "app" to s("JullAI Local"), "appVersion" to s(m.appVersion), "exportedAt" to n(m.exportedAt), "title" to s(m.title),
        "counts" to JObj(LinkedHashMap<String, J>().also { mp -> m.counts.forEach { (k, v) -> mp[k] = n(v) } }),
        "assets" to arr(m.assets.map { obj("id" to s(it.id), "path" to s(it.path), "kind" to s(it.kind), "bytes" to n(it.bytes), "sha256" to s(it.sha256)) }),
        "note" to s("Los modelos GGUF nunca se incluyen. Solo se importan los archivos de data/. biblia.md es solo lectura."),
    )

    private fun characterJson(c: BCharacter) = obj(
        "name" to s(c.name), "aliases" to sl(c.aliases), "appearance" to s(c.appearance), "personality" to s(c.personality),
        "speechStyle" to s(c.speechStyle), "history" to s(c.history), "motivations" to s(c.motivations), "likesDislikes" to s(c.likesDislikes),
        "behaviorInstructions" to s(c.behaviorInstructions), "initialRelationship" to s(c.initialRelationship), "scenario" to s(c.scenario),
        "firstMessage" to s(c.firstMessage), "alternateGreetings" to sl(c.alternateGreetings), "dialogueExamples" to s(c.dialogueExamples),
        "privateNotes" to s(c.privateNotes), "tags" to sl(c.tags), "creator" to s(c.creator), "portraitAsset" to (c.portraitAsset?.let { s(it) } ?: JNull),
    )

    private fun lorebookJson(l: BLorebook) = obj(
        "name" to s(l.name), "description" to s(l.description), "scanDepth" to n(l.scanDepth),
        "entries" to arr(
            l.entries.map {
                obj(
                    "name" to s(it.name), "keys" to sl(it.keys), "secondaryKeys" to sl(it.secondaryKeys), "content" to s(it.content),
                    "enabled" to bo(it.enabled), "constant" to bo(it.constant), "selective" to bo(it.selective), "caseSensitive" to bo(it.caseSensitive),
                    "priority" to n(it.priority), "insertionOrder" to n(it.insertionOrder),
                )
            },
        ),
    )

    private fun sessionJson(x: BSession) = obj(
        "title" to s(x.title), "scenarioText" to s(x.scenarioText), "userName" to s(x.userName), "userPersona" to s(x.userPersona),
        "narrativeRules" to s(x.narrativeRules), "summary" to s(x.summary), "temperature" to n(x.temperature), "topP" to n(x.topP),
        "maxTokens" to n(x.maxTokens), "contextLength" to n(x.contextLength), "createdAt" to n(x.createdAt), "updatedAt" to n(x.updatedAt),
        "coveredOrder" to n(x.coveredOrder),
    )

    private fun messageJson(m: BMessage) = obj(
        "id" to n(m.srcId), "role" to s(m.role), "content" to s(m.content), "orderIndex" to n(m.orderIndex), "createdAt" to n(m.createdAt),
        "state" to s(m.state), "swipes" to sl(m.swipes), "swipeIndex" to n(m.swipeIndex),
    )

    private fun memoryJson(m: BMemory) = obj(
        "id" to n(m.srcId), "content" to s(m.content), "importance" to n(m.importance), "narrativeDate" to s(m.narrativeDate), "origin" to s(m.origin),
        "verification" to s(m.verification), "state" to s(m.state), "pinned" to bo(m.pinned), "related" to sl(m.related),
        "sourceMessageId" to nn(m.sourceMessageSrcId), "sourceNote" to s(m.sourceNote), "createdAt" to n(m.createdAt), "updatedAt" to n(m.updatedAt),
    )

    private fun summaryJson(x: BSummary) = obj(
        "version" to n(x.version), "text" to s(x.text), "source" to s(x.source), "coversUpToOrder" to n(x.coversUpToOrder), "note" to s(x.note), "createdAt" to n(x.createdAt),
    )

    private fun timelineJson(t: BTimeline) = obj(
        "id" to n(t.srcId), "text" to s(t.text), "narrativeDate" to s(t.narrativeDate), "orderKey" to n(t.orderKey), "characters" to sl(t.characters),
        "origin" to s(t.origin), "state" to s(t.state), "sourceMessageId" to nn(t.sourceMessageSrcId), "createdAt" to n(t.createdAt),
    )

    private fun relationshipJson(r: BRelationship) = obj(
        "id" to n(r.srcId), "a" to s(r.a), "b" to s(r.b), "trust" to n(r.trust), "affection" to n(r.affection), "respect" to n(r.respect),
        "romantic" to n(r.romantic), "status" to s(r.status), "note" to s(r.note), "createdAt" to n(r.createdAt), "updatedAt" to n(r.updatedAt),
    )

    private fun relEventJson(e: BRelEvent) = obj(
        "relationshipId" to n(e.srcRelationshipId), "state" to s(e.state), "origin" to s(e.origin), "reason" to s(e.reason),
        "dTrust" to n(e.dTrust), "dAffection" to n(e.dAffection), "dRespect" to n(e.dRespect), "dRomantic" to n(e.dRomantic),
        "trustAfter" to nn(e.trustAfter), "affectionAfter" to nn(e.affectionAfter), "respectAfter" to nn(e.respectAfter), "romanticAfter" to nn(e.romanticAfter),
        "sourceMessageId" to nn(e.sourceMessageSrcId), "createdAt" to n(e.createdAt),
    )

    private fun volumeJson(v: BVolume) = obj(
        "id" to n(v.srcId), "number" to n(v.number), "title" to s(v.title), "state" to s(v.state), "continuitySummary" to s(v.continuitySummary),
        "createdAt" to n(v.createdAt), "closedAt" to nn(v.closedAt),
    )

    private fun chapterJson(c: BChapter) = obj(
        "id" to n(c.srcId), "volumeId" to n(c.srcVolumeId), "number" to n(c.number), "title" to s(c.title), "state" to s(c.state),
        "startOrder" to n(c.startOrder), "endOrder" to nn(c.endOrder), "summary" to s(c.summary), "novelText" to s(c.novelText),
        "novelState" to s(c.novelState), "createdAt" to n(c.createdAt), "closedAt" to nn(c.closedAt),
    )

    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    /** Tipo de imagen por los primeros bytes (no por el nombre). */
    fun extensionOf(bytes: ByteArray): String = when {
        bytes.size > 8 && bytes[0] == 0x89.toByte() && bytes[1] == 'P'.code.toByte() -> "png"
        bytes.size > 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
        bytes.size > 12 && String(bytes, 0, 4, Charsets.ISO_8859_1) == "RIFF" && String(bytes, 8, 4, Charsets.ISO_8859_1) == "WEBP" -> "webp"
        else -> "png"
    }

    // ===================== LECTURA Y VALIDACIÓN =====================

    fun read(input: InputStream, limits: ZipSafety.Limits = ZipSafety.Limits()): Bible = decode(ZipSafety.read(input, limits))

    fun decode(files: Map<String, ByteArray>): Bible {
        val warnings = ArrayList<String>()
        val manifest = decodeManifest(files)
        val assets = HashMap<String, ByteArray>()
        for (ref in manifest.assets) {
            val bytes = files[ref.path] ?: throw BibleException("Falta el recurso «${ref.path}» que declara el manifiesto: el archivo está incompleto.")
            if (bytes.size != ref.bytes || sha256(bytes) != ref.sha256) throw BibleException("El recurso «${ref.path}» no coincide con su suma de verificación: el archivo está dañado o fue modificado.")
            assets[ref.id] = bytes
        }
        for (name in files.keys) if (name.startsWith("assets/") && manifest.assets.none { it.path == name })
            throw BibleException("El archivo contiene el recurso «$name» que el manifiesto no declara.")

        fun json(name: String, required: Boolean): JObj? {
            val bytes = files[ZipSafety.dataPath(name)]
            if (bytes == null) { if (required) throw BibleException("Falta data/$name.json: no es un .jullai completo."); return null }
            return parse(bytes, "data/$name.json")
        }
        val pj = json("personaje", true)!!
        val character = decodeCharacter(R(pj.obj("personaje") ?: throw BibleException("data/personaje.json: falta «personaje»."), "personaje"), assets, manifest, warnings)
        val lorebook = pj.obj("lorebook")?.let { decodeLorebook(R(it, "lorebook")) }
        val session = decodeSession(R(json("partida", true)!!, "partida"))
        val mj = json("mensajes", true)!!
        val messages = decodeMessages(mj)
        val msgIds = messages.map { it.srcId }.toSet()
        val knowledge = (json("conocimiento", false)?.arr("conocimiento") ?: emptyList<J>()).let { list ->
            limit(list.size, StoryLimits.MAX_KNOWLEDGE, "elementos de conocimiento")
            list.mapIndexed { i, it ->
                val r = R(it.asObjOrFail("conocimiento[$i]"), "conocimiento[$i]")
                BKnowledge(r.str("scope", 40, req = true), r.str("text", 2000, req = true), r.long("createdAt", 0, Long.MAX_VALUE, 0))
            }
        }
        val memJson = json("memoria", false)
        val memories = decodeList(memJson, "recuerdos", StoryLimits.MAX_MEMORIES, "recuerdos") { r -> decodeMemory(r, msgIds, warnings) }
        ensureUnique(memories.map { it.srcId }, "recuerdos")
        val summaries = decodeList(memJson, "resumenes", StoryLimits.MAX_SUMMARIES, "resúmenes") { r -> decodeSummary(r) }
        if (summaries.map { it.version }.toSet().size != summaries.size) throw BibleException("data/memoria.json: hay versiones de resumen repetidas.")
        val timeline = decodeList(memJson, "cronologia", StoryLimits.MAX_TIMELINE, "acontecimientos") { r -> decodeTimeline(r, msgIds, warnings) }
        ensureUnique(timeline.map { it.srcId }, "cronología")
        val relJson = json("relaciones", false)
        val relationships = decodeList(relJson, "relaciones", StoryLimits.MAX_RELATIONSHIPS, "relaciones") { r -> decodeRelationship(r) }
        ensureUnique(relationships.map { it.srcId }, "relaciones")
        if (relationships.map { TextNorm.fold(it.a) + "\u0000" + TextNorm.fold(it.b) }.toSet().size != relationships.size) throw BibleException("data/relaciones.json: hay relaciones repetidas (mismos dos nombres).")
        val relIds = relationships.map { it.srcId }.toSet()
        val relEvents = decodeList(relJson, "eventos", StoryLimits.MAX_RELATION_EVENTS, "eventos de relación") { r -> decodeRelEvent(r, relIds, msgIds) }
        val structJson = json("estructura", false)
        val volumes = decodeList(structJson, "volumenes", StoryLimits.MAX_VOLUMES, "volúmenes") { r -> decodeVolume(r) }
        ensureUnique(volumes.map { it.srcId }, "volúmenes")
        if (volumes.map { it.number }.toSet().size != volumes.size) throw BibleException("data/estructura.json: hay números de volumen repetidos.")
        if (volumes.count { it.state == VolumeState.ABIERTO } > 1) throw BibleException("data/estructura.json: hay más de un volumen abierto.")
        val volIds = volumes.map { it.srcId }.toSet()
        val chapters = decodeList(structJson, "capitulos", StoryLimits.MAX_CHAPTERS, "capítulos") { r -> decodeChapter(r, volIds) }
        ensureUnique(chapters.map { it.srcId }, "capítulos")
        if (chapters.map { it.number }.toSet().size != chapters.size) throw BibleException("data/estructura.json: hay números de capítulo repetidos.")
        if (chapters.count { it.state == ChapterState.ABIERTO } > 1) throw BibleException("data/estructura.json: hay más de un capítulo abierto.")

        val counts = manifest.counts
        fun chk(key: String, actual: Int) { counts[key]?.let { if (it != actual) throw BibleException("El número de «$key» no coincide con el manifiesto ($actual en lugar de $it): el archivo está incompleto o fue modificado.") } }
        chk("mensajes", messages.size); chk("conocimiento", knowledge.size); chk("recuerdos", memories.size); chk("resumenes", summaries.size)
        chk("cronologia", timeline.size); chk("relaciones", relationships.size); chk("eventosRelacion", relEvents.size)
        chk("volumenes", volumes.size); chk("capitulos", chapters.size); chk("entradasLorebook", lorebook?.entries?.size ?: 0)

        return Bible(manifest, character, lorebook, session, messages, knowledge, memories, summaries, timeline, relationships, relEvents, volumes, chapters, assets, warnings)
    }

    // ---------------- ayudas de lectura ----------------

    private fun parse(bytes: ByteArray, name: String): JObj {
        val j = try { MiniJson.parse(String(bytes, Charsets.UTF_8)) } catch (e: JsonException) { throw BibleException("$name no es un JSON válido: ${e.message}") }
        return j as? JObj ?: throw BibleException("$name no tiene el formato esperado.")
    }

    private fun J?.asObjOrFail(where: String): JObj = this as? JObj ?: throw BibleException("$where: se esperaba un objeto.")
    private fun JObj.arr(key: String): List<J>? = (fields[key] as? JArr)?.items
    private fun JObj.obj(key: String): JObj? = fields[key] as? JObj
    private fun limit(actual: Int, max: Int, what: String) { if (actual > max) throw BibleException("El archivo tiene demasiados $what ($actual; máximo $max).") }
    private fun ensureUnique(ids: List<Long>, what: String) { if (ids.toSet().size != ids.size) throw BibleException("El archivo tiene identificadores repetidos en $what.") }

    private fun <T> decodeList(file: JObj?, key: String, max: Int, what: String, f: (R) -> T): List<T> {
        val list = file?.arr(key) ?: return emptyList()
        limit(list.size, max, what)
        return list.mapIndexed { i, it -> f(R(it.asObjOrFail("$key[$i]"), "$key[$i]")) }
    }

    private class R(val o: JObj, val path: String) {
        fun fail(msg: String): Nothing = throw BibleException("$path: $msg")

        fun str(k: String, max: Int, req: Boolean = false, def: String = ""): String {
            val v = o.fields[k]
            if (v == null || v is JNull) { if (req) fail("falta «$k»."); return def }
            val s = (v as? JStr)?.v ?: fail("«$k» debe ser texto.")
            if (s.length > max) fail("«$k» es demasiado largo (${s.length} caracteres; máximo $max).")
            if (req && s.isBlank()) fail("«$k» no puede estar vacío.")
            return s
        }

        fun long(k: String, min: Long, max: Long, def: Long?): Long {
            val v = o.fields[k]
            if (v == null || v is JNull) return def ?: fail("falta «$k».")
            val d = (v as? JNum)?.v ?: fail("«$k» debe ser un número.")
            if (d.isNaN() || d.isInfinite() || d != Math.floor(d)) fail("«$k» debe ser un número entero.")
            val l = d.toLong()
            if (l < min || l > max) fail("«$k» fuera de rango ($l; permitido $min a $max).")
            return l
        }

        fun int(k: String, min: Int, max: Int, def: Int? = null): Int = long(k, min.toLong(), max.toLong(), def?.toLong()).toInt()

        fun nullLong(k: String): Long? = if (o.fields[k] == null || o.fields[k] is JNull) null else long(k, 0, Long.MAX_VALUE, null)
        fun nullInt(k: String, min: Int, max: Int): Int? = if (o.fields[k] == null || o.fields[k] is JNull) null else int(k, min, max)

        fun bool(k: String, def: Boolean): Boolean {
            val v = o.fields[k] ?: return def
            if (v is JNull) return def
            return (v as? JBool)?.v ?: fail("«$k» debe ser sí/no.")
        }

        fun float(k: String, min: Float, max: Float, def: Float): Float {
            val v = o.fields[k] ?: return def
            if (v is JNull) return def
            val d = (v as? JNum)?.v ?: fail("«$k» debe ser un número.")
            if (d.isNaN() || d.isInfinite()) fail("«$k» no es un número válido.")
            return d.toFloat().coerceIn(min, max)
        }

        fun strList(k: String, maxItems: Int, maxLen: Int): List<String> {
            val v = o.fields[k] ?: return emptyList()
            if (v is JNull) return emptyList()
            val a = (v as? JArr)?.items ?: fail("«$k» debe ser una lista.")
            if (a.size > maxItems) fail("«$k» tiene demasiados elementos (máximo $maxItems).")
            return a.map { x ->
                val s = (x as? JStr)?.v ?: fail("«$k» solo puede contener texto.")
                if (s.length > maxLen) fail("Un elemento de «$k» es demasiado largo.")
                s
            }
        }

        fun oneOf(k: String, allowed: Set<String>, def: String? = null): String {
            val v = str(k, 40, req = def == null, def = def ?: "")
            if (v !in allowed) fail("«$k» tiene un valor desconocido («$v»).")
            return v
        }
    }

    private fun decodeManifest(files: Map<String, ByteArray>): BibleManifest {
        val bytes = files[ZipSafety.MANIFEST] ?: throw BibleException("Falta manifest.json: no es un .jullai de esta app.")
        val r = R(parse(bytes, "manifest.json"), "manifest")
        val format = r.str("format", 40, req = true)
        if (format != BibleManifest.FORMAT) throw BibleException("Este archivo no es una partida de JullAI (formato «$format»).")
        val version = r.int("formatVersion", 1, 10_000)
        val minReader = r.int("minReaderFormat", 1, 10_000, def = version)
        if (minReader > BibleManifest.FORMAT_VERSION)
            throw BibleException("Este archivo se creó con una versión más nueva de JullAI (formato $version). Actualiza la app para importarlo.")
        val countsObj = r.o.obj("counts")
        val counts = LinkedHashMap<String, Int>()
        countsObj?.fields?.forEach { (k, v) ->
            val d = (v as? JNum)?.v ?: throw BibleException("manifest: el recuento «$k» no es un número.")
            if (d < 0 || d > 1e9 || d != Math.floor(d)) throw BibleException("manifest: el recuento «$k» no es válido.")
            counts[k] = d.toInt()
        }
        val assets = ArrayList<BibleAssetRef>()
        val list = r.o.arr("assets") ?: emptyList()
        if (list.size > 32) throw BibleException("manifest: demasiados recursos.")
        list.forEachIndexed { i, it ->
            val a = R(it.asObjOrFail("assets[$i]"), "manifest.assets[$i]")
            val id = a.str("id", 64, req = true)
            val path = a.str("path", 100, req = true)
            if (!Regex("[A-Za-z0-9_-]{1,64}").matches(id)) a.fail("identificador de recurso no válido.")
            ZipSafety.checkName(path)
            if (!path.startsWith("assets/")) a.fail("la ruta del recurso no es de assets/.")
            if (assets.any { x -> x.id == id || x.path == path }) a.fail("recurso repetido.")
            assets.add(BibleAssetRef(id, path, a.str("kind", 20, def = "retrato"), a.int("bytes", 0, Int.MAX_VALUE), a.str("sha256", 64, req = true).lowercase()))
        }
        return BibleManifest(format, version, minReader, r.str("appVersion", 40, def = "?"), r.long("exportedAt", 0, Long.MAX_VALUE, 0), r.str("title", 200, def = ""), counts, assets)
    }

    private fun decodeCharacter(r: R, assets: Map<String, ByteArray>, manifest: BibleManifest, warnings: MutableList<String>): BCharacter {
        val portrait = r.str("portraitAsset", 64).ifEmpty { null }
        var portraitOk = portrait
        if (portrait != null && !assets.containsKey(portrait)) { warnings.add("El retrato declarado no está en el archivo: se importará sin imagen."); portraitOk = null }
        return BCharacter(
            name = r.str("name", 200, req = true), aliases = r.strList("aliases", 50, 200),
            appearance = r.str("appearance", 20_000), personality = r.str("personality", 20_000), speechStyle = r.str("speechStyle", 20_000),
            history = r.str("history", 40_000), motivations = r.str("motivations", 20_000), likesDislikes = r.str("likesDislikes", 20_000),
            behaviorInstructions = r.str("behaviorInstructions", 20_000), initialRelationship = r.str("initialRelationship", 20_000),
            scenario = r.str("scenario", 20_000), firstMessage = r.str("firstMessage", 20_000), alternateGreetings = r.strList("alternateGreetings", 40, 20_000),
            dialogueExamples = r.str("dialogueExamples", 40_000), privateNotes = r.str("privateNotes", 40_000), tags = r.strList("tags", 100, 100),
            creator = r.str("creator", 200), portraitAsset = portraitOk,
        )
    }

    private fun decodeLorebook(r: R): BLorebook {
        val list = r.o.arr("entries") ?: emptyList()
        limit(list.size, StoryLimits.MAX_LORE_ENTRIES, "entradas de lorebook")
        return BLorebook(
            r.str("name", 200, def = "Lorebook"), r.str("description", 2000), r.int("scanDepth", 1, 50, 4),
            list.mapIndexed { i, it ->
                val e = R(it.asObjOrFail("entries[$i]"), "lorebook.entries[$i]")
                BLoreEntry(
                    e.str("name", 200), e.strList("keys", 100, 200), e.strList("secondaryKeys", 100, 200), e.str("content", 20_000),
                    e.bool("enabled", true), e.bool("constant", false), e.bool("selective", false), e.bool("caseSensitive", false),
                    e.int("priority", -100_000, 100_000, 10), e.int("insertionOrder", -100_000, 100_000, 100),
                )
            },
        )
    }

    private fun decodeSession(r: R) = BSession(
        title = r.str("title", 200, req = true), scenarioText = r.str("scenarioText", 20_000), userName = r.str("userName", 80, req = true),
        userPersona = r.str("userPersona", 20_000), narrativeRules = r.str("narrativeRules", 20_000), summary = r.str("summary", StoryLimits.SUMMARY_CHARS),
        temperature = r.float("temperature", 0f, 2f, 0.85f), topP = r.float("topP", 0.1f, 1f, 0.92f),
        maxTokens = r.int("maxTokens", 16, 2048, 384), contextLength = r.int("contextLength", 512, 8192, 4096),
        createdAt = r.long("createdAt", 0, Long.MAX_VALUE, 0), updatedAt = r.long("updatedAt", 0, Long.MAX_VALUE, 0),
        coveredOrder = r.int("coveredOrder", -1, Int.MAX_VALUE, -1),
    )

    private val ROLES = setOf("user", "assistant")
    private val MSG_STATES = setOf("COMPLETE", "GENERATING", "INTERRUPTED", "ERROR")

    private fun decodeMessages(f: JObj): List<BMessage> {
        val list = f.arr("mensajes") ?: throw BibleException("data/mensajes.json: falta «mensajes».")
        limit(list.size, StoryLimits.MAX_MESSAGES, "mensajes")
        val ids = HashSet<Long>()
        val orders = HashSet<Int>()
        return list.mapIndexed { i, it ->
            val r = R(it.asObjOrFail("mensajes[$i]"), "mensajes[$i]")
            val id = r.long("id", 0, Long.MAX_VALUE, null)
            val order = r.int("orderIndex", 0, Int.MAX_VALUE)
            if (!ids.add(id)) r.fail("identificador de mensaje repetido.")
            if (!orders.add(order)) r.fail("posición de mensaje repetida ($order).")
            val swipes = r.strList("swipes", 40, StoryLimits.MAX_MESSAGE_CHARS)
            // Una respuesta que se estaba generando al exportar pasa a «interrumpida»: aquí no hay ninguna generación en curso.
            val state = r.oneOf("state", MSG_STATES, "COMPLETE").let { if (it == "GENERATING") "INTERRUPTED" else it }
            BMessage(
                id, r.oneOf("role", ROLES), r.str("content", StoryLimits.MAX_MESSAGE_CHARS), order, r.long("createdAt", 0, Long.MAX_VALUE, 0), state,
                swipes, r.int("swipeIndex", 0, 1000, 0).coerceAtMost((swipes.size - 1).coerceAtLeast(0)),
            )
        }.sortedBy { it.orderIndex }
    }

    private fun refMsg(r: R, key: String, ids: Set<Long>, warnings: MutableList<String>): Long? {
        val v = r.nullLong(key) ?: return null
        if (v !in ids) { warnings.add("${r.path}: el mensaje de origen ya no existe; se importa sin referencia."); return null }
        return v
    }

    private fun decodeMemory(r: R, msgIds: Set<Long>, warnings: MutableList<String>) = BMemory(
        srcId = r.long("id", 0, Long.MAX_VALUE, null), content = r.str("content", StoryLimits.MEMORY_CHARS, req = true),
        importance = r.int("importance", 1, 5, 3), narrativeDate = r.str("narrativeDate", StoryLimits.DATE_CHARS),
        origin = r.oneOf("origin", Origin.MEMORY, Origin.USUARIO), verification = r.oneOf("verification", Verification.ALL),
        state = r.oneOf("state", ItemState.ALL, ItemState.ACTIVO), pinned = r.bool("pinned", false), related = r.strList("related", 20, StoryLimits.NAME_CHARS),
        sourceMessageSrcId = refMsg(r, "sourceMessageId", msgIds, warnings), sourceNote = r.str("sourceNote", StoryLimits.NOTE_CHARS),
        createdAt = r.long("createdAt", 0, Long.MAX_VALUE, 0), updatedAt = r.long("updatedAt", 0, Long.MAX_VALUE, 0),
    )

    private fun decodeSummary(r: R) = BSummary(
        r.int("version", 1, Int.MAX_VALUE), r.str("text", StoryLimits.SUMMARY_CHARS), r.oneOf("source", Origin.SUMMARY, Origin.USUARIO),
        r.int("coversUpToOrder", -1, Int.MAX_VALUE, -1), r.str("note", StoryLimits.NOTE_CHARS), r.long("createdAt", 0, Long.MAX_VALUE, 0),
    )

    private fun decodeTimeline(r: R, msgIds: Set<Long>, warnings: MutableList<String>) = BTimeline(
        r.long("id", 0, Long.MAX_VALUE, null), r.str("text", StoryLimits.TIMELINE_CHARS, req = true), r.str("narrativeDate", StoryLimits.DATE_CHARS),
        r.int("orderKey", -1_000_000, 1_000_000_000, 0), r.strList("characters", 20, StoryLimits.NAME_CHARS), r.oneOf("origin", Origin.TIMELINE, Origin.USUARIO),
        r.oneOf("state", ItemState.ALL, ItemState.ACTIVO), refMsg(r, "sourceMessageId", msgIds, warnings), r.long("createdAt", 0, Long.MAX_VALUE, 0),
    )

    private fun decodeRelationship(r: R) = BRelationship(
        r.long("id", 0, Long.MAX_VALUE, null), r.str("a", StoryLimits.NAME_CHARS, req = true), r.str("b", StoryLimits.NAME_CHARS, req = true),
        r.int("trust", 1, 100), r.int("affection", 1, 100), r.int("respect", 1, 100), r.int("romantic", 1, 100),
        r.str("status", 120), r.str("note", StoryLimits.NOTE_CHARS), r.long("createdAt", 0, Long.MAX_VALUE, 0), r.long("updatedAt", 0, Long.MAX_VALUE, 0),
    )

    private fun decodeRelEvent(r: R, relIds: Set<Long>, msgIds: Set<Long>): BRelEvent {
        val rel = r.long("relationshipId", 0, Long.MAX_VALUE, null)
        if (rel !in relIds) r.fail("hace referencia a una relación que no existe en el archivo.")
        val src = r.nullLong("sourceMessageId")?.takeIf { it in msgIds }
        return BRelEvent(
            rel, r.oneOf("state", EventState.ALL), r.oneOf("origin", Origin.RELATION_EVENT, Origin.USUARIO), r.str("reason", StoryLimits.REASON_CHARS),
            r.int("dTrust", -100, 100, 0), r.int("dAffection", -100, 100, 0), r.int("dRespect", -100, 100, 0), r.int("dRomantic", -100, 100, 0),
            r.nullInt("trustAfter", 1, 100), r.nullInt("affectionAfter", 1, 100), r.nullInt("respectAfter", 1, 100), r.nullInt("romanticAfter", 1, 100),
            src, r.long("createdAt", 0, Long.MAX_VALUE, 0),
        )
    }

    private fun decodeVolume(r: R) = BVolume(
        r.long("id", 0, Long.MAX_VALUE, null), r.int("number", 1, 100_000), r.str("title", StoryLimits.TITLE_CHARS),
        r.oneOf("state", VolumeState.ALL), r.str("continuitySummary", StoryLimits.SUMMARY_CHARS), r.long("createdAt", 0, Long.MAX_VALUE, 0), r.nullLong("closedAt"),
    )

    private fun decodeChapter(r: R, volIds: Set<Long>): BChapter {
        val vol = r.long("volumeId", 0, Long.MAX_VALUE, null)
        if (vol !in volIds) r.fail("hace referencia a un volumen que no existe en el archivo.")
        val start = r.int("startOrder", 0, Int.MAX_VALUE)
        val end = r.nullInt("endOrder", 0, Int.MAX_VALUE)
        if (end != null && end < start) r.fail("el capítulo termina antes de empezar.")
        val state = r.oneOf("state", ChapterState.ALL)
        if (state == ChapterState.CERRADO && end == null) r.fail("un capítulo cerrado necesita «endOrder».")
        return BChapter(
            r.long("id", 0, Long.MAX_VALUE, null), vol, r.int("number", 1, 100_000), r.str("title", StoryLimits.TITLE_CHARS), state, start, end,
            r.str("summary", StoryLimits.SUMMARY_CHARS), r.str("novelText", StoryLimits.NOVEL_CHARS), r.oneOf("novelState", NovelState.ALL, NovelState.NINGUNA),
            r.long("createdAt", 0, Long.MAX_VALUE, 0), r.nullLong("closedAt"),
        )
    }
}
