package com.jullai.local

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.jullai.local.chat.ChatViewModel
import com.jullai.local.roleplay.CharactersViewModel
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.StoryViewModel
import com.jullai.local.ui.AppRoot

class MainActivity : ComponentActivity() {
    private val container: AppContainer get() = (application as JullApp).container

    private val chatVm: ChatViewModel by viewModels { factoryOf { ChatViewModel(container) } }
    private val modelsVm: ModelsViewModel by viewModels { factoryOf { ModelsViewModel(container) } }
    private val settingsVm: SettingsViewModel by viewModels { factoryOf { SettingsViewModel(container) } }
    private val charactersVm: CharactersViewModel by viewModels { factoryOf { CharactersViewModel(container) } }
    private val rpVm: RoleplayViewModel by viewModels { factoryOf { RoleplayViewModel(container) } }
    private val storyVm: StoryViewModel by viewModels { factoryOf { StoryViewModel(container) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // El selector de archivos del sistema (SAF) no necesita permisos de almacenamiento.
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) modelsVm.importModel(uri)
            }
            AppRoot(chatVm, modelsVm, settingsVm, charactersVm, rpVm, storyVm, onPickModel = { picker.launch(arrayOf("*/*")) })
        }
    }

    override fun onDestroy() {
        // Si la actividad termina de verdad (no es un giro de pantalla), se liberan los recursos nativos.
        if (isFinishing) container.releaseNative()
        super.onDestroy()
    }

    private fun <T : ViewModel> factoryOf(block: () -> T): ViewModelProvider.Factory =
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <V : ViewModel> create(modelClass: Class<V>): V = block() as V
        }
}
