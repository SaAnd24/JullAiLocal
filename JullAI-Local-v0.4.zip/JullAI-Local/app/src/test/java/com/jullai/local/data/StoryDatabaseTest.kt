package com.jullai.local.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.jullai.local.story.BibleCodec
import com.jullai.local.story.BibleException
import com.jullai.local.story.ChapterState
import com.jullai.local.story.EventState
import com.jullai.local.story.ItemState
import com.jullai.local.story.Origin
import com.jullai.local.story.ProposedEvent
import com.jullai.local.story.ProposedMemory
import com.jullai.local.story.ProposedRelation
import com.jullai.local.story.RankedMemoryRetriever
import com.jullai.local.story.RelDelta
import com.jullai.local.story.RelValues
import com.jullai.local.story.RetrievalRequest
import com.jullai.local.story.Verification
import com.jullai.local.story.VolumeState
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Memoria, relaciones, capítulos/volúmenes y exportación contra una base Room REAL (Robolectric). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class StoryDatabaseTest {
    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var role: RoleplayRepository
    private lateinit var story: StoryRepository
    private var clock = 1_000L

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        role = RoleplayRepository(db) { clock++ }
        story = StoryRepository(db) { clock++ }
    }

    @After fun tearDown() { db.close() }

    private fun newSession(name: String = "Aria", user: String = "Ana", model: String? = "a.gguf"): Long = runBlocking {
        val c = CharacterEntity(name = name, firstMessage = "Hola, viajera.", createdAt = 1, updatedAt = 1)
        val id = role.saveCharacter(c)
        role.startSession(c.copy(id = id), "una taberna", user, "exploradora", AppSettings(), model)
    }

    private suspend fun say(sid: Long, text: String, reply: String) {
        val (_, a) = role.appendUserTurn(sid, text)
        role.finish(a, reply, MessageState.COMPLETE)
    }

    // ---------------- recuerdos ----------------

    @Test fun memoryCrudAndPinned() = runBlocking {
        val sid = newSession()
        val id = story.addMemory(sid, "Aria guarda el mapa en la torre.", 4, "primer día", listOf("Aria"), false)
        assertEquals(Verification.CONFIRMADO, db.memories().get(id)!!.verification)
        story.setPinned(id, true)
        assertTrue(db.memories().get(id)!!.pinned)
        story.editMemory(id, "Aria esconde el mapa en la torre norte.", 5, "primer día", listOf("Aria"))
        assertEquals("Aria esconde el mapa en la torre norte.", db.memories().get(id)!!.content)
        assertTrue("editar no quita lo fijado", db.memories().get(id)!!.pinned)
        story.deleteMemory(id)
        assertNull(db.memories().get(id))
    }

    @Test fun proposalsNeverBecomeActiveWithoutTheUser() = runBlocking {
        val sid = newSession()
        val n = story.proposeMemories(sid, listOf(ProposedMemory("Ana desconfía del posadero.", 3, true), ProposedMemory("El mapa está en la torre.", 4, false)), null, "análisis")
        assertEquals(2, n)
        assertEquals("nada activo todavía", 0, db.memories().listActive(sid).size)
        val inferred = db.memories().listAll(sid).first { it.verification == Verification.INFERIDO }
        assertEquals(ItemState.PROPUESTO, inferred.state)
        story.acceptMemory(inferred.id, "Ana desconfía mucho del posadero.")
        val after = db.memories().get(inferred.id)!!
        assertEquals(ItemState.ACTIVO, after.state)
        assertEquals("aceptar es una decisión del usuario", Verification.CONFIRMADO, after.verification)
        assertEquals("Ana desconfía mucho del posadero.", after.content)
        val other = db.memories().listAll(sid).first { it.state == ItemState.PROPUESTO }
        story.discardMemory(other.id)
        assertEquals(ItemState.DESCARTADO, db.memories().get(other.id)!!.state)
        // Lo descartado no vuelve a proponerse.
        assertEquals(0, story.proposeMemories(sid, listOf(ProposedMemory("El mapa está en la torre.", 4, false)), null, "x"))
    }

    @Test fun automaticProposalsNeverTouchPinnedOrExistingMemories() = runBlocking {
        val sid = newSession()
        val id = story.addMemory(sid, "Aria jamás miente.", 5, "", emptyList(), true)
        story.proposeMemories(sid, listOf(ProposedMemory("Aria jamás miente.", 5, false), ProposedMemory("Aria miente a menudo.", 3, true)), null, "x")
        val m = db.memories().get(id)!!
        assertEquals("Aria jamás miente.", m.content)
        assertTrue(m.pinned)
        assertEquals(ItemState.ACTIVO, m.state)
    }

    @Test fun pinningAProposalIsRefused() = runBlocking {
        val sid = newSession()
        story.proposeMemories(sid, listOf(ProposedMemory("Un hecho propuesto.", 3, false)), null, "x")
        val p = db.memories().listAll(sid).single()
        try { story.setPinned(p.id, true); fail("debía rechazarse") } catch (e: StoryException) { assertFalse(db.memories().get(p.id)!!.pinned) }
    }

    @Test fun memoriesPersistAcrossDatabaseReopen() = runBlocking {
        val name = "persist-story.db"
        context.deleteDatabase(name)
        var d = Room.databaseBuilder(context, AppDatabase::class.java, name).addMigrations(Migrations.MIGRATION_1_2, Migrations.MIGRATION_2_3).allowMainThreadQueries().build()
        val r = RoleplayRepository(d) { clock++ }
        val s = StoryRepository(d) { clock++ }
        val c = CharacterEntity(name = "Aria", firstMessage = "Hola", createdAt = 1, updatedAt = 1)
        val cid = r.saveCharacter(c)
        val sid = r.startSession(c.copy(id = cid), "", "Ana", "", AppSettings(), null)
        s.addMemory(sid, "El pacto se rompió en el puente.", 5, "", listOf("Aria"), true)
        s.saveSummary(sid, "Resumen guardado", Origin.USUARIO)
        d.close()
        d = Room.databaseBuilder(context, AppDatabase::class.java, name).addMigrations(Migrations.MIGRATION_1_2, Migrations.MIGRATION_2_3).allowMainThreadQueries().build()
        try {
            val back = d.memories().listActive(sid).single()
            assertEquals("El pacto se rompió en el puente.", back.content)
            assertTrue(back.pinned)
            assertEquals("Resumen guardado", d.roleSessions().get(sid)!!.summary)
        } finally { d.close(); context.deleteDatabase(name) }
    }

    @Test fun retrievalFindsAnOldMemoryInALaterScene() = runBlocking {
        val sid = newSession()
        story.addMemory(sid, "El herrero Doran forjó la espada rota del rey.", 4, "año 3", listOf("Doran"), false)
        repeat(30) { story.addMemory(sid, "Dato de relleno número $it sobre mercados y cosechas.", 2, "", emptyList(), false) }
        val r = RankedMemoryRetriever(story).retrieve(
            RetrievalRequest(sid, listOf("¿Quién arregló la espada del rey?", "Pregunto por Doran, el herrero."), listOf("Aria", "Ana"), 400),
        ) { it.length / 4 }
        assertTrue("debe recuperar el recuerdo del herrero", r.memories.any { it.text.contains("Doran") })
        assertTrue("sin salirse del presupuesto", r.usedTokens <= 400)
    }

    @Test fun pinnedMemoriesNeverOverflowTheBudget() = runBlocking {
        val sid = newSession()
        repeat(40) { story.addMemory(sid, "Recuerdo fijado largo número $it con bastante texto para ocupar sitio en el contexto del modelo.", 5, "", emptyList(), true) }
        val r = RankedMemoryRetriever(story).retrieve(RetrievalRequest(sid, listOf("hola"), listOf("Aria", "Ana"), 300)) { it.length / 4 }
        assertTrue(r.usedTokens <= 300)
        assertTrue(r.memories.isNotEmpty())
    }

    @Test fun modelSwitchKeepsMemories() = runBlocking {
        val sid = newSession(model = "a.gguf")
        story.addMemory(sid, "Hecho que debe sobrevivir al cambio de modelo.", 3, "", emptyList(), false)
        val s = db.roleSessions().get(sid)!!
        role.updateSession(s.copy(modelFileName = "b.gguf"))
        assertEquals(1, db.memories().listActive(sid).size)
    }

    @Test fun memoriesBelongToTheirSessionOnly() = runBlocking {
        val a = newSession(name = "Aria"); val b = newSession(name = "Bruno")
        story.addMemory(a, "Secreto de la partida A.", 3, "", emptyList(), false)
        assertEquals(0, db.memories().listActive(b).size)
        assertEquals(0, story.searchMemories(b, "secreto").size)
        db.roleSessions().delete(a)
        assertEquals(0, db.memories().listAll(a).size)
    }

    // ---------------- relaciones ----------------

    @Test fun relationshipsArePerSessionAndDefaultsAreNeutral() = runBlocking {
        val a = newSession(); val b = newSession()
        story.ensureDefaultRelationship(a, "Aria", "Ana")
        story.ensureDefaultRelationship(a, "Aria", "Ana")   // idempotente
        assertEquals(1, db.relationships().list(a).size)
        assertEquals(0, db.relationships().list(b).size)
        val r = db.relationships().list(a).single()
        assertTrue(listOf(r.trust, r.affection, r.respect, r.romantic).all { it in 1..100 })
    }

    @Test fun modelProposalIsLimitedAndNeedsAcceptance() = runBlocking {
        val sid = newSession()
        story.ensureDefaultRelationship(sid, "Aria", "Ana")
        val before = db.relationships().list(sid).single()
        val n = story.proposeRelationChanges(sid, listOf(ProposedRelation("Aria", "Ana", RelDelta(40, 0, 0, 0), "Ana la salvó de una emboscada")), null)
        assertEquals(1, n)
        assertEquals("proponer no cambia nada", before.trust, db.relationships().get(before.id)!!.trust)
        val ev = db.relationshipEvents().list(sid).first { it.state == EventState.PROPUESTO }
        assertTrue("el salto se recorta al máximo permitido", ev.dTrust in 1..6)
        assertNull(story.acceptRelationEvent(ev.id))
        assertEquals(before.trust + ev.dTrust, db.relationships().get(before.id)!!.trust)
        assertEquals(EventState.APLICADO, db.relationshipEvents().get(ev.id)!!.state)
    }

    @Test fun proposalWithoutReasonOrForUnknownPeopleIsIgnored() = runBlocking {
        val sid = newSession()
        story.ensureDefaultRelationship(sid, "Aria", "Ana")
        assertEquals(0, story.proposeRelationChanges(sid, listOf(ProposedRelation("Aria", "Ana", RelDelta(3, 0, 0, 0), "")), null))
        assertEquals(0, story.proposeRelationChanges(sid, listOf(ProposedRelation("Aria", "Fantasma", RelDelta(3, 0, 0, 0), "porque sí")), null))
    }

    @Test fun manualCorrectionKeepsHistoryAndStaysInRange() = runBlocking {
        val sid = newSession()
        story.ensureDefaultRelationship(sid, "Aria", "Ana")
        val r = db.relationships().list(sid).single()
        story.setRelationshipManually(r.id, RelValues(90, 10, 55, 1), "aliados", "Lo decidí yo")
        val now = db.relationships().get(r.id)!!
        assertEquals(listOf(90, 10, 55, 1), listOf(now.trust, now.affection, now.respect, now.romantic))
        assertTrue(db.relationshipEvents().listFor(r.id).any { it.origin == Origin.USUARIO && it.reason == "Lo decidí yo" })
        try { story.setRelationshipManually(r.id, RelValues(0, 10, 55, 1), "", "x"); fail("fuera de rango") } catch (e: Exception) { /* correcto */ }
        assertEquals(90, db.relationships().get(r.id)!!.trust)
    }

    // ---------------- resúmenes ----------------

    @Test fun summariesAreVersionedAndRestorable() = runBlocking {
        val sid = newSession()
        story.saveSummary(sid, "Primera versión.", Origin.USUARIO)
        story.saveSummary(sid, "Segunda versión.", Origin.MODELO)
        val restored = story.restoreSummary(sid, 1)
        assertEquals(3, restored)
        assertEquals("Primera versión.", db.roleSessions().get(sid)!!.summary)
        assertEquals("el historial nunca se reescribe", "Segunda versión.", db.summaries().get(sid, 2)!!.text)
    }

    // ---------------- capítulos y volúmenes ----------------

    @Test fun chapterAndVolumeLifecycleKeepsStateAndOriginalLog() = runBlocking {
        val sid = newSession()
        story.ensureStructure(sid)
        say(sid, "Primer mensaje", "Primera respuesta")
        story.addMemory(sid, "Un hecho del volumen uno.", 3, "", emptyList(), false)
        story.ensureDefaultRelationship(sid, "Aria", "Ana")
        val messagesBefore = db.roleMessages().list(sid).map { it.content }

        val next = story.closeChapter(sid, true)
        assertNotNull(next)
        assertEquals(1, db.chapters().list(sid).count { it.state == ChapterState.CERRADO })
        say(sid, "Segundo mensaje", "Segunda respuesta")

        story.closeVolume(sid, "Continuidad: Ana y Aria cruzaron el puente.")
        val vols = db.volumes().list(sid)
        assertEquals(2, vols.size)
        assertEquals(VolumeState.ARCHIVADO, vols.first { it.number == 1 }.state)
        assertEquals(VolumeState.ABIERTO, vols.first { it.number == 2 }.state)
        assertEquals("Continuidad: Ana y Aria cruzaron el puente.", db.roleSessions().get(sid)!!.summary)
        // El nuevo volumen conserva recuerdos, relaciones y mensajes.
        assertEquals(1, db.memories().listActive(sid).size)
        assertEquals(1, db.relationships().list(sid).size)
        assertTrue(db.roleMessages().list(sid).map { it.content }.containsAll(messagesBefore))
        assertNotNull(db.chapters().open(sid))
    }

    @Test fun reopenVolumeOnlyWhileTheNextOneIsEmpty() = runBlocking {
        val sid = newSession()
        story.ensureStructure(sid)
        say(sid, "uno", "dos")
        story.closeVolume(sid, "Resumen de cierre.")
        val v1 = db.volumes().list(sid).first { it.number == 1 }
        story.reopenVolume(v1.id)
        assertEquals(1, db.volumes().list(sid).size)
        assertEquals(VolumeState.ABIERTO, db.volumes().get(v1.id)!!.state)
        // Si el volumen siguiente ya tiene mensajes, no se puede deshacer.
        story.closeVolume(sid, "Otro cierre.")
        say(sid, "tres", "cuatro")
        val v1b = db.volumes().list(sid).first { it.number == 1 }
        try { story.reopenVolume(v1b.id); fail("debía rechazarse") } catch (e: StoryException) { assertEquals(2, db.volumes().list(sid).size) }
    }

    @Test fun novelEditDoesNotChangeOriginalMessages() = runBlocking {
        val sid = newSession()
        story.ensureStructure(sid)
        say(sid, "Entro a la sala.", "Una sombra se mueve.")
        val chId = story.closeChapter(sid, false).let { db.chapters().list(sid).first().id }
        val before = db.roleMessages().list(sid).map { it.content }
        story.saveNovelGenerated(chId, "Entró en la sala; una sombra se movió.")
        story.saveNovelEdited(chId, "Texto corregido por mí.")
        assertEquals("Texto corregido por mí.", db.chapters().get(chId)!!.novelText)
        assertEquals(before, db.roleMessages().list(sid).map { it.content })
    }

    // ---------------- exportar / importar ----------------

    private fun roundTrip(sid: Long): com.jullai.local.story.Bible {
        val bible = BibleService(db) { clock++ }.let { svc -> runBlocking { svc.export(sid) { null } } }
        val out = ByteArrayOutputStream(); BibleCodec.write(bible, out)
        return BibleCodec.read(ByteArrayInputStream(out.toByteArray()))
    }

    @Test fun exportImportRoundTripCreatesAnIndependentSession() = runBlocking {
        val sid = newSession()
        story.ensureStructure(sid)
        say(sid, "Hola Aria", "Hola Ana")
        story.addMemory(sid, "Ana prometió volver al faro.", 4, "noche", listOf("Ana"), true)
        story.proposeMemories(sid, listOf(ProposedMemory("Aria teme al mar.", 3, true)), null, "x")
        story.addEvent(sid, "Llegaron al faro.", "noche", listOf("Ana"), null)
        story.ensureDefaultRelationship(sid, "Aria", "Ana")
        story.saveSummary(sid, "Resumen para exportar.", Origin.USUARIO)

        val bible = roundTrip(sid)
        val svc = BibleService(db) { clock++ }
        val newId = svc.import(bible, null)

        assertNotEquals(sid, newId)
        val copy = db.roleSessions().get(newId)!!
        assertEquals("Resumen para exportar.", copy.summary)
        assertNull("el modelo no viaja en el archivo", copy.modelFileName)
        assertEquals(db.roleMessages().list(sid).map { it.content }, db.roleMessages().list(newId).map { it.content })
        assertEquals(1, db.memories().listActive(newId).size)
        assertTrue(db.memories().listActive(newId).single().pinned)
        assertEquals("las propuestas pendientes siguen pendientes", 1, db.memories().listAll(newId).count { it.state == ItemState.PROPUESTO })
        assertEquals(1, db.timeline().listActive(newId).size)
        assertEquals(1, db.relationships().list(newId).size)
        // La original no cambió y la copia es independiente.
        assertEquals(1, db.memories().listActive(sid).size)
        story.addMemory(newId, "Solo en la copia.", 3, "", emptyList(), false)
        assertEquals(1, db.memories().listActive(sid).size)
        // Importar nunca borra por coincidencia de nombre: ahora hay dos partidas con título parecido.
        assertEquals(2, db.sessionLookup().titles().size)
        assertNotEquals(db.roleSessions().get(sid)!!.title, copy.title)
    }

    @Test fun importingTwiceNeverOverwrites() = runBlocking {
        val sid = newSession()
        story.ensureStructure(sid)
        say(sid, "uno", "dos")
        val bible = roundTrip(sid)
        val svc = BibleService(db) { clock++ }
        val a = svc.import(bible, null); val b = svc.import(bible, null)
        assertEquals(3, setOf(sid, a, b).size)
        assertEquals(3, db.sessionLookup().titles().size)
    }

    @Test fun corruptArchiveIsRejectedWithoutTouchingData() = runBlocking {
        val sid = newSession()
        story.addMemory(sid, "Dato intacto.", 3, "", emptyList(), false)
        try { BibleCodec.read(ByteArrayInputStream("esto no es un zip".toByteArray())); fail("debía rechazarse") } catch (e: BibleException) { /* correcto */ }
        assertEquals(1, db.memories().listActive(sid).size)
        assertEquals(1, db.sessionLookup().titles().size)
    }
}
