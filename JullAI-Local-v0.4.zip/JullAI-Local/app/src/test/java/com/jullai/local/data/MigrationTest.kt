package com.jullai.local.data

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Crea a mano una base de datos de la v0.2 (versión 1) con datos del usuario, la abre con la versión actual
 * (migración 1→2 + validación de esquema de Room) y comprueba que NO se perdió nada.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MigrationTest {
    @Test fun upgradeFromV1KeepsUserDataAndCreatesRoleplayTables() = runBlocking {
        val context: Context = ApplicationProvider.getApplicationContext()
        val name = "migration-test.db"
        context.deleteDatabase(name)

        // --- Base de datos v1 (esquema exacto de la v0.2) ---
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(name).callback(object : SupportSQLiteOpenHelper.Callback(1) {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    db.execSQL("CREATE TABLE IF NOT EXISTS `models` (`fileName` TEXT NOT NULL, `displayName` TEXT NOT NULL, `sizeBytes` INTEGER NOT NULL, `sha256` TEXT NOT NULL, `importedAt` INTEGER NOT NULL, `isDefault` INTEGER NOT NULL, PRIMARY KEY(`fileName`))")
                    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_models_sha256` ON `models` (`sha256`)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `conversations` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `modelFileName` TEXT, `systemPrompt` TEXT NOT NULL, `temperature` REAL NOT NULL, `topP` REAL NOT NULL, `maxTokens` INTEGER NOT NULL, `contextLength` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS `index_conversations_updatedAt` ON `conversations` (`updatedAt`)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `messages` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `conversationId` INTEGER NOT NULL, `role` TEXT NOT NULL, `content` TEXT NOT NULL, `orderIndex` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `state` TEXT NOT NULL, FOREIGN KEY(`conversationId`) REFERENCES `conversations`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
                    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_messages_conversationId_orderIndex` ON `messages` (`conversationId`, `orderIndex`)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS `settings` (`settingKey` TEXT NOT NULL, `settingValue` TEXT NOT NULL, PRIMARY KEY(`settingKey`))")
                    db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
                    db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'viejo')")
                    db.execSQL("INSERT INTO conversations VALUES(1,'Mi chat',NULL,'sys',0.7,0.9,512,2048,1,2)")
                    db.execSQL("INSERT INTO messages VALUES(1,1,'user','hola',0,1,'COMPLETE')")
                    db.execSQL("INSERT INTO models VALUES('m.gguf','m',100,'abc',1,1)")
                    db.execSQL("INSERT INTO settings VALUES('threads','6')")
                }
                override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
            }).build(),
        )
        helper.writableDatabase.close()
        helper.close()

        // --- Se abre con la versión actual: Room ejecuta la migración y valida TODO el esquema ---
        val db = Room.databaseBuilder(context, AppDatabase::class.java, name).addMigrations(Migrations.MIGRATION_1_2, Migrations.MIGRATION_2_3).allowMainThreadQueries().build()
        try {
            assertEquals("Mi chat", db.conversations().get(1)!!.title)
            assertEquals("hola", db.messages().list(1).single().content)
            assertEquals("m.gguf", db.models().all().single().fileName)
            assertEquals("6", db.settings().all().single { it.settingKey == "threads" }.settingValue)
            // Las tablas nuevas existen y funcionan (incluida la clave foránea y el índice único).
            val now = 5L
            val ch = db.characters().insert(CharacterEntity(name = "Aria", createdAt = now, updatedAt = now))
            val s = db.roleSessions().insert(RoleSessionEntity(characterId = ch, title = "t", userName = "Ana", createdAt = now, updatedAt = now))
            db.roleMessages().insert(RoleMessageEntity(sessionId = s, role = "user", content = "x", orderIndex = 0, createdAt = now, state = "COMPLETE"))
            assertNotNull(db.roleSessions().get(s))
            db.characters().delete(ch)
            assertEquals(0, db.roleMessages().list(s).size)   // CASCADE funciona
        } finally {
            db.close()
            context.deleteDatabase(name)
        }
    }
}
