package com.jullai.local.data

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.jullai.local.story.Origin
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Migración 2→3 (0.3 → 0.4) con una base REALISTA de la 0.3 escrita a mano: no se pierde nada, las tablas nuevas
 * nacen vacías y funcionan, y el resumen que el usuario escribió a mano se conserva como versión 1.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MigrationV3Test {
    private fun buildLegacy(context: Context, name: String, version: Int, create: (SupportSQLiteDatabase) -> Unit) {
        context.deleteDatabase(name)
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(name).callback(object : SupportSQLiteOpenHelper.Callback(version) {
                override fun onCreate(db: SupportSQLiteDatabase) = create(db)
                override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
            }).build(),
        )
        helper.writableDatabase.close()
        helper.close()
    }

    private fun open(context: Context, name: String) =
        Room.databaseBuilder(context, AppDatabase::class.java, name)
            .addMigrations(Migrations.MIGRATION_1_2, Migrations.MIGRATION_2_3).allowMainThreadQueries().build()

    @Test fun upgradeFromV03KeepsEverythingAndStoryTablesWork() = runBlocking {
        val context: Context = ApplicationProvider.getApplicationContext()
        val name = "mig-v3.db"
        buildLegacy(context, name, 2) { LegacyDbs.createV2(it); LegacyDbs.insertV03Data(it) }

        val db = open(context, name)
        try {
            // Todo lo de la 0.3 sigue intacto.
            assertEquals("Mi chat", db.conversations().get(1)!!.title)
            val s = db.roleSessions().get(1)!!
            assertEquals("Ana conoció a Aria en la taberna.", s.summary)
            assertEquals(3, db.roleMessages().list(1).size)
            assertEquals("Busco el mapa del tesoro.", db.roleMessages().list(1)[1].content)
            assertEquals("6", db.settings().all().single { it.settingKey == "threads" }.settingValue)
            assertEquals("m.gguf", db.models().all().single().fileName)

            // Las tablas nuevas nacen vacías y funcionan.
            val story = StoryRepository(db) { 10L }
            assertEquals(0, db.memories().listAll(1).size)
            story.ensureStructure(1)
            assertEquals(1, db.volumes().list(1).size)
            story.addMemory(1, "Aria guarda el mapa en la torre.", 4, "primer día", listOf("Aria"), true)
            assertEquals(1, story.searchMemories(1, "torre").size)

            // El resumen manual de la 0.3 se conserva como versión 1 al guardar el primero versionado.
            val v = story.saveSummary(1, "Resumen nuevo", Origin.USUARIO)
            assertEquals(2, v)
            val versions = db.summaries().list(1)
            assertEquals("Ana conoció a Aria en la taberna.", versions.first { it.version == 1 }.text)
            assertEquals("Resumen nuevo", db.roleSessions().get(1)!!.summary)

            // Borrar la partida limpia todo lo nuevo (CASCADE) sin tocar el resto.
            db.roleSessions().delete(1)
            assertEquals(0, db.memories().listAll(1).size)
            assertEquals(0, db.volumes().list(1).size)
            assertEquals("Mi chat", db.conversations().get(1)!!.title)
        } finally { db.close(); context.deleteDatabase(name) }
    }

    @Test fun upgradeFromV02GoesThroughBothMigrations() = runBlocking {
        val context: Context = ApplicationProvider.getApplicationContext()
        val name = "mig-v3-from-v1.db"
        buildLegacy(context, name, 1) { LegacyDbs.createV1(it); it.execSQL("INSERT INTO conversations VALUES(1,'Viejo',NULL,'sys',0.7,0.9,512,2048,1,2)") }
        val db = open(context, name)
        try {
            assertEquals("Viejo", db.conversations().get(1)!!.title)
            assertNotNull(db.memories())
            assertTrue(db.volumes().list(1).isEmpty())
        } finally { db.close(); context.deleteDatabase(name) }
    }

    @Test fun ftsIsCreatedAndStaysInSyncOrFallsBackHonestly() = runBlocking {
        val context: Context = ApplicationProvider.getApplicationContext()
        val name = "mig-v3-fts.db"
        buildLegacy(context, name, 2) { LegacyDbs.createV2(it); LegacyDbs.insertV03Data(it) }
        val db = open(context, name)
        try {
            val story = StoryRepository(db) { 10L }
            val id = story.addMemory(1, "El dragón duerme bajo la montaña.", 3, "", emptyList(), false)
            // Con FTS o sin él, la búsqueda debe encontrar el recuerdo (con o sin tildes) y dejar de encontrarlo al borrarlo.
            assertEquals(1, story.searchMemories(1, "dragon").size)
            story.deleteMemory(id)
            assertEquals(0, story.searchMemories(1, "dragon").size)
        } finally { db.close(); context.deleteDatabase(name) }
    }
}
