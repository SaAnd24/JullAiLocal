package com.jullai.local.imaging.nativebridge

/** Recibe el progreso real del motor (solo si el motor compilado lo expone). */
interface SdProgress {
    fun onProgress(step: Int, steps: Int, seconds: Float)
}

/**
 * Puente JNI hacia stable-diffusion.cpp (ver src/main/cpp). Todas las funciones pesadas deben llamarse desde un hilo de trabajo.
 * Si la biblioteca no se pudo cargar, [loadError] explica por qué y la app sigue funcionando sin imágenes.
 */
object SdBridge {
    @Volatile var loadError: String? = null
        private set
    val isLoaded: Boolean

    init {
        var ok = false
        try {
            System.loadLibrary("jullai_sd")
            ok = true
        } catch (e: UnsatisfiedLinkError) {
            loadError = "No se pudo cargar la biblioteca nativa de imágenes: ${e.message}"
        } catch (e: SecurityException) {
            loadError = "No se permite cargar la biblioteca nativa de imágenes."
        }
        isLoaded = ok
    }

    @JvmStatic external fun nativeInit()
    @JvmStatic external fun nativeVersion(): String
    @JvmStatic external fun nativeCapabilities(): String
    @JvmStatic external fun nativeGetLog(): String
    @JvmStatic external fun nativeLastError(): String
    @JvmStatic external fun nativeLastInfo(): String
    @JvmStatic external fun nativeLoad(path: String, threads: Int, img2img: Boolean): Long
    @JvmStatic external fun nativeGenerate(handle: Long, params: String, prompt: String, negative: String, initRgb: ByteArray?, callback: SdProgress?): ByteArray?
    @JvmStatic external fun nativeCancel(): Boolean
    @JvmStatic external fun nativeFree(handle: Long)
}
