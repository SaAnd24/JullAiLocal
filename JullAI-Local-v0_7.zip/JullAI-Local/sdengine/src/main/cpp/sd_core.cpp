#include "sd_core.hpp"

#include <atomic>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <memory>
#include <mutex>
#include <type_traits>
#include <utility>

#include "stable-diffusion.h"

#ifndef JULLAI_SD_COMMIT
#define JULLAI_SD_COMMIT "desconocido"
#endif

namespace jsd {
namespace {

// ---- detección de campos (SFINAE) ----
#define JSD_HAS(NAME)                                                                                \
    template <class T, class = void> struct has_##NAME : std::false_type {};                         \
    template <class T> struct has_##NAME<T, std::void_t<decltype(std::declval<T&>().NAME)>> : std::true_type {};

JSD_HAS(model_path) JSD_HAS(n_threads) JSD_HAS(vae_decode_only) JSD_HAS(free_params_immediately) JSD_HAS(vae_tiling)
JSD_HAS(lora_model_dir) JSD_HAS(prompt) JSD_HAS(negative_prompt) JSD_HAS(width) JSD_HAS(height) JSD_HAS(seed) JSD_HAS(batch_count)
JSD_HAS(sample_params) JSD_HAS(sample_steps) JSD_HAS(guidance) JSD_HAS(txt_cfg) JSD_HAS(sample_method)
JSD_HAS(vae_tiling_params) JSD_HAS(enabled) JSD_HAS(loras) JSD_HAS(lora_count) JSD_HAS(init_image) JSD_HAS(strength)

// Asigna solo si el campo existe en la cabecera real. Devuelve si se asignó.
#define JSD_IF_HAS(OBJ, NAME, ...)                                                                   \
    [&](auto& o_) -> bool {                                                                          \
        using O_ = std::decay_t<decltype(o_)>;                                                       \
        if constexpr (has_##NAME<O_>::value) { __VA_ARGS__ return true; }                            \
        else { return false; }                                                                       \
    }(OBJ)

#define JSD_SET(OBJ, NAME, VAL)                                                                      \
    [&](auto& o_) -> bool {                                                                          \
        using O_ = std::decay_t<decltype(o_)>;                                                       \
        if constexpr (has_##NAME<O_>::value) { o_.NAME = (VAL); return true; }                       \
        else { return false; }                                                                       \
    }(OBJ)

std::mutex g_log_mu;
std::deque<std::string> g_log;
std::atomic<bool> g_cancel_flag{false};
ProgressFn* g_progress = nullptr;
std::mutex g_gen_mu;   // una generación a la vez

#ifdef JULLAI_SD_HAS_LOG
void log_cb(enum sd_log_level_t level, const char* text, void*) {
    if (!text) return;
    std::lock_guard<std::mutex> l(g_log_mu);
    std::string s = text;
    while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) s.pop_back();
    if (level >= SD_LOG_INFO || s.find("rror") != std::string::npos) {
        g_log.push_back(s);
        while (g_log.size() > 40) g_log.pop_front();
    }
}
#endif

#ifdef JULLAI_SD_HAS_PROGRESS
void progress_cb(int step, int steps, float time, void*) {
    if (g_progress && *g_progress) (*g_progress)(step, steps, time);
}
#endif

std::string stem(const std::string& path) {
    auto i = path.find_last_of('/');
    std::string f = i == std::string::npos ? path : path.substr(i + 1);
    auto d = f.find_last_of('.');
    return d == std::string::npos ? f : f.substr(0, d);
}

}  // namespace

std::string commit() { return JULLAI_SD_COMMIT; }

std::string capabilities() {
    std::string s;
    auto add = [&](const char* k, bool v) { s += k; s += v ? "=1;" : "=0;"; };
#ifdef JULLAI_SD_HAS_CANCEL
    add("cancel", true);
#else
    add("cancel", false);
#endif
#ifdef JULLAI_SD_HAS_PROGRESS
    add("progress", true);
#else
    add("progress", false);
#endif
    add("vae_tiling", has_vae_tiling_params<sd_img_gen_params_t>::value || has_vae_tiling<sd_ctx_params_t>::value);
    add("lora", has_loras<sd_img_gen_params_t>::value || has_lora_model_dir<sd_ctx_params_t>::value);
    add("img2img", has_init_image<sd_img_gen_params_t>::value);
    add("negative", has_negative_prompt<sd_img_gen_params_t>::value);
#ifdef JULLAI_SD_HAS_SAMPLER_NAME
    s += "samplers=euler_a,euler,dpm++2m,lcm;";
#else
    s += "samplers=;";   // sin conversión por nombre no se ofrece ningún sampler
#endif
    return s;
}

void init_logging() {
#ifdef JULLAI_SD_HAS_LOG
    sd_set_log_callback(log_cb, nullptr);
#endif
#ifdef JULLAI_SD_HAS_PROGRESS
    sd_set_progress_callback(progress_cb, nullptr);
#endif
}

std::string recent_log() {
    std::lock_guard<std::mutex> l(g_log_mu);
    std::string out;
    for (auto& s : g_log) { out += s; out += '\n'; }
    return out;
}

void* load(const std::string& path, int threads, bool allow_img2img, std::string& error) {
    try {
        sd_ctx_params_t cp;
        sd_ctx_params_init(&cp);
        JSD_SET(cp, model_path, path.c_str());
        JSD_SET(cp, n_threads, threads);
        JSD_SET(cp, vae_decode_only, !allow_img2img);
        JSD_SET(cp, free_params_immediately, false);   // si no, la segunda imagen fallaría
        sd_ctx_t* ctx = new_sd_ctx(&cp);
        if (!ctx) {
            error = "El motor no pudo cargar el modelo.";
            auto log = recent_log();
            if (!log.empty()) error += " Detalle: " + log.substr(log.size() > 400 ? log.size() - 400 : 0);
            return nullptr;
        }
        return ctx;
    } catch (const std::bad_alloc&) {
        error = "Sin memoria al cargar el modelo.";
    } catch (const std::exception& e) {
        error = std::string("Error al cargar el modelo: ") + e.what();
    } catch (...) {
        error = "Error desconocido al cargar el modelo.";
    }
    return nullptr;
}

GenResult generate(void* ctx_, const GenParams& p, const ProgressFn& progress) {
    GenResult r;
    if (!ctx_) { r.error = "No hay modelo cargado."; return r; }
    std::lock_guard<std::mutex> gen(g_gen_mu);
    auto* ctx = static_cast<sd_ctx_t*>(ctx_);
    auto t0 = std::chrono::steady_clock::now();
    ProgressFn pf = progress;
    g_progress = &pf;
    g_cancel_flag = false;
    // API actual: bool generate_image(ctx, params, sd_image_t** images_out, int* num_images_out). La biblioteca reserva el vector
    // de imágenes y el búfer de cada una con malloc; las liberamos nosotros.
    sd_image_t* out = nullptr;
    int out_n = 0;
    auto release_out = [&]() {
        if (out) { for (int i = 0; i < out_n; ++i) free(out[i].data); free(out); }
        out = nullptr; out_n = 0;
    };
    try {
        sd_img_gen_params_t ip;
        sd_img_gen_params_init(&ip);
        std::string prompt = p.prompt;
        std::shared_ptr<void> keep;   // mantiene vivos los datos que la API referencia por puntero
        if (JSD_SET(ip, negative_prompt, p.negative.c_str())) r.applied.push_back("prompt negativo");
        else if (!p.negative.empty()) r.ignored.push_back("prompt negativo (el motor no lo expone)");
        JSD_SET(ip, width, p.width);
        JSD_SET(ip, height, p.height);
        JSD_SET(ip, seed, (int64_t)p.seed);
        JSD_SET(ip, batch_count, 1);
        r.applied.push_back("semilla " + std::to_string(p.seed));

        // muestreo: pasos, guía y sampler (cada campo solo si existe en la cabecera real)
        JSD_IF_HAS(ip, sample_params, {
            auto& sp = o_.sample_params;
            if (JSD_SET(sp, sample_steps, p.steps)) r.applied.push_back(std::to_string(p.steps) + " pasos");
            JSD_IF_HAS(sp, guidance, {
                if (JSD_SET(sp.guidance, txt_cfg, p.cfg)) r.applied.push_back("CFG " + std::to_string(p.cfg).substr(0, 4));
            });
#if defined(JULLAI_SD_HAS_SAMPLER_NAME)
            auto m = str_to_sample_method(p.sampler.c_str());
            if (JSD_SET(sp, sample_method, m)) r.applied.push_back("sampler " + p.sampler);
#endif
        });
        if (p.cfg <= 1.0001f && !p.negative.empty()) r.ignored.push_back("prompt negativo sin efecto con CFG 1");

        // VAE por mosaicos
        if (p.tiling) {
            bool ok = JSD_IF_HAS(ip, vae_tiling_params, { JSD_SET(o_.vae_tiling_params, enabled, true); });
            if (ok) r.applied.push_back("VAE por mosaicos");
            else r.ignored.push_back("VAE por mosaicos (no disponible en este motor compilado)");
        }

        // LoRA: lista explícita si existe en la API
        if (!p.lora_path.empty()) {
            bool lora_done = JSD_IF_HAS(ip, loras, {
                using Item = std::remove_const_t<std::remove_pointer_t<decltype(o_.loras)>>;
                auto item = std::make_shared<Item>();
                item->path = p.lora_path.c_str();
                item->multiplier = p.lora_strength;
                keep = item;
                o_.loras = item.get();
                JSD_SET(o_, lora_count, 1);
            });
            if (lora_done) r.applied.push_back("LoRA " + stem(p.lora_path));
            else r.ignored.push_back("LoRA (el motor compilado no la admite)");
        }
        JSD_SET(ip, prompt, prompt.c_str());

        // imagen de referencia
        if (!p.init_rgb.empty()) {
            bool ok = JSD_IF_HAS(ip, init_image, {
                sd_image_t init{};
                init.width = (uint32_t)p.width; init.height = (uint32_t)p.height; init.channel = 3;
                init.data = const_cast<uint8_t*>(p.init_rgb.data());
                o_.init_image = init;
                JSD_SET(o_, strength, p.init_strength);
            });
            if (ok) r.applied.push_back("imagen de referencia (fuerza " + std::to_string(p.init_strength).substr(0, 4) + ")");
            else r.ignored.push_back("imagen de referencia (el motor compilado no la admite)");
        }

        if (!generate_image(ctx, &ip, &out, &out_n)) release_out();
    } catch (const std::bad_alloc&) {
        r.error = "Sin memoria durante la generación.";
    } catch (const std::exception& e) {
        r.error = std::string("Error durante la generación: ") + e.what();
    } catch (...) {
        r.error = "Error desconocido durante la generación.";
    }
    g_progress = nullptr;
    r.millis = (long)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();

    if (!r.error.empty()) { release_out(); return r; }
    if (!out || out_n < 1 || !out->data) {
        if (g_cancel_flag) { r.cancelled = true; r.error = "Cancelada."; }
        else {
            r.error = "El motor no devolvió ninguna imagen.";
            auto log = recent_log();
            if (!log.empty()) r.error += " Detalle: " + log.substr(log.size() > 400 ? log.size() - 400 : 0);
        }
        release_out();
        return r;
    }
    if (g_cancel_flag) { release_out(); r.cancelled = true; r.error = "Cancelada."; return r; }

    const int w = (int)out->width, h = (int)out->height, ch = (int)out->channel;
    if (w <= 0 || h <= 0 || (ch != 3 && ch != 4)) {
        r.error = "El motor devolvió una imagen con formato inesperado.";
        release_out();
        return r;
    }
    r.rgb.resize((size_t)w * h * 3);
    for (size_t i = 0, n = (size_t)w * h; i < n; ++i) {
        r.rgb[i * 3] = out->data[i * ch];
        r.rgb[i * 3 + 1] = out->data[i * ch + 1];
        r.rgb[i * 3 + 2] = out->data[i * ch + 2];
    }
    r.width = w; r.height = h; r.ok = true;
    release_out();
    return r;
}

bool cancel() {
#ifdef JULLAI_SD_HAS_CANCEL
    g_cancel_flag = true;
    sd_cancel_generation(SD_CANCEL_ALL);
    return true;
#else
    return false;
#endif
}

void release(void* ctx) {
    if (ctx) free_sd_ctx(static_cast<sd_ctx_t*>(ctx));
}

}  // namespace jsd
