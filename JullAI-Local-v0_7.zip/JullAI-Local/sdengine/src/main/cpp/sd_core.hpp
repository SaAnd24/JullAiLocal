// Capa fina sobre la API C de stable-diffusion.cpp (commit fijado en tools/fetch_sd.sh).
// Sin JNI: así se puede probar en Linux con una cabecera simulada (tools/sd-host-test).
//
// La API de stable-diffusion.cpp cambia con frecuencia («API and command-line option may change frequently»). Por eso:
//  - cada campo de las estructuras se asigna SOLO si existe en la cabecera real (detección en tiempo de compilación),
//  - cada función opcional (cancelar, progreso, registro, sampler por nombre) se activa con una macro que CMake define
//    únicamente si una prueba de compilación contra la cabecera real tiene éxito,
//  - lo que se aplicó y lo que se ignoró se devuelve en cada generación, y las capacidades salen de lo realmente compilado.
#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace jsd {

struct GenParams {
    std::string prompt, negative, sampler = "euler_a", lora_path;
    int width = 256, height = 384, steps = 20, threads = 4;
    float cfg = 7.0f, lora_strength = 1.0f, init_strength = 0.6f;
    int64_t seed = 1;
    bool tiling = true;
    std::vector<uint8_t> init_rgb;   // vacío = texto a imagen
};

struct GenResult {
    bool ok = false;
    bool cancelled = false;
    std::vector<uint8_t> rgb;
    int width = 0, height = 0;
    long millis = 0;
    std::string error;
    std::vector<std::string> applied, ignored;
};

using ProgressFn = std::function<void(int step, int steps, float seconds)>;

std::string capabilities();                              // "cancel=1;progress=1;..." según lo compilado
std::string commit();
void init_logging();
std::string recent_log();                                // últimas líneas del registro del motor
void* load(const std::string& path, int threads, bool allow_img2img, std::string& error);
GenResult generate(void* ctx, const GenParams& p, const ProgressFn& progress);
bool cancel();                                           // false si el motor compilado no permite cancelar
void release(void* ctx);

}  // namespace jsd
