// Puente JNI hacia sd_core (stable-diffusion.cpp). Biblioteca NATIVA SEPARADA de jullai_engine (llama.cpp): cada una enlaza su propia
// copia de ggml y se carga con System.loadLibrary (RTLD_LOCAL), por lo que no hay colisiones de símbolos entre ambas.
#include <jni.h>

#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>

#include "sd_core.hpp"

#define JNI_FN(name) Java_com_jullai_local_imaging_nativebridge_SdBridge_##name

namespace {
std::mutex g_mu;
std::string g_last_error;
std::string g_last_info;

void set_error(const std::string& e) { std::lock_guard<std::mutex> l(g_mu); g_last_error = e; }

std::string to_std(JNIEnv* env, jstring s) {
    if (!s) return std::string();
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string out = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

std::unordered_map<std::string, std::string> parse_kv(const std::string& s) {
    std::unordered_map<std::string, std::string> m;
    size_t i = 0;
    while (i < s.size()) {
        size_t e = s.find('\n', i);
        if (e == std::string::npos) e = s.size();
        std::string line = s.substr(i, e - i);
        size_t eq = line.find('=');
        if (eq != std::string::npos) m[line.substr(0, eq)] = line.substr(eq + 1);
        i = e + 1;
    }
    return m;
}
int geti(const std::unordered_map<std::string, std::string>& m, const char* k, int d) { auto it = m.find(k); return it == m.end() ? d : atoi(it->second.c_str()); }
float getf(const std::unordered_map<std::string, std::string>& m, const char* k, float d) { auto it = m.find(k); return it == m.end() ? d : (float)atof(it->second.c_str()); }
std::string gets(const std::unordered_map<std::string, std::string>& m, const char* k) { auto it = m.find(k); return it == m.end() ? std::string() : it->second; }
}  // namespace

extern "C" {

JNIEXPORT void JNICALL JNI_FN(nativeInit)(JNIEnv*, jclass) { jsd::init_logging(); }

JNIEXPORT jstring JNICALL JNI_FN(nativeVersion)(JNIEnv* env, jclass) { return env->NewStringUTF(jsd::commit().c_str()); }
JNIEXPORT jstring JNICALL JNI_FN(nativeCapabilities)(JNIEnv* env, jclass) { return env->NewStringUTF(jsd::capabilities().c_str()); }
JNIEXPORT jstring JNICALL JNI_FN(nativeGetLog)(JNIEnv* env, jclass) { return env->NewStringUTF(jsd::recent_log().c_str()); }
JNIEXPORT jstring JNICALL JNI_FN(nativeLastError)(JNIEnv* env, jclass) { std::lock_guard<std::mutex> l(g_mu); return env->NewStringUTF(g_last_error.c_str()); }
JNIEXPORT jstring JNICALL JNI_FN(nativeLastInfo)(JNIEnv* env, jclass) { std::lock_guard<std::mutex> l(g_mu); return env->NewStringUTF(g_last_info.c_str()); }

JNIEXPORT jlong JNICALL JNI_FN(nativeLoad)(JNIEnv* env, jclass, jstring path, jint threads, jboolean img2img) {
    std::string err;
    void* ctx = jsd::load(to_std(env, path), threads, img2img == JNI_TRUE, err);
    if (!ctx) set_error(err);
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT jbyteArray JNICALL JNI_FN(nativeGenerate)(JNIEnv* env, jclass, jlong handle, jstring params, jstring prompt, jstring negative, jbyteArray initRgb, jobject callback) {
    auto kv = parse_kv(to_std(env, params));
    jsd::GenParams p;
    p.prompt = to_std(env, prompt);
    p.negative = to_std(env, negative);
    p.width = geti(kv, "width", 256); p.height = geti(kv, "height", 384); p.steps = geti(kv, "steps", 20); p.threads = geti(kv, "threads", 4);
    p.cfg = getf(kv, "cfg", 7.f); p.seed = atoll(gets(kv, "seed").c_str()); p.sampler = gets(kv, "sampler");
    p.tiling = geti(kv, "tiling", 1) != 0; p.lora_path = gets(kv, "lora_path"); p.lora_strength = getf(kv, "lora_strength", 1.f); p.init_strength = getf(kv, "init_strength", 0.6f);
    if (initRgb) {
        jsize n = env->GetArrayLength(initRgb);
        p.init_rgb.resize((size_t)n);
        env->GetByteArrayRegion(initRgb, 0, n, reinterpret_cast<jbyte*>(p.init_rgb.data()));
    }
    JavaVM* vm = nullptr;
    env->GetJavaVM(&vm);
    jobject cb = callback ? env->NewGlobalRef(callback) : nullptr;
    jmethodID mid = nullptr;
    if (cb) { jclass c = env->GetObjectClass(cb); mid = env->GetMethodID(c, "onProgress", "(IIF)V"); env->DeleteLocalRef(c); }

    jsd::ProgressFn progress;
    if (cb && mid) {
        progress = [vm, cb, mid](int step, int steps, float secs) {
            JNIEnv* e = nullptr;
            bool attached = false;
            if (vm->GetEnv(reinterpret_cast<void**>(&e), JNI_VERSION_1_6) != JNI_OK) {
                if (vm->AttachCurrentThread(&e, nullptr) != JNI_OK) return;
                attached = true;
            }
            e->CallVoidMethod(cb, mid, (jint)step, (jint)steps, (jfloat)secs);
            if (e->ExceptionCheck()) e->ExceptionClear();
            if (attached) vm->DetachCurrentThread();
        };
    }
    jsd::GenResult r = jsd::generate(reinterpret_cast<void*>(handle), p, progress);
    if (cb) env->DeleteGlobalRef(cb);

    std::string info = std::string("ok=") + (r.ok ? "1" : "0") + "\ncancelled=" + (r.cancelled ? "1" : "0") + "\nwidth=" + std::to_string(r.width) +
                       "\nheight=" + std::to_string(r.height) + "\nmillis=" + std::to_string(r.millis) + "\n";
    for (auto& a : r.applied) info += "applied=" + a + "\n";
    for (auto& a : r.ignored) info += "ignored=" + a + "\n";
    {
        std::lock_guard<std::mutex> l(g_mu);
        g_last_info = info;
        g_last_error = r.error;
    }
    if (!r.ok) return nullptr;
    jbyteArray out = env->NewByteArray((jsize)r.rgb.size());
    if (!out) { set_error("Sin memoria para devolver la imagen."); return nullptr; }
    env->SetByteArrayRegion(out, 0, (jsize)r.rgb.size(), reinterpret_cast<const jbyte*>(r.rgb.data()));
    return out;
}

JNIEXPORT jboolean JNICALL JNI_FN(nativeCancel)(JNIEnv*, jclass) { return jsd::cancel() ? JNI_TRUE : JNI_FALSE; }
JNIEXPORT void JNICALL JNI_FN(nativeFree)(JNIEnv*, jclass, jlong handle) { jsd::release(reinterpret_cast<void*>(handle)); }

}  // extern "C"
