# Motor de imágenes de la 0.6: decisión y motivos

**Elegido: `leejet/stable-diffusion.cpp` (MIT), solo CPU, aislado en el módulo `:sdengine`.** No se incorporó Local Dream ni ningún otro motor.

## Qué se pudo verificar y qué no (investigación del 25-oct-2026)

| Dato | Estado |
|---|---|
| Licencia de Local Dream: **CC BY-NC 4.0** | Leído en el archivo `LICENSE` del repositorio. |
| Local Dream es una **aplicación completa** (NPU Snapdragon + CPU/GPU) | Leído en su README. No se auditó su código fuente; lo que sigue sobre su arquitectura (CPU con MNN, modelos convertidos a formatos propios, servidor local interno) viene del README y no está comprobado línea a línea. |
| Que Local Dream funciona en el Helio G100 (~2 min o menos) | **Dato del usuario.** Se usó como referencia, no como garantía. No lo medí. |
| stable-diffusion.cpp: licencia MIT, proyecto muy activo | Repositorio y notas de versión consultados. |
| Cancelación de generación en la biblioteca | Hay `sd_cancel_generation` desde la versión `master-994-e779d4f` (22-oct-2026), según el PR #2190. Es la razón del commit fijado. |
| Aceleración OpenCL | Documentada para GPU **Adreno**. La Mali-G57 del Helio G100 no está soportada: **no se usa GPU**. Vulkan en Mali-G57 no se probó y no se activa. |
| Cambios frecuentes de API (campos de estructuras, teselado del VAE, LoRA) | Comprobado en varios PR de septiembre-octubre de 2026. |
| **Cabecera `stable-diffusion.h` exacta del commit fijado** | **NO pude leerla** (sin red desde el entorno de compilación; la herramienta de lectura solo abre URL ya vistas). Por eso el código nativo se escribió para tolerar cambios (ver más abajo) y el workflow comprueba la cabecera real antes de compilar. |

## Comparación

| Criterio | Local Dream | stable-diffusion.cpp |
|---|---|---|
| Licencia | CC BY-NC 4.0: **no comercial**, no pensada para código; incompatible con distribuir libremente el APK | **MIT** (basta conservar el aviso) |
| Forma | App completa; hay que extraer/adaptar código y modelos convertidos | Biblioteca C/C++ con API C; encaja en CMake/JNI |
| Modelos | Formatos propios convertidos (no los .safetensors que ya tiene el usuario) | `.safetensors` y `.gguf` de SD 1.x directamente |
| Ruta CPU en el Helio G100 | Probada por el usuario | **No probada** (ggml NEON; sin medición) |
| Cancelar / progreso | No evaluado | Callback de progreso + `sd_cancel_generation` en el commit fijado |
| LCM, VAE por mosaicos, LoRA, img2img | No evaluado | Expuestos por la API (la app detecta en compilación cuáles hay) |
| Integración en este APK | Alta dificultad + restricción de licencia | Media: segunda `.so`, sin tocar `LlamaBridge` |

**Riesgo asumido:** Local Dream es la única ruta que el usuario *sabe* que funciona en su teléfono. stable-diffusion.cpp se eligió por licencia, formatos, integración y control (cancelación, parámetros), pero **su velocidad y estabilidad en el Helio G100 son una incógnita hasta probarlo** (ver `PRUEBAS_MANUALES.md`, sección V). Si resultase inviable, la interfaz `ImageEngine` permite sustituir el motor sin rehacer UI, fichas ni recursos.

## Commit fijado
- Versión: `master-994-e779d4f`, commit completo `e779d4f149aae16e3319b66a320ec4bee8fc5e7c` (`tools/fetch_sd.sh` lo clona y **falla** si el hash no coincide; el workflow lo ejecuta).
- Licencia: MIT. El script conserva el archivo `LICENSE` junto al código descargado. Ver `THIRD_PARTY_LICENSES.md`.

## Aislamiento de llama.cpp
`stable-diffusion.cpp` lleva su propia copia de ggml, con los mismos nombres de destinos CMake que llama.cpp. Por eso va en **otro módulo Gradle (`:sdengine`) con su propio CMake** y genera `libjullai_sd.so`; `libjullai_engine.so` (llama.cpp) no cambia. Cada una se carga con `System.loadLibrary` (RTLD_LOCAL) y enlaza sus símbolos ocultos (`-fvisibility=hidden`, `--exclude-libs`), así no chocan. **Compartir ggml queda descartado** (no probado). `LlamaBridge` y `LlamaEngine` no se modificaron; el único cambio en el motor de texto es un gancho opcional `EngineController.beforeLoad`.

## Cómo tolera la API cambiante (`sdengine/src/main/cpp/sd_core.cpp`)
- Cada campo de las estructuras se asigna **solo si existe** en la cabecera real (detección con plantillas).
- Cada función opcional (cancelar, progreso, registro, sampler por nombre) se activa con una macro que CMake define **solo si una prueba de compilación contra la cabecera real tiene éxito**.
- Las capacidades que ve la app (`EngineCapabilities`) salen de lo realmente compilado; lo que falta no se ofrece y cada imagen devuelve qué parámetros se aplicaron y cuáles se ignoraron.
- Si cambia algo imprescindible (`new_sd_ctx`, `generate_image`, nombres de las estructuras), la compilación falla con un mensaje claro de `tools/check_sd_api.py`/`check_sd_shim.sh`: habrá que ajustar `sd_core.cpp` (≈280 líneas, un solo archivo).

## Formatos admitidos
- **Checkpoint:** `.safetensors` o `.gguf` de **Stable Diffusion 1.x en un solo archivo, con VAE integrado**. Se valida por contenido (nombres y formas de tensores), no por extensión.
- **LoRA:** `.safetensors` (se usa solo con los preajustes LCM; debe ser una LoRA LCM de SD 1.5).
- **Rechazados con motivo:** `.ckpt`/pickle (ejecutan código), SDXL, SD 2.x, inpainting, formato diffusers de varios archivos, archivos truncados.
- **Conversión:** no existe. La app no convierte ni renombra nada; si quieres cuantizar o convertir, hazlo con herramientas externas y vuelve a importar.

## Lo que NO es compatible (declarado, no prometido)
SDXL, FLUX, vídeo, lotes, ControlNet, PhotoMaker, IP-Adapter, inpainting, GPU (Mali), resoluciones fuera de la lista (máx. 512×768), reanudar una imagen a mitad de inferencia, y **consistencia garantizada de rostro/vestuario**: image-to-image desde una referencia ayuda pero no lo asegura.
