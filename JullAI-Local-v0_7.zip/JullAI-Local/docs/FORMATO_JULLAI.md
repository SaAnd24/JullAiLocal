# Formato `.jullai` (versión 1)

Un `.jullai` es un archivo ZIP que guarda **una partida completa** para llevarla a otro teléfono o guardarla como copia.
**No incluye el modelo GGUF.** Formato interno: `jullai-biblia`, versión `1`.

## Contenido

| Archivo | Para qué sirve | ¿Se lee al importar? |
|---|---|---|
| `manifest.json` | formato, versión, versión de la app, fecha, recuentos y la lista de recursos con su SHA-256 | Sí |
| `biblia.md` | la biblia de la partida **para leer** (personaje, escenario, resumen, recuerdos, relaciones, cronología, capítulos). No incluye notas privadas del creador | **No** (solo lectura) |
| `data/personaje.json` | ficha del personaje y su lorebook | Sí |
| `data/partida.json` | escenario, nombres, reglas, resumen vigente, parámetros (sin modelo) | Sí |
| `data/mensajes.json` | el registro original de mensajes, con sus alternativas | Sí |
| `data/conocimiento.json` | «Saber»: hechos, secretos… | Sí |
| `data/memoria.json` | recuerdos (con confianza, fijado y estado), versiones del resumen, cronología | Sí |
| `data/relaciones.json` | relaciones, su historial y las propuestas pendientes | Sí |
| `data/estructura.json` | volúmenes y capítulos (incluido el texto novelado) | Sí |
| `assets/<id>.png/.jpg/.webp` | retrato ya reducido | Sí (con comprobación de SHA-256) |

Los identificadores del archivo son solo para enlazar entre sí los elementos del propio archivo; al importar se crean identificadores nuevos.

## Validación al importar (antes de tocar tus datos)

1. **Nombres**: lista cerrada. Se rechazan rutas absolutas, `..`, barras invertidas, unidades (`C:`), nombres repetidos (también con otras mayúsculas) y cualquier archivo inesperado.
2. **Tamaños contados al leer**: límite de entradas, de cada archivo y del total (una bomba de compresión se corta, no se confía en el tamaño que declara el ZIP).
3. **Versión y formato**: formato y versión conocidos (una versión mayor se rechaza con un mensaje claro).
4. **Contenido**: tipos, rangos (p. ej. relaciones 1-100), listas de valores (estados, orígenes), identificadores únicos, referencias que existan y recuentos iguales a los del manifiesto.
5. **Recursos**: la suma SHA-256 de cada imagen debe coincidir con el manifiesto.

Si algo falla, **no se escribe nada** y la app explica el motivo. Si todo es correcto se muestra una **vista previa** y, al confirmar, se importa dentro de **una sola transacción**
como partida **nueva** (con su propio personaje; el título añade «(importada)» si ya hay otra igual). Nunca se sobrescribe ni se borra nada por coincidir un nombre. La partida importada
no trae modelo: elige uno en Motor.

## Compatibilidad futura

Esta versión rechaza archivos de una versión del formato mayor que la que conoce, con un mensaje claro. Un `.jullai` antiguo al que le falten archivos opcionales se sigue pudiendo importar.

## Añadido en la 0.5: instantánea opcional del mundo (`data/mundo.json`)

Si la partida tiene un mundo vinculado, el `.jullai` incluye **un elemento más y opcional**, `data/mundo.json`: la enciclopedia ACTIVA del mundo en un solo JSON
(`format: "jullai-worldpack-snapshot"`, `formatVersion: 1`) con `world`, `entradas`, `fuentes` (solo referencias, sin texto) y `link` (continuidad, reparto, spoilers y época de la partida).
Los campos se validan igual que en un `.worldpack` (tipos, rangos, esquemas de URL permitidos, duplicados, tamaños).

- El `formatVersion` del `.jullai` **no cambia** (sigue siendo 1). Un `.jullai` sin mundo es idéntico al de la 0.4. Un `.jullai` con `data/mundo.json` **no lo abre la 0.4** (rechaza el elemento por inesperado).
- Una instantánea inválida **rechaza todo el archivo** antes de tocar tus datos.
- Al importar eliges cómo enlazar: crear el mundo desde la copia, usar el que ya tienes (mismo identificador), combinar (añade solo lo que falta) o crear una copia independiente. Si ya existe un mundo distinto con ese identificador no hay opción por defecto: tienes que elegir. Nunca se borra ni se sobrescribe un mundo existente.
- Quien tenga el `.jullai` pero no el mundo base lo recupera de la instantánea; quien ya lo tiene puede reutilizarlo. Avance, relaciones y recuerdos de la partida siguen siendo independientes del mundo.
