# Formato `.worldpack` (versión 1)

Un `.worldpack` es el **mundo base** (la enciclopedia), no una partida. Una partida se exporta aparte como `.jullai` (ver `FORMATO_JULLAI.md`), que puede llevar una instantánea del mundo.
Es un ZIP **cerrado**: solo se admiten estos nombres, en la raíz y sin carpetas.

| Archivo | ¿Obligatorio? | Contenido |
|---|---|---|
| `manifest.json` | Sí | `format: "jullai-worldpack"`, `formatVersion`, `minReaderFormat`, `appVersion`, `exportedAt`, `title`, `worldUuid`, `worldRevision`, `counts` (entradas, fuentes) y `files`: tamaño y SHA-256 de cada archivo |
| `world.json` | Sí | `uuid`, `name`, `description`, `language`, `setting`, `era`, `rules`, `narrativeLimits`, `spoilerLevel`, `castMode`, `continuityMode`, `researchDepth`, `preferredSources`, `priorityCharacters`, `priorityPlaces`, `revision` |
| `characters.json` | No | entradas de tipo PERSONAJE, ALIAS y RELACION |
| `locations.json` | No | entradas LUGAR |
| `timeline.json` | No | entradas ACONTECIMIENTO |
| `entries.json` | No | el resto de tipos (OBJETO, CRIATURA, CONCEPTO, REGLA, SECRETO, CONFLICTO, OTRO) |
| `sources.json` | No | fuentes: `kind`, `uri` (http/https o nombre de archivo), `title`, `status`, `license`, `provenance`, `consultedAt`. **Sin texto** |
| `lore.md` | No | resumen legible; solo lectura, no se interpreta al importar |

Cada entrada: `type`, `name`, `aliases`, `summary`, `details`, `confidence`, `origin`, `sourceIndex` (posición en `sources.json` o nulo), `sourceRef`, `evidence`, `factKey`, `contradictionGroup`, `related`, `spoilerLevel` (0–3), `eraTag`, `state` (solo viajan las activas).
`confidence` ∈ `CONFIRMADO_POR_FUENTE`, `CONFIANZA_LIMITADA`, `CONTRADICCION`, `INTERPRETACION_DE_AFICIONADOS`, `INVENCION_DE_ROLEPLAY`.

## Qué NO contiene
Libros, guiones, textos completos de las fuentes ni imágenes. Solo datos estructurados, referencias, licencias y resúmenes breves. El texto extraído de cada fuente se queda en el dispositivo.

## Validación al importar (antes de tocar nada)
Nombres de archivo de la lista cerrada · sin `..`, rutas absolutas, `\`, `:` ni carpetas (**ZIP-slip**) · sin elementos repetidos · máx. 16 elementos, 8 MB por elemento y 24 MB descomprimidos ·
archivos obligatorios presentes · todo archivo coincide con el manifiesto (tamaño y SHA-256) y todo archivo declarado existe (si no, «incompleto») · `format` y versión (un archivo más nuevo se rechaza con un mensaje claro) ·
tipos de dato, rangos y valores permitidos · textos limpiados y recortados · `sourceIndex` válido · URIs solo http/https · sin entradas duplicadas (tipo + nombre + clave de hecho + fuente) ·
recuentos igual que el manifiesto · máx. 5000 entradas y 300 fuentes.

## Importación
Calcula una vista previa y **nunca borra ni sobrescribe**. Opciones: *crear* (mundo nuevo), *copia independiente* (nuevo identificador y nombre «(importado)»), *combinar* (solo añade entradas y fuentes que faltan, sin tocar las existentes) y *usar el existente*.
Un mundo importado nace con la investigación online **desactivada**.

## Relación con `.jullai`
`.worldpack` = mundo base y compartible entre partidas. `.jullai` = una partida (mensajes, memoria, relaciones...), con `data/mundo.json` opcional: instantánea del mundo + ajustes de la partida respecto a él.
Avance, relaciones y recuerdos jamás viajan en un `.worldpack`.
