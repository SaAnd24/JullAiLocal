# Investigación automática (0.7)

## Qué hace, fase por fase
1. **IDENTIFICANDO** — busca la obra en Wikipedia (`generator=search` + `wikibase-shortdesc`) en el idioma del mundo y en inglés; clasifica por tipo (serie, anime, cómic, película, libro, videojuego, franquicia).
   Si hay candidatos plausibles de **tipos distintos**, la 0.7 elige el primero y lo anota (la pregunta interactiva de continuidad está pendiente en la interfaz). Wikidata aporta enlaces entre idiomas, el identificador de Fandom (P6262) y personajes (P674).
2. **DESCUBRIENDO_FUENTES** — valida la wiki de Fandom en vivo (siteinfo + una página parecida al título), busca listados de personajes en Wikipedia, categorías de personajes/lugares de Fandom y el reparto del artículo.
   Un nombre de una sola palabra no se busca en Wikipedia (podría ser otra cosa). El **plan se guarda** (`world_identity.planJson`).
3. **DESCARGANDO** — cada página del plan es una fuente `mw:<api>#<título>` (única por mundo). Las páginas de personaje producen `PERSONAJE` (spoiler 0) + «— historia» (spoiler 2) + «— notas de aficionados» (confianza *aficionados*).
4. **IMAGENES_DE_PERSONAJES** — imagen principal de cada personaje (`pageimages`, con la licencia de `imageinfo`; alternativa: API v1 de Fandom). Solo CDN de Wikimedia/Fandom, tamaño máximo 3 MB, tipo comprobado por bytes (PNG/JPEG/WEBP). Estados por personaje: OK / SIN_IMAGEN / FALLIDA.
5. **CONTRADICCIONES** — se marcan, nunca se resuelven solas.

## Seguridad y límites
- Lista cerrada de APIs (`WikiHosts`), https, sin puertos ni credenciales; redirecciones revisadas; 1,1 s mínimo entre peticiones al mismo servidor; User-Agent identificable; texto recibido = datos no confiables.
- Reintentos: máximo 3 intentos por tarea; fallos temporales (red, saturación) reintentan; los definitivos (404, 403) no. Reanudable e idempotente: lo ya procesado no se repite.
- **Licencias**: texto de wikis normalmente CC BY-SA (se guarda la declarada por cada wiki). Imágenes: la licencia/autoría declarada; «no libre» o «desconocida» se muestra tal cual. Nunca se presume libre.

## No verificado
Respuestas reales de las APIs (el entorno de desarrollo no tenía acceso), cobertura para obras poco documentadas, wikis de Fandom en otros idiomas (se prueba la raíz y variantes del título), rendimiento en el teléfono.
