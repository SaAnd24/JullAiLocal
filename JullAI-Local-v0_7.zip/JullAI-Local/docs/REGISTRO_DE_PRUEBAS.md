# Registro de pruebas — v0.6 (la 0.5 queda debajo, sin cambios)

Entorno: Linux **sin Android SDK, Gradle, NDK ni compilador de Kotlin**, con Python 3, g++ y SQLite. Fecha: 25-10-2026. Sin teléfono.

## EJECUTADO en este entorno
| # | Qué | Resultado |
|---|---|---|
| 1 | `tools/verify/check_schema.py` (migraciones v1→v5 contra las entidades Kotlin + todas las consultas en SQLite real) | **OK**: 31 entidades, 31 tablas, 185 consultas, FTS4 |
| 2 | `tools/sd-host-test/run.sh`: `sd_core.cpp` compilado con g++ -Wall contra una cabecera **SIMULADA** y 8 comprobaciones (carga fallida con registro, generar, progreso, LoRA, mosaicos, aviso de negativo con CFG 1, img2img, cancelar a mitad y volver a generar) | **OK**. **No prueba compatibilidad con stable-diffusion.cpp real.** |
| 3 | `sd_core.cpp` contra una cabecera simulada **reducida** (sin LoRA, mosaicos, img2img ni cancelar) | **Compila**: la detección de campos tolera API más pobre |
| 4 | Revisión estática propia (llaves/paréntesis equilibrados, imports internos con declaración) en 30 archivos Kotlin | 0 problemas. **No sustituye a compilar.** |

## NO ejecutado (escrito; lo ejecutará GitHub Actions o tú)
- **Compilación Kotlin/Gradle y del módulo nativo para Android** (workflow `build.yml`; incluye `fetch_sd.sh`, `check_sd_api.py`, `check_sd_shim.sh` antes de compilar). Estado: **sin confirmar**. Riesgo principal: la cabecera real de stable-diffusion.cpp en el commit fijado, que no pude leer.
- `jullai_sd_jni.cpp` (JNI): **no se compiló en ningún sitio** (no hay `jni.h` aquí).
- **39 pruebas unitarias nuevas** (`app/src/test/.../imaging/`): `ImagingLogicTest` (27: lectura de safetensors/GGUF escritos a mano, rechazo de SDXL/SD2/inpainting/diffusers/pickle/truncados/cabeceras mentirosas, LoRA, resoluciones, validación de peticiones, coste, prompts, **coordinador** con motor/texto/teléfono falsos: libera texto, prioridad del texto, memoria baja, calor, texto no liberable, error y recarga, acción del jugador que cancela y libera antes del texto, motor sin cancelar, térmico crítico y presión de memoria, política de ilustraciones, planificador y su orden, metadatos tolerantes, ajustes) e `ImagingDatabaseTest` (12 con Room/Robolectric: guardar recurso y metadatos en una transacción, sin modelo, **fallo del motor sin tocar recursos previos**, orden de prioridad, pausa por texto, aplazar por calor y reanudar, tarea interrumpida tras reinicio, cancelar por el usuario, LCM sin LoRA, cascadas, ilustraciones por sesión, migración desde datos de la 0.3). Las ejecutará `testDebugUnitTest`. Alguna podría fallar por errores de la propia prueba, como ocurrió en la 0.4.
- Las 0.4/0.5 existentes (181 + 79) siguen en el repositorio; solo cambió su llamada a `Migrations.ALL`.

## NO PROBADO en dispositivo (requiere tu Infinix; ver `PRUEBAS_MANUALES.md` R–Y)
Generación real de una imagen · cancelar con el motor real · tiempos, RAM y temperatura en el Helio G100 · LCM-LoRA con tu checkpoint · image-to-image · comportamiento bajo presión térmica o de memoria reales ·
cambio texto↔imagen en el teléfono · importación de modelos reales de cientos de MB.

## Tabla de resultados medidos (a rellenar por quien pruebe)
| Dispositivo | Modelo | Resolución | Pasos / sampler | Carga (s) | Total (s) | s/paso | RAM libre mín. | Temp. fin | Notas |
|---|---|---|---|---|---|---|---|---|---|
| Infinix · Helio G100 · 8 GB | — | 256×384 | 20 / Euler a | — | — | — | — | — | **sin medir** |
| Infinix · Helio G100 · 8 GB | — | 256×384 | 6 / LCM | — | — | — | — | — | **sin medir** |

---
# (v0.5) Registro anterior

Entorno donde se escribió la 0.5: Linux **sin Android SDK, sin Gradle y sin compilador de Kotlin**, con Python 3 y SQLite. Fecha: 25-10-2026.
**Consecuencia:** el código Kotlin nuevo NO se compiló ni se ejecutó aquí. Lo único ejecutado es lo de las secciones 1 y 2.

## 0) La 0.4 en GitHub Actions (referencia real, aportada por el usuario)
- `assembleDebug`: compiló y generó el APK.
- `testDebugUnitTest`: 181 pruebas, 180 pasaron, **1 falló**: `StoryDatabaseTest.manualCorrectionKeepsHistoryAndStaysInRange` (AssertionError en la línea del `fail("fuera de rango")`).
- Causa: la prueba esperaba una excepción con `catch (e: Exception)`; `fail()` lanza `AssertionError` (no hereda de `Exception`) y el código real **recorta** a 1–100 (`RelationshipRules.manualSet`, cubierto por `RelationshipRulesTest`).
- Corrección: la prueba ahora afirma el recorte (`[1, 10, 55, 100]`). **Sin cambios en la app.** Pendiente de confirmar en Actions.

## 1) Verificador de esquema (`tools/verify/check_schema.py`) — EJECUTADO, pasa
`Entidades: 27 · tablas en la base: 27 · consultas revisadas: 158 · FTS4: sí → OK`. Crea una base SQLite con las sentencias de `Migrations.kt` (v1→v4) y comprueba columnas, tipos, NOT NULL,
claves primarias, índices, claves foráneas y que todas las consultas `@Query` son válidas, más la sintaxis FTS4 de `world_entries_fts`. **No es Room.** También corre en Actions (`schema-check.log`).
El SQL de las 8 tablas nuevas se generó a partir de `WorldEntities.kt` con un script y lo valida este verificador.

## 2) Revisión estática — EJECUTADA (no sustituye a compilar)
Script propio sobre los archivos nuevos: llaves/paréntesis/corchetes equilibrados e `import com.jullai.local.*` que apuntan a algo declarado (25 archivos, 0 problemas). Además se comprobaron a mano
las firmas reutilizadas (`MiniJson`, `TextNorm`, `PromptSection`, `EngineController`, `PortraitStore`, `FtsSupport`, DAOs).

## 3) Escritas y NO ejecutadas (79 pruebas nuevas; las ejecutará Actions)
| Clase | Pruebas | Qué cubre |
|---|---|---|
| `world.WorldpackTest` | 18 | ida y vuelta; archivos esperados y sin texto de fuentes; confianza y contradicciones; **ZIP-slip** (`../`, `/abs`, `\`); nombres inesperados; entradas ZIP repetidas; archivos obligatorios ausentes; declarado y ausente («incompleto»); **archivo manipulado (SHA-256)**; entradas duplicadas; misma entidad de fuentes distintas permitida; elemento demasiado grande; demasiados elementos; basura y vacío; versión más nueva; esquemas de URL maliciosos; valores no permitidos; instantánea con enlace; instantánea inválida |
| `world.WorldLogicTest` | 34 | texto no confiable (invisibles, marcas de chat, aviso de inyección); HTML/Markdown/secciones/trozos; lector de MediaWiki; **extracción verificada** (cita en la fuente → confirmado; si no, limitada y sin cita; nombre ausente; líneas rotas; instrucciones en la salida del modelo); spoilers separados; contradicciones; **recuperación** (solo lo pertinente, presupuesto, spoilers, confianza visible, nada si no hay coincidencias, continuidad); escenas (hablante, lugar, cambio de lugar, fallback seguro, no lanza nunca); recursos nulos sin «éxito falso»; elecciones; preparación real; bloqueo de red local/privada; `robots.txt` |
| `data.WorldDatabaseTest` | 27 | Room real (Robolectric): crear/editar mundo sin conexión; «confirmado» exige fuente y cita; duplicados y no sobrescritura; contradicciones mostradas; **el lore no cambia por jugar**; **un mundo, dos partidas con memorias independientes**; borrar mundo conserva la partida; exportar/importar/copia/combinar/duplicar sin tocar el original; instantánea del `.jullai`; recuperación sin red y FTS4; **motor de investigación** (éxito solo con fuentes y entradas; solo fallos ≠ éxito; sin fuentes ≠ éxito; no compatibles; reintentos limitados y reanudación sin repetir fuentes; cancelación; tarea final no se relanza; cambiar URL); primera escena; metadatos de escena sin tocar el texto; registro de recursos; **migración 2→3→4 con datos reales de la 0.3** |
| Anteriores | 181 | 0.2–0.4 (`StoryDatabaseTest` y migraciones ajustadas a la cadena hasta la v4) |

## 4) Mapa de las pruebas de aceptación del documento 0.5
| Prueba pedida | Automática (escrita, sin ejecutar) | Manual (`PRUEBAS_MANUALES.md`) |
|---|---|---|
| Crear y editar un mundo sin conexión | `createAndEditWorldOffline`, `confirmedRequiresSourceAndEvidence` | K (4–8) |
| Importar fuentes locales | `byExtensionRejectsUnknownFormats`, `htmlToText…`, `markdownToText…` | L (9–12) |
| Investigar una fuente accesible y gestionar fuentes inaccesibles | `researchSucceeds…`, `researchWithOnlyFailures…`, `unsupportedSources…` (proveedores falsos) | M (13–16) — **requiere red y una wiki real** |
| Cancelar y reanudar una tarea | `cancelledTaskStops…`, `cancelBetweenSources…`, `temporaryFailure…Resumes…` | M (17–18) — **WorkManager solo se prueba en el teléfono** |
| Exportar e importar un `.worldpack` | `roundTrip…`, `exportImportCopy…`, `mergeAddsOnly…` | O (20–21) |
| Recuperar entradas en modo avión | `retrievalWorksWithNoNetwork…`, `fullTextSearchPath…` | P (24) en modo avión |
| Rechazar un ZIP malicioso o incompleto | `zipSlip…`, `missingRequiredFiles…`, `declaredFileMissing…`, `tampered…`, `garbage…` | O (22) |
| El lore base no se altera por hechos de la partida | `gameplayNeverTouchesTheEncyclopedia` | P (26) |
| Un personaje y un mundo en dos partidas con memorias independientes | `oneWorldTwoSessionsWithIndependentMemories` | P (27) |
| Roleplay visual con retratos importados | `assetsRegistry…`, `assetResolver…` (la pantalla NO) | Q (29–30) |
| Seguir con acciones libres sin imágenes o metadatos | `directorNeverThrows…`, `sceneMetadataIsStored…` (la pantalla NO) | Q (31) |
| Memoria, historial y relaciones de la 0.4 accesibles | pruebas 0.4 | J (2) |

## 5) Pendiente de dispositivo
Todo lo de `docs/PRUEBAS_MANUALES.md`, en especial: investigación con una wiki real, WorkManager (reanudar tras matar la app, aplazamiento), novela visual en vertical y horizontal, y el rendimiento de la
recuperación con mundos grandes.

## 0.7 — lo que SÍ se ejecutó (kotlinc + JUnit local, sin Android)
- `DiscoveryTest` 33/33 (lista cerrada, resolución de obra, nombres de personajes, planificador, imágenes y licencias, con respuestas falsas de forma MediaWiki).
- `EngineTest` 6/6 (flujo completo con almacén en memoria, segunda ejecución sin duplicados, reintento sin conexión, obra desconocida, imagen inválida, cancelación).
- `CastTest` 3/3 (ficha → personaje sin inventar campos, candidatos sin spoilers, códec del plan).
- `DownloaderTest` 8/8 contra un servidor HTTP local (descarga, redirecciones, corte + reanudación Range, servidor que ignora Range, SHA/tamaño/espacio/404/GGUF inválido, no pisar archivos, cancelación conserva parcial).
- `tools/verify/check_schema.py`: 33 entidades, migración 5→6 coherente.
**No se ejecutó**: compilación del APK, Compose, Room real/Robolectric (incluidas las pruebas existentes de la 0.5/0.6 con el motor reescrito), APIs reales de Wikipedia/Wikidata/Fandom/Hugging Face.
