#!/usr/bin/env bash
# Comprueba sd_core.cpp contra la cabecera REAL descargada por tools/fetch_sd.sh: replica los sondeos de CMake y hace una
# compilación solo-sintaxis (rápida, sin enlazar). Si falla, el mensaje de g++ indica qué campo o función cambió en la API.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SD="$ROOT/sdengine/src/main/cpp/stable-diffusion.cpp"
CPP="$ROOT/sdengine/src/main/cpp"
[ -f "$SD/include/stable-diffusion.h" ] || { echo "Falta la cabecera: ejecuta tools/fetch_sd.sh"; exit 2; }
probe() { printf '#include "stable-diffusion.h"\n%s\n' "$2" | g++ -std=c++17 -fsyntax-only -I"$SD/include" -x c++ - 2>/dev/null && { echo "  sondeo $1: sí"; DEFS="$DEFS -D$1=1"; } || echo "  sondeo $1: NO"; }
DEFS=""
probe JULLAI_SD_HAS_CANCEL   'void f(){ sd_cancel_generation(SD_CANCEL_ALL); }'
probe JULLAI_SD_HAS_PROGRESS 'static void cb(int,int,float,void*){} void f(){ sd_set_progress_callback(cb,nullptr); }'
probe JULLAI_SD_HAS_LOG      'static void cb(enum sd_log_level_t,const char*,void*){} void f(){ sd_set_log_callback(cb,nullptr); }'
probe JULLAI_SD_HAS_SAMPLER_NAME 'void f(){ auto m = str_to_sample_method("euler_a"); (void)m; }'
echo "Compilando sd_core.cpp (solo sintaxis) contra la cabecera real..."
g++ -std=c++17 -fsyntax-only -Wall -I"$SD/include" -I"$CPP" $DEFS "$CPP/sd_core.cpp" && echo "OK: sd_core.cpp es compatible con la cabecera real (sintaxis y tipos)."
