#!/usr/bin/env bash
# Descarga stable-diffusion.cpp (MIT) en un commit FIJO dentro de sdengine/src/main/cpp/stable-diffusion.cpp.
# El commit está fijado por hash completo; si el repositorio ofrece otro, la compilación se detiene.
# Origen de la elección: lanzamiento master-994-e779d4f (22-oct-2026, primer commit con sd_cancel_generation en la biblioteca).
set -euo pipefail

SD_TAG="master-994-e779d4f"
SD_COMMIT="e779d4f149aae16e3319b66a320ec4bee8fc5e7c"
DEST="$(cd "$(dirname "$0")/.." && pwd)/sdengine/src/main/cpp/stable-diffusion.cpp"

if [ -f "$DEST/CMakeLists.txt" ] && [ "$(cat "$DEST/.pinned_commit" 2>/dev/null || echo x)" = "$SD_COMMIT" ]; then
  echo "stable-diffusion.cpp $SD_TAG ya está descargado."; exit 0
fi
rm -rf "$DEST"
echo "Descargando stable-diffusion.cpp $SD_TAG ..."
git clone --no-checkout https://github.com/leejet/stable-diffusion.cpp "$DEST"
git -C "$DEST" checkout --quiet "$SD_COMMIT"
ACTUAL="$(git -C "$DEST" rev-parse HEAD)"
if [ "$ACTUAL" != "$SD_COMMIT" ]; then echo "ERROR: commit $ACTUAL distinto del esperado $SD_COMMIT" >&2; exit 1; fi
git -C "$DEST" submodule update --init --recursive --depth 1
echo "$ACTUAL" > "$DEST/.pinned_commit"
# Licencia: se conserva junto al código descargado (MIT, atribución obligatoria al redistribuir).
test -f "$DEST/LICENSE" && echo "Licencia presente: $(head -1 "$DEST/LICENSE")"
find "$DEST" -name .git -maxdepth 3 -prune -exec rm -rf {} + 2>/dev/null || true
echo "stable-diffusion.cpp $SD_TAG listo en $DEST"
