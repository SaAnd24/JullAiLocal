package com.jullai.local.engine;

/** Réplica en Java de las firmas nativas de LlamaBridge.kt, SOLO para la prueba en el equipo de desarrollo. */
public final class LlamaBridge {
    public interface TokenCallback { boolean onToken(byte[] bytes); }
    private LlamaBridge() {}
    public static native void nativeInit();
    public static native String nativeSystemInfo();
    public static native String nativeGetLog();
    public static native String nativeInspectModel(String path);
    public static native long nativeLoadModel(String path, boolean useMmap);
    public static native String nativeModelInfo(long model);
    public static native void nativeFreeModel(long model);
    public static native long nativeCreateContext(long model, int nCtx, int nBatch, int nThreads);
    public static native void nativeFreeContext(long ctx);
    public static native void nativeCancel(long ctx);
    public static native int nativeCountTokens(long model, String text);
    public static native String nativeApplyTemplate(long model, String[] roles, String[] contents, boolean addAssistant);
    public static native int nativeGenerate(long ctx, String prompt, int maxTokens, float temperature, float topP, int topK, long seed, boolean reuseCache, TokenCallback cb);
    public static native int nativeLastReused(long ctx);
    public static native void nativeResetCache(long ctx);
}
