import com.jullai.local.engine.LlamaBridge;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

public class HostTest {
    static int failures = 0;
    static void check(String name, boolean ok) {
        System.out.println((ok ? "[OK]   " : "[FALLO] ") + name);
        if (!ok) failures++;
    }

    public static void main(String[] args) throws Exception {
        String modelPath = args[0];
        String junkPath = args[1];
        System.loadLibrary("jullai_engine");
        LlamaBridge.nativeInit();
        check("info del sistema no vacía", LlamaBridge.nativeSystemInfo().length() > 0);

        // 1) Archivo inválido -> excepción clara, sin caída del proceso.
        boolean threw = false;
        try { LlamaBridge.nativeInspectModel(junkPath); } catch (IllegalStateException e) { threw = true; System.out.println("      mensaje: " + e.getMessage()); }
        check("archivo inválido lanza IllegalStateException", threw);

        threw = false;
        try { LlamaBridge.nativeLoadModel(junkPath, true); } catch (IllegalStateException e) { threw = true; }
        check("cargar archivo inválido lanza excepción", threw);

        // 2) Inspección con el motor.
        String info = LlamaBridge.nativeInspectModel(modelPath);
        System.out.println(info);
        check("inspección devuelve arquitectura llama", info.contains("architecture=llama"));

        // 3) Carga real + contexto.
        long model = LlamaBridge.nativeLoadModel(modelPath, true);
        check("modelo cargado (handle != 0)", model != 0);
        long ctx = LlamaBridge.nativeCreateContext(model, 256, 64, 2);
        check("contexto creado (handle != 0)", ctx != 0);

        // 4) Plantilla conversacional.
        String prompt = LlamaBridge.nativeApplyTemplate(model, new String[]{"system", "user"}, new String[]{"Eres útil.", "Hola"}, true);
        System.out.println("      prompt con plantilla: " + prompt.replace("\n", "\\n"));
        check("plantilla contiene marcas im_start", prompt.contains("<|im_start|>"));
        int nTok = LlamaBridge.nativeCountTokens(model, prompt);
        check("conteo de tokens > 0 (" + nTok + ")", nTok > 0);

        // 5) Generación progresiva con límite de tokens.
        AtomicInteger chunks = new AtomicInteger();
        ByteArrayOutputStream all = new ByteArrayOutputStream();
        int reason = LlamaBridge.nativeGenerate(ctx, prompt, 24, 0.8f, 0.9f, 40, 42L, false, b -> {
            chunks.incrementAndGet();
            all.write(b, 0, b.length);
            return true;
        });
        String text = new String(all.toByteArray(), StandardCharsets.UTF_8);
        check("generación devolvió tokens progresivamente (" + chunks.get() + " trozos)", chunks.get() > 1);
        check("fin por límite de tokens (razón=" + reason + ")", reason == 1);

        // 6) Determinismo con semilla fija / temperatura 0 (greedy).
        ByteArrayOutputStream g1 = new ByteArrayOutputStream(), g2 = new ByteArrayOutputStream();
        LlamaBridge.nativeGenerate(ctx, prompt, 12, 0f, 1f, 0, 1L, false, b -> { g1.write(b, 0, b.length); return true; });
        LlamaBridge.nativeGenerate(ctx, prompt, 12, 0f, 1f, 0, 1L, false, b -> { g2.write(b, 0, b.length); return true; });
        check("greedy reproducible entre dos generaciones", java.util.Arrays.equals(g1.toByteArray(), g2.toByteArray()));

        // 7) Cancelación desde el callback.
        AtomicInteger n2 = new AtomicInteger();
        int r2 = LlamaBridge.nativeGenerate(ctx, prompt, 200, 0.8f, 0.9f, 40, 7L, false, b -> n2.incrementAndGet() < 3);
        check("cancelación desde callback (razón=" + r2 + ", trozos=" + n2.get() + ")", r2 == 2 && n2.get() == 3);

        // 8) Cancelación desde OTRO hilo con nativeCancel.
        final long ctxF = ctx;
        AtomicInteger n3 = new AtomicInteger();
        Thread canceller = new Thread(() -> {
            try { while (n3.get() < 5) Thread.sleep(1); } catch (InterruptedException ignored) {}
            LlamaBridge.nativeCancel(ctxF);
        });
        canceller.start();
        int r3 = LlamaBridge.nativeGenerate(ctx, prompt, 5000, 0.8f, 0.9f, 40, 9L, false, b -> { n3.incrementAndGet(); return true; });
        canceller.join();
        check("nativeCancel desde otro hilo detiene la generación (razón=" + r3 + ", trozos=" + n3.get() + ")", r3 == 2 && n3.get() < 5000);

        // 9) La generación puede reanudarse tras cancelar (el motor sigue sano).
        int r4 = LlamaBridge.nativeGenerate(ctx, prompt, 5, 0.8f, 0.9f, 40, 11L, false, b -> true);
        check("nueva generación tras cancelar funciona (razón=" + r4 + ")", r4 == 1);

        // 10) Mensaje que no cabe en el contexto -> excepción, no caída.
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 400; i++) sb.append("palabra ");
        threw = false;
        try { LlamaBridge.nativeGenerate(ctx, sb.toString(), 5, 0.8f, 0.9f, 40, 1L, false, b -> true); } catch (IllegalStateException e) { threw = true; System.out.println("      mensaje: " + e.getMessage()); }
        check("prompt demasiado largo lanza excepción", threw);

        // 10b) Reutilización de la caché KV (v0.2): mismo resultado que sin caché y menos tokens procesados.
        String p1 = LlamaBridge.nativeApplyTemplate(model, new String[]{"system", "user"}, new String[]{"Eres util.", "Cuenta una historia corta sobre un faro."}, true);
        String p2 = LlamaBridge.nativeApplyTemplate(model, new String[]{"system", "user", "assistant", "user"}, new String[]{"Eres util.", "Cuenta una historia corta sobre un faro.", "Habia una vez un faro.", "Sigue."}, true);
        LlamaBridge.nativeResetCache(ctx);
        ByteArrayOutputStream noCache = new ByteArrayOutputStream();
        LlamaBridge.nativeGenerate(ctx, p1, 6, 0f, 1f, 0, 1L, false, b -> true);
        LlamaBridge.nativeGenerate(ctx, p2, 10, 0f, 1f, 0, 1L, false, b -> { noCache.write(b, 0, b.length); return true; });
        check("sin reutilización: 0 tokens reutilizados", LlamaBridge.nativeLastReused(ctx) == 0);
        LlamaBridge.nativeResetCache(ctx);
        ByteArrayOutputStream withCache = new ByteArrayOutputStream();
        LlamaBridge.nativeGenerate(ctx, p1, 6, 0f, 1f, 0, 1L, true, b -> true);
        LlamaBridge.nativeGenerate(ctx, p2, 10, 0f, 1f, 0, 1L, true, b -> { withCache.write(b, 0, b.length); return true; });
        int reusedN = LlamaBridge.nativeLastReused(ctx);
        check("con caché reutiliza tokens del turno anterior (" + reusedN + ")", reusedN > 0);
        check("con caché el resultado greedy es idéntico al de sin caché", java.util.Arrays.equals(noCache.toByteArray(), withCache.toByteArray()));
        // Mismo prompt exacto dos veces: reutiliza casi todo pero decodifica al menos 1 token.
        LlamaBridge.nativeGenerate(ctx, p2, 4, 0f, 1f, 0, 1L, true, b -> true);
        int reusedSame = LlamaBridge.nativeLastReused(ctx);
        check("mismo prompt repetido reutiliza el prefijo (" + reusedSame + ")", reusedSame > 0);
        // Tras cancelar en mitad de una generación con caché, la siguiente sigue siendo correcta.
        AtomicInteger n5 = new AtomicInteger();
        LlamaBridge.nativeGenerate(ctx, p2, 100, 0.8f, 0.9f, 40, 5L, true, b -> n5.incrementAndGet() < 2);
        ByteArrayOutputStream afterCancel = new ByteArrayOutputStream();
        LlamaBridge.nativeGenerate(ctx, p2, 10, 0f, 1f, 0, 1L, true, b -> { afterCancel.write(b, 0, b.length); return true; });
        check("tras cancelar con caché la salida greedy sigue siendo idéntica", java.util.Arrays.equals(noCache.toByteArray(), afterCancel.toByteArray()));
        // Un prompt totalmente distinto no reutiliza nada y funciona.
        LlamaBridge.nativeGenerate(ctx, "<|im_start|>user\nOtra cosa totalmente distinta<|im_end|>\n<|im_start|>assistant\n", 4, 0f, 1f, 0, 1L, true, b -> true);
        check("prompt distinto reutiliza poco o nada (" + LlamaBridge.nativeLastReused(ctx) + ")", LlamaBridge.nativeLastReused(ctx) < reusedN);

        // 11) Liberación explícita.
        LlamaBridge.nativeFreeContext(ctx);
        LlamaBridge.nativeFreeModel(model);
        check("recursos liberados sin caída", true);

        // 12) Ciclo cargar/liberar repetido (detecta fugas evidentes / dobles liberaciones).
        for (int i = 0; i < 5; i++) {
            long m = LlamaBridge.nativeLoadModel(modelPath, true);
            long c = LlamaBridge.nativeCreateContext(m, 128, 32, 2);
            LlamaBridge.nativeGenerate(c, prompt, 3, 0f, 1f, 0, 1L, false, b -> true);
            LlamaBridge.nativeFreeContext(c);
            LlamaBridge.nativeFreeModel(m);
        }
        check("5 ciclos cargar/generar/liberar", true);

        System.out.println(failures == 0 ? "\nTODAS LAS PRUEBAS PASARON" : "\nFALLOS: " + failures);
        System.exit(failures == 0 ? 0 : 1);
    }
}
