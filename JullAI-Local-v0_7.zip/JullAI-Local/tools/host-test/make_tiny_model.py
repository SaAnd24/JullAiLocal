#!/usr/bin/env python3
"""Genera un modelo GGUF minúsculo con PESOS ALEATORIOS para probar la mecánica del motor
(cargar, generar, cancelar, liberar). No produce texto con sentido: solo valida la tubería nativa.
Usa el vocabulario de llama.cpp/models/ggml-vocab-llama-spm.gguf.
Uso: make_tiny_model.py <llama.cpp dir> <salida.gguf>
"""
import sys
import numpy as np

llama_dir, out_path = sys.argv[1], sys.argv[2]
sys.path.insert(0, f"{llama_dir}/gguf-py")
from gguf import GGUFReader, GGUFWriter  # noqa: E402

vocab = GGUFReader(f"{llama_dir}/models/ggml-vocab-llama-spm.gguf")

def field_value(name):
    f = vocab.fields[name]
    return f.contents()

tokens = field_value("tokenizer.ggml.tokens")
scores = field_value("tokenizer.ggml.scores")
types = field_value("tokenizer.ggml.token_type")

n_vocab, n_embd, n_ff, n_head, n_layer = len(tokens), 64, 128, 4, 2
w = GGUFWriter(out_path, "llama")
w.add_name("tiny-random-test")
w.add_context_length(512)
w.add_embedding_length(n_embd)
w.add_block_count(n_layer)
w.add_feed_forward_length(n_ff)
w.add_head_count(n_head)
w.add_head_count_kv(n_head)
w.add_layer_norm_rms_eps(1e-5)
w.add_rope_dimension_count(n_embd // n_head)
w.add_vocab_size(n_vocab)
w.add_file_type(0)
w.add_tokenizer_model("llama")
w.add_token_list(tokens)
w.add_token_scores(scores)
w.add_token_types(types)
w.add_bos_token_id(1)
w.add_eos_token_id(2)
w.add_unk_token_id(0)
w.add_add_bos_token(True)
w.add_add_eos_token(False)
w.add_chat_template("{% for m in messages %}<|im_start|>{{ m['role'] }}\n{{ m['content'] }}<|im_end|>\n{% endfor %}{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}")

rng = np.random.default_rng(1234)
def t(*shape, scale=0.05):
    return (rng.standard_normal(shape) * scale).astype(np.float32)

w.add_tensor("token_embd.weight", t(n_vocab, n_embd))
w.add_tensor("output_norm.weight", np.ones(n_embd, dtype=np.float32))
w.add_tensor("output.weight", t(n_vocab, n_embd))
for i in range(n_layer):
    w.add_tensor(f"blk.{i}.attn_norm.weight", np.ones(n_embd, dtype=np.float32))
    w.add_tensor(f"blk.{i}.attn_q.weight", t(n_embd, n_embd))
    w.add_tensor(f"blk.{i}.attn_k.weight", t(n_embd, n_embd))
    w.add_tensor(f"blk.{i}.attn_v.weight", t(n_embd, n_embd))
    w.add_tensor(f"blk.{i}.attn_output.weight", t(n_embd, n_embd))
    w.add_tensor(f"blk.{i}.ffn_norm.weight", np.ones(n_embd, dtype=np.float32))
    w.add_tensor(f"blk.{i}.ffn_gate.weight", t(n_ff, n_embd))
    w.add_tensor(f"blk.{i}.ffn_up.weight", t(n_ff, n_embd))
    w.add_tensor(f"blk.{i}.ffn_down.weight", t(n_embd, n_ff))

w.write_header_to_file()
w.write_kv_data_to_file()
w.write_tensors_to_file()
w.close()
print("modelo de prueba escrito en", out_path)
