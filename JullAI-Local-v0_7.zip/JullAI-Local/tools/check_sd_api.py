#!/usr/bin/env python3
"""Comprobación RÁPIDA, antes de compilar, de que la cabecera real de stable-diffusion.cpp contiene lo que usa sd_core.cpp.
No sustituye a compilar: da un diagnóstico legible si la API cambió. Salida != 0 solo si falta algo IMPRESCINDIBLE."""
import re, sys, pathlib
root = pathlib.Path(__file__).resolve().parents[1] / "sdengine/src/main/cpp/stable-diffusion.cpp"
hdr = root / "include" / "stable-diffusion.h"
if not hdr.exists():
    print(f"No existe {hdr}. ¿Se ejecutó tools/fetch_sd.sh?"); sys.exit(2)
t = hdr.read_text(encoding="utf-8", errors="replace")
required = ["sd_ctx_params_init", "sd_img_gen_params_init", "new_sd_ctx", "free_sd_ctx", "generate_image", "sd_image_t", "sd_ctx_params_t", "sd_img_gen_params_t"]
optional = {"sd_cancel_generation": "cancelar", "sd_set_progress_callback": "progreso", "sd_set_log_callback": "registro", "str_to_sample_method": "sampler por nombre",
            "vae_tiling_params": "VAE por mosaicos", "loras": "LoRA", "init_image": "image-to-image", "negative_prompt": "prompt negativo"}
fields = ["model_path", "n_threads", "vae_decode_only", "free_params_immediately", "prompt", "width", "height", "seed", "sample_params", "sample_steps", "txt_cfg"]
bad = [r for r in required if not re.search(r"\b" + r + r"\b", t)]
print("Cabecera:", hdr)
for name, why in optional.items():
    print(f"  opcional {name:<26} ({why}): {'presente' if re.search(chr(92)+'b'+name+chr(92)+'b', t) else 'AUSENTE → esa función no se ofrecerá'}")
for f in fields:
    if not re.search(r"\b" + f + r"\b", t): print(f"  AVISO: campo «{f}» no aparece en la cabecera (sd_core lo omitirá; la generación puede degradarse)")
if bad:
    print("FALTA lo imprescindible:", ", ".join(bad)); sys.exit(1)
print("OK: lo imprescindible está en la cabecera (la compilación real lo confirmará).")
