#include <cassert>
#include <cstdio>
#include <string>
#include <thread>
#include "sd_core.hpp"
#define CHECK(c) do { if (!(c)) { std::printf("FALLO línea %d: %s\n", __LINE__, #c); return 1; } } while (0)
int main() {
    jsd::init_logging();
    auto caps = jsd::capabilities();
    CHECK(caps.find("cancel=1") != std::string::npos);
    CHECK(caps.find("progress=1") != std::string::npos);
    CHECK(caps.find("lora=1") != std::string::npos);
    CHECK(caps.find("img2img=1") != std::string::npos);
    std::string err;
    CHECK(jsd::load("/tmp/bad.safetensors", 2, false, err) == nullptr);
    CHECK(err.find("tensor mismatch") != std::string::npos);
    void* ctx = jsd::load("/tmp/ok.safetensors", 2, true, err);
    CHECK(ctx != nullptr);
    jsd::GenParams p; p.prompt = "a cat"; p.negative = "bad"; p.width = 64; p.height = 64; p.steps = 4; p.cfg = 1.0f; p.sampler = "lcm"; p.seed = 7;
    p.lora_path = "/tmp/lcm.safetensors";
    int calls = 0;
    auto r = jsd::generate(ctx, p, [&](int s, int n, float) { if (s <= n) ++calls; });
    CHECK(r.ok); CHECK(r.width == 64 && r.height == 64); CHECK(r.rgb.size() == 64u * 64 * 3); CHECK(calls == 4);
    bool lora = false, tile = false, ign = false;
    for (auto& a : r.applied) { if (a.find("LoRA") == 0) lora = true; if (a.find("mosaicos") != std::string::npos) tile = true; }
    for (auto& a : r.ignored) if (a.find("sin efecto con CFG 1") != std::string::npos) ign = true;
    CHECK(lora); CHECK(tile); CHECK(ign);
    // img2img
    p.init_rgb.assign(64 * 64 * 3, 10);
    auto r2 = jsd::generate(ctx, p, nullptr);
    CHECK(r2.ok);
    // cancelación a mitad
    p.steps = 50; p.init_rgb.clear();
    std::thread t([&] { std::this_thread::sleep_for(std::chrono::milliseconds(100)); jsd::cancel(); });
    auto r3 = jsd::generate(ctx, p, nullptr);
    t.join();
    CHECK(!r3.ok); CHECK(r3.cancelled);
    // tras cancelar, otra generación funciona
    p.steps = 2;
    auto r4 = jsd::generate(ctx, p, nullptr);
    CHECK(r4.ok);
    jsd::release(ctx);
    std::printf("OK: 8 comprobaciones del núcleo nativo contra la cabecera SIMULADA\n");
    return 0;
}
