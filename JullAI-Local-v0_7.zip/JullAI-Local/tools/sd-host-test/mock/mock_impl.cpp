#include <atomic>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <string>
#include <thread>
#include "stable-diffusion.h"
struct sd_ctx_t { std::string path; };
static std::atomic<bool> g_cancel{false};
static sd_progress_cb_t g_pcb = nullptr; static void* g_pdata = nullptr;
static sd_log_cb_t g_lcb = nullptr;
void sd_set_log_callback(sd_log_cb_t cb, void*) { g_lcb = cb; }
void sd_set_progress_callback(sd_progress_cb_t cb, void* d) { g_pcb = cb; g_pdata = d; }
void sd_ctx_params_init(sd_ctx_params_t* p) { memset(p, 0, sizeof(*p)); p->free_params_immediately = true; p->vae_decode_only = true; }
void sd_img_gen_params_init(sd_img_gen_params_t* p) { memset(p, 0, sizeof(*p)); p->sample_params.guidance.txt_cfg = 7.f; p->sample_params.sample_steps = 20; }
sd_ctx_t* new_sd_ctx(const sd_ctx_params_t* p) {
    if (!p->model_path || std::string(p->model_path).find("bad") != std::string::npos) { if (g_lcb) g_lcb(SD_LOG_ERROR, "error: tensor mismatch\n", nullptr); return nullptr; }
    return new sd_ctx_t{p->model_path};
}
void free_sd_ctx(sd_ctx_t* c) { delete c; }
enum sample_method_t str_to_sample_method(const char* s) { std::string x = s; return x == "euler_a" ? EULER_A_SAMPLE_METHOD : x == "euler" ? EULER_SAMPLE_METHOD : x == "lcm" ? LCM_SAMPLE_METHOD : SAMPLE_METHOD_COUNT; }
void sd_cancel_generation(enum sd_cancel_mode_t) { g_cancel = true; }
bool generate_image(sd_ctx_t*, const sd_img_gen_params_t* p, sd_image_t** images_out, int* num_images_out) {
    *images_out = nullptr; *num_images_out = 0;
    g_cancel = false;
    int steps = p->sample_params.sample_steps;
    for (int i = 1; i <= steps; ++i) {
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
        if (g_pcb) g_pcb(i, steps, 0.02f, g_pdata);
        if (g_cancel) return false;
    }
    auto* img = (sd_image_t*)malloc(sizeof(sd_image_t));
    img->width = p->width; img->height = p->height; img->channel = 3;
    img->data = (uint8_t*)malloc((size_t)p->width * p->height * 3);
    for (size_t i = 0; i < (size_t)p->width * p->height * 3; ++i) img->data[i] = (uint8_t)(i % 251);
    *images_out = img; *num_images_out = 1;
    return true;
}
