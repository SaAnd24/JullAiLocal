// CABECERA SIMULADA. Reproduce de memoria la FORMA de la API de stable-diffusion.cpp solo para comprobar que sd_core.cpp compila
// y que su lógica (campos opcionales, cancelación, errores, conversión RGB) se comporta. NO es la cabecera real del commit fijado:
// que el código compile contra la real lo comprueba el workflow (tools/check_sd_api.py + CMake).
#pragma once
#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
enum sd_log_level_t { SD_LOG_DEBUG, SD_LOG_INFO, SD_LOG_WARN, SD_LOG_ERROR };
enum sample_method_t { EULER_A_SAMPLE_METHOD, EULER_SAMPLE_METHOD, LCM_SAMPLE_METHOD, SAMPLE_METHOD_COUNT };
enum sd_cancel_mode_t { SD_CANCEL_ALL, SD_CANCEL_NEW_ONLY };
typedef struct { uint32_t width; uint32_t height; uint32_t channel; uint8_t* data; } sd_image_t;
typedef struct { float txt_cfg; } sd_guidance_params_t;
typedef struct { sd_guidance_params_t guidance; enum sample_method_t sample_method; int sample_steps; } sd_sample_params_t;
typedef struct { bool enabled; int tile_size_w; } sd_tiling_params_t;
typedef struct { const char* path; float multiplier; } sd_lora_t;
typedef struct sd_ctx_t sd_ctx_t;
typedef struct { const char* model_path; int n_threads; bool vae_decode_only; bool free_params_immediately; } sd_ctx_params_t;
typedef struct {
    const sd_lora_t* loras; uint32_t lora_count; const char* prompt; const char* negative_prompt;
    sd_image_t init_image; int width; int height; sd_sample_params_t sample_params; float strength; int64_t seed; int batch_count;
    sd_tiling_params_t vae_tiling_params;
} sd_img_gen_params_t;
typedef void (*sd_log_cb_t)(enum sd_log_level_t level, const char* text, void* data);
typedef void (*sd_progress_cb_t)(int step, int steps, float time, void* data);
void sd_set_log_callback(sd_log_cb_t cb, void* data);
void sd_set_progress_callback(sd_progress_cb_t cb, void* data);
void sd_ctx_params_init(sd_ctx_params_t* p);
void sd_img_gen_params_init(sd_img_gen_params_t* p);
sd_ctx_t* new_sd_ctx(const sd_ctx_params_t* p);
void free_sd_ctx(sd_ctx_t* ctx);
bool generate_image(sd_ctx_t* ctx, const sd_img_gen_params_t* p, sd_image_t** images_out, int* num_images_out);
enum sample_method_t str_to_sample_method(const char* s);
void sd_cancel_generation(enum sd_cancel_mode_t mode);
#ifdef __cplusplus
}
#endif
