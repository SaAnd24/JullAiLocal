#!/usr/bin/env bash
# Compila sd_core.cpp contra la cabecera SIMULADA y ejecuta las comprobaciones. No prueba compatibilidad con stable-diffusion.cpp real.
set -euo pipefail
cd "$(dirname "$0")"
CPP=../../sdengine/src/main/cpp
g++ -std=c++17 -Wall -Wextra -pthread -Imock -I$CPP \
  -DJULLAI_SD_HAS_CANCEL -DJULLAI_SD_HAS_PROGRESS -DJULLAI_SD_HAS_LOG -DJULLAI_SD_HAS_SAMPLER_NAME \
  $CPP/sd_core.cpp mock/mock_impl.cpp test_main.cpp -o /tmp/sd_host_test
/tmp/sd_host_test
