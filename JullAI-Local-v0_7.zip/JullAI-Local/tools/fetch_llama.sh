#!/usr/bin/env bash
# Descarga llama.cpp en una versión FIJA (etiqueta + commit) dentro de app/src/main/cpp/llama.cpp.
# Fijar el commit garantiza que la compilación sea reproducible aunque el proyecto original cambie.
set -euo pipefail

LLAMA_TAG="b11829"
LLAMA_COMMIT="184f6536024668e8908ab8c86033d56708e62b40"
DEST="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/cpp/llama.cpp"

if [ -f "$DEST/CMakeLists.txt" ]; then
  CURRENT="$(cat "$DEST/.pinned_commit" 2>/dev/null || echo unknown)"
  if [ "$CURRENT" = "$LLAMA_COMMIT" ]; then
    echo "llama.cpp $LLAMA_TAG ya está descargado."
    exit 0
  fi
  echo "Hay una copia distinta de llama.cpp ($CURRENT); se reemplaza."
  rm -rf "$DEST"
fi

echo "Descargando llama.cpp $LLAMA_TAG ..."
git clone --depth 1 --branch "$LLAMA_TAG" https://github.com/ggml-org/llama.cpp "$DEST"

ACTUAL="$(git -C "$DEST" rev-parse HEAD)"
if [ "$ACTUAL" != "$LLAMA_COMMIT" ]; then
  echo "ERROR: el commit descargado ($ACTUAL) no coincide con el esperado ($LLAMA_COMMIT)." >&2
  exit 1
fi
echo "$ACTUAL" > "$DEST/.pinned_commit"
rm -rf "$DEST/.git"   # no hace falta el historial
echo "llama.cpp $LLAMA_TAG listo en $DEST"
