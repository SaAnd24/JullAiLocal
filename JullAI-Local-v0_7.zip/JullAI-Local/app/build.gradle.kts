plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.jullai.local"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.jullai.local"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "0.7.0"

        ndk {
            // Solo ARM64: el teléfono objetivo (Helio G100) es arm64-v8a.
            abiFilters += "arm64-v8a"
        }
        externalNativeBuild {
            cmake {
                // Siempre optimizado: una compilación "debug" de llama.cpp sería muchísimo más lenta.
                arguments += listOf("-DCMAKE_BUILD_TYPE=Release", "-DANDROID_STL=c++_static")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    signingConfigs {
        // Clave de DEPURACIÓN fija (contraseña pública "android"; no es una clave secreta ni de publicación).
        // Sin ella, GitHub Actions firma cada compilación con una clave distinta y Android se niega a instalar
        // una versión nueva encima de la anterior.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        jniLibs {
            // Debe quedar sin comprimir para poder cargarse directamente del APK.
            useLegacyPackaging = false
        }
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
        // Robolectric necesita los recursos de Android para las pruebas de la base de datos.
        unitTests.isIncludeAndroidResources = true
    }
}

ksp {
    // Room guarda aquí el esquema de cada versión de la base de datos (hay que subir esta carpeta al repositorio).
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    // v0.6: motor nativo de imágenes (stable-diffusion.cpp), en un módulo y una biblioteca .so separados del texto
    implementation(project(":sdengine"))
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Room (base de datos local). Sin migraciones destructivas.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    // v0.5: tareas de investigación que sobreviven a cierres de la app
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    ksp("androidx.room:room-compiler:2.6.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    testImplementation("androidx.test:core:1.6.1")
}
