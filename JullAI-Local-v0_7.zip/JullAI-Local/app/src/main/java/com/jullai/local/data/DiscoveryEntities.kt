package com.jullai.local.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/*
 * Investigación automática (v0.7). Todo es ADITIVO respecto a la 0.6: solo se añaden 2 tablas, ninguna tabla anterior cambia.
 *  - world_identity: qué obra y continuidad se identificó para un mundo y el plan de fuentes descubierto (para reanudar sin repetir).
 *  - canon_images: imágenes de personajes canónicos guardadas en la caché PRIVADA, con su origen y su licencia.
 */

/** Obra identificada para un mundo. [planJson] es el plan de fuentes ya descubierto (vacío si aún no se ha planificado). */
@Entity(
    tableName = "world_identity",
    foreignKeys = [ForeignKey(entity = WorldEntity::class, parentColumns = ["id"], childColumns = ["worldId"], onDelete = ForeignKey.CASCADE)],
)
data class WorldIdentityEntity(
    @PrimaryKey val worldId: Long,
    val qid: String = "",
    val title: String,
    val kind: String,
    val lang: String = "",
    val description: String = "",
    /** Un artículo de Wikipedia por línea: «idioma<TAB>título». */
    val wikipedia: String = "",
    val fandomSub: String = "",
    val fandomTitle: String = "",
    val planJson: String = "",
    val notes: String = "",
    val identifiedAt: Long,
    val plannedAt: Long? = null,
)

/** Imagen canónica de un personaje, cacheada en el almacenamiento privado. [file] es el nombre dentro de PortraitStore. */
@Entity(
    tableName = "canon_images",
    foreignKeys = [ForeignKey(entity = WorldEntity::class, parentColumns = ["id"], childColumns = ["worldId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["worldId"]), Index(value = ["worldId", "entryName"], unique = true)],
)
data class CanonImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val worldId: Long,
    val entryName: String,
    val pageApi: String = "",
    val pageTitle: String = "",
    val imageUrl: String = "",
    val fileName: String = "",
    val license: String = "",
    val attribution: String = "",
    val nonFree: Boolean = false,
    val file: String? = null,
    val sha256: String = "",
    /** OK = guardada; SIN_IMAGEN = la página no tiene una imagen utilizable; FALLIDA = error al descargarla (se puede reintentar). */
    val state: String = "FALLIDA",
    val error: String = "",
    val createdAt: Long,
    val updatedAt: Long,
)
