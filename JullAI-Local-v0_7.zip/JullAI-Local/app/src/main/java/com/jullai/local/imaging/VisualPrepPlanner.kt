package com.jullai.local.imaging

import com.jullai.local.story.TextNorm
import com.jullai.local.world.AssetKind

data class CharRef(val id: Long, val name: String, val appearance: String, val profile: VisualProfile = VisualProfile(), val stage: String = "")
data class PlaceRef(val name: String, val description: String = "")

/** Lo que ya existe (importado o generado), para no pedir lo que ya se tiene. */
data class ExistingAsset(val kind: String, val characterId: Long?, val locationRef: String, val emotion: String, val label: String)

class PlanInput(
    val worldId: Long?,
    val sessionId: Long?,
    val main: CharRef,
    val others: List<CharRef>,
    val places: List<PlaceRef>,
    val existing: List<ExistingAsset>,
    val preset: QualityPreset,
    val style: String = "",
    /** Expresiones que se usarán pronto (p. ej. las más habituales); por defecto, tres. */
    val expressions: List<String> = listOf("ALEGRIA", "SERIO", "TRISTEZA"),
    val openTaskKeys: Set<String> = emptySet(),
)

/**
 * Plan de preparación visual por mundo, en el orden pedido:
 * 1 imagen base del personaje principal · 2 retratos de otros esenciales · 3 fondo de la primera localización ·
 * 4 expresiones/poses cercanas · 5 recursos de futuras localizaciones · 6 ilustraciones (solo bajo petición; nunca se planifican solas).
 * Es una función pura: devuelve tareas, no ejecuta nada. Omite lo que ya existe o ya está en cola.
 */
object VisualPrepPlanner {
    const val MAX_OTHERS = 3
    const val MAX_FUTURE_PLACES = 2

    fun key(kind: String, characterId: Long?, place: String, emotion: String) =
        "$kind|${characterId ?: 0}|${TextNorm.fold(place).trim()}|$emotion"

    private fun has(existing: List<ExistingAsset>, kind: String, characterId: Long?, place: String, emotion: String): Boolean = existing.any { a ->
        a.kind == kind && a.characterId == characterId &&
            (kind != AssetKind.FONDO || TextNorm.fold(a.locationRef).trim() == TextNorm.fold(place).trim()) &&
            (kind != AssetKind.EXPRESION || a.emotion.equals(emotion, true))
    }

    fun plan(i: PlanInput): List<TaskSpec> {
        val out = ArrayList<TaskSpec>()
        fun add(spec: TaskSpec, k: String) {
            if (k in i.openTaskKeys || out.any { key(it.kind, it.characterId, it.locationRef, it.emotion) == k }) return
            out.add(spec)
        }
        val tier = i.preset.tier
        fun portrait(c: CharRef, priority: Int) {
            if (has(i.existing, AssetKind.RETRATO, c.id, "", "")) return
            val size = ImageSizes.forKind(AssetKind.RETRATO, tier)
            add(
                TaskSpec(AssetKind.RETRATO, priority, size, i.preset.steps, PromptBuilder.character(c.profile, c.appearance, stage = c.stage), PromptBuilder.negative(c.profile),
                    worldId = i.worldId, sessionId = i.sessionId, characterId = c.id, label = "Retrato de ${c.name}", preset = i.preset.id),
                key(AssetKind.RETRATO, c.id, "", ""),
            )
        }
        fun background(p: PlaceRef, priority: Int) {
            if (has(i.existing, AssetKind.FONDO, null, p.name, "")) return
            val size = ImageSizes.forKind(AssetKind.FONDO, tier)
            add(
                TaskSpec(AssetKind.FONDO, priority, size, i.preset.steps, PromptBuilder.background(i.style, p.name, p.description), PromptBuilder.DEFAULT_NEGATIVE + ", people, person, character",
                    worldId = i.worldId, sessionId = i.sessionId, label = "Fondo: ${p.name}", locationRef = p.name, preset = i.preset.id),
                key(AssetKind.FONDO, null, p.name, ""),
            )
        }
        // 1) base del personaje principal; 2) otros esenciales
        portrait(i.main, TaskPriority.FIRST_SCENE)
        i.others.take(MAX_OTHERS).forEach { portrait(it, TaskPriority.FIRST_SCENE) }
        // 3) fondo de la primera localización
        i.places.firstOrNull()?.let { background(it, TaskPriority.FIRST_SCENE) }
        // 4) expresiones (solo del principal; reutilizan la referencia si el motor lo permite)
        i.expressions.forEach { e ->
            if (has(i.existing, AssetKind.EXPRESION, i.main.id, "", e)) return@forEach
            val size = ImageSizes.forKind(AssetKind.RETRATO, tier)
            add(
                TaskSpec(AssetKind.EXPRESION, TaskPriority.NEXT_SCENE, size, i.preset.steps, PromptBuilder.character(i.main.profile, i.main.appearance, emotion = e, stage = i.main.stage), PromptBuilder.negative(i.main.profile),
                    worldId = i.worldId, sessionId = i.sessionId, characterId = i.main.id, label = "${i.main.name}: ${com.jullai.local.world.Emotion.label(e)}", emotion = e, preset = i.preset.id),
                key(AssetKind.EXPRESION, i.main.id, "", e),
            )
        }
        // 5) futuras localizaciones
        i.places.drop(1).take(MAX_FUTURE_PLACES).forEach { background(it, TaskPriority.VARIANT) }
        return out.sortedBy { it.priority }
    }
}
