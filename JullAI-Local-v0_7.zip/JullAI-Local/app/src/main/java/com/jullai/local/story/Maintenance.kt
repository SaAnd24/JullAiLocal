package com.jullai.local.story

import com.jullai.local.chat.ContextBuilder

/**
 * Mantenimiento de la memoria con el modelo local: UNA sola inferencia que propone resumen, recuerdos, cronología y
 * cambios de relación. Nada de lo que devuelve se guarda como verdad: el resumen es un borrador editable y el resto
 * entra como PROPUESTA que el usuario acepta, edita o descarta.
 */

data class ProposedMemory(val content: String, val importance: Int, val inferred: Boolean)
data class ProposedEvent(val text: String, val date: String)
data class ProposedRelation(val a: String, val b: String, val delta: RelDelta, val reason: String)

class ParsedMaintenance(
    val summary: String?,
    val memories: List<ProposedMemory>,
    val events: List<ProposedEvent>,
    val relations: List<ProposedRelation>,
    /** Líneas que no se pudieron interpretar (por si el modelo pequeño no siguió el formato). */
    val ignoredLines: Int,
    val raw: String,
) {
    fun isEmpty() = summary.isNullOrBlank() && memories.isEmpty() && events.isEmpty() && relations.isEmpty()
}

object MaintenanceParser {
    const val MAX_MEMORIES = 6
    const val MAX_INFERENCES = 3
    const val MAX_EVENTS = 5
    const val MAX_RELATIONS = 3
    private const val MIN_TEXT = 8

    private val LINE = Regex("""^\s*(?:[-*•]\s*|\d+[.)]\s*)?(RESUMEN|RECUERDO|INFERENCIA|CRONOLOG[IÍ]A|RELACI[OÓ]N)\s*(\[[^\]]*])?\s*[:：]?\s*(.*)$""", RegexOption.IGNORE_CASE)
    private val DELTA = Regex("""(confianza|afecto|respeto|rom[aá]ntico)\s*[=:]\s*([+\-−–]?\s*\d{1,3})""", RegexOption.IGNORE_CASE)

    fun parse(rawInput: String): ParsedMaintenance {
        val raw = rawInput.replace("\r\n", "\n")
        var summary: StringBuilder? = null
        val memories = ArrayList<ProposedMemory>()
        val events = ArrayList<ProposedEvent>()
        val relations = ArrayList<ProposedRelation>()
        var ignored = 0
        var inSummary = false
        var inferences = 0

        for (line in raw.lines()) {
            if (line.isBlank()) { if (inSummary) summary?.append('\n'); continue }
            val m = LINE.matchEntire(line)
            if (m == null) {
                if (inSummary) summary?.append('\n')?.append(line.trim()) else ignored++
                continue
            }
            inSummary = false
            val kind = TextNorm.fold(m.groupValues[1]).uppercase()
            val bracket = m.groupValues[2].removePrefix("[").removeSuffix("]").trim()
            val body = m.groupValues[3].trim()
            when {
                kind == "RESUMEN" -> {
                    if (summary == null) { summary = StringBuilder(body); inSummary = true }
                    else ignored++
                }
                kind == "RECUERDO" || kind == "INFERENCIA" -> {
                    val text = TextNorm.clean(body, StoryLimits.MEMORY_CHARS)
                    val inferred = kind == "INFERENCIA"
                    if (text.length < MIN_TEXT) { ignored++; continue }
                    val importance = Regex("""\d""").find(bracket)?.value?.toIntOrNull()?.coerceIn(1, 5) ?: 3
                    if (inferred) { if (inferences++ >= MAX_INFERENCES) continue }
                    else if (memories.count { !it.inferred } >= MAX_MEMORIES) continue
                    memories.add(ProposedMemory(text, importance, inferred))
                }
                kind.startsWith("CRONOLOG") -> {
                    val text = TextNorm.clean(body, StoryLimits.TIMELINE_CHARS)
                    if (text.length < MIN_TEXT) { ignored++; continue }
                    if (events.size < MAX_EVENTS) events.add(ProposedEvent(text, TextNorm.clean(bracket, StoryLimits.DATE_CHARS)))
                }
                kind.startsWith("RELACI") -> {
                    val names = bracket.split(Regex("""\s*(?:->|→|>|=>)\s*"""))
                    if (names.size != 2 || names.any { it.isBlank() }) { ignored++; continue }
                    val head = body.substringBefore('|')
                    val reason = TextNorm.clean(body.substringAfter('|', ""), StoryLimits.REASON_CHARS)
                    var t = 0; var a = 0; var r = 0; var ro = 0
                    var any = false
                    for (d in DELTA.findAll(head)) {
                        val v = d.groupValues[2].replace("−", "-").replace("–", "-").replace(" ", "").toIntOrNull() ?: continue
                        any = true
                        when (TextNorm.fold(d.groupValues[1])) {
                            "confianza" -> t = v
                            "afecto" -> a = v
                            "respeto" -> r = v
                            else -> ro = v
                        }
                    }
                    if (!any) { ignored++; continue }
                    if (relations.size < MAX_RELATIONS) {
                        relations.add(ProposedRelation(TextNorm.clean(names[0], StoryLimits.NAME_CHARS), TextNorm.clean(names[1], StoryLimits.NAME_CHARS), RelDelta(t, a, r, ro), reason))
                    }
                }
            }
        }
        val s = summary?.toString()?.let { TextNorm.clean(it, StoryLimits.SUMMARY_CHARS) }?.takeIf { it.isNotBlank() }
        return ParsedMaintenance(s, memories, events, relations, ignored, raw)
    }
}

/** Evita proponer lo que ya existe (o ya se descartó). */
object Dedup {
    const val THRESHOLD = 0.7

    fun isDuplicate(text: String, existing: Collection<String>, threshold: Double = THRESHOLD): Boolean =
        existing.any { TextNorm.similarity(text, it) >= threshold }

    fun <T> filterNew(items: List<T>, textOf: (T) -> String, existing: Collection<String>): List<T> {
        val seen = ArrayList<String>(existing)
        val out = ArrayList<T>()
        for (i in items) {
            val t = textOf(i)
            if (isDuplicate(t, seen)) continue
            seen.add(t)
            out.add(i)
        }
        return out
    }
}

object MaintenancePolicy {
    /** ¿Toca ejecutar el mantenimiento automáticamente? En MANUAL nunca; el botón del usuario siempre está disponible. */
    fun isDue(mode: String, everyTurns: Int, userTurnsSinceCovered: Int, chapterJustClosed: Boolean): Boolean = when (mode) {
        AutoMode.CADA_N -> userTurnsSinceCovered >= everyTurns.coerceAtLeast(3)
        AutoMode.CAPITULO -> chapterJustClosed
        else -> false
    }
}

/** Mensaje de la historia ya con el nombre de quien habla. */
data class StoryLine(val orderIndex: Int, val speaker: String, val text: String)

class MaintenancePrompt(
    val messages: List<com.jullai.local.engine.ChatMessage>,
    /** Último orderIndex de mensaje incluido (el siguiente mantenimiento seguirá desde ahí). */
    val coversUpTo: Int,
    val linesIncluded: Int,
    val linesPending: Int,
)

object MaintenancePrompts {
    const val SYSTEM = "Eres el archivista de una historia de rol. Lees un fragmento y devuelves SOLO líneas con estos prefijos, sin explicaciones ni saludos:\n" +
        "RESUMEN: resumen actualizado de toda la historia hasta ahora (3 a 8 frases, tercera persona, pasado): sucesos, decisiones, conflictos abiertos y tramas pendientes.\n" +
        "RECUERDO[1-5]: un hecho importante y duradero que ocurrió o quedó establecido (una frase). El número es su importancia.\n" +
        "INFERENCIA[1-5]: algo que se deduce pero que nadie dijo claramente (una frase).\n" +
        "CRONOLOGIA[cuándo]: un acontecimiento con su momento en la historia (por ejemplo «segundo día, noche»).\n" +
        "RELACION[Nombre>Nombre] confianza=+1 afecto=0 respeto=+2 romantico=0 | motivo breve\n" +
        "Reglas: usa solo lo que aparece en el texto y no inventes nada; no repitas los recuerdos ya conocidos; " +
        "máximo 6 RECUERDO, 3 INFERENCIA, 5 CRONOLOGIA y 3 RELACION; los cambios de relación van de -6 a +6 (romantico de -3 a +3) y solo si ocurrió algo en la escena."

    /** Reserva para la respuesta del modelo en el mantenimiento. */
    const val OUTPUT_TOKENS = 700

    /**
     * Construye el mensaje con el tramo SIN PROCESAR más antiguo que quepa (así no quedan huecos entre ejecuciones).
     * Devuelve null si no hay nada nuevo que procesar.
     */
    suspend fun build(
        participants: String,
        previousSummary: String,
        knownMemories: List<String>,
        lines: List<StoryLine>,
        contextLength: Int,
        count: suspend (String) -> Int,
        applyTemplate: suspend (List<com.jullai.local.engine.ChatMessage>) -> String,
    ): MaintenancePrompt? {
        if (lines.isEmpty()) return null
        val reserve = OUTPUT_TOKENS.coerceAtMost(contextLength / 3)
        val limit = contextLength - reserve - ContextBuilder.SAFETY_TOKENS
        val sysCost = count(SYSTEM) + ContextBuilder.PER_MESSAGE_OVERHEAD * 2
        var room = limit - sysCost - 40
        if (room < 120) return null

        // Resumen anterior y recuerdos conocidos: como mucho una cuarta parte del espacio cada uno.
        val prev = com.jullai.local.roleplay.RoleplayContextBuilder.truncate(previousSummary.trim(), room / 4, count)
        room -= if (prev.isEmpty()) 0 else count(prev) + 8
        val known = ArrayList<String>()
        var knownBudget = room / 5
        for (k in knownMemories) {
            val c = count(k) + 2
            if (c > knownBudget) continue
            knownBudget -= c
            known.add(k)
        }
        room -= known.sumOf { count(it) + 2 }
        if (room < 80) return null

        val included = ArrayList<StoryLine>()
        var used = 0
        for (l in lines) {
            val text = "${l.speaker}: ${l.text.trim()}"
            val c = count(text) + 2
            if (used + c > room) {
                if (included.isEmpty()) {
                    // Un mensaje enorme: se recorta para poder avanzar.
                    val cut = com.jullai.local.roleplay.RoleplayContextBuilder.truncate(l.text.trim(), room - 20, count)
                    included.add(l.copy(text = cut)); used = room
                }
                break
            }
            used += c
            included.add(l)
        }
        val body = buildString {
            append("PERSONAJES: ").append(participants).append('\n')
            if (prev.isNotEmpty()) append("\nRESUMEN ANTERIOR:\n").append(prev).append('\n')
            if (known.isNotEmpty()) { append("\nRECUERDOS YA CONOCIDOS (no los repitas):\n"); known.forEach { append("- ").append(it.trim().replace('\n', ' ')).append('\n') } }
            append("\nFRAGMENTO NUEVO DE LA HISTORIA:\n")
            included.forEach { append(it.speaker).append(": ").append(it.text.trim()).append('\n') }
        }
        val msgs = listOf(com.jullai.local.engine.ChatMessage("system", SYSTEM), com.jullai.local.engine.ChatMessage("user", body))
        return MaintenancePrompt(msgs, included.last().orderIndex, included.size, lines.size - included.size)
    }
}
