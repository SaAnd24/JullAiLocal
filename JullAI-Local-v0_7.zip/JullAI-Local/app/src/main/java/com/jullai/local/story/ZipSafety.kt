package com.jullai.local.story

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipException
import java.util.zip.ZipInputStream

/**
 * Lectura SEGURA de un .jullai (contenedor ZIP). Todo archivo importado es dato no confiable:
 *  - solo se aceptan nombres de una lista cerrada (nada de rutas absolutas, «..», barras invertidas ni unidades);
 *  - sin entradas duplicadas (ni siquiera con otras mayúsculas);
 *  - los tamaños se cuentan al LEER (no se confía en el tamaño que declara el archivo), así una bomba de compresión se corta;
 *  - límites de número de entradas, tamaño por entrada y tamaño total.
 * Nada se escribe en disco desde aquí: el contenido se devuelve en memoria, por nombre.
 */
object ZipSafety {
    class Limits(
        val maxEntries: Int = 64,
        val maxJsonBytes: Int = 16 * 1024 * 1024,
        val maxAssetBytes: Int = 6 * 1024 * 1024,
        val maxTotalBytes: Long = 48L * 1024 * 1024,
    )

    val DATA_FILES = listOf("personaje", "partida", "mensajes", "conocimiento", "memoria", "relaciones", "estructura")
    const val MANIFEST = "manifest.json"
    const val READABLE = "biblia.md"
    /** v0.5, OPCIONAL: instantánea del mundo de la partida (mismo contenido que un .worldpack, en un solo JSON). */
    const val WORLD_SNAPSHOT = "data/mundo.json"
    private val ASSET = Regex("""assets/[A-Za-z0-9_-]{1,64}\.(png|jpg|jpeg|webp)""")
    private val NAME_CHARS = Regex("""[A-Za-z0-9._/\-]{1,100}""")

    fun dataPath(name: String) = "data/$name.json"

    /** Devuelve el nombre si es aceptable; si no, lanza con un mensaje claro. */
    fun checkName(raw: String): String {
        if (raw.isEmpty() || raw.length > 100) throw BibleException("El archivo contiene un nombre interno no válido.")
        if (raw.startsWith("/") || raw.contains('\\') || raw.contains(':') || raw.contains('\u0000'))
            throw BibleException("El archivo contiene rutas no permitidas («$raw»). Se rechaza por seguridad.")
        val parts = raw.split('/')
        if (parts.any { it == ".." || it == "." || it.isEmpty() })
            throw BibleException("El archivo contiene rutas no permitidas («$raw»). Se rechaza por seguridad.")
        if (!NAME_CHARS.matches(raw)) throw BibleException("El archivo contiene un nombre con caracteres no permitidos.")
        val ok = raw == MANIFEST || raw == READABLE ||
            DATA_FILES.any { raw == dataPath(it) } || raw == WORLD_SNAPSHOT || ASSET.matches(raw)
        if (!ok) throw BibleException("El archivo contiene un elemento inesperado («$raw»). No parece un .jullai de esta app.")
        return raw
    }

    fun isJson(name: String) = name.endsWith(".json")

    fun read(input: InputStream, limits: Limits = Limits()): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        val seen = HashSet<String>()
        var total = 0L
        var entries = 0
        try {
            ZipInputStream(input).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val rawName = e.name
                    if (e.isDirectory) {
                        if (rawName != "data/" && rawName != "assets/") throw BibleException("El archivo contiene carpetas inesperadas («$rawName»).")
                        continue
                    }
                    if (++entries > limits.maxEntries) throw BibleException("El archivo contiene demasiados elementos (máximo ${limits.maxEntries}).")
                    val name = checkName(rawName)
                    if (!seen.add(name.lowercase())) throw BibleException("El archivo contiene el elemento «$name» repetido. Se rechaza por seguridad.")
                    val cap = if (isJson(name) || name == READABLE) limits.maxJsonBytes else limits.maxAssetBytes
                    val buf = ByteArrayOutputStream()
                    val chunk = ByteArray(16 * 1024)
                    var n = 0
                    while (true) {
                        val r = zin.read(chunk)
                        if (r < 0) break
                        n += r
                        total += r
                        if (n > cap) throw BibleException("El elemento «$name» es demasiado grande (límite ${cap / (1024 * 1024)} MB). Se rechaza el archivo.")
                        if (total > limits.maxTotalBytes) throw BibleException("El archivo descomprimido es demasiado grande (límite ${limits.maxTotalBytes / (1024 * 1024)} MB). Se rechaza.")
                        buf.write(chunk, 0, r)
                    }
                    out[name] = buf.toByteArray()
                }
            }
        } catch (e: BibleException) {
            throw e
        } catch (e: ZipException) {
            throw BibleException("El archivo no es un .jullai válido o está dañado (${e.message}).")
        } catch (e: java.io.EOFException) {
            throw BibleException("El archivo está incompleto o dañado.")
        } catch (e: java.io.IOException) {
            throw BibleException("No se pudo leer el archivo (${e.message}).")
        }
        if (out.isEmpty()) throw BibleException("El archivo está vacío o no es un .jullai.")
        return out
    }
}
