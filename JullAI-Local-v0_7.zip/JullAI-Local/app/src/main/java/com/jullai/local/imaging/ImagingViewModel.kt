package com.jullai.local.imaging

import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.AppContainer
import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.ImageMetaEntity
import com.jullai.local.data.ImageModelEntity
import com.jullai.local.data.ImageTaskEntity
import com.jullai.local.data.VisualAssetEntity
import com.jullai.local.data.VisualProfileEntity
import com.jullai.local.story.TextNorm
import com.jullai.local.world.AssetKind
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Formulario del estudio de imágenes. */
data class StudioForm(
    val prompt: String = "",
    val negative: String = PromptBuilder.DEFAULT_NEGATIVE,
    val seedText: String = "",
    val size: ImageSize = ImageSizes.PORTRAIT_LOW,
    val steps: Int = QualityPreset.LOW_POWER.steps,
    val presetId: String = QualityPreset.LOW_POWER.id,
    val kind: String = AssetKind.RETRATO,
    val characterId: Long? = null,
    val location: String = "",
    val emotion: String = "",
    val pose: String = "",
    val sourceTaskId: Long? = null,
)

class ImagingViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.imageRepository
    val store get() = c.portraits
    val engine get() = c.imageEngine

    val models: StateFlow<List<ImageModelEntity>> = repo.observeModels().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks: StateFlow<List<ImageTaskEntity>> = repo.observeTasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val metas: StateFlow<List<ImageMetaEntity>> = repo.observeMeta().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val assets: StateFlow<List<VisualAssetEntity>> = c.worldRepository.observeAssets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val characters: StateFlow<List<CharacterEntity>> = c.roleplayRepository.characters().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val settings get() = c.imageSettings.settings
    val queueRunning get() = c.imageQueue.running
    val progress get() = c.imageQueue.progress
    val queueMessage get() = c.imageQueue.message
    val queueError get() = c.imageQueue.lastError
    val currentTask get() = c.imageQueue.currentTask
    val coord get() = c.coordinator.state

    private val _form = MutableStateFlow(StudioForm())
    val form: StateFlow<StudioForm> = _form.asStateFlow()
    private val _diag = MutableStateFlow<EngineDiagnostics?>(null)
    val diag: StateFlow<EngineDiagnostics?> = _diag.asStateFlow()
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()
    private val _busy = MutableStateFlow<String?>(null)
    val busy: StateFlow<String?> = _busy.asStateFlow()
    private val _copied = MutableStateFlow(0L)
    val importedBytes: StateFlow<Long> = _copied.asStateFlow()

    fun clearNotice() { _notice.value = null }
    fun edit(f: (StudioForm) -> StudioForm) = _form.update(f)

    private fun act(label: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            if (label != null) _busy.value = label
            try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) { _notice.value = e.message ?: "Error inesperado." } finally { if (label != null) _busy.value = null }
        }
    }

    fun refreshDiagnostics() = act { _diag.value = engine.diagnose() }

    fun capabilities(): EngineCapabilities = engine.capabilities()
    fun costHistoryLoader(): suspend () -> List<Pair<Double, Long>> = { repo.costHistory() }

    // ---------------- modelos ----------------
    fun importModel(uri: Uri, kindHint: String?) = act("Importando el modelo… (puede tardar: son varios cientos de MB)") {
        _copied.value = 0
        val (name, size) = withContext(Dispatchers.IO) {
            c.app.contentResolver.query(uri, null, null, null, null)?.use { cur ->
                val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = cur.getColumnIndex(OpenableColumns.SIZE)
                if (cur.moveToFirst()) (if (ni >= 0) cur.getString(ni) else null).orEmpty() to (if (si >= 0) cur.getLong(si) else -1L) else "" to -1L
            } ?: ("" to -1L)
        }
        val out = withContext(Dispatchers.IO) { c.imageModels.import(uri, name.substringBeforeLast('.'), size, kindHint) { _copied.value = it } }
        when (out) {
            is ImportOutcome.Rejected -> _notice.value = "No se importó: ${out.reason}"
            is ImportOutcome.Imported -> {
                repo.addModel(out.entity)
                _notice.value = "Importado «${out.entity.displayName}» (${out.probe.summary()}). Estructura reconocida, pero AÚN NO comprobada con el motor: pulsa «Comprobar con el motor».".plus(if (out.probe.warnings.isNotEmpty()) " Avisos: " + out.probe.warnings.joinToString(" ") else "")
            }
        }
        _copied.value = 0
    }

    fun validateModel(m: ImageModelEntity) = act("Comprobando el modelo con el motor…") {
        if (m.kind == ImageModelKinds.LORA) { _notice.value = "Una LoRA no se puede comprobar sola: se valida al aplicarla en una generación."; return@act }
        val err = c.coordinator.probeLoad(c.imageModels.file(m).absolutePath, m.sizeBytes, c.imageSettings.settings.value.threads)
        repo.markValidated(m.id, err == null, err ?: "Cargado correctamente por el motor.")
        _notice.value = if (err == null) "El motor cargó «${m.displayName}» correctamente. El modelo de texto se recargará al enviar tu próxima acción." else "El motor NO aceptó el modelo: $err"
    }

    fun setDefault(m: ImageModelEntity) = act { repo.setDefault(m.id) }
    fun clearDefaultLora() = act { repo.clearDefault(ImageModelKinds.LORA) }
    fun deleteModel(m: ImageModelEntity) = act { repo.deleteModel(m.id)?.let { c.imageModels.delete(it) } }

    // ---------------- estudio ----------------
    fun fillFromProfile() = act {
        val f = _form.value
        val ch = characters.value.firstOrNull { it.id == f.characterId }
        if (ch == null) { _notice.value = "Elige primero un personaje."; return@act }
        val p = repo.profile(ch.id)?.toProfile() ?: VisualProfile()
        val prompt = when (f.kind) {
            AssetKind.FONDO -> PromptBuilder.background(p.style, f.location, "")
            else -> PromptBuilder.character(p, ch.appearance, f.emotion, f.pose)
        }
        _form.update { it.copy(prompt = prompt, negative = PromptBuilder.negative(p)) }
    }

    fun applyPreset(id: String) {
        val p = QualityPreset.byId(id)
        _form.update { it.copy(presetId = p.id, steps = p.steps, size = ImageSizes.forKind(it.kind, p.tier)) }
    }

    fun setKind(kind: String) = _form.update { it.copy(kind = kind, size = ImageSizes.forKind(kind, QualityPreset.byId(it.presetId).tier)) }

    /** Encola la generación del estudio (misma cola y mismas reglas que todo lo demás). [newSeed] = regenerar con otra semilla. */
    fun generate(newSeed: Boolean = false) = act {
        val f = _form.value
        val s = c.imageSettings.settings.value
        if (!s.enabled) { _notice.value = "La generación de imágenes está desactivada en los ajustes visuales."; return@act }
        if (f.prompt.isBlank()) { _notice.value = "Escribe un prompt."; return@act }
        if (repo.defaultModel(ImageModelKinds.CHECKPOINT) == null) { _notice.value = "Importa antes un checkpoint SD 1.x en la pestaña «Modelos»."; return@act }
        var preset = QualityPreset.byId(f.presetId)
        val caps = engine.capabilities()
        if (preset.needsLcmLora && (repo.defaultModel(ImageModelKinds.LORA) == null || !caps.lora)) {
            preset = QualityPreset.LOW_POWER
            _notice.value = "Sin LoRA LCM seleccionada se usa el modo de bajo consumo normal."
        }
        val seed = if (newSeed) -1L else (f.seedText.trim().toLongOrNull() ?: -1L)
        val id = c.imageQueue.enqueue(
            TaskSpec(
                kind = f.kind, priority = TaskPriority.FIRST_SCENE, size = f.size, steps = f.steps.coerceIn(1, 50), prompt = f.prompt.trim(),
                negativePrompt = if (caps.negativePrompt) f.negative.trim() else "", characterId = f.characterId, label = characters.value.firstOrNull { it.id == f.characterId }?.let { "${AssetKind.label(f.kind)}: ${it.name}" } ?: AssetKind.label(f.kind),
                locationRef = f.location, emotion = f.emotion, pose = f.pose, seed = seed, preset = preset.id,
            ),
        )
        _form.update { it.copy(sourceTaskId = id) }
        c.imageQueue.kick(wake = true)
    }

    // ---------------- cola ----------------
    fun startQueue() { c.imageQueue.kick(wake = true) }
    fun cancelTask(id: Long) = act { c.imageQueue.cancel(id) }
    fun cancelAll() = act { c.imageQueue.cancelAll() }
    fun retryTask(id: Long) = act { c.imageQueue.retry(id) }
    fun clearFinished() = act { repo.clearFinished() }
    fun updateSettings(change: (ImageSettings) -> ImageSettings) = act { c.imageSettings.update(change) }

    /** Plan de preparación visual de una partida (principal + localizaciones). Solo encola lo que falta; no ejecuta nada por sí solo. */
    fun planForSession(sessionId: Long) = act("Preparando la lista de recursos…") {
        val session = c.roleplayRepository.getSession(sessionId) ?: run { _notice.value = "No se encontró la partida."; return@act }
        val ch = c.roleplayRepository.character(session.characterId) ?: run { _notice.value = "No se encontró el personaje."; return@act }
        val link = c.worldRepository.sessionWorld(sessionId)
        val places = link?.worldId?.let { c.worldRepository.locationNames(it) }.orEmpty().map { PlaceRef(it) }
        val profile = repo.profile(ch.id)?.toProfile() ?: VisualProfile()
        val existing = c.db.visualAssets().listAll().map { ExistingAsset(it.kind, it.characterId, it.locationRef, it.emotion, it.label) }
        val open = repo.pendingTasks().map { VisualPrepPlanner.key(it.kind, it.characterId, it.locationRef, it.emotion) }.toSet()
        val specs = VisualPrepPlanner.plan(
            PlanInput(link?.worldId, sessionId, CharRef(ch.id, ch.name, ch.appearance, profile), emptyList(), places, existing, QualityPreset.byId(c.imageSettings.settings.value.preset), openTaskKeys = open),
        )
        specs.forEach { c.imageQueue.enqueue(it) }
        _notice.value = if (specs.isEmpty()) "No falta ningún recurso básico (o ya están en cola)." else "${specs.size} tarea(s) añadidas a la cola. Pulsa «Generar ahora» cuando quieras empezar."
    }

    /** Ilustración de una escena (petición manual o sugerida). */
    fun illustrate(sessionId: Long, messageId: Long, narration: String, locationRef: String, run: Boolean = true) = act {
        val session = c.roleplayRepository.getSession(sessionId) ?: return@act
        val ch = c.roleplayRepository.character(session.characterId) ?: return@act
        val profile = repo.profile(ch.id)?.toProfile() ?: VisualProfile()
        val s = c.imageSettings.settings.value
        if (!s.enabled) { _notice.value = "La generación de imágenes está desactivada en los ajustes visuales."; return@act }
        if (repo.defaultModel(ImageModelKinds.CHECKPOINT) == null) { _notice.value = "Importa antes un checkpoint SD 1.x (Estudio de imágenes → Modelos). El texto de la historia sigue funcionando sin imágenes."; return@act }
        val preset = QualityPreset.byId(s.preset)
        val people = listOf(profile.physical.ifBlank { ch.appearance }.take(140)).filter { it.isNotBlank() }
        val prompt = PromptBuilder.scene(profile.style, PromptBuilder.summarizeScene(narration), people, locationRef)
        c.imageQueue.enqueue(
            TaskSpec(AssetKind.ILUSTRACION, TaskPriority.FIRST_SCENE, ImageSizes.forKind(AssetKind.ILUSTRACION, preset.tier), preset.steps, prompt, PromptBuilder.negative(profile),
                sessionId = sessionId, messageId = messageId, characterId = ch.id, label = "Escena: ${PromptBuilder.summarizeScene(narration, 40)}", locationRef = locationRef, preset = preset.id),
        )
        if (run) { c.imageQueue.kick(wake = true); _notice.value = null }   // petición manual: empieza ya (siempre detrás del texto)
    }

    // ---------------- galería ----------------
    fun reassign(a: VisualAssetEntity, kind: String, characterId: Long?, location: String, emotion: String, label: String) = act { repo.reassign(a.id, kind, characterId, location, emotion, label) }
    fun deleteAsset(a: VisualAssetEntity) = act { c.worldRepository.deleteAsset(a.id)?.let { c.portraits.delete(it) } }
    suspend fun metaOf(assetId: Long): ImageMetaEntity? = repo.meta(assetId)

    fun reuseParams(m: ImageMetaEntity, kind: String) {
        val size = ImageSizes.find(m.width, m.height) ?: ImageSizes.forKind(kind, 0)
        _form.update { it.copy(prompt = m.prompt, negative = m.negativePrompt, seedText = m.seed.toString(), size = size, steps = m.steps, presetId = m.preset.ifBlank { it.presetId }, kind = kind) }
    }

    // ---------------- perfil visual ----------------
    suspend fun profileOf(characterId: Long): VisualProfileEntity? = repo.profile(characterId)
    fun saveProfile(characterId: Long, physical: String, style: String, outfits: String, negative: String, reference: Long?) = act {
        repo.saveProfile(VisualProfileEntity(characterId = characterId, physicalDescription = physical.take(600), styleDescription = style.take(200), outfits = outfits.take(800), negativeDefaults = negative.take(300), referenceAssetId = reference, updatedAt = 0))
        _notice.value = "Perfil visual guardado."
    }

    fun suggestedReference(characterId: Long): Long? = assets.value.firstOrNull { it.characterId == characterId && it.kind == AssetKind.RETRATO }?.id

    fun hasModel(): Boolean = models.value.any { it.kind == ImageModelKinds.CHECKPOINT && it.compat != ModelCompat.REJECTED }
    fun folded(s: String) = TextNorm.fold(s)
}

fun VisualProfileEntity.toProfile() = VisualProfile(physicalDescription, styleDescription, outfits, negativeDefaults)
