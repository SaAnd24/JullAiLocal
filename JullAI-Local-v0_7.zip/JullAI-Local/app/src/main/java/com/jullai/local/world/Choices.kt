package com.jullai.local.world

/**
 * Elecciones opcionales sugeridas por el narrador («1) …», «A. …»). Solo se LEEN del final del texto para ofrecer botones:
 * el texto narrativo no se modifica y escribir una acción libre siempre es posible.
 */
object Choices {
    private val LINE = Regex("^\\s*(?:[-•*]\\s*)?(?:\\(?[1-4A-Da-d][.)]|\\[[1-4A-Da-d]])\\s+(.{3,90}?)\\s*$")

    fun parse(text: String): List<String> {
        val lines = text.trimEnd().lines().takeLast(8)
        val out = ArrayList<String>()
        for (l in lines.asReversed()) {
            val m = LINE.find(l)
            if (m != null) out.add(0, m.groupValues[1].trim()) else if (out.isNotEmpty()) break
        }
        return if (out.size in 2..4) out else emptyList()
    }
}
