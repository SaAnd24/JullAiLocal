package com.jullai.local.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/*
 * Mundos, conocimiento, fuentes e investigación (v0.5). Todo es ADITIVO respecto a la 0.4: ninguna tabla anterior cambia.
 *
 * Regla de oro: la enciclopedia de un mundo (world_entries) es DISTINTA de lo que ocurre en una partida (memories,
 * timeline_events... de la 0.4). Una partida nunca escribe en world_entries por sí sola.
 * Los valores de texto (tipos, confianza, estados) están definidos en world/WorldModels.kt.
 */

/** Un universo reutilizable. [uuid] identifica el mundo entre dispositivos y en los archivos .worldpack. */
@Entity(
    tableName = "worlds",
    indices = [Index(value = ["uuid"], unique = true), Index(value = ["updatedAt"])],
)
data class WorldEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uuid: String,
    val name: String,
    val description: String = "",
    val language: String = "es",
    val setting: String = "",
    val era: String = "",
    val rules: String = "",
    val narrativeLimits: String = "",
    val spoilerLevel: String = "SIN_SPOILERS",
    val castMode: String = "MIXTO",
    val continuityMode: String = "FLEXIBLE",
    val researchDepth: String = "BASICA",
    val preferredSources: String = "",
    val priorityCharacters: String = "",
    val priorityPlaces: String = "",
    val allowOnline: Boolean = false,
    val origin: String = "LOCAL",
    val revision: Int = 1,
    val createdAt: Long,
    val updatedAt: Long,
)

/** Hecho de la enciclopedia de un mundo. Guarda su procedencia y su nivel de confianza. */
@Entity(
    tableName = "world_entries",
    foreignKeys = [ForeignKey(entity = WorldEntity::class, parentColumns = ["id"], childColumns = ["worldId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["worldId"]), Index(value = ["worldId", "type"]), Index(value = ["worldId", "state"])],
)
data class WorldEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val worldId: Long,
    val type: String,
    val name: String,
    val aliases: String = "",
    val summary: String = "",
    val details: String = "",
    val confidence: String,
    val origin: String,
    val sourceId: Long? = null,
    val sourceRef: String = "",
    val evidence: String = "",
    val factKey: String = "",
    val contradictionGroup: String = "",
    val relatedNames: String = "",
    val spoilerLevel: Int = 0,
    val eraTag: String = "",
    val state: String = "ACTIVO",
    val createdAt: Long,
    val updatedAt: Long,
)

/** Fuente consultada o importada. El texto extraído se guarda en un archivo privado ([textFile]), no en la base. */
@Entity(
    tableName = "sources",
    foreignKeys = [ForeignKey(entity = WorldEntity::class, parentColumns = ["id"], childColumns = ["worldId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["worldId"]), Index(value = ["worldId", "uri"], unique = true)],
)
data class SourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val worldId: Long,
    val kind: String,
    val uri: String,
    val title: String = "",
    val status: String = "PENDIENTE",
    val error: String = "",
    val attempts: Int = 0,
    val consultedAt: Long? = null,
    val license: String = "",
    val provenance: String = "",
    val contentHash: String = "",
    val textFile: String? = null,
    val charCount: Int = 0,
    val taskId: Long? = null,
    val createdAt: Long,
    val updatedAt: Long,
)

/** Tarea de investigación: se guarda para poder cancelarla y reanudarla después de interrupciones. */
@Entity(
    tableName = "research_tasks",
    foreignKeys = [ForeignKey(entity = WorldEntity::class, parentColumns = ["id"], childColumns = ["worldId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["worldId"]), Index(value = ["status"])],
)
data class ResearchTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val worldId: Long,
    val phase: String = "PENDIENTE",
    val status: String = "PENDIENTE",
    val progressDone: Int = 0,
    val progressTotal: Int = 0,
    val sourcesOk: Int = 0,
    val sourcesFailed: Int = 0,
    val entriesCreated: Int = 0,
    val attempts: Int = 0,
    val maxAttempts: Int = 3,
    val lastError: String = "",
    val note: String = "",
    val workId: String? = null,
    val createdAt: Long,
    val updatedAt: Long,
    val finishedAt: Long? = null,
)

/**
 * Vínculo de una partida con un mundo. Es independiente del mundo: avance, relaciones y recuerdos siguen en las tablas de la 0.4.
 * worldId pasa a nulo si se borra el mundo (la partida no se borra); worldUuid y worldName permiten reencontrarlo.
 */
@Entity(
    tableName = "world_sessions",
    foreignKeys = [
        ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = WorldEntity::class, parentColumns = ["id"], childColumns = ["worldId"], onDelete = ForeignKey.SET_NULL),
    ],
    indices = [Index(value = ["worldId"])],
)
data class WorldSessionEntity(
    @PrimaryKey val sessionId: Long,
    val worldId: Long? = null,
    val worldUuid: String = "",
    val worldName: String = "",
    val castMode: String = "MIXTO",
    val continuityMode: String = "FLEXIBLE",
    val spoilerLevel: String = "SIN_SPOILERS",
    val startEra: String = "",
    val visual: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long,
)

/** Paso de la preparación progresiva de una partida. El progreso se calcula contando pasos reales, nunca se simula. */
@Entity(
    tableName = "prep_steps",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "step"], unique = true)],
)
data class PrepStepEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val step: Int,
    val title: String,
    val status: String = "PENDIENTE",
    val detail: String = "",
    val updatedAt: Long,
)

/** Recurso visual reutilizable (retrato o fondo importado por el usuario). No hay generación de imágenes en esta versión. */
@Entity(
    tableName = "visual_assets",
    indices = [Index(value = ["kind"]), Index(value = ["characterId"]), Index(value = ["worldId"])],
)
data class VisualAssetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val file: String,
    val label: String = "",
    val characterId: Long? = null,
    val worldId: Long? = null,
    val locationRef: String = "",
    val emotion: String = "",
    val createdAt: Long,
)

/** Metadatos visuales de un turno. El texto narrativo original NUNCA se modifica. */
@Entity(
    tableName = "scene_meta",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "messageId"], unique = true)],
)
data class SceneMetaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val messageId: Long,
    val locationRef: String = "",
    val speaker: String = "",
    val emotion: String = "",
    val pose: String = "",
    val eventType: String = "DIALOGO",
    val assetRefs: String = "",
    val important: Boolean = false,
    val valid: Boolean = true,
    val createdAt: Long,
)
