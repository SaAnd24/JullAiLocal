package com.jullai.local.data

import androidx.room.withTransaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class SettingsRepository(private val db: AppDatabase, scope: CoroutineScope) {
    val settings: StateFlow<AppSettings> = db.settings().observeAll()
        .map { rows -> AppSettings.fromMap(rows.associate { it.settingKey to it.settingValue }) }
        .stateIn(scope, SharingStarted.Eagerly, AppSettings())

    suspend fun save(value: AppSettings) {
        db.withTransaction {
            db.settings().putAll(value.toMap().map { (k, v) -> SettingEntity(k, v) })
        }
    }

    suspend fun update(change: (AppSettings) -> AppSettings) = save(change(settings.value))
}
