package com.jullai.local.engine

/** Estimación APROXIMADA de memoria. No sustituye medir en el dispositivo. */
object MemoryEstimator {
    /**
     * Caché KV en f16: 2 (K y V) * capas * contexto * (dimensión por cabeza * cabezas KV) * 2 bytes.
     * Devuelve 0 si faltan datos del modelo.
     */
    fun kvCacheBytes(info: ModelInfo, nCtx: Int): Long {
        if (info.nLayer <= 0 || info.nHead <= 0 || info.nEmbd <= 0 || info.nHeadKv <= 0 || nCtx <= 0) return 0
        val headDim = info.nEmbd.toLong() / info.nHead
        val kvDim = headDim * info.nHeadKv
        return 2L * info.nLayer * nCtx * kvDim * 2L
    }

    /** Pesos (tamaño del archivo) + caché KV + margen fijo para búferes de cómputo. */
    fun totalBytes(fileSize: Long, info: ModelInfo, nCtx: Int): Long =
        fileSize + kvCacheBytes(info, nCtx) + COMPUTE_MARGIN_BYTES

    /** true si la estimación supera la fracción prudente de la RAM disponible. */
    fun isRisky(totalBytes: Long, availableBytes: Long): Boolean =
        availableBytes > 0 && totalBytes > (availableBytes * RISK_FRACTION).toLong()

    private const val COMPUTE_MARGIN_BYTES = 256L * 1024 * 1024
    private const val RISK_FRACTION = 0.7
}
