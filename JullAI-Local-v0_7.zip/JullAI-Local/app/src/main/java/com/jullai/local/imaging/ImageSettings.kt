package com.jullai.local.imaging

import com.jullai.local.data.AppDatabase
import com.jullai.local.data.SettingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/** Cuándo se prepara una ilustración completa. NUNCA se genera una imagen por cada respuesta normal. */
object IllustrationMode {
    const val OFF = "OFF"
    const val MANUAL = "MANUAL"
    const val IMPORTANT = "IMPORTANTES"
    const val BALANCED = "EQUILIBRADA"
    val ALL = listOf(OFF, MANUAL, IMPORTANT, BALANCED)

    fun label(m: String) = when (m) {
        OFF -> "Desactivadas"; MANUAL -> "Solo cuando las pido"; IMPORTANT -> "Proponer en escenas importantes"; BALANCED -> "Escenas importantes con pausa mínima"; else -> m
    }
}

/**
 * Ajustes visuales. Viven en la tabla `settings` existente con claves propias («img_*»), separados de AppSettings para no tocar
 * los ajustes de las versiones anteriores. Los valores por defecto priorizan estabilidad y bajo consumo.
 */
data class ImageSettings(
    val enabled: Boolean = true,
    val preset: String = QualityPreset.LOW_POWER.id,
    val illustrationMode: String = IllustrationMode.MANUAL,
    val minGapTurns: Int = 8,
    /** Si es false (por defecto) las tareas esperan a que pulses «Generar ahora»: nada se lanza solo y calienta el teléfono. */
    val autoRun: Boolean = false,
    val useReference: Boolean = true,
    val threads: Int = 4,
    val loraStrength: Float = 1f,
    val vaeTiling: Boolean = true,
) {
    fun toMap(): Map<String, String> = mapOf(
        K_ENABLED to enabled.toString(), K_PRESET to preset, K_ILLUS to illustrationMode, K_GAP to minGapTurns.toString(),
        K_AUTO to autoRun.toString(), K_REF to useReference.toString(),
        K_THREADS to threads.toString(), K_LORA_STR to loraStrength.toString(), K_TILING to vaeTiling.toString(),
    )

    companion object {
        const val K_ENABLED = "img_enabled"
        const val K_PRESET = "img_preset"
        const val K_ILLUS = "img_illus_mode"
        const val K_GAP = "img_min_gap_turns"
        const val K_AUTO = "img_auto_run"
        const val K_REF = "img_use_reference"
        const val K_THREADS = "img_threads"
        const val K_LORA_STR = "img_lora_strength"
        const val K_TILING = "img_vae_tiling"

        fun fromMap(m: Map<String, String>): ImageSettings {
            val d = ImageSettings()
            return ImageSettings(
                enabled = m[K_ENABLED]?.toBooleanStrictOrNull() ?: d.enabled,
                preset = QualityPreset.byId(m[K_PRESET]).id,
                illustrationMode = m[K_ILLUS]?.takeIf { it in IllustrationMode.ALL } ?: d.illustrationMode,
                minGapTurns = m[K_GAP]?.toIntOrNull()?.coerceIn(2, 100) ?: d.minGapTurns,
                autoRun = m[K_AUTO]?.toBooleanStrictOrNull() ?: d.autoRun,
                useReference = m[K_REF]?.toBooleanStrictOrNull() ?: d.useReference,
                threads = m[K_THREADS]?.toIntOrNull()?.coerceIn(1, 8) ?: d.threads,
                loraStrength = m[K_LORA_STR]?.toFloatOrNull()?.coerceIn(0f, 2f) ?: d.loraStrength,
                vaeTiling = m[K_TILING]?.toBooleanStrictOrNull() ?: d.vaeTiling,
            )
        }
    }
}

class ImageSettingsStore(private val db: AppDatabase, scope: CoroutineScope) {
    val settings: StateFlow<ImageSettings> = db.settings().observeAll()
        .map { rows -> ImageSettings.fromMap(rows.associate { it.settingKey to it.settingValue }) }
        .stateIn(scope, SharingStarted.Eagerly, ImageSettings())

    suspend fun update(change: (ImageSettings) -> ImageSettings) {
        val next = change(settings.value)
        db.settings().putAll(next.toMap().map { (k, v) -> SettingEntity(k, v) })
    }
}
