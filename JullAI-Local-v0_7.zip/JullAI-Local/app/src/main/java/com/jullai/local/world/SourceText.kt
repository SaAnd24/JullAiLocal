package com.jullai.local.world

import com.jullai.local.roleplay.JArr
import com.jullai.local.roleplay.JNull
import com.jullai.local.roleplay.JNum
import com.jullai.local.roleplay.JObj
import com.jullai.local.roleplay.JStr
import com.jullai.local.roleplay.J
import com.jullai.local.roleplay.JsonException
import com.jullai.local.roleplay.MiniJson
import com.jullai.local.roleplay.asArr
import com.jullai.local.roleplay.asObj
import com.jullai.local.roleplay.get
import com.jullai.local.roleplay.obj
import com.jullai.local.roleplay.arr
import com.jullai.local.roleplay.str

/** Conversión de texto de fuentes (HTML, Markdown, TXT, respuestas de MediaWiki) a texto plano limpio. Lógica pura. */
object SourceText {
    const val MAX_INPUT = 3_000_000

    private val DROP_BLOCKS = Regex("<(script|style|noscript|template|head|svg|iframe)\\b[^>]*>.*?</\\1\\s*>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val COMMENTS = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL)
    private val BREAKS = Regex("</?(p|div|br|li|ul|ol|h[1-6]|tr|table|section|article|blockquote|dd|dt)\\b[^>]*>", RegexOption.IGNORE_CASE)
    private val TAGS = Regex("<[^>]{0,2000}>")

    fun htmlToText(html: String): String {
        val src = if (html.length > MAX_INPUT) html.substring(0, MAX_INPUT) else html
        var s = COMMENTS.replace(src, " ")
        s = DROP_BLOCKS.replace(s, " ")
        s = BREAKS.replace(s, "\n")
        s = TAGS.replace(s, "")
        s = decodeEntities(s)
        return tidy(s)
    }

    fun markdownToText(md: String): String {
        val src = if (md.length > MAX_INPUT) md.substring(0, MAX_INPUT) else md
        var s = src.replace("\r\n", "\n")
        s = Regex("!\\[[^\\]]*]\\([^)]*\\)").replace(s, "")
        s = Regex("\\[([^\\]]+)]\\([^)]*\\)").replace(s, "$1")
        s = Regex("^\\s{0,3}#{1,6}\\s*", RegexOption.MULTILINE).replace(s, "")
        s = s.replace("**", "").replace("__", "").replace("`", "")
        s = TAGS.replace(s, "")
        return tidy(decodeEntities(s))
    }

    fun plainToText(t: String): String = tidy((if (t.length > MAX_INPUT) t.substring(0, MAX_INPUT) else t).replace("\r\n", "\n"))

    /** Elige el conversor por extensión (txt, md, markdown, html, htm). Null si no es un formato compatible. */
    fun byExtension(fileName: String, content: String): String? {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "txt", "text" -> plainToText(content)
            "md", "markdown" -> markdownToText(content)
            "html", "htm", "xhtml" -> htmlToText(content)
            else -> null
        }
    }

    private fun tidy(s: String): String =
        s.lines().joinToString("\n") { it.replace(Regex("[ \\t\\u00A0]+"), " ").trim() }
            .replace(Regex("\\n{3,}"), "\n\n").trim()

    fun decodeEntities(s: String): String {
        if (!s.contains('&')) return s
        val named = mapOf(
            "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ", "ndash" to "–", "mdash" to "—",
            "hellip" to "…", "laquo" to "«", "raquo" to "»", "iexcl" to "¡", "iquest" to "¿", "aacute" to "á", "eacute" to "é",
            "iacute" to "í", "oacute" to "ó", "uacute" to "ú", "ntilde" to "ñ", "uuml" to "ü", "Aacute" to "Á", "Eacute" to "É",
            "Iacute" to "Í", "Oacute" to "Ó", "Uacute" to "Ú", "Ntilde" to "Ñ", "rsquo" to "’", "lsquo" to "‘", "ldquo" to "“", "rdquo" to "”",
        )
        return Regex("&(#x[0-9a-fA-F]{1,6}|#[0-9]{1,7}|[A-Za-z]{2,8});").replace(s) { m ->
            val g = m.groupValues[1]
            when {
                g.startsWith("#x") || g.startsWith("#X") -> codePoint(g.substring(2).toIntOrNull(16))
                g.startsWith("#") -> codePoint(g.substring(1).toIntOrNull())
                else -> named[g] ?: m.value
            }
        }
    }

    private fun codePoint(cp: Int?): String =
        if (cp == null || cp <= 0 || cp > 0x10FFFF || cp in 0xD800..0xDFFF) "" else String(Character.toChars(cp))

    /** Texto con «== Título ==» (como devuelve MediaWiki con explaintext) → lista (título, texto). La introducción tiene título vacío. */
    fun sections(text: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var title = ""
        val body = StringBuilder()
        val head = Regex("^={2,6}\\s*(.+?)\\s*={2,6}\\s*$")
        for (line in text.lines()) {
            val m = head.find(line)
            if (m != null) {
                if (body.isNotBlank() || title.isNotEmpty()) out.add(title to body.toString().trim())
                title = m.groupValues[1]
                body.setLength(0)
            } else body.append(line).append('\n')
        }
        if (body.isNotBlank() || title.isNotEmpty()) out.add(title to body.toString().trim())
        return out
    }

    /** Divide un texto largo en trozos de como mucho [maxChars], cortando en párrafos o frases. */
    fun chunks(text: String, maxChars: Int): List<String> {
        require(maxChars >= 200) { "Trozo demasiado pequeño." }
        val out = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) out.add(cur.toString().trim()); cur.setLength(0) }
        for (para in text.split(Regex("\\n\\s*\\n"))) {
            var p = para.trim()
            if (p.isEmpty()) continue
            while (p.length > maxChars) {
                val cut = p.lastIndexOf(". ", maxChars).let { if (it < maxChars / 2) maxChars else it + 1 }
                if (cur.length + cut + 2 > maxChars) flush()
                cur.append(p.substring(0, cut).trim()).append("\n\n")
                flush()
                p = p.substring(cut).trim()
            }
            if (cur.length + p.length + 2 > maxChars) flush()
            cur.append(p).append("\n\n")
        }
        flush()
        return out
    }
}

/** Una página devuelta por una API MediaWiki. */
class WikiPage(
    val title: String,
    val pageId: Long,
    val revisionId: Long,
    val url: String,
    /** Texto plano, ya limpio. */
    val text: String,
)

class WikiSiteInfo(val siteName: String, val rightsText: String, val rightsUrl: String, val language: String)

/** Lectura de las respuestas JSON de la API de MediaWiki (formatversion=2). */
object WikiParse {
    /** Títulos de una respuesta de list=search o list=allpages. Vacío si el formato no es el esperado. */
    fun searchTitles(json: String): List<String> {
        val root = parseOrNull(json)?.asObj() ?: return emptyList()
        val list = root.obj("query")?.arr("search")?.items ?: return emptyList()
        return list.mapNotNull { it.asObj()?.str("title") }.map { UntrustedText.oneLine(it, 200) }.filter { it.isNotBlank() }
    }

    /** Páginas de prop=extracts|info|revisions. Las páginas inexistentes («missing») se omiten. */
    fun extractPages(json: String): List<WikiPage> {
        val root = parseOrNull(json)?.asObj() ?: return emptyList()
        val pages = root.obj("query")?.arr("pages")?.items ?: return emptyList()
        val out = ArrayList<WikiPage>()
        for (p in pages) {
            val o = p.asObj() ?: continue
            if ((o.fields["missing"] as? com.jullai.local.roleplay.JBool)?.v == true) continue
            val title = o.str("title") ?: continue
            val extract = o.str("extract") ?: continue
            val pageId = num(o.fields["pageid"])
            val rev = o.arr("revisions")?.items?.firstOrNull()?.asObj()?.let { num(it.fields["revid"]) } ?: 0L
            val url = o.str("fullurl") ?: o.str("canonicalurl") ?: ""
            out.add(WikiPage(UntrustedText.oneLine(title, 200), pageId, rev, url.take(500), UntrustedText.sanitize(extract, WorldLimits.MAX_SOURCE_CHARS)))
        }
        return out
    }

    /** Respuesta de action=parse&prop=text (HTML renderizado) → página con texto plano. */
    fun parsePage(json: String, fallbackTitle: String): WikiPage? {
        val root = parseOrNull(json)?.asObj() ?: return null
        val p = root.obj("parse") ?: return null
        val html = p.str("text") ?: return null
        val title = p.str("title") ?: fallbackTitle
        val text = UntrustedText.sanitize(SourceText.htmlToText(html), WorldLimits.MAX_SOURCE_CHARS)
        if (text.isBlank()) return null
        return WikiPage(UntrustedText.oneLine(title, 200), num(p.fields["pageid"]), num(p.fields["revid"]), "", text)
    }

    fun siteInfo(json: String): WikiSiteInfo? {
        val q = parseOrNull(json)?.asObj()?.obj("query") ?: return null
        val general = q.obj("general")
        val rights = q.obj("rightsinfo")
        return WikiSiteInfo(
            siteName = UntrustedText.oneLine(general?.str("sitename") ?: "", 120),
            rightsText = UntrustedText.oneLine(rights?.str("text") ?: "", 200),
            rightsUrl = (rights?.str("url") ?: "").take(300),
            language = UntrustedText.oneLine(general?.str("lang") ?: "", 16),
        )
    }

    /** MediaWiki indica errores de API en un objeto «error» (o «errors»). Devuelve el mensaje, o null si no hay error. */
    fun apiError(json: String): String? {
        val o = parseOrNull(json)?.asObj() ?: return "La respuesta no es JSON válido."
        val e = o.obj("error") ?: return null
        return UntrustedText.oneLine(e.str("info") ?: e.str("code") ?: "error de la API", 200)
    }

    private fun num(j: J?): Long = (j as? JNum)?.v?.toLong() ?: 0L

    private fun parseOrNull(json: String): J? = try { MiniJson.parse(json) } catch (e: JsonException) { null }
}
