package com.jullai.local.engine

import java.io.InputStream

/** Resultado de la comprobación rápida de cabecera GGUF (antes de copiar un archivo de varios GB). */
sealed interface GgufCheck {
    data class Ok(val version: Int, val tensorCount: Long, val kvCount: Long) : GgufCheck
    data class Invalid(val reason: String) : GgufCheck
}

/**
 * Comprobación barata de la cabecera: 4 bytes "GGUF", versión (u32), nº de tensores (u64), nº de metadatos (u64).
 * NO sustituye la validación real del motor (nativeInspectModel), solo evita copiar archivos que claramente no son GGUF.
 */
object GgufHeader {
    private const val MIN_VERSION = 2
    private const val MAX_VERSION = 3

    fun check(input: InputStream): GgufCheck {
        val header = ByteArray(24)
        var read = 0
        while (read < header.size) {
            val n = input.read(header, read, header.size - read)
            if (n < 0) break
            read += n
        }
        return parse(header, read)
    }

    fun parse(header: ByteArray, available: Int): GgufCheck {
        if (available < 24) return GgufCheck.Invalid("El archivo es demasiado pequeño para ser un modelo GGUF.")
        if (header[0] != 'G'.code.toByte() || header[1] != 'G'.code.toByte() ||
            header[2] != 'U'.code.toByte() || header[3] != 'F'.code.toByte()
        ) {
            return GgufCheck.Invalid("No es un archivo GGUF (la cabecera no empieza por \"GGUF\").")
        }
        val version = readLeInt(header, 4)
        if (version < MIN_VERSION || version > MAX_VERSION) {
            return GgufCheck.Invalid("Versión de GGUF no soportada: $version.")
        }
        val tensors = readLeLong(header, 8)
        val kv = readLeLong(header, 16)
        if (tensors < 0 || tensors > 1_000_000 || kv < 0 || kv > 1_000_000) {
            return GgufCheck.Invalid("La cabecera GGUF tiene valores imposibles (archivo dañado).")
        }
        return GgufCheck.Ok(version, tensors, kv)
    }

    private fun readLeInt(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or ((b[off + 3].toInt() and 0xFF) shl 24)

    private fun readLeLong(b: ByteArray, off: Int): Long {
        var v = 0L
        for (i in 7 downTo 0) v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        return v
    }
}
