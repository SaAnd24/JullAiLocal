package com.jullai.local.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.AppContainer
import com.jullai.local.data.AppSettings
import com.jullai.local.data.ConversationEntity
import com.jullai.local.data.MessageEntity
import com.jullai.local.data.MessageRole
import com.jullai.local.data.MessageState
import com.jullai.local.engine.ChatMessage
import com.jullai.local.engine.EngineState
import com.jullai.local.engine.FinishReason
import com.jullai.local.engine.GenEvent
import com.jullai.local.engine.GenerationParams
import com.jullai.local.engine.LoadedModel
import com.jullai.local.engine.StoredModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Estado de la generación actual. messageId != null significa "ocupado" (no se puede enviar otro mensaje). */
data class GenState(
    val messageId: Long? = null,
    val phase: String = "",
    val stats: String = "",
    val error: String? = null,
)

/** Texto que se está recibiendo para una respuesta (se muestra antes de guardarse del todo en la base de datos). */
data class StreamText(val messageId: Long, val text: String)

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.chatRepository
    private val controller = c.controller
    private val engine = c.engine

    val conversations: StateFlow<List<ConversationEntity>> =
        repo.conversations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val models: StateFlow<List<StoredModel>> =
        c.registry.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings> = c.settingsRepository.settings

    private val _currentId = MutableStateFlow<Long?>(null)
    val currentId: StateFlow<Long?> = _currentId.asStateFlow()

    val current: StateFlow<ConversationEntity?> = _currentId
        .flatMapLatest { id -> if (id == null) flowOf(null) else repo.conversation(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val messages: StateFlow<List<MessageEntity>> = _currentId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _gen = MutableStateFlow(GenState())
    val gen: StateFlow<GenState> = _gen.asStateFlow()

    private val _stream = MutableStateFlow<StreamText?>(null)
    val stream: StateFlow<StreamText?> = _stream.asStateFlow()

    private val _editing = MutableStateFlow<MessageEntity?>(null)
    val editing: StateFlow<MessageEntity?> = _editing.asStateFlow()

    val engineState: StateFlow<EngineState> = controller.state
    val loaded: StateFlow<LoadedModel?> = controller.loaded
    val busyLoading: StateFlow<String?> = controller.busy

    /** Posición de lectura por conversación (índice y desplazamiento de la lista), solo mientras la app esté abierta. */
    private val savedScroll = HashMap<Long, Pair<Int, Int>>()
    fun scrollFor(conversationId: Long): Pair<Int, Int> = savedScroll[conversationId] ?: (0 to 0)
    fun saveScroll(conversationId: Long, index: Int, offset: Int) { savedScroll[conversationId] = index to offset }

    private var genJob: Job? = null
    private val updateMutex = Mutex()

    private fun isBusy() = _gen.value.messageId != null

    // ---------------- Conversaciones ----------------

    fun open(id: Long) {
        if (_currentId.value != id) {
            _editing.value = null
            if (!isBusy()) _gen.value = GenState()
        }
        _currentId.value = id
    }

    fun newConversation(onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val all = c.registry.list()
            val model = all.firstOrNull { it.isDefault } ?: all.firstOrNull()
            val id = repo.createConversation(settings.value.conversationDefaults(), model?.fileName)
            open(id)
            onCreated(id)
        }
    }

    fun rename(id: Long, title: String) { viewModelScope.launch { repo.rename(id, title) } }

    fun delete(id: Long, then: () -> Unit = {}) {
        viewModelScope.launch {
            if (_currentId.value == id) {
                if (isBusy()) stopAndWait()
                _currentId.value = null
                _editing.value = null
            }
            repo.delete(id)
            then()
        }
    }

    /** Cambia modelo o parámetros de la conversación. Las llamadas se aplican de una en una (lectura-modificación-escritura). */
    fun updateConversation(change: (ConversationEntity) -> ConversationEntity) {
        val id = _currentId.value ?: return
        viewModelScope.launch {
            updateMutex.withLock {
                val cur = repo.getConversation(id) ?: return@withLock
                repo.updateSettings(change(cur))
            }
        }
    }

    // ---------------- Envío y generación ----------------

    fun send(text: String) {
        val conv = current.value ?: return
        val clean = text.trim()
        if (clean.isEmpty() || isBusy()) return
        val editingMsg = _editing.value
        _editing.value = null
        _gen.value = GenState(messageId = PREPARING, phase = "Preparando…")
        genJob = viewModelScope.launch {
            val assistantId = try {
                if (editingMsg != null) repo.editUserMessage(editingMsg.id, clean)
                else repo.appendUserTurn(conv.id, clean).second
            } catch (e: CancellationException) {
                _gen.value = GenState(); throw e
            } catch (e: Exception) {
                _gen.value = GenState(error = "No se pudo guardar el mensaje: ${e.message}")
                null
            }
            if (assistantId != null) {
                generate(conv.id, assistantId)
            } else if (_gen.value.error == null) {
                _gen.value = GenState()
            }
        }
    }

    /** Regenera la ÚLTIMA respuesta (reemplaza su contenido). */
    fun regenerate() {
        val conv = current.value ?: return
        val last = messages.value.lastOrNull() ?: return
        if (isBusy() || last.role != MessageRole.ASSISTANT) return
        _gen.value = GenState(messageId = PREPARING, phase = "Preparando…")
        genJob = viewModelScope.launch {
            if (repo.resetAssistantForRegeneration(last.id)) {
                generate(conv.id, last.id)
            } else {
                _gen.value = GenState()
            }
        }
    }

    fun startEdit(message: MessageEntity) {
        if (isBusy() || message.role != MessageRole.USER) return
        _editing.value = message
    }

    fun cancelEdit() { _editing.value = null }

    /** Detiene la generación. Si el motor aún no empezó a generar (cargando modelo, construyendo contexto), cancela el trabajo. */
    fun stop() {
        if (engine.state.value == EngineState.GENERATING) engine.cancel() else genJob?.cancel()
    }

    private suspend fun stopAndWait() {
        stop()
        genJob?.join()
    }

    fun dismissError() { _gen.update { it.copy(error = null) } }

    private suspend fun resolveModel(conv: ConversationEntity): StoredModel? {
        val all = c.registry.list()
        return conv.modelFileName?.let { f -> all.firstOrNull { it.fileName == f } }
            ?: all.firstOrNull { it.isDefault }
            ?: all.firstOrNull()
    }

    private suspend fun generate(conversationId: Long, assistantId: Long) {
        val sb = StringBuilder()
        var state = MessageState.COMPLETE
        var cancelled = false
        var errorText: String? = null
        var statsText = ""
        var lastSave = System.nanoTime()
        try {
            val conv = repo.getConversation(conversationId) ?: throw IllegalStateException("La conversación ya no existe.")
            val model = resolveModel(conv)
                ?: throw IllegalStateException("No hay ningún modelo importado. Ve a Modelos e importa un archivo .gguf.")
            val appSettings = settings.value
            _gen.value = GenState(messageId = assistantId, phase = "Cargando el modelo si hace falta…")
            controller.ensureLoaded(model, conv.contextLength, appSettings.threads)

            val rows = repo.history(conversationId)
            val target = rows.firstOrNull { it.id == assistantId }
                ?: throw IllegalStateException("No se encontró la respuesta a generar.")
            val history = rows
                .filter { it.orderIndex < target.orderIndex && it.content.isNotBlank() }
                .map { ChatMessage(it.role, it.content) }

            _gen.update { it.copy(phase = "Preparando el contexto…") }
            val ctx = ContextBuilder.build(
                systemPrompt = conv.systemPrompt,
                history = history,
                contextLength = conv.contextLength,
                maxResponseTokens = conv.maxTokens,
                countTokens = { engine.countTokens(it) },
                applyTemplate = { engine.applyTemplate(it) },
            )
            _gen.update {
                it.copy(
                    phase = if (ctx.droppedMessages > 0) "Generando… (${ctx.droppedMessages} mensajes antiguos fuera del contexto)" else "Generando…",
                )
            }

            val params = GenerationParams(
                temperature = conv.temperature,
                topP = conv.topP,
                maxTokens = conv.maxTokens,
                reuseCache = appSettings.reuseKvCache,
            )
            engine.generate(ctx.prompt, params).collect { ev ->
                when (ev) {
                    is GenEvent.Text -> {
                        sb.append(ev.text)
                        _stream.value = StreamText(assistantId, sb.toString())
                        val now = System.nanoTime()
                        if (now - lastSave > SAVE_EVERY_NANOS) {
                            lastSave = now
                            repo.savePartial(assistantId, sb.toString())
                        }
                    }
                    is GenEvent.Finished -> {
                        val secs = ev.millis / 1000.0
                        val tps = if (secs > 0) ev.tokens / secs else 0.0
                        val reused = engine.lastReusedTokens()
                        val why = when (ev.reason) {
                            FinishReason.END -> ""
                            FinishReason.MAX_TOKENS -> " · límite de tokens de respuesta"
                            FinishReason.CANCELLED -> " · detenida"
                            FinishReason.CONTEXT_FULL -> " · contexto lleno"
                        }
                        statsText = "%d tokens en %.1f s (%.1f tok/s) · prompt %d tokens (%d reutilizados)%s"
                            .format(ev.tokens, secs, tps, ctx.promptTokens, reused, why)
                    }
                }
            }
        } catch (e: CancellationException) {
            cancelled = true
            throw e
        } catch (e: Exception) {
            state = MessageState.ERROR
            errorText = e.message ?: "Error durante la generación."
        } finally {
            withContext(NonCancellable) {
                // Pase lo que pase, lo recibido hasta ahora queda guardado.
                runCatching { repo.finish(assistantId, sb.toString(), if (cancelled) MessageState.INTERRUPTED else state) }
                _stream.value = null
                _gen.value = GenState(stats = statsText, error = errorText)
            }
        }
    }

    companion object {
        private const val PREPARING = -1L
        private const val SAVE_EVERY_NANOS = 1_500_000_000L
    }
}
