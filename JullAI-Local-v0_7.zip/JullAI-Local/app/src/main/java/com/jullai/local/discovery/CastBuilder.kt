package com.jullai.local.discovery

import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.WorldEntryEntity
import com.jullai.local.story.TextNorm
import com.jullai.local.world.EntryState
import com.jullai.local.world.EntryType

/**
 * Convierte las fichas de personaje investigadas en personajes jugables. Solo se copia lo que la fuente dijo (apariencia, personalidad,
 * habilidades, relaciones); estilo de habla, primer mensaje y escenario quedan VACÍOS para no inventar canon. El usuario puede completarlos.
 */
object CastBuilder {
    const val CREATOR = "Investigación automática"

    /** Entradas que dan lugar a un personaje: activas, de tipo personaje y sin spoiler (las de trama no son fichas). */
    fun candidates(entries: List<WorldEntryEntity>): List<WorldEntryEntity> =
        entries.filter { it.type == EntryType.PERSONAJE && it.state == EntryState.ACTIVO && it.spoilerLevel == 0 && it.name.isNotBlank() }

    fun key(name: String) = TextNorm.fold(name).trim()

    /** [history] es la entrada «<nombre> — historia» si existe. [portrait] es el archivo de una imagen canónica ya guardada. */
    fun build(entry: WorldEntryEntity, history: WorldEntryEntity?, worldId: Long, worldName: String, portrait: String?, sourceNote: String, now: Long): CharacterEntity {
        val d = CharacterSheet.parseDetails(entry.details)
        val actor = d[CharacterSheet.L_ACTOR].orEmpty()
        return CharacterEntity(
            name = entry.name,
            aliases = entry.aliases,
            portraitFile = portrait,
            appearance = d[CharacterSheet.L_APPEARANCE].orEmpty(),
            personality = d[CharacterSheet.L_PERSONALITY].orEmpty(),
            history = history?.let { it.details.ifBlank { it.summary } }.orEmpty().ifBlank { entry.summary },
            motivations = "",
            likesDislikes = "",
            behaviorInstructions = listOf(d[CharacterSheet.L_ABILITIES]?.let { "Habilidades: $it" }, d[CharacterSheet.L_RELATIONS]?.let { "Relaciones: $it" }).filterNotNull().joinToString("\n"),
            worldId = worldId,
            privateNotes = listOf("Ficha creada automáticamente a partir de «$worldName».", if (actor.isNotBlank()) "Intérprete: $actor" else "", sourceNote).filter { it.isNotBlank() }.joinToString("\n"),
            tags = "canon",
            creator = CREATOR,
            createdAt = now, updatedAt = now,
        )
    }
}
