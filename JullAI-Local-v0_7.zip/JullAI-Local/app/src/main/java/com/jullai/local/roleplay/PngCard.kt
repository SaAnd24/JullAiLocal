package com.jullai.local.roleplay

import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.DataFormatException
import java.util.zip.Inflater

/**
 * Extrae el JSON de una tarjeta guardada dentro de un PNG (chunks de texto «chara» = V1/V2 y «ccv3» = V3,
 * con el JSON en base64). No asume que todo PNG trae una tarjeta. Lee los chunks a mano, sin decodificar la imagen.
 */
object PngCard {
    private val SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    fun isPng(bytes: ByteArray): Boolean = bytes.size >= 8 && (0 until 8).all { bytes[it] == SIGNATURE[it] }

    /** Devuelve el JSON (texto) de la tarjeta. Lanza CardException con un mensaje claro si no hay tarjeta. */
    fun extractJson(bytes: ByteArray): String {
        if (bytes.size > CardLimits.MAX_PNG_BYTES) throw CardException("El PNG es demasiado grande (más de ${CardLimits.MAX_PNG_BYTES / 1_000_000} MB).")
        if (!isPng(bytes)) throw CardException("El archivo no es un PNG válido.")
        var chara: String? = null
        var ccv3: String? = null
        var pos = 8
        while (pos + 8 <= bytes.size) {
            val len = readInt(bytes, pos)
            if (len < 0 || len.toLong() > bytes.size - pos - 12L) break // chunk truncado o corrupto: se deja de leer
            val type = String(bytes, pos + 4, 4, Charsets.ISO_8859_1)
            val dataStart = pos + 8
            if (type == "tEXt" || type == "zTXt" || type == "iTXt") {
                val text = readTextChunk(type, bytes, dataStart, len)
                if (text != null) {
                    when (text.first.lowercase()) {
                        "chara" -> if (chara == null) chara = text.second
                        "ccv3" -> if (ccv3 == null) ccv3 = text.second
                    }
                }
            }
            if (type == "IEND") break
            pos = dataStart + len + 4 // datos + CRC (no se verifica: se tolera un CRC defectuoso)
        }
        val payload = ccv3 ?: chara
            ?: throw CardException("Este PNG no contiene una tarjeta de personaje (no tiene los datos «chara» ni «ccv3»). Puede ser una imagen normal.")
        return decodePayload(payload)
    }

    private fun decodePayload(payload: String): String {
        val trimmed = payload.trim()
        if (trimmed.startsWith("{")) return trimmed // algunas herramientas guardan el JSON sin base64
        val raw = try {
            Base64.getDecoder().decode(trimmed.filter { !it.isWhitespace() })
        } catch (e: IllegalArgumentException) {
            throw CardException("Los datos de la tarjeta dentro del PNG no son base64 válido.")
        }
        if (raw.size > CardLimits.MAX_JSON_BYTES) throw CardException("La tarjeta dentro del PNG es demasiado grande.")
        val text = String(raw, Charsets.UTF_8).removePrefix("﻿")
        if (!text.trimStart().startsWith("{")) throw CardException("Los datos de la tarjeta dentro del PNG no son un JSON.")
        return text
    }

    private fun readInt(b: ByteArray, p: Int): Int =
        ((b[p].toInt() and 0xFF) shl 24) or ((b[p + 1].toInt() and 0xFF) shl 16) or ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)

    /** Devuelve (palabra clave, texto) o null si el chunk no se puede leer. */
    private fun readTextChunk(type: String, b: ByteArray, start: Int, len: Int): Pair<String, String>? {
        val end = start + len
        var z = start
        while (z < end && b[z] != 0.toByte()) z++
        if (z >= end) return null
        val keyword = String(b, start, z - start, Charsets.ISO_8859_1)
        if (!keyword.equals("chara", true) && !keyword.equals("ccv3", true)) return null // solo se leen los chunks que interesan
        return when (type) {
            "tEXt" -> keyword to String(b, z + 1, end - z - 1, Charsets.ISO_8859_1)
            "zTXt" -> {
                if (z + 2 > end || b[z + 1] != 0.toByte()) return null
                inflate(b, z + 2, end - z - 2)?.let { keyword to String(it, Charsets.ISO_8859_1) }
            }
            else -> { // iTXt: flag, método, idioma\0, clave traducida\0, texto
                if (z + 3 > end) return null
                val compressed = b[z + 1] != 0.toByte()
                var p = z + 3
                while (p < end && b[p] != 0.toByte()) p++   // idioma
                p++
                while (p < end && b[p] != 0.toByte()) p++   // clave traducida
                p++
                if (p > end) return null
                val body = if (compressed) inflate(b, p, end - p) else b.copyOfRange(p, end)
                body?.let { keyword to String(it, Charsets.UTF_8) }
            }
        }
    }

    /** Descomprime con tope de tamaño (protege contra «bombas» de compresión). */
    private fun inflate(b: ByteArray, off: Int, len: Int): ByteArray? {
        val inf = Inflater()
        try {
            inf.setInput(b, off, len)
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                out.write(buf, 0, n)
                if (out.size() > CardLimits.MAX_INFLATED_BYTES) throw CardException("Los datos comprimidos de la tarjeta son demasiado grandes.")
            }
            return out.toByteArray()
        } catch (e: DataFormatException) {
            return null
        } finally {
            inf.end()
        }
    }
}
