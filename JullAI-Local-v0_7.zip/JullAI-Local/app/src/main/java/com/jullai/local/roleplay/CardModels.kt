package com.jullai.local.roleplay

/** Error comprensible (en español) al leer una tarjeta o un archivo de personaje. */
class CardException(message: String) : Exception(message)

/** Límites duros para datos importados (no confiables). */
object CardLimits {
    const val MAX_JSON_BYTES = 6_000_000
    const val MAX_PNG_BYTES = 25_000_000
    const val MAX_INFLATED_BYTES = 8_000_000
    const val MAX_FIELD_CHARS = 60_000
    const val MAX_NAME_CHARS = 120
    const val MAX_GREETINGS = 40
    const val MAX_GREETING_CHARS = 20_000
    const val MAX_LORE_ENTRIES = 1_000
    const val MAX_LORE_CONTENT_CHARS = 20_000
    const val MAX_KEYS_PER_ENTRY = 50
    const val MAX_KEY_CHARS = 200
    const val MAX_TAGS = 30
}

data class ParsedLoreEntry(
    val name: String = "",
    val keys: List<String> = emptyList(),
    val secondaryKeys: List<String> = emptyList(),
    val content: String = "",
    val enabled: Boolean = true,
    val constant: Boolean = false,
    val selective: Boolean = false,
    val caseSensitive: Boolean = false,
    val priority: Int = 10,
    val insertionOrder: Int = 100,
)

data class ParsedLorebook(
    val name: String = "",
    val description: String = "",
    val scanDepth: Int = 4,
    val entries: List<ParsedLoreEntry> = emptyList(),
)

data class ParsedCharacter(
    val name: String = "",
    val aliases: List<String> = emptyList(),
    val appearance: String = "",
    val personality: String = "",
    val speechStyle: String = "",
    val history: String = "",
    val motivations: String = "",
    val likesDislikes: String = "",
    val behaviorInstructions: String = "",
    val initialRelationship: String = "",
    val scenario: String = "",
    val firstMessage: String = "",
    val alternateGreetings: List<String> = emptyList(),
    val dialogueExamples: String = "",
    val privateNotes: String = "",
    val tags: List<String> = emptyList(),
    val creator: String = "",
)

data class ParsedCard(
    val character: ParsedCharacter,
    val lorebook: ParsedLorebook?,
    /** "V1", "V2", "V3" o "JullAI". */
    val format: String,
    val warnings: List<String>,
)

/** Limpieza de texto importado: sin caracteres de control (salvo salto de línea y tabulador) y con límite de longitud. */
object Sanitize {
    fun text(raw: String?, max: Int = CardLimits.MAX_FIELD_CHARS, label: String? = null, warnings: MutableList<String>? = null): String {
        if (raw == null) return ""
        val sb = StringBuilder(minOf(raw.length, max + 16))
        var i = 0
        while (i < raw.length) {
            val c = raw[i]
            when {
                c == '\r' -> { sb.append('\n'); if (i + 1 < raw.length && raw[i + 1] == '\n') i++ }
                c == '\n' || c == '\t' -> sb.append(c)
                c.code < 0x20 || c.code == 0x7F || c == ' ' || c == ' ' -> {}
                else -> sb.append(c)
            }
            i++
        }
        var out = sb.toString().trim()
        if (out.length > max) {
            out = out.substring(0, max).trimEnd()
            if (label != null) warnings?.add("«$label» era demasiado largo y se recortó a $max caracteres.")
        }
        return out
    }

    fun oneLine(raw: String?, max: Int): String =
        text(raw, max).replace('\n', ' ').replace(Regex(" {2,}"), " ").trim()
}
