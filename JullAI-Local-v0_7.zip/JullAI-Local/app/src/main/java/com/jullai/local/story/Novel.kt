package com.jullai.local.story

import com.jullai.local.engine.ChatMessage

/** Mensaje del registro original usado para novelar un capítulo. */
data class NovelLine(val speaker: String, val text: String, val isUser: Boolean)

/**
 * Novela de un capítulo y cierre de volumen. El registro original NO se toca: la novela es una representación aparte
 * y editable. La aplicación pide al modelo que no invente, pero no puede garantizarlo: por eso la novela nunca modifica
 * los recuerdos, la cronología ni las relaciones.
 */
object NovelPlanner {
    const val SYSTEM = "Eres un novelista. Reescribes fragmentos de una historia de rol como prosa narrativa de novela, en tercera persona y tiempo pasado, en español.\n" +
        "Reglas: conserva TODOS los hechos, los diálogos importantes y el orden de los sucesos; no añadas acontecimientos nuevos ni cambies lo que ocurrió; " +
        "puedes mejorar la redacción, describir con más detalle lo que ya está implícito y dar forma a los diálogos; no resumas en exceso; " +
        "no escribas notas, títulos ni comentarios: solo el texto de la novela."

    const val OUTPUT_TOKENS = 900

    /** Agrupa mensajes consecutivos en trozos que quepan en [budgetTokens]. Un mensaje enorme forma su propio trozo. */
    suspend fun chunks(lines: List<NovelLine>, budgetTokens: Int, count: suspend (String) -> Int): List<List<NovelLine>> {
        val out = ArrayList<List<NovelLine>>()
        var cur = ArrayList<NovelLine>()
        var used = 0
        for (l in lines) {
            val c = count("${l.speaker}: ${l.text}") + 3
            if (cur.isNotEmpty() && used + c > budgetTokens) { out.add(cur); cur = ArrayList(); used = 0 }
            cur.add(l); used += c
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    fun prompt(chapterTitle: String, previousTail: String, chunk: List<NovelLine>, part: Int, parts: Int): List<ChatMessage> {
        val body = buildString {
            append("CAPÍTULO: ").append(chapterTitle.ifBlank { "(sin título)" }).append(" — parte ").append(part).append(" de ").append(parts).append("\n")
            if (previousTail.isNotBlank()) append("\nFINAL DE LA PARTE ANTERIOR (continúa desde aquí sin repetirlo):\n").append(previousTail.trim()).append("\n")
            append("\nREGISTRO ORIGINAL A NOVELAR:\n")
            chunk.forEach { append(it.speaker).append(": ").append(it.text.trim()).append('\n') }
            append("\nEscribe ahora la novela de este fragmento.")
        }
        return listOf(ChatMessage("system", SYSTEM), ChatMessage("user", body))
    }

    /** Último párrafo (acotado) para dar continuidad entre partes. */
    fun tail(text: String, maxChars: Int = 600): String {
        val t = text.trim()
        if (t.length <= maxChars) return t
        val cut = t.takeLast(maxChars)
        val nl = cut.indexOf('\n')
        return (if (nl in 0 until maxChars / 2) cut.substring(nl + 1) else cut).trim()
    }

    /** Une las partes con una línea en blanco. */
    fun join(parts: List<String>): String = parts.map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n\n")
}

/** Resumen de continuidad al cerrar un volumen: situación, acontecimientos, relaciones, conflictos y tramas pendientes. */
object ContinuityDraft {
    const val SYSTEM = "Eres el archivista de una historia de rol. Escribes el resumen de continuidad para abrir un nuevo volumen. " +
        "Devuelve SOLO estas cuatro secciones, cada una con su encabezado en mayúsculas seguido de dos puntos y líneas que empiecen por «- »:\n" +
        "SITUACIÓN ACTUAL:\nACONTECIMIENTOS:\nCONFLICTOS ABIERTOS:\nTRAMAS PENDIENTES:\n" +
        "Usa solo la información que te doy; no inventes nada. Sé concreto y breve."

    val SECTIONS = listOf("SITUACIÓN ACTUAL", "ACONTECIMIENTOS", "RELACIONES", "CONFLICTOS ABIERTOS", "TRAMAS PENDIENTES")

    fun prompt(volumeTitle: String, currentSummary: String, chapterSummaries: List<String>, keyMemories: List<String>, recentEvents: List<String>): List<ChatMessage> {
        val body = buildString {
            append("VOLUMEN: ").append(volumeTitle).append('\n')
            if (currentSummary.isNotBlank()) append("\nRESUMEN ACTUAL DE LA HISTORIA:\n").append(currentSummary.trim()).append('\n')
            if (chapterSummaries.isNotEmpty()) { append("\nRESÚMENES DE CAPÍTULOS:\n"); chapterSummaries.forEach { append("- ").append(it.trim().replace('\n', ' ')).append('\n') } }
            if (keyMemories.isNotEmpty()) { append("\nRECUERDOS IMPORTANTES:\n"); keyMemories.forEach { append("- ").append(it.trim().replace('\n', ' ')).append('\n') } }
            if (recentEvents.isNotEmpty()) { append("\nACONTECIMIENTOS RECIENTES:\n"); recentEvents.forEach { append("- ").append(it.trim().replace('\n', ' ')).append('\n') } }
        }
        return listOf(ChatMessage("system", SYSTEM), ChatMessage("user", body))
    }

    /** Extrae las secciones de la respuesta del modelo (tolerante: sin encabezados todo va a «SITUACIÓN ACTUAL»). */
    fun parseSections(raw: String): Map<String, String> {
        val out = LinkedHashMap<String, StringBuilder>()
        var cur: String? = null
        val heads = SECTIONS.associateBy { TextNorm.fold(it) }
        for (line in raw.replace("\r\n", "\n").lines()) {
            val trimmed = line.trim().trimStart('#', '*', ' ').trimEnd('*', ' ')
            val key = trimmed.substringBefore(':', "").let { TextNorm.fold(it).trim() }
            val head = heads[key]
            if (head != null && trimmed.contains(':')) {
                cur = head
                out.getOrPut(head) { StringBuilder() }
                val rest = trimmed.substringAfter(':').trim()
                if (rest.isNotEmpty()) out.getValue(head).append(if (rest.startsWith("-")) rest else "- $rest").append('\n')
            } else if (line.isNotBlank()) {
                val k = cur ?: SECTIONS[0].also { cur = it }
                out.getOrPut(k) { StringBuilder() }.append(line.trim()).append('\n')
            }
        }
        return out.mapValues { it.value.toString().trim() }
    }

    /**
     * Compone el texto final del resumen de continuidad. Las RELACIONES las pone la aplicación con los valores reales
     * (no el modelo). Las secciones que falten se dejan visibles para que el usuario las complete.
     */
    fun compose(modelSections: Map<String, String>, relations: List<RelationItem>): String = buildString {
        for (s in SECTIONS) {
            append(s).append(":\n")
            if (s == "RELACIONES") {
                if (relations.isEmpty()) append("- (sin relaciones registradas)\n")
                else relations.forEach { append(StoryRender.relation(it)).append('\n') }
            } else {
                val v = modelSections[s].orEmpty().trim()
                append(if (v.isEmpty()) "- (sin datos: complétalo a mano)" else v).append('\n')
            }
            append('\n')
        }
    }.trimEnd()

    /** Borrador sin modelo: junta lo ya guardado para que el usuario solo lo revise. */
    fun fallbackSections(currentSummary: String, chapterSummaries: List<String>, recentEvents: List<String>): Map<String, String> = linkedMapOf(
        "SITUACIÓN ACTUAL" to currentSummary.trim().ifEmpty { "" }.let { if (it.isEmpty()) "" else "- " + it.replace('\n', ' ') },
        "ACONTECIMIENTOS" to (chapterSummaries.map { "- " + it.trim().replace('\n', ' ') } + recentEvents.map { "- " + it.trim().replace('\n', ' ') }).joinToString("\n"),
    )
}
