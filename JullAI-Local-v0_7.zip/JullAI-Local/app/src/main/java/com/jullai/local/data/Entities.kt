package com.jullai.local.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Modelo GGUF importado. El archivo vive en filesDir/models; aquí solo se guarda el registro. */
@Entity(tableName = "models", indices = [Index(value = ["sha256"], unique = true)])
data class ModelEntity(
    @PrimaryKey val fileName: String,
    val displayName: String,
    val sizeBytes: Long,
    val sha256: String,
    val importedAt: Long,
    val isDefault: Boolean,
)

/**
 * Conversación de chat general. Lleva sus propios parámetros.
 * modelFileName NO es clave foránea a propósito: borrar un modelo nunca debe borrar conversaciones.
 */
@Entity(tableName = "conversations", indices = [Index(value = ["updatedAt"])])
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val modelFileName: String? = null,
    val systemPrompt: String = "",
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val maxTokens: Int = 512,
    val contextLength: Int = 2048,
    val createdAt: Long,
    val updatedAt: Long,
)

/** Mensaje de una conversación. Se borra en cascada con su conversación. */
@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["conversationId", "orderIndex"], unique = true)],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,
    val content: String,
    val orderIndex: Int,
    val createdAt: Long,
    val state: String,
)

/** Ajustes globales en forma clave/valor. */
@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val settingKey: String,
    val settingValue: String,
)

object MessageRole {
    const val USER = "user"
    const val ASSISTANT = "assistant"
}

object MessageState {
    const val COMPLETE = "COMPLETE"
    const val GENERATING = "GENERATING"
    /** La app se cerró (o se detuvo antes de empezar) con la respuesta a medias. El texto parcial se conserva. */
    const val INTERRUPTED = "INTERRUPTED"
    const val ERROR = "ERROR"
}
