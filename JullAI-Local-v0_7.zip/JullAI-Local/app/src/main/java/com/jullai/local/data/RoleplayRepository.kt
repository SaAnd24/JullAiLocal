package com.jullai.local.data

import androidx.room.withTransaction
import com.jullai.local.roleplay.CardParser
import com.jullai.local.roleplay.KnowledgeItem
import com.jullai.local.roleplay.LoreEntry
import com.jullai.local.roleplay.Macros
import com.jullai.local.roleplay.ParsedCard
import com.jullai.local.roleplay.ParsedCharacter
import com.jullai.local.roleplay.ParsedLoreEntry
import com.jullai.local.roleplay.ParsedLorebook
import com.jullai.local.roleplay.RpCharacter
import com.jullai.local.roleplay.Swipes
import kotlinx.coroutines.flow.Flow

// ---------------- Conversión entre entidades y modelos puros ----------------

fun splitLines(s: String): List<String> = s.split('\n').map { it.trim() }.filter { it.isNotEmpty() }

fun CharacterEntity.alternateGreetingList(): List<String> = Swipes.parse(alternateGreetings)

fun CharacterEntity.toRp() = RpCharacter(
    name = name, aliases = splitLines(aliases), appearance = appearance, personality = personality, speechStyle = speechStyle,
    history = history, motivations = motivations, likesDislikes = likesDislikes, behaviorInstructions = behaviorInstructions,
    initialRelationship = initialRelationship, dialogueExamples = dialogueExamples,
    // privateNotes NO se copia: no existe en RpCharacter.
)

fun CharacterEntity.toParsed() = ParsedCharacter(
    name = name, aliases = splitLines(aliases), appearance = appearance, personality = personality, speechStyle = speechStyle,
    history = history, motivations = motivations, likesDislikes = likesDislikes, behaviorInstructions = behaviorInstructions,
    initialRelationship = initialRelationship, scenario = scenario, firstMessage = firstMessage,
    alternateGreetings = alternateGreetingList(), dialogueExamples = dialogueExamples, privateNotes = privateNotes,
    tags = tags.split(',').map { it.trim() }.filter { it.isNotEmpty() }, creator = creator,
)

fun ParsedCharacter.toEntity(now: Long, portraitFile: String?, lorebookId: Long?) = CharacterEntity(
    name = name, aliases = aliases.joinToString("\n"), portraitFile = portraitFile, appearance = appearance, personality = personality,
    speechStyle = speechStyle, history = history, motivations = motivations, likesDislikes = likesDislikes,
    behaviorInstructions = behaviorInstructions, initialRelationship = initialRelationship, scenario = scenario,
    firstMessage = firstMessage, alternateGreetings = Swipes.toJson(alternateGreetings), dialogueExamples = dialogueExamples,
    lorebookId = lorebookId, privateNotes = privateNotes, tags = tags.joinToString(", "), creator = creator,
    createdAt = now, updatedAt = now,
)

fun LoreEntryEntity.toLore() = LoreEntry(
    id = id, name = name, keys = splitLines(keys), secondaryKeys = splitLines(secondaryKeys), content = content, enabled = enabled,
    constant = constant, selective = selective, caseSensitive = caseSensitive, priority = priority, insertionOrder = insertionOrder,
)

fun ParsedLoreEntry.toEntity(bookId: Long) = LoreEntryEntity(
    lorebookId = bookId, name = name, keys = keys.joinToString("\n"), secondaryKeys = secondaryKeys.joinToString("\n"), content = content,
    enabled = enabled, constant = constant, selective = selective, caseSensitive = caseSensitive, priority = priority, insertionOrder = insertionOrder,
)

fun LoreEntryEntity.toParsed() = ParsedLoreEntry(
    name = name, keys = splitLines(keys), secondaryKeys = splitLines(secondaryKeys), content = content, enabled = enabled,
    constant = constant, selective = selective, caseSensitive = caseSensitive, priority = priority, insertionOrder = insertionOrder,
)

/**
 * Operaciones de roleplay. Lo que toca varias tablas va en UNA transacción.
 *
 * Comportamiento decidido (v0.3):
 *  - Editar un mensaje del USUARIO: se reemplaza, se descartan los posteriores y se genera una respuesta nueva (igual que el chat).
 *  - Editar una respuesta del personaje: se reemplaza el texto de la alternativa activa; no se regenera nada.
 *  - Regenerar: NO borra la respuesta anterior; la conserva como alternativa («swipe») y genera otra.
 *  - Continuar: añade texto al final de la última respuesta.
 *  - Una partida pertenece a UN personaje; borrar el personaje borra sus partidas (el aviso de confirmación lo dice).
 */
class RoleplayRepository(
    private val db: AppDatabase,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    // ---------------- Personajes ----------------
    fun characters(): Flow<List<CharacterEntity>> = db.characters().observeAll()
    suspend fun character(id: Long): CharacterEntity? = db.characters().get(id)
    suspend fun sessionCountOf(characterId: Long): Int = db.characters().sessionCount(characterId)

    /** Inserta (id = 0) o actualiza. Devuelve el id. */
    suspend fun saveCharacter(c: CharacterEntity): Long {
        val now = clock()
        return if (c.id == 0L) db.characters().insert(c.copy(createdAt = now, updatedAt = now))
        else { db.characters().update(c.copy(updatedAt = now)); c.id }
    }

    /** Duplica la ficha (con su propia copia del lorebook). El retrato se comparte por nombre de archivo y lo copia quien llama. */
    suspend fun duplicateCharacter(id: Long, newPortraitFile: String?): Long? = db.withTransaction {
        val src = db.characters().get(id) ?: return@withTransaction null
        val now = clock()
        var newBook: Long? = null
        src.lorebookId?.let { bid ->
            db.lorebooks().get(bid)?.let { b ->
                newBook = db.lorebooks().insert(b.copy(id = 0, name = b.name + " (copia)", createdAt = now, updatedAt = now))
                db.loreEntries().insertAll(db.loreEntries().list(bid).map { it.copy(id = 0, lorebookId = newBook!!) })
            }
        }
        db.characters().insert(src.copy(id = 0, name = src.name + " (copia)", portraitFile = newPortraitFile, lorebookId = newBook, createdAt = now, updatedAt = now))
    }

    /** Borra el personaje, sus partidas (CASCADE) y su lorebook si ningún otro personaje lo usa. Devuelve el retrato a borrar del disco. */
    suspend fun deleteCharacter(id: Long): String? = db.withTransaction {
        val c = db.characters().get(id) ?: return@withTransaction null
        db.characters().delete(id)
        c.lorebookId?.let { if (db.lorebooks().usersOf(it) == 0) db.lorebooks().delete(it) }
        c.portraitFile
    }

    /** Importa una tarjeta ya validada: lorebook (si trae) + personaje en una sola transacción. */
    suspend fun importCard(card: ParsedCard, portraitFile: String?): Long = db.withTransaction {
        val now = clock()
        var bookId: Long? = null
        card.lorebook?.let { b ->
            bookId = db.lorebooks().insert(LorebookEntity(name = b.name, description = b.description, scanDepth = b.scanDepth, createdAt = now, updatedAt = now))
            db.loreEntries().insertAll(b.entries.map { it.toEntity(bookId!!) })
        }
        db.characters().insert(card.character.toEntity(now, portraitFile, bookId))
    }

    /** JSON propio (ficha + lorebook). Incluye las notas privadas del creador: es la copia del usuario, no un envío al modelo. */
    suspend fun exportJson(characterId: Long): String? {
        val c = db.characters().get(characterId) ?: return null
        val book = c.lorebookId?.let { bid ->
            db.lorebooks().get(bid)?.let { b ->
                ParsedLorebook(b.name, b.description, b.scanDepth, db.loreEntries().list(bid).map { it.toParsed() })
            }
        }
        return CardParser.toOwnJson(c.toParsed(), book)
    }

    // ---------------- Escenarios guardados ----------------
    suspend fun scenariosOf(characterId: Long): List<ScenarioEntity> = db.scenarios().forCharacter(characterId)
    suspend fun addScenario(characterId: Long, title: String, text: String): Long =
        db.scenarios().insert(ScenarioEntity(characterId = characterId, title = title.trim().take(80).ifBlank { "Escenario" }, text = text.trim(), createdAt = clock()))
    suspend fun deleteScenario(id: Long) = db.scenarios().delete(id)

    // ---------------- Lorebooks ----------------
    fun lorebooks(): Flow<List<LorebookEntity>> = db.lorebooks().observeAll()
    fun lorebook(id: Long): Flow<LorebookEntity?> = db.lorebooks().observe(id)
    fun loreEntries(bookId: Long): Flow<List<LoreEntryEntity>> = db.loreEntries().observe(bookId)
    fun loreEntryCount(bookId: Long): Flow<Int> = db.lorebooks().observeEntryCount(bookId)
    suspend fun loreEntriesList(bookId: Long): List<LoreEntryEntity> = db.loreEntries().list(bookId)

    suspend fun lorebookOnce(id: Long): LorebookEntity? = db.lorebooks().get(id)

    /** Borra el lorebook solo si ningún personaje lo usa (se llama tras desvincularlo en el editor). */
    suspend fun deleteLorebookIfUnused(id: Long) {
        if (db.lorebooks().usersOf(id) == 0) db.lorebooks().delete(id)
    }

    suspend fun createLorebook(name: String): Long {
        val now = clock()
        return db.lorebooks().insert(LorebookEntity(name = name.trim().take(120).ifBlank { "Lorebook nuevo" }, createdAt = now, updatedAt = now))
    }

    suspend fun renameLorebook(id: Long, name: String, description: String, scanDepth: Int) {
        val b = db.lorebooks().get(id) ?: return
        db.lorebooks().update(b.copy(name = name.trim().take(120).ifBlank { b.name }, description = description.take(2000), scanDepth = scanDepth.coerceIn(1, 50), updatedAt = clock()))
    }

    suspend fun saveLoreEntry(e: LoreEntryEntity): Long =
        if (e.id == 0L) db.loreEntries().insert(e) else { db.loreEntries().update(e); e.id }

    suspend fun deleteLoreEntry(id: Long) = db.loreEntries().delete(id)

    /** Quita el lorebook de ese personaje; si nadie más lo usa, se borra con sus entradas. */
    suspend fun unlinkLorebook(characterId: Long) = db.withTransaction {
        val c = db.characters().get(characterId) ?: return@withTransaction
        val bid = c.lorebookId ?: return@withTransaction
        db.characters().update(c.copy(lorebookId = null, updatedAt = clock()))
        if (db.lorebooks().usersOf(bid) == 0) db.lorebooks().delete(bid)
    }

    suspend fun linkLorebook(characterId: Long, lorebookId: Long) {
        val c = db.characters().get(characterId) ?: return
        db.characters().update(c.copy(lorebookId = lorebookId, updatedAt = clock()))
    }

    // ---------------- Partidas ----------------
    fun sessions(): Flow<List<SessionListItem>> = db.roleSessions().observeList()
    fun session(id: Long): Flow<RoleSessionEntity?> = db.roleSessions().observe(id)
    suspend fun getSession(id: Long): RoleSessionEntity? = db.roleSessions().get(id)
    fun messages(sessionId: Long): Flow<List<RoleMessageEntity>> = db.roleMessages().observe(sessionId)
    suspend fun history(sessionId: Long): List<RoleMessageEntity> = db.roleMessages().list(sessionId)
    fun knowledge(sessionId: Long): Flow<List<KnowledgeItemEntity>> = db.knowledge().observe(sessionId)
    suspend fun knowledgeList(sessionId: Long): List<KnowledgeItem> = db.knowledge().list(sessionId).map { KnowledgeItem(it.scope, it.text) }

    /**
     * Crea la partida con una COPIA del escenario y, si el personaje tiene mensaje de bienvenida, un primer mensaje
     * cuyas alternativas son el saludo principal y los saludos alternativos (se cambian con ‹ ›).
     */
    suspend fun startSession(c: CharacterEntity, scenarioText: String, userName: String, persona: String, defaults: AppSettings, modelFileName: String?): Long =
        db.withTransaction {
            val now = clock()
            val user = userName.trim().take(40).ifBlank { "Viajero" }
            val sid = db.roleSessions().insert(
                RoleSessionEntity(
                    characterId = c.id, title = c.name, scenarioText = scenarioText.trim(), userName = user, userPersona = persona.trim(),
                    narrativeRules = defaults.rpNarrativeRules, modelFileName = modelFileName, temperature = defaults.rpTemperature,
                    topP = defaults.rpTopP, maxTokens = defaults.rpMaxTokens, contextLength = defaults.rpContext, createdAt = now, updatedAt = now,
                ),
            )
            val greetings = (listOf(c.firstMessage) + c.alternateGreetingList()).filter { it.isNotBlank() }
                .map { Macros.apply(it.trim(), c.name, user) }.take(Swipes.MAX)
            if (greetings.isNotEmpty()) {
                db.roleMessages().insert(
                    RoleMessageEntity(sessionId = sid, role = MessageRole.ASSISTANT, content = greetings[0], orderIndex = 0, createdAt = now,
                        state = MessageState.COMPLETE, swipes = Swipes.toJson(greetings), swipeIndex = 0),
                )
            }
            sid
        }

    suspend fun renameSession(id: Long, title: String) {
        db.roleSessions().rename(id, title.trim().replace('\n', ' ').take(60).ifBlank { "Partida" }, clock())
    }

    suspend fun deleteSession(id: Long) = db.roleSessions().delete(id)

    suspend fun updateSession(s: RoleSessionEntity) = db.roleSessions().update(s.copy(updatedAt = clock()))

    suspend fun addKnowledge(sessionId: Long, scope: String, text: String): Long =
        db.knowledge().insert(KnowledgeItemEntity(sessionId = sessionId, scope = scope, text = text.trim().take(2000), createdAt = clock()))

    suspend fun deleteKnowledge(id: Long) = db.knowledge().delete(id)

    /** Guarda el mensaje del usuario ANTES de generar y crea el hueco de la respuesta. Devuelve (id usuario, id respuesta). */
    suspend fun appendUserTurn(sessionId: Long, text: String): Pair<Long, Long> = db.withTransaction {
        val now = clock()
        val next = db.roleMessages().maxOrder(sessionId) + 1
        val u = db.roleMessages().insert(RoleMessageEntity(sessionId = sessionId, role = MessageRole.USER, content = text, orderIndex = next, createdAt = now, state = MessageState.COMPLETE))
        val a = db.roleMessages().insert(RoleMessageEntity(sessionId = sessionId, role = MessageRole.ASSISTANT, content = "", orderIndex = next + 1, createdAt = now, state = MessageState.GENERATING))
        db.roleSessions().touch(sessionId, now)
        u to a
    }

    suspend fun editUserMessage(messageId: Long, newText: String): Long? = db.withTransaction {
        val m = db.roleMessages().get(messageId) ?: return@withTransaction null
        if (m.role != MessageRole.USER) return@withTransaction null
        val now = clock()
        db.roleMessages().updateContent(messageId, newText)
        db.roleMessages().deleteAfter(m.sessionId, m.orderIndex)
        val id = db.roleMessages().insert(RoleMessageEntity(sessionId = m.sessionId, role = MessageRole.ASSISTANT, content = "", orderIndex = m.orderIndex + 1, createdAt = now, state = MessageState.GENERATING))
        db.roleSessions().touch(m.sessionId, now)
        id
    }

    /** Reemplaza el texto de una respuesta del personaje (la alternativa activa). */
    suspend fun editAssistantMessage(messageId: Long, newText: String): Boolean = db.withTransaction {
        val m = db.roleMessages().get(messageId) ?: return@withTransaction false
        if (m.role != MessageRole.ASSISTANT || m.state == MessageState.GENERATING) return@withTransaction false
        val (items, idx) = Swipes.effective(newText, m.swipes, m.swipeIndex)
        db.roleMessages().updateAll(messageId, newText, MessageState.COMPLETE, Swipes.toJson(items), idx)
        db.roleSessions().touch(m.sessionId, clock())
        true
    }

    private suspend fun lastAssistant(messageId: Long): RoleMessageEntity? {
        val m = db.roleMessages().get(messageId) ?: return null
        if (m.role != MessageRole.ASSISTANT) return null
        if (db.roleMessages().maxOrder(m.sessionId) != m.orderIndex) return null   // solo la última
        return m
    }

    /** Regenerar: conserva la respuesta actual como alternativa y abre una vacía. */
    suspend fun prepareNewSwipe(messageId: Long): Boolean = db.withTransaction {
        val m = lastAssistant(messageId) ?: return@withTransaction false
        if (m.state == MessageState.GENERATING) return@withTransaction false
        val (items, idx) = Swipes.effective(m.content, m.swipes, m.swipeIndex)
        val (n, ni) = Swipes.withNew(items, idx)
        db.roleMessages().updateAll(messageId, "", MessageState.GENERATING, Swipes.toJson(n), ni)
        db.roleSessions().touch(m.sessionId, clock())
        true
    }

    /** Cambia a la alternativa anterior (-1) o siguiente (+1) de la ÚLTIMA respuesta. */
    suspend fun selectSwipe(messageId: Long, delta: Int): Boolean = db.withTransaction {
        val m = lastAssistant(messageId) ?: return@withTransaction false
        if (m.state == MessageState.GENERATING) return@withTransaction false
        val (items, idx) = Swipes.effective(m.content, m.swipes, m.swipeIndex)
        val ni = (idx + delta).coerceIn(0, items.size - 1)
        if (ni == idx) return@withTransaction false
        db.roleMessages().updateAll(messageId, items[ni], MessageState.COMPLETE, Swipes.toJson(items), ni)
        true
    }

    /** Continuar: devuelve el texto actual y deja la respuesta en estado GENERATING (el texto se conserva). Null si no procede. */
    suspend fun prepareContinuation(messageId: Long): String? = db.withTransaction {
        val m = lastAssistant(messageId) ?: return@withTransaction null
        if (m.state == MessageState.GENERATING || m.content.isBlank()) return@withTransaction null
        db.roleMessages().updateAll(messageId, m.content, MessageState.GENERATING, m.swipes, m.swipeIndex)
        m.content
    }

    suspend fun savePartial(messageId: Long, content: String) = db.roleMessages().updateContent(messageId, content)

    suspend fun finish(messageId: Long, content: String, state: String) {
        db.withTransaction {
            val m = db.roleMessages().get(messageId) ?: return@withTransaction
            val (items, idx) = Swipes.effective(content, m.swipes, m.swipeIndex)
            db.roleMessages().updateAll(messageId, content, state, Swipes.toJson(items), idx)
            db.roleSessions().touch(m.sessionId, clock())
        }
    }

    /** Borra el último mensaje de la partida (para deshacer un turno). */
    suspend fun deleteLastMessage(sessionId: Long): Boolean = db.withTransaction {
        val list = db.roleMessages().list(sessionId)
        val last = list.lastOrNull() ?: return@withTransaction false
        db.roleMessages().delete(last.id)
        db.roleSessions().touch(sessionId, clock())
        true
    }

    suspend fun markInterruptedOnStart(): Int = db.roleMessages().markGeneratingAsInterrupted()
}
