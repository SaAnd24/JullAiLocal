package com.jullai.local.imaging

import androidx.room.withTransaction
import com.jullai.local.data.AppDatabase
import com.jullai.local.data.ImageMetaEntity
import com.jullai.local.data.ImageModelEntity
import com.jullai.local.data.ImageTaskEntity
import com.jullai.local.data.VisualAssetEntity
import com.jullai.local.data.VisualProfileEntity
import kotlinx.coroutines.flow.Flow

object TaskStatus {
    const val PENDIENTE = "PENDIENTE"
    const val EN_CURSO = "EN_CURSO"
    const val LISTA = "LISTA"
    const val FALLIDA = "FALLIDA"
    const val CANCELADA = "CANCELADA"
    const val APLAZADA = "APLAZADA"

    fun label(s: String) = when (s) {
        PENDIENTE -> "Pendiente"; EN_CURSO -> "En curso"; LISTA -> "Lista"; FALLIDA -> "Fallida"; CANCELADA -> "Cancelada"; APLAZADA -> "Aplazada"; else -> s
    }
}

/** Orden de prioridad pedido: 1 = texto que el usuario espera (no pasa por la cola), después estas. */
object TaskPriority {
    const val FIRST_SCENE = 2
    const val NEXT_SCENE = 3
    const val VARIANT = 4
    const val ILLUSTRATION = 5
}

object ImageModelKinds {
    const val CHECKPOINT = "CHECKPOINT"
    const val LORA = "LORA"
}

object ModelCompat {
    const val OK = "OK"                 // el motor lo cargó de verdad
    const val UNVERIFIED = "UNVERIFIED" // estructura reconocida, aún sin carga real
    const val REJECTED = "REJECTED"
}

data class TaskSpec(
    val kind: String,
    val priority: Int,
    val size: ImageSize,
    val steps: Int,
    val prompt: String,
    val negativePrompt: String = "",
    val worldId: Long? = null,
    val sessionId: Long? = null,
    val messageId: Long? = null,
    val characterId: Long? = null,
    val label: String = "",
    val locationRef: String = "",
    val emotion: String = "",
    val pose: String = "",
    val seed: Long = -1,
    val preset: String = QualityPreset.LOW_POWER.id,
)

/** Todo el acceso a datos del módulo de imágenes. No contiene lógica de generación. */
class ImageRepository(private val db: AppDatabase, private val clock: () -> Long = System::currentTimeMillis) {

    // ---------- modelos ----------
    fun observeModels(): Flow<List<ImageModelEntity>> = db.imageModels().observeAll()
    suspend fun models(): List<ImageModelEntity> = db.imageModels().listAll()
    suspend fun model(id: Long): ImageModelEntity? = db.imageModels().get(id)
    suspend fun modelByFile(fileName: String): ImageModelEntity? = db.imageModels().byFileName(fileName)
    suspend fun defaultModel(kind: String): ImageModelEntity? = db.imageModels().defaultOf(kind)

    suspend fun addModel(m: ImageModelEntity): Long = db.withTransaction {
        val id = db.imageModels().insert(m.copy(importedAt = if (m.importedAt == 0L) clock() else m.importedAt))
        // El primer checkpoint válido se marca por defecto automáticamente.
        if (m.compat != ModelCompat.REJECTED && db.imageModels().defaultOf(m.kind) == null && m.kind == ImageModelKinds.CHECKPOINT) db.imageModels().setDefault(id)
        id
    }

    suspend fun setDefault(id: Long) = db.withTransaction {
        val m = db.imageModels().get(id) ?: return@withTransaction
        db.imageModels().clearDefault(m.kind)
        db.imageModels().setDefault(id)
    }

    suspend fun clearDefault(kind: String) = db.imageModels().clearDefault(kind)

    suspend fun markValidated(id: Long, ok: Boolean, note: String) {
        val m = db.imageModels().get(id) ?: return
        db.imageModels().update(m.copy(engineValidated = ok, compat = if (ok) ModelCompat.OK else ModelCompat.REJECTED, note = note.take(400)))
    }

    /** Elimina el registro; devuelve el nombre de archivo para que quien llama borre el archivo del disco. */
    suspend fun deleteModel(id: Long): String? {
        val m = db.imageModels().get(id) ?: return null
        db.imageModels().delete(id)
        return m.fileName
    }

    // ---------- tareas ----------
    fun observeTasks(): Flow<List<ImageTaskEntity>> = db.imageTasks().observeAll()
    suspend fun task(id: Long): ImageTaskEntity? = db.imageTasks().get(id)
    suspend fun pendingTasks(): List<ImageTaskEntity> = db.imageTasks().pending()
    suspend fun openCount(): Int = db.imageTasks().openCount()

    suspend fun enqueue(s: TaskSpec): Long {
        val now = clock()
        return db.imageTasks().insert(
            ImageTaskEntity(
                kind = s.kind, priority = s.priority, status = TaskStatus.PENDIENTE, worldId = s.worldId, sessionId = s.sessionId, messageId = s.messageId,
                characterId = s.characterId, label = s.label.take(80), locationRef = s.locationRef.take(120), emotion = s.emotion, pose = s.pose.take(40),
                prompt = s.prompt, negativePrompt = s.negativePrompt, width = s.size.width, height = s.size.height, steps = s.steps, seed = s.seed,
                preset = s.preset, createdAt = now, updatedAt = now,
            ),
        )
    }

    suspend fun updateTask(t: ImageTaskEntity) = db.imageTasks().update(t.copy(updatedAt = clock()))

    suspend fun resetRunning(note: String): Int = db.imageTasks().resetRunning(note, clock())
    suspend fun wakeDeferred(): Int = db.imageTasks().wakeDeferred(clock())
    suspend fun cancelAllOpen(note: String): Int = db.imageTasks().cancelAllOpen(note, clock())
    suspend fun clearFinished(): Int = db.imageTasks().clearFinished()
    suspend fun deleteTask(id: Long) = db.imageTasks().delete(id)

    // ---------- recursos + metadatos de generación ----------
    fun observeMeta(): Flow<List<ImageMetaEntity>> = db.imageMeta().observeAll()
    suspend fun meta(assetId: Long): ImageMetaEntity? = db.imageMeta().get(assetId)
    suspend fun illustrationsOf(sessionId: Long): List<ImageMetaEntity> = db.imageMeta().forSession(sessionId).filter { it.slot == "ILUSTRACION" }
    suspend fun forMessage(sessionId: Long, messageId: Long): List<ImageMetaEntity> = db.imageMeta().forMessage(sessionId, messageId)

    /** Guarda el recurso y sus parámetros en UNA transacción: nunca queda un recurso sin su registro ni al revés. */
    suspend fun saveGenerated(
        kind: String, file: String, label: String, characterId: Long?, worldId: Long?, locationRef: String, emotion: String,
        meta: ImageMetaEntity,
    ): Long = db.withTransaction {
        val assetId = db.visualAssets().insert(
            VisualAssetEntity(kind = kind, file = file, label = label.take(80), characterId = characterId, worldId = worldId, locationRef = locationRef.take(120), emotion = emotion, createdAt = clock()),
        )
        db.imageMeta().put(meta.copy(assetId = assetId, slot = kind))
        assetId
    }

    /** Cambia el tipo/asignación de un recurso (galería: «guardar como retrato», asignar a personaje o lugar). */
    suspend fun reassign(assetId: Long, kind: String, characterId: Long?, locationRef: String, emotion: String, label: String) {
        val a = db.visualAssets().get(assetId) ?: return
        db.visualAssets().update(a.copy(kind = kind, characterId = characterId, locationRef = locationRef.take(120), emotion = emotion, label = label.take(80)))
    }

    /** Duración y coste de generaciones reales anteriores, para estimar tiempos con datos propios. */
    suspend fun costHistory(limit: Int = 12): List<Pair<Double, Long>> =
        db.imageMeta().recent(limit).filter { it.durationMs > 0 && it.steps > 0 }.map { CostEstimate.relative(it.steps, it.width, it.height, it.cfg) to it.durationMs }

    // ---------- perfiles visuales ----------
    suspend fun profile(characterId: Long): VisualProfileEntity? = db.visualProfiles().forCharacter(characterId)
    fun observeProfile(characterId: Long): Flow<VisualProfileEntity?> = db.visualProfiles().observeFor(characterId)

    suspend fun saveProfile(p: VisualProfileEntity) {
        val old = db.visualProfiles().forCharacter(p.characterId)
        db.visualProfiles().put(p.copy(id = old?.id ?: 0, updatedAt = clock()))
    }
}
