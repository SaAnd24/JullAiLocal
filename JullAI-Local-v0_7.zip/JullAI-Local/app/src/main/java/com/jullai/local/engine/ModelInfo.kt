package com.jullai.local.engine

/** Metadatos del modelo devueltos por el motor (líneas "clave=valor"). */
data class ModelInfo(
    val description: String,
    val architecture: String,
    val name: String,
    val sizeLabel: String,
    val license: String,
    val hasChatTemplate: Boolean,
    val nCtxTrain: Int,
    val nLayer: Int,
    val nEmbd: Int,
    val nHead: Int,
    val nHeadKv: Int,
) {
    companion object {
        fun parse(raw: String): ModelInfo {
            val map = raw.lineSequence()
                .mapNotNull { line ->
                    val i = line.indexOf('=')
                    if (i <= 0) null else line.substring(0, i) to line.substring(i + 1).trim()
                }.toMap()
            fun int(key: String) = map[key]?.toIntOrNull() ?: 0
            return ModelInfo(
                description = map["desc"].orEmpty(),
                architecture = map["architecture"].orEmpty(),
                name = map["name"].orEmpty(),
                sizeLabel = map["size_label"].orEmpty(),
                license = map["license"].orEmpty(),
                hasChatTemplate = map["has_chat_template"] == "true",
                nCtxTrain = int("n_ctx_train"),
                nLayer = int("n_layer"),
                nEmbd = int("n_embd"),
                nHead = int("n_head"),
                nHeadKv = int("n_head_kv"),
            )
        }
    }
}
