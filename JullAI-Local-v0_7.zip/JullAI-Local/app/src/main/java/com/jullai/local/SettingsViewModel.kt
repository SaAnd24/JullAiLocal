package com.jullai.local

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.data.AppSettings
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settingsRepository.settings

    fun update(change: (AppSettings) -> AppSettings) {
        viewModelScope.launch { c.settingsRepository.update(change) }
    }
}
