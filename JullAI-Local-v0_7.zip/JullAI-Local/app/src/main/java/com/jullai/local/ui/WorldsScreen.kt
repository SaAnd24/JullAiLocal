package com.jullai.local.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullai.local.data.ResearchTaskEntity
import com.jullai.local.data.SourceEntity
import com.jullai.local.data.WorldEntity
import com.jullai.local.data.WorldEntryEntity
import com.jullai.local.data.WorldImportChoice
import com.jullai.local.roleplay.WorldViewModel
import com.jullai.local.world.AssetKind
import com.jullai.local.world.CastMode
import com.jullai.local.world.Confidence
import com.jullai.local.world.Continuity
import com.jullai.local.world.Emotion
import com.jullai.local.world.EntryOrigin
import com.jullai.local.world.EntryState
import com.jullai.local.world.EntryType
import com.jullai.local.world.ResearchDepth
import com.jullai.local.world.ResearchPhase
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceStatus
import com.jullai.local.world.SpoilerLevel
import com.jullai.local.world.TaskStatus

fun displayNameOf(context: Context, uri: Uri): String =
    runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull() ?: (uri.lastPathSegment ?: "archivo")

private const val INTERNET_NOTE = "La investigación online es OPCIONAL y es lo único que usa el permiso INTERNET: consulta APIs de MediaWiki y las URLs que tú indiques, " +
    "identificándose como JullAI-Local, con límite de ritmo y respetando robots.txt. Sin conexión puedes crear, editar, importar archivos locales, " +
    "exportar/importar .worldpack y jugar con normalidad."

// ======================= Lista de mundos =======================

@Composable
fun WorldsScreen(vm: WorldViewModel, onBack: () -> Unit, onOpen: (Long) -> Unit, onNew: () -> Unit) {
    val worlds by vm.worlds.collectAsState()
    val transfer by vm.transfer.collectAsState()
    val notice by vm.notice.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.readWorldpack(uri) }
    var choice by rememberSaveable { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Mundos", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                BasicText("Un mundo es una enciclopedia reutilizable (personajes, lugares, reglas...). Las partidas lo consultan pero nunca lo modifican.", style = Type.Nota)
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InkButton("Nuevo mundo", onNew)
                    InkButton("Importar .worldpack", { picker.launch(arrayOf("*/*")) }, primary = false, enabled = !transfer.busy)
                }
                if (transfer.busy) BasicText(transfer.message ?: "", style = Type.Nota)
                transfer.error?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Granate)) }
                if (transfer.plan == null) transfer.message?.takeIf { !transfer.busy }?.let { BasicText(it, style = Type.Nota) }
                BasicText(INTERNET_NOTE, style = Type.Nota.copy(color = Ink.MarfilTenue), modifier = Modifier.padding(top = 8.dp))
            }
            if (worlds.isEmpty()) item { BasicText("Aún no tienes mundos. Crea uno o importa un .worldpack.", style = Type.Cuerpo, modifier = Modifier.padding(top = 10.dp)) }
            items(worlds, key = { it.id }) { w ->
                Column(Modifier.fillMaxWidth().clickable { onOpen(w.id) }.padding(vertical = 8.dp)) {
                    BasicText(w.name, style = Type.Seccion)
                    BasicText("${Continuity.label(w.continuityMode)} · ${CastMode.label(w.castMode)} · ${SpoilerLevel.label(w.spoilerLevel)}", style = Type.Nota)
                    if (w.description.isNotBlank()) BasicText(w.description.take(140), style = Type.Nota.copy(color = Ink.MarfilTenue))
                    Divider()
                }
            }
        }
    }

    notice?.let { n -> InkDialog("Aviso", { vm.dismissNotice() }) { BasicText(n, style = Type.Cuerpo); Row(Modifier.padding(top = 12.dp)) { InkButton("Entendido", { vm.dismissNotice() }) } } }

    transfer.plan?.let { plan ->
        val default = when { plan.existing == null -> "CREAR"; !plan.needsExplicitChoice -> "USAR_EXISTENTE"; else -> "" }
        val sel = choice.ifEmpty { default }
        InkDialog("Importar mundo", { vm.dismissTransfer(); choice = "" }) {
            BasicText("«${plan.worldName}» · ${plan.entryCount} entradas · ${plan.sourceCount} fuentes", style = Type.Cuerpo.copy(color = Ink.Oro))
            if (plan.existing == null) BasicText("Se creará un mundo NUEVO. No se toca nada de lo que ya tienes.", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
            else {
                BasicText("Ya tienes un mundo con este identificador: «${plan.existing.name}». Elige qué hacer (nunca se borra ni se sobrescribe nada):", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    InkChip("Crear una copia independiente", sel == "COPIA", { choice = "COPIA" })
                    InkChip("Combinar: añadir solo lo que falta (${plan.newEntriesIfMerged} entradas)", sel == "COMBINAR", { choice = "COMBINAR" })
                    if (!plan.needsExplicitChoice) InkChip("Ya lo tienes igual: no hacer nada", sel == "USAR_EXISTENTE", { choice = "USAR_EXISTENTE" })
                }
            }
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Importar", { vm.confirmWorldpack(WorldImportChoice.valueOf(sel)); choice = "" }, enabled = sel.isNotEmpty())
                InkButton("Cancelar", { vm.dismissTransfer(); choice = "" }, primary = false)
            }
        }
    }
}

// ======================= Asistente de creación =======================

@Composable
fun WorldWizardScreen(vm: WorldViewModel, onBack: () -> Unit, onCreated: (Long) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var language by rememberSaveable { mutableStateOf("es") }
    var setting by rememberSaveable { mutableStateOf("") }
    var era by rememberSaveable { mutableStateOf("") }
    var spoilers by rememberSaveable { mutableStateOf(SpoilerLevel.SIN) }
    var cast by rememberSaveable { mutableStateOf(CastMode.MIXTO) }
    var continuity by rememberSaveable { mutableStateOf(Continuity.FLEXIBLE) }
    var rules by rememberSaveable { mutableStateOf("") }
    var limits by rememberSaveable { mutableStateOf("") }
    var depth by rememberSaveable { mutableStateOf(ResearchDepth.BASICA) }
    var sources by rememberSaveable { mutableStateOf("") }
    var chars by rememberSaveable { mutableStateOf("") }
    var places by rememberSaveable { mutableStateOf("") }
    var online by rememberSaveable { mutableStateOf(false) }
    val notice by vm.notice.collectAsState()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Nuevo mundo", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
            item {
                SectionTitle("1 · Lo básico")
                LabeledField("Nombre", name, { name = it }, placeholder = "Nombre del universo")
                LabeledField("Descripción", description, { description = it }, minHeight = 70)
                LabeledField("Idioma", language, { language = it }, placeholder = "es")
                LabeledField("Ambientación", setting, { setting = it }, minHeight = 60, hint = "Tono, estética, tecnología...")

                SectionTitle("2 · Continuidad y reparto (son independientes)")
                LabeledField("Época o continuidad", era, { era = it }, hint = "Ej.: «antes de la guerra», «temporada 2»")
                BasicText("Continuidad", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Continuity.ALL.forEach { InkChip(Continuity.label(it).substringBefore(" ("), continuity == it, { continuity = it }) } }
                BasicText(Continuity.rule(continuity), style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
                BasicText("Reparto", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { CastMode.ALL.forEach { InkChip(CastMode.label(it).replace("Personajes ", ""), cast == it, { cast = it }) } }
                BasicText("Spoilers", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { SpoilerLevel.ALL.forEach { InkChip(SpoilerLevel.label(it), spoilers == it, { spoilers = it }) } }

                SectionTitle("3 · Reglas y límites")
                LabeledField("Reglas del universo", rules, { rules = it }, minHeight = 70, hint = "Magia, tecnología, costumbres...")
                LabeledField("Límites narrativos", limits, { limits = it }, minHeight = 60, hint = "Qué evitar en las escenas")

                SectionTitle("4 · Investigación (opcional)")
                BasicText(INTERNET_NOTE, style = Type.Nota)
                InkToggleRow("Permitir investigación online en este mundo", online, { online = it })
                BasicText("Profundidad", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 8.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { ResearchDepth.ALL.forEach { InkChip(ResearchDepth.label(it), depth == it, { depth = it }) } }
                LabeledField("Fuentes preferidas", sources, { sources = it }, minHeight = 60, hint = "Una por línea. Para una wiki: dirección de su api.php, p. ej. https://es.wikipedia.org/w/api.php")
                LabeledField("Personajes prioritarios", chars, { chars = it }, hint = "Separados por comas")
                LabeledField("Lugares prioritarios", places, { places = it }, hint = "Separados por comas")

                Spacer(Modifier.height(16.dp))
                InkButton("Crear mundo", {
                    vm.createWorld(
                        WorldEntity(
                            uuid = "", name = name, description = description, language = language, setting = setting, era = era, rules = rules, narrativeLimits = limits,
                            spoilerLevel = spoilers, castMode = cast, continuityMode = continuity, researchDepth = depth, preferredSources = sources,
                            priorityCharacters = chars, priorityPlaces = places, allowOnline = online, createdAt = 0, updatedAt = 0,
                        ),
                        onCreated,
                    )
                }, enabled = name.trim().length >= 2)
                BasicText("Puedes empezar a jugar sin investigar nada: el mundo se amplía cuando quieras.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp, bottom = 24.dp))
            }
        }
    }
    notice?.let { n -> InkDialog("Aviso", { vm.dismissNotice() }) { BasicText(n, style = Type.Cuerpo); Row(Modifier.padding(top = 12.dp)) { InkButton("Entendido", { vm.dismissNotice() }) } } }
}

// ======================= Detalle del mundo =======================

@Composable
fun WorldDetailScreen(vm: WorldViewModel, worldId: Long, onBack: () -> Unit) {
    val world by vm.world(worldId).collectAsState(initial = null)
    var tab by rememberSaveable { mutableStateOf(0) }
    val notice by vm.notice.collectAsState()
    val transfer by vm.transfer.collectAsState()
    val context = LocalContext.current
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri -> if (uri != null) vm.exportWorld(worldId, uri) }
    var deleting by remember { mutableStateOf(false) }
    val w = world

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(w?.name ?: "Mundo", onBack)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Resumen", "Entradas", "Fuentes", "Investigar", "Recursos").forEachIndexed { i, t -> InkChip(t, tab == i, { tab = i }) }
        }
        Divider()
        if (w == null) { BasicText("Cargando…", style = Type.Nota, modifier = Modifier.padding(20.dp)); return@Column }
        when (tab) {
            0 -> WorldSummaryTab(vm, w, onExport = { exporter.launch(w.name.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".worldpack") }, onDelete = { deleting = true })
            1 -> EntriesTab(vm, w)
            2 -> SourcesTab(vm, w)
            3 -> ResearchTab(vm, w)
            else -> AssetsTab(vm, w)
        }
    }
    notice?.let { n -> InkDialog("Aviso", { vm.dismissNotice() }) { BasicText(n, style = Type.Cuerpo); Row(Modifier.padding(top = 12.dp)) { InkButton("Entendido", { vm.dismissNotice() }) } } }
    if (transfer.message != null || transfer.error != null) {
        InkDialog("Exportación", { vm.dismissTransfer() }) { BasicText(transfer.error ?: transfer.message ?: "", style = Type.Cuerpo); Row(Modifier.padding(top = 12.dp)) { InkButton("Aceptar", { vm.dismissTransfer() }, enabled = !transfer.busy) } }
    }
    if (deleting && w != null) {
        InkDialog("Borrar mundo", { deleting = false }) {
            BasicText("Se borrará «${w.name}» con su enciclopedia y fuentes. Las partidas que lo usan NO se borran: pasan a no tener mundo.", style = Type.Cuerpo)
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Borrar", { deleting = false; vm.deleteWorld(worldId) { onBack() } }, danger = true)
                InkButton("Cancelar", { deleting = false }, primary = false)
            }
        }
    }
}

@Composable
private fun WorldSummaryTab(vm: WorldViewModel, w: WorldEntity, onExport: () -> Unit, onDelete: () -> Unit) {
    var edit by rememberSaveable(w.id) { mutableStateOf(false) }
    var name by rememberSaveable(w.id, w.revision) { mutableStateOf(w.name) }
    var description by rememberSaveable(w.id, w.revision) { mutableStateOf(w.description) }
    var setting by rememberSaveable(w.id, w.revision) { mutableStateOf(w.setting) }
    var era by rememberSaveable(w.id, w.revision) { mutableStateOf(w.era) }
    var rules by rememberSaveable(w.id, w.revision) { mutableStateOf(w.rules) }
    var limits by rememberSaveable(w.id, w.revision) { mutableStateOf(w.narrativeLimits) }
    var sources by rememberSaveable(w.id, w.revision) { mutableStateOf(w.preferredSources) }
    var chars by rememberSaveable(w.id, w.revision) { mutableStateOf(w.priorityCharacters) }
    var places by rememberSaveable(w.id, w.revision) { mutableStateOf(w.priorityPlaces) }
    var spoilers by rememberSaveable(w.id, w.revision) { mutableStateOf(w.spoilerLevel) }
    var cast by rememberSaveable(w.id, w.revision) { mutableStateOf(w.castMode) }
    var cont by rememberSaveable(w.id, w.revision) { mutableStateOf(w.continuityMode) }
    var depth by rememberSaveable(w.id, w.revision) { mutableStateOf(w.researchDepth) }
    var online by rememberSaveable(w.id, w.revision) { mutableStateOf(w.allowOnline) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
        item {
            BasicText("Origen: ${if (w.origin == "IMPORTADO") "importado (sus reglas se envían al modelo como información, no como órdenes)" else "creado aquí"} · revisión ${w.revision}", style = Type.Nota)
            if (!edit) {
                BasicText(w.description.ifBlank { "Sin descripción." }, style = Type.Cuerpo, modifier = Modifier.padding(top = 8.dp))
                listOf("Idioma" to w.language, "Ambientación" to w.setting, "Época" to w.era, "Continuidad" to Continuity.label(w.continuityMode), "Reparto" to CastMode.label(w.castMode),
                    "Spoilers" to SpoilerLevel.label(w.spoilerLevel), "Reglas" to w.rules, "Límites" to w.narrativeLimits, "Investigación" to "${ResearchDepth.label(w.researchDepth)} · ${if (w.allowOnline) "online permitida" else "sin conexión"}")
                    .filter { it.second.isNotBlank() }.forEach { BasicText("${it.first}: ${it.second}", style = Type.Nota, modifier = Modifier.padding(top = 4.dp)) }
                Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InkButton("Editar", { edit = true }, primary = false)
                    InkButton("Exportar", onExport, primary = false)
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InkButton("Duplicar", { vm.duplicateWorld(w.id) }, primary = false)
                    InkButton("Borrar", onDelete, danger = true)
                }
                BasicText("El .worldpack contiene el mundo base (datos estructurados, referencias y resúmenes breves), no libros ni textos completos. Una partida se exporta aparte como .jullai y lleva una copia del conocimiento de su mundo.", style = Type.Nota, modifier = Modifier.padding(top = 10.dp))
            } else {
                LabeledField("Nombre", name, { name = it }); LabeledField("Descripción", description, { description = it }, minHeight = 70)
                LabeledField("Ambientación", setting, { setting = it }, minHeight = 50); LabeledField("Época o continuidad", era, { era = it })
                BasicText("Continuidad", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Continuity.ALL.forEach { InkChip(Continuity.label(it).substringBefore(" ("), cont == it, { cont = it }) } }
                BasicText("Reparto", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { CastMode.ALL.forEach { InkChip(CastMode.label(it).replace("Personajes ", ""), cast == it, { cast = it }) } }
                BasicText("Spoilers", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { SpoilerLevel.ALL.forEach { InkChip(SpoilerLevel.label(it), spoilers == it, { spoilers = it }) } }
                LabeledField("Reglas", rules, { rules = it }, minHeight = 70); LabeledField("Límites narrativos", limits, { limits = it }, minHeight = 50)
                InkToggleRow("Permitir investigación online", online, { online = it })
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { ResearchDepth.ALL.forEach { InkChip(ResearchDepth.label(it), depth == it, { depth = it }) } }
                LabeledField("Fuentes preferidas", sources, { sources = it }, minHeight = 50); LabeledField("Personajes prioritarios", chars, { chars = it }); LabeledField("Lugares prioritarios", places, { places = it })
                Row(Modifier.padding(top = 14.dp, bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InkButton("Guardar", {
                        vm.updateWorld(w.copy(name = name, description = description, setting = setting, era = era, rules = rules, narrativeLimits = limits, preferredSources = sources, priorityCharacters = chars, priorityPlaces = places, spoilerLevel = spoilers, castMode = cast, continuityMode = cont, researchDepth = depth, allowOnline = online))
                        edit = false
                    }, enabled = name.trim().length >= 2)
                    InkButton("Cancelar", { edit = false }, primary = false)
                }
            }
        }
    }
}

// ----------------------- Entradas -----------------------

@Composable
private fun EntriesTab(vm: WorldViewModel, w: WorldEntity) {
    val entries by vm.entries(w.id).collectAsState(initial = emptyList())
    var filter by rememberSaveable(w.id) { mutableStateOf("") }
    var editing by remember { mutableStateOf<WorldEntryEntity?>(null) }
    var creating by remember { mutableStateOf(false) }
    val shown = entries.filter { filter.isBlank() || it.name.contains(filter, true) || it.summary.contains(filter, true) || it.aliases.contains(filter, true) }
    val proposed = entries.count { it.state == EntryState.PROPUESTO }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { InkButton("Nueva entrada", { creating = true }) }
            InkField(filter, { filter = it }, "Buscar en la enciclopedia", Modifier.fillMaxWidth().padding(top = 8.dp))
            BasicText("${entries.size} entradas" + (if (proposed > 0) " · $proposed propuestas por revisar (no llegan al modelo hasta que las aceptes)" else ""), style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
        }
        items(shown, key = { it.id }) { e ->
            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                BasicText("${e.name}  ·  ${EntryType.label(e.type)}", style = Type.Seccion.copy(fontSize = 16.sp))
                BasicText(Confidence.label(e.confidence) + (if (e.state == EntryState.PROPUESTO) " · PROPUESTA" else "") + (if (e.spoilerLevel > 0) " · spoiler ${e.spoilerLevel}" else ""),
                    style = Type.Nota.copy(color = if (e.confidence == Confidence.CONTRADICCION) Ink.Granate else Ink.Oro))
                if (e.summary.isNotBlank()) BasicText(e.summary, style = Type.Cuerpo)
                if (e.sourceRef.isNotBlank()) BasicText("Fuente: ${e.sourceRef}", style = Type.Nota)
                if (e.confidence == Confidence.CONTRADICCION) BasicText("Esta información se contradice con otra fuente: ambas versiones se conservan; decide tú.", style = Type.Nota.copy(color = Ink.Granate))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (e.state == EntryState.PROPUESTO) { InkLink("Aceptar", { vm.acceptEntry(e.id) }); InkLink("Descartar", { vm.discardEntry(e.id) }, danger = true) }
                    InkLink("Editar", { editing = e }); InkLink("Borrar", { vm.deleteEntry(e.id) }, danger = true)
                }
                Divider()
            }
        }
    }
    if (creating) EntryDialog(null, w.id, onDismiss = { creating = false }, onSave = { vm.saveEntry(it); creating = false })
    editing?.let { e -> EntryDialog(e, w.id, onDismiss = { editing = null }, onSave = { vm.saveEntry(it); editing = null }) }
}

@Composable
private fun EntryDialog(entry: WorldEntryEntity?, worldId: Long, onDismiss: () -> Unit, onSave: (WorldEntryEntity) -> Unit) {
    var type by remember { mutableStateOf(entry?.type ?: EntryType.PERSONAJE) }
    var name by remember { mutableStateOf(entry?.name ?: "") }
    var aliases by remember { mutableStateOf(entry?.aliases ?: "") }
    var summary by remember { mutableStateOf(entry?.summary ?: "") }
    var details by remember { mutableStateOf(entry?.details ?: "") }
    var conf by remember { mutableStateOf(entry?.confidence ?: Confidence.INVENCION) }
    var sourceRef by remember { mutableStateOf(entry?.sourceRef ?: "") }
    var evidence by remember { mutableStateOf(entry?.evidence ?: "") }
    var factKey by remember { mutableStateOf(entry?.factKey ?: "") }
    var spoiler by remember { mutableStateOf(entry?.spoilerLevel ?: 0) }
    InkDialog(if (entry == null) "Nueva entrada" else "Editar entrada", onDismiss) {
        LazyColumn(Modifier.height(420.dp)) {
            item {
                BasicText("Tipo", style = Type.Nota.copy(color = Ink.Oro))
                ChipFlow(EntryType.ALL, { it == type }, { EntryType.label(it) }, { type = it })
                LabeledField("Nombre", name, { name = it }); LabeledField("Alias (uno por línea)", aliases, { aliases = it }, minHeight = 40)
                LabeledField("Resumen", summary, { summary = it }, minHeight = 60); LabeledField("Detalles", details, { details = it }, minHeight = 60)
                BasicText("Confianza", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                ChipFlow(Confidence.ALL, { it == conf }, { Confidence.label(it) }, { conf = it })
                BasicText("«Confirmado por la fuente» exige indicar la fuente y la cita donde lo verificaste.", style = Type.Nota)
                LabeledField("Fuente (referencia)", sourceRef, { sourceRef = it }); LabeledField("Cita verificada", evidence, { evidence = it }, minHeight = 40)
                LabeledField("Clave del hecho (opcional)", factKey, { factKey = it }, hint = "Ej.: «Ana|edad». Sirve para detectar contradicciones")
                BasicText("Nivel de spoiler (0 = ninguno, 3 = secreto central)", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (0..3).forEach { InkChip("$it", spoiler == it, { spoiler = it }) } }
            }
        }
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Guardar", {
                val base = entry ?: WorldEntryEntity(worldId = worldId, type = type, name = name, confidence = conf, origin = EntryOrigin.MANUAL, createdAt = 0, updatedAt = 0)
                onSave(base.copy(type = type, name = name, aliases = aliases, summary = summary, details = details, confidence = conf, sourceRef = sourceRef, evidence = evidence, factKey = factKey, spoilerLevel = spoiler, state = if (entry?.state == EntryState.PROPUESTO) EntryState.ACTIVO else (entry?.state ?: EntryState.ACTIVO)))
            }, enabled = name.trim().length >= 2)
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}

// ----------------------- Fuentes -----------------------

@Composable
private fun SourcesTab(vm: WorldViewModel, w: WorldEntity) {
    val sources by vm.sources(w.id).collectAsState(initial = emptyList())
    val extract by vm.extract.collectAsState()
    val context = LocalContext.current
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importFile(w.id, uri, displayNameOf(context, uri)) }
    var url by rememberSaveable(w.id) { mutableStateOf("") }
    var wikiApi by rememberSaveable(w.id) { mutableStateOf("") }
    var wikiTitle by rememberSaveable(w.id) { mutableStateOf("") }
    var manualTitle by rememberSaveable(w.id) { mutableStateOf("") }
    var manualText by rememberSaveable(w.id) { mutableStateOf("") }
    var changing by remember { mutableStateOf<SourceEntity?>(null) }
    var pasting by remember { mutableStateOf<SourceEntity?>(null) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
        item {
            BasicText("Fuentes: archivos locales (TXT, Markdown, HTML), URLs tuyas y páginas de wikis MediaWiki. Los PDF aún no son compatibles. El texto de las fuentes es un DATO: nunca puede dar órdenes a la app ni al modelo.", style = Type.Nota)
            InkButton("Importar archivo local", { filePicker.launch(arrayOf("*/*")) }, modifier = Modifier.padding(top = 8.dp), primary = false)
            LabeledField("Añadir URL", url, { url = it }, placeholder = "https://…")
            InkButton("Añadir URL", { vm.addUrl(w.id, url); url = "" }, modifier = Modifier.padding(top = 6.dp), primary = false, enabled = url.isNotBlank())
            LabeledField("Wiki (dirección de su api.php)", wikiApi, { wikiApi = it }, placeholder = "https://es.wikipedia.org/w/api.php")
            LabeledField("Título de la página", wikiTitle, { wikiTitle = it })
            InkButton("Añadir página de wiki", { vm.addWiki(w.id, wikiApi, wikiTitle); wikiTitle = "" }, modifier = Modifier.padding(top = 6.dp), primary = false, enabled = wikiApi.isNotBlank() && wikiTitle.isNotBlank())
            LabeledField("Pegar texto a mano (título)", manualTitle, { manualTitle = it })
            LabeledField("Texto", manualText, { manualText = it }, minHeight = 70)
            InkButton("Importar texto", { vm.importManualText(w.id, manualTitle, manualText); manualText = "" }, modifier = Modifier.padding(top = 6.dp), primary = false, enabled = manualText.length >= 20)
            SectionTitle("Fuentes (${sources.size})")
            if (extract.busy) { BasicText(extract.message ?: "", style = Type.Nota); InkLink("Detener", { vm.stopExtract() }, danger = true) }
            extract.error?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Granate)) }
            if (!extract.busy) extract.message?.let { BasicText(it, style = Type.Nota) }
        }
        items(sources, key = { it.id }) { s ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                BasicText(s.title.ifBlank { s.uri }, style = Type.Cuerpo.copy(color = Ink.Oro))
                BasicText("${SourceStatus.label(s.status)} · ${s.kind}" + (if (s.charCount > 0) " · ${s.charCount} caracteres" else ""), style = Type.Nota.copy(color = if (s.status == SourceStatus.PROCESADA) Ink.Marfil else Ink.Granate))
                if (s.error.isNotBlank()) BasicText(s.error, style = Type.Nota.copy(color = Ink.Granate))
                if (s.provenance.isNotBlank()) BasicText("Procedencia: ${s.provenance}", style = Type.Nota)
                if (s.license.isNotBlank()) BasicText("Licencia: ${s.license}", style = Type.Nota)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (s.status == SourceStatus.PROCESADA) InkLink("Extraer con el modelo local", { vm.extractWithModel(s.id) }, enabled = !extract.busy)
                    if (s.status == SourceStatus.FALLIDA || s.status == SourceStatus.NO_COMPATIBLE) { InkLink("Cambiar dirección", { changing = s }); InkLink("Importar a mano", { pasting = s }) }
                    InkLink("Quitar", { vm.deleteSource(s.id) }, danger = true)
                }
                Divider()
            }
        }
    }
    changing?.let { s ->
        var v by remember(s.id) { mutableStateOf(s.uri) }
        InkDialog("Cambiar dirección", { changing = null }) {
            InkField(v, { v = it }, "Nueva dirección", Modifier.fillMaxWidth())
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { InkButton("Guardar", { vm.changeSourceUri(s.id, v); changing = null }, enabled = v.isNotBlank()); InkButton("Cancelar", { changing = null }, primary = false) }
        }
    }
    pasting?.let { s ->
        var v by remember(s.id) { mutableStateOf("") }
        InkDialog("Importar contenido a mano", { pasting = null }) {
            BasicText("Pega el texto de «${s.title.ifBlank { s.uri }}».", style = Type.Nota)
            InkField(v, { v = it }, "Texto", Modifier.fillMaxWidth(), minHeight = 120)
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) { InkButton("Importar", { vm.replaceWithManual(s.id, v); pasting = null }, enabled = v.length >= 20); InkButton("Cancelar", { pasting = null }, primary = false) }
        }
    }
}

// ----------------------- Investigación -----------------------

@Composable
private fun ResearchTab(vm: WorldViewModel, w: WorldEntity) {
    val tasks by vm.tasks(w.id).collectAsState(initial = emptyList())
    val active = tasks.firstOrNull { !TaskStatus.isFinal(it.status) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
        item {
            BasicText(INTERNET_NOTE, style = Type.Nota)
            if (!w.allowOnline) BasicText("La investigación online está desactivada en este mundo (Resumen → Editar). Sin ella puedes seguir importando archivos locales y escribiendo entradas.", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton(if (tasks.isEmpty()) "Investigar" else "Investigar / reintentar", { vm.startResearch(w.id) }, enabled = w.allowOnline && active == null)
                if (active != null) InkButton("Cancelar", { vm.cancelResearch(active.id) }, danger = true)
            }
            BasicText("Las fuentes ya procesadas no se vuelven a pedir. Una investigación solo cuenta como completada si obtuvo fuentes y entradas válidas.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
        }
        items(tasks, key = { it.id }) { t -> TaskCard(vm, t) }
    }
}

@Composable
private fun TaskCard(vm: WorldViewModel, t: ResearchTaskEntity) {
    val note by vm.workNote(t.id).collectAsState(initial = "")
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        BasicText("Tarea ${t.id} · ${TaskStatus.label(t.status)}", style = Type.Seccion.copy(fontSize = 16.sp))
        BasicText("Fase: ${ResearchPhase.label(t.phase)} · ${t.progressDone} de ${t.progressTotal} fuentes · ${t.sourcesOk} correctas · ${t.sourcesFailed} con error · ${t.entriesCreated} entradas · intento ${t.attempts}/${t.maxAttempts}", style = Type.Nota)
        if (!TaskStatus.isFinal(t.status) && note.isNotBlank()) BasicText(note, style = Type.Nota.copy(color = Ink.Oro))
        if (t.note.isNotBlank()) BasicText(t.note, style = Type.Nota)
        if (t.lastError.isNotBlank()) BasicText("Último error: ${t.lastError}", style = Type.Nota.copy(color = Ink.Granate))
        Divider()
    }
}

// ----------------------- Recursos visuales -----------------------

@Composable
private fun AssetsTab(vm: WorldViewModel, w: WorldEntity) {
    val assets by vm.assets.collectAsState()
    var kind by rememberSaveable { mutableStateOf(AssetKind.RETRATO) }
    var label by rememberSaveable { mutableStateOf("") }
    var location by rememberSaveable { mutableStateOf("") }
    var character by rememberSaveable { mutableStateOf("") }
    var emotion by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importAsset(kind, uri, label, null, w.id, location, emotion)
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
        item {
            BasicText("Registro de recursos visuales reutilizables. En esta versión SOLO se usan imágenes que tú importes: no se generan imágenes (eso llega en la 0.6). Sin imagen, la novela visual muestra una alternativa neutral.", style = Type.Nota)
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InkChip("Retrato", kind == AssetKind.RETRATO, { kind = AssetKind.RETRATO }); InkChip("Fondo", kind == AssetKind.FONDO, { kind = AssetKind.FONDO })
            }
            LabeledField("Etiqueta", label, { label = it }, hint = if (kind == AssetKind.RETRATO) "Nombre EXACTO del personaje al que representa (p. ej. Aria)" else "Nombre del recurso")
            if (kind == AssetKind.FONDO) LabeledField("Localización", location, { location = it }, hint = "Nombre EXACTO de un lugar de la enciclopedia")
            if (kind == AssetKind.RETRATO) {
                BasicText("Emoción de este retrato (opcional)", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                ChipFlow(Emotion.ALL, { it == emotion }, { Emotion.label(it) }, { emotion = if (emotion == it) "" else it })
            }
            InkButton("Elegir imagen", { picker.launch(arrayOf("image/*")) }, modifier = Modifier.padding(top = 10.dp), enabled = label.isNotBlank() && (kind == AssetKind.RETRATO || location.isNotBlank()))
            SectionTitle("Recursos (${assets.size})")
        }
        items(assets, key = { it.id }) { a ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PortraitImage(vm.portraitStore, a.file, a.label, Modifier.size(56.dp), maxSide = 128)
                Column(Modifier.weight(1f)) {
                    BasicText("${a.kind} · ${a.label}", style = Type.Cuerpo)
                    BasicText(listOf(a.locationRef, a.emotion).filter { it.isNotBlank() }.joinToString(" · "), style = Type.Nota)
                    InkLink("Quitar", { vm.deleteAsset(a.id) }, danger = true)
                }
            }
        }
    }
}
