package com.jullai.local.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.ScenarioEntity
import com.jullai.local.roleplay.CharactersViewModel
import com.jullai.local.roleplay.ImportPreview
import com.jullai.local.roleplay.RoleplayViewModel

/** Biblioteca de personajes: importar tarjetas, crear, editar, duplicar, exportar, eliminar y empezar partidas. */
@Composable
fun CharactersScreen(
    vm: CharactersViewModel,
    settingsUserName: String,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit,
    onOpenSession: (Long) -> Unit,
) {
    val characters by vm.characters.collectAsState()
    val preview by vm.preview.collectAsState()
    val message by vm.message.collectAsState()
    val busy by vm.busy.collectAsState()
    var starting by remember { mutableStateOf<CharacterEntity?>(null) }
    var deleting by remember { mutableStateOf<CharacterEntity?>(null) }
    var exportId by remember { mutableStateOf<Long?>(null) }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.previewImport(uri) }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val id = exportId
        if (uri != null && id != null) vm.exportTo(id, uri)
        exportId = null
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Personajes", onBack)
        Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Nuevo personaje", { onEdit(0L) })
                InkButton("Importar tarjeta", { importPicker.launch(arrayOf("*/*")) }, primary = false, enabled = !busy)
            }
            BasicText(
                "Importa tarjetas de SillyTavern (PNG con tarjeta, o JSON; formatos V1, V2 y lectura básica de V3) o el JSON de JullAI. " +
                    "Verás una vista previa antes de guardar nada.",
                style = Type.Nota,
                modifier = Modifier.padding(top = 10.dp),
            )
            if (busy) BasicText("Trabajando…", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 6.dp))
        }
        Divider()
        if (characters.isEmpty()) {
            Box(Modifier.padding(20.dp)) { BasicText("Aún no tienes personajes. Crea uno o importa una tarjeta.", style = Type.Cuerpo) }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)) {
                items(characters, key = { it.id }) { ch ->
                    CharacterRow(
                        ch = ch, vm = vm,
                        onPlay = { starting = ch },
                        onEdit = { onEdit(ch.id) },
                        onDuplicate = { vm.duplicate(ch.id) },
                        onExport = { exportId = ch.id; exportPicker.launch(ch.name.take(40).ifBlank { "personaje" } + ".jullai.json") },
                        onDelete = { deleting = ch },
                    )
                }
            }
        }
    }

    preview?.let { p -> ImportPreviewDialog(p, onConfirm = { vm.confirmImport() }, onDismiss = { vm.dismissPreview() }) }
    message?.let { m ->
        InkDialog("Aviso", onDismiss = { vm.dismissMessage() }) {
            BasicText(m, style = Type.Cuerpo)
            Box(Modifier.padding(top = 14.dp)) { InkButton("Aceptar", { vm.dismissMessage() }) }
        }
    }
    starting?.let { ch ->
        StartSessionDialog(
            ch = ch, vm = vm, defaultUserName = settingsUserName,
            onDismiss = { starting = null },
            onCreated = { id -> starting = null; onOpenSession(id) },
        )
    }
    deleting?.let { ch ->
        DeleteCharacterDialog(ch, vm, onDismiss = { deleting = null }, onConfirm = { vm.delete(ch.id); deleting = null })
    }
}

@Composable
private fun CharacterRow(
    ch: CharacterEntity, vm: CharactersViewModel,
    onPlay: () -> Unit, onEdit: () -> Unit, onDuplicate: () -> Unit, onExport: () -> Unit, onDelete: () -> Unit,
) {
    Column(
        Modifier.padding(vertical = 6.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(8.dp)).padding(12.dp),
    ) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onPlay)) {
            PortraitImage(vm.portraitStore, ch.portraitFile, ch.name, Modifier.width(64.dp).height(88.dp))
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                BasicText(ch.name, style = Type.Seccion.copy(color = Ink.Oro), maxLines = 2)
                if (ch.aliases.isNotBlank()) BasicText("También: " + ch.aliases.lines().filter { it.isNotBlank() }.joinToString(", "), style = Type.Nota, maxLines = 1)
                val summary = ch.personality.ifBlank { ch.appearance }.replace('\n', ' ')
                if (summary.isNotBlank()) BasicText(summary.take(140), style = Type.Nota, maxLines = 3, modifier = Modifier.padding(top = 2.dp))
                if (ch.tags.isNotBlank()) BasicText(ch.tags, style = Type.Nota.copy(color = Ink.Granate), maxLines = 1, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Row(Modifier.padding(top = 6.dp)) {
            InkLink("Jugar", onPlay)
            InkLink("Editar", onEdit)
            InkLink("Duplicar", onDuplicate)
        }
        Row {
            InkLink("Exportar", onExport)
            InkLink("Eliminar", onDelete, danger = true)
        }
    }
}

@Composable
private fun ImportPreviewDialog(p: ImportPreview, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = p.card.character
    InkDialog("Vista previa de la tarjeta", onDismiss) {
        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
            BasicText(c.name, style = Type.Titulo)
            BasicText("Formato: ${p.card.format} · archivo: ${p.sourceName}" + if (p.portraitBytes != null) " · con imagen" else "", style = Type.Nota)
            val desc = c.appearance.ifBlank { c.personality }
            if (desc.isNotBlank()) BasicText(desc.take(500) + if (desc.length > 500) "…" else "", style = Type.Cuerpo, modifier = Modifier.padding(top = 8.dp))
            BasicText(
                "Saludos: ${1.takeIf { c.firstMessage.isNotBlank() } ?: 0} + ${c.alternateGreetings.size} alternativos · " +
                    "lorebook: ${p.card.lorebook?.entries?.size ?: 0} entradas",
                style = Type.Nota, modifier = Modifier.padding(top = 8.dp),
            )
            if (c.privateNotes.isNotBlank()) BasicText("Las notas del creador se guardarán como notas privadas (nunca se envían al modelo).", style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
            if (p.card.warnings.isNotEmpty()) {
                BasicText("Avisos", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 10.dp))
                p.card.warnings.forEach { BasicText("• $it", style = Type.Nota, modifier = Modifier.padding(top = 2.dp)) }
            }
            BasicText(
                "El contenido de la tarjeta se trata como datos del personaje: nada de lo que contiene se ejecuta.",
                style = Type.Nota, modifier = Modifier.padding(top = 10.dp),
            )
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Importar", onConfirm)
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}

@Composable
private fun DeleteCharacterDialog(ch: CharacterEntity, vm: CharactersViewModel, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    var sessions by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(ch.id) { sessions = vm.sessionCountOf(ch.id) }
    InkDialog("Eliminar personaje", onDismiss) {
        BasicText(
            "«${ch.name}» se borrará de este teléfono" +
                (sessions?.let { if (it > 0) ", junto con sus $it partida(s) de roleplay y todos sus mensajes" else "" } ?: "") +
                ". Si su lorebook no lo usa otro personaje, también se borra. No se puede deshacer (puedes exportarlo antes).",
            style = Type.Cuerpo,
        )
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Eliminar", onConfirm, danger = true, enabled = sessions != null)
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}

/** Elegir escenario, nombre y persona del usuario y empezar la partida. */
@Composable
private fun StartSessionDialog(ch: CharacterEntity, vm: CharactersViewModel, defaultUserName: String, onDismiss: () -> Unit, onCreated: (Long) -> Unit) {
    var saved by remember { mutableStateOf<List<ScenarioEntity>>(emptyList()) }
    var reload by remember { mutableStateOf(0) }
    LaunchedEffect(ch.id, reload) { saved = vm.scenariosOf(ch.id) }

    // -1 = escenario de la ficha, -2 = escribir uno nuevo, otro valor = id de un escenario guardado
    var choice by remember { mutableStateOf(if (ch.scenario.isNotBlank()) -1L else -2L) }
    var custom by remember { mutableStateOf("") }
    var saveIt by remember { mutableStateOf(false) }
    var userName by remember { mutableStateOf(defaultUserName) }
    var persona by remember { mutableStateOf("") }
    val appSettings by vm.playerProfile.collectAsState()
    val hasProfile = appSettings.playerProfileName.isNotBlank() || appSettings.playerProfilePersona.isNotBlank()
    // 0 = usar mi perfil global (copia fija), 1 = adaptarlo para esta partida, 2 = independiente
    var profileMode by remember { mutableStateOf(2) }
    fun applyProfile(mode: Int) {
        profileMode = mode
        if (mode != 2) {
            userName = appSettings.playerProfileName.ifBlank { defaultUserName }
            persona = appSettings.playerProfilePersona
        }
    }

    InkDialog("Nueva partida con ${ch.name}", onDismiss) {
        Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
            BasicText("Escenario", style = Type.Nota.copy(color = Ink.Oro))
            if (ch.scenario.isNotBlank()) ScenarioOption("Escenario de la ficha", ch.scenario, choice == -1L) { choice = -1L }
            saved.forEach { s ->
                ScenarioOption(s.title, s.text, choice == s.id, onDelete = { vm.deleteScenario(s.id) { reload++; if (choice == s.id) choice = -2L } }) { choice = s.id }
            }
            ScenarioOption("Escribir uno nuevo", "", choice == -2L) { choice = -2L }
            if (choice == -2L) {
                InkField(custom, { custom = it }, "Describe dónde y cuándo empieza la historia", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 60)
                InkToggleRow("Guardar este escenario para reutilizarlo", saveIt, { saveIt = it })
            }
            if (hasProfile) {
                BasicText("Tu perfil global", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row {
                    InkChip("Usarlo", profileMode == 0, { applyProfile(0) }, Modifier.padding(end = 6.dp))
                    InkChip("Adaptarlo", profileMode == 1, { applyProfile(1) }, Modifier.padding(end = 6.dp))
                    InkChip("Independiente", profileMode == 2, { profileMode = 2 })
                }
                BasicText("La partida guarda su propia copia: cambiarla después no toca tu perfil global.", style = Type.Nota)
            }
            LabeledField("Tu nombre en la historia", userName, { userName = it }, hint = "Sustituye a {{user}} en la ficha y los saludos.", enabled = profileMode != 0)
            LabeledField("Tu personaje (opcional)", persona, { persona = it }, placeholder = "Quién eres, cómo eres…", minHeight = 44, maxHeight = 120, enabled = profileMode != 0)
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton(
                "Empezar",
                {
                    val text = when (choice) { -1L -> ch.scenario; -2L -> custom; else -> saved.firstOrNull { it.id == choice }?.text ?: "" }
                    val title = if (choice == -2L && saveIt && custom.isNotBlank()) custom.trim().lineSequence().first().take(40) else null
                    vm.startSession(ch, text, userName, persona, title, onCreated)
                },
                enabled = userName.isNotBlank(),
            )
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}

@Composable
private fun ScenarioOption(title: String, text: String, selected: Boolean, onDelete: (() -> Unit)? = null, onClick: () -> Unit) {
    Column(
        Modifier.padding(top = 6.dp).fillMaxWidth()
            .background(if (selected) Ink.Pizarra else Ink.Tinta, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick).padding(10.dp),
    ) {
        BasicText((if (selected) "● " else "○ ") + title, style = Type.Cuerpo.copy(color = if (selected) Ink.Oro else Ink.Marfil))
        if (text.isNotBlank()) BasicText(text.take(160) + if (text.length > 160) "…" else "", style = Type.Nota, maxLines = 3)
        if (onDelete != null) InkLink("Quitar de los guardados", onDelete, danger = true)
    }
}
