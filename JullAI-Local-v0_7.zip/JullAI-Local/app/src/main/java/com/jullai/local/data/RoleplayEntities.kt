package com.jullai.local.data

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Lorebook (libro de datos del mundo) con entradas activadas por palabras clave. Puede compartirse entre personajes. */
@Entity(tableName = "lorebooks")
data class LorebookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val scanDepth: Int = 4,
    val createdAt: Long,
    val updatedAt: Long,
)

/** keys / secondaryKeys: una clave por línea. */
@Entity(
    tableName = "lorebook_entries",
    foreignKeys = [ForeignKey(entity = LorebookEntity::class, parentColumns = ["id"], childColumns = ["lorebookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["lorebookId"])],
)
data class LoreEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lorebookId: Long,
    val name: String = "",
    val keys: String = "",
    val secondaryKeys: String = "",
    val content: String = "",
    val enabled: Boolean = true,
    val constant: Boolean = false,
    val selective: Boolean = false,
    val caseSensitive: Boolean = false,
    val priority: Int = 10,
    val insertionOrder: Int = 100,
)

/**
 * Ficha de personaje. aliases: uno por línea. alternateGreetings: lista JSON de textos.
 * privateNotes NUNCA se envía al modelo. worldId queda vacío hasta la v0.5.
 * Borrar el lorebook asociado deja lorebookId en NULL (no borra el personaje).
 */
@Entity(
    tableName = "characters",
    foreignKeys = [ForeignKey(entity = LorebookEntity::class, parentColumns = ["id"], childColumns = ["lorebookId"], onDelete = ForeignKey.SET_NULL)],
    indices = [Index(value = ["lorebookId"]), Index(value = ["name"])],
)
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val aliases: String = "",
    val portraitFile: String? = null,
    val appearance: String = "",
    val personality: String = "",
    val speechStyle: String = "",
    val history: String = "",
    val motivations: String = "",
    val likesDislikes: String = "",
    val behaviorInstructions: String = "",
    val initialRelationship: String = "",
    val scenario: String = "",
    val firstMessage: String = "",
    val alternateGreetings: String = "[]",
    val dialogueExamples: String = "",
    val worldId: Long? = null,
    val lorebookId: Long? = null,
    val privateNotes: String = "",
    val tags: String = "",
    val creator: String = "",
    val createdAt: Long,
    val updatedAt: Long,
)

/** Escenario guardado y reutilizable de un personaje. */
@Entity(
    tableName = "scenarios",
    foreignKeys = [ForeignKey(entity = CharacterEntity::class, parentColumns = ["id"], childColumns = ["characterId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["characterId"])],
)
data class ScenarioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val characterId: Long,
    val title: String,
    val text: String,
    val createdAt: Long,
)

/**
 * Partida de roleplay: independiente por personaje y SIN relación con las conversaciones del chat general.
 * scenarioText es una copia: editar la ficha después no cambia partidas ya empezadas.
 * modelFileName no es clave foránea (borrar un modelo nunca borra partidas).
 */
@Entity(
    tableName = "role_sessions",
    foreignKeys = [ForeignKey(entity = CharacterEntity::class, parentColumns = ["id"], childColumns = ["characterId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["characterId"]), Index(value = ["updatedAt"])],
)
data class RoleSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val characterId: Long,
    val title: String,
    val scenarioText: String = "",
    val userName: String,
    val userPersona: String = "",
    val narrativeRules: String = "",
    val summary: String = "",
    val modelFileName: String? = null,
    val temperature: Float = 0.85f,
    val topP: Float = 0.92f,
    val maxTokens: Int = 384,
    val contextLength: Int = 4096,
    val createdAt: Long,
    val updatedAt: Long,
)

/** swipes: lista JSON con todas las respuestas alternativas; swipeIndex = la activa (su texto está también en content). */
@Entity(
    tableName = "role_messages",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "orderIndex"], unique = true)],
)
data class RoleMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val role: String,
    val content: String,
    val orderIndex: Int,
    val createdAt: Long,
    val state: String,
    val swipes: String = "[]",
    val swipeIndex: Int = 0,
)

/** Conocimiento de la partida separado por quién lo sabe (ver KnowledgeScope). */
@Entity(
    tableName = "knowledge_items",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId"])],
)
data class KnowledgeItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val scope: String,
    val text: String,
    val createdAt: Long,
)

/** Fila de la lista de partidas: la partida + datos del personaje. */
data class SessionListItem(
    @Embedded val session: RoleSessionEntity,
    val characterName: String,
    val portraitFile: String?,
)
