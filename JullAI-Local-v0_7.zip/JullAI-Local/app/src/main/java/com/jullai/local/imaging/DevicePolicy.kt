package com.jullai.local.imaging

/** Estado térmico simplificado (PowerManager.THERMAL_STATUS_* en Android 10+; UNKNOWN si el sistema no lo informa). */
enum class ThermalLevel {
    UNKNOWN, NONE, LIGHT, MODERATE, SEVERE, CRITICAL;

    companion object {
        /** Convierte el valor de PowerManager.getCurrentThermalStatus() (0..6). */
        fun fromAndroid(status: Int): ThermalLevel = when {
            status < 0 -> UNKNOWN
            status == 0 -> NONE
            status == 1 -> LIGHT
            status == 2 -> MODERATE
            status == 3 -> SEVERE
            else -> CRITICAL     // 4 CRITICAL, 5 EMERGENCY, 6 SHUTDOWN
        }

        fun label(l: ThermalLevel) = when (l) {
            UNKNOWN -> "no informado"; NONE -> "normal"; LIGHT -> "ligero"; MODERATE -> "moderado"; SEVERE -> "alto"; CRITICAL -> "crítico"
        }
    }
}

data class MemoryStatus(val availableBytes: Long, val totalBytes: Long, val lowMemory: Boolean)

/** Lo que el coordinador necesita saber del teléfono. En Android lo implementa AndroidDeviceGate; en pruebas, un falso. */
interface DeviceGate {
    fun memory(): MemoryStatus
    fun thermal(): ThermalLevel
}

enum class GateAction { ALLOW, DEFER, CANCEL }

object DevicePolicy {
    /** Margen sobre el tamaño del archivo del modelo para tensores de cómputo, VAE y búferes (heurística, no medida). */
    private const val BASE_OVERHEAD = 700L * 1024 * 1024
    private const val SAFETY = 500L * 1024 * 1024

    /** Memoria que se pide libre antes de cargar el motor visual. Escala con los píxeles de la imagen. Es una HEURÍSTICA. */
    fun memoryNeeded(modelBytes: Long, width: Int, height: Int, tiling: Boolean): Long {
        val pixelFactor = (width.toLong() * height) / (256L * 384L)             // 1 para 256×384
        val activations = 150L * 1024 * 1024 * pixelFactor.coerceAtLeast(1) / (if (tiling) 2 else 1)
        return (modelBytes * 105 / 100) + BASE_OVERHEAD + activations + SAFETY
    }

    /** Qué hacer con un estado térmico: no empezar en nivel alto; cancelar lo que corre en nivel crítico. */
    fun thermal(level: ThermalLevel, running: Boolean): GateAction = when (level) {
        ThermalLevel.UNKNOWN, ThermalLevel.NONE, ThermalLevel.LIGHT, ThermalLevel.MODERATE -> GateAction.ALLOW
        ThermalLevel.SEVERE -> if (running) GateAction.ALLOW else GateAction.DEFER
        ThermalLevel.CRITICAL -> if (running) GateAction.CANCEL else GateAction.DEFER
    }

    fun memory(m: MemoryStatus, needed: Long, running: Boolean): GateAction = when {
        running && m.lowMemory -> GateAction.CANCEL
        !running && (m.lowMemory || m.availableBytes < needed) -> GateAction.DEFER
        else -> GateAction.ALLOW
    }

    fun humanMb(bytes: Long) = "${bytes / (1024 * 1024)} MB"
}
