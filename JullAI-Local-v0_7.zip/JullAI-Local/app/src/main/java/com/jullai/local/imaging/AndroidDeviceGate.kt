package com.jullai.local.imaging

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager

/**
 * Memoria y temperatura reales del teléfono. El estado térmico solo existe desde Android 10 (API 29): en versiones anteriores
 * (o si el sistema no lo informa) se devuelve UNKNOWN y solo actúa el control de memoria.
 */
class AndroidDeviceGate(private val context: Context, private val onThermal: (ThermalLevel) -> Unit = {}) : DeviceGate {
    private val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    override fun memory(): MemoryStatus {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return MemoryStatus(mi.availMem, mi.totalMem, mi.lowMemory)
    }

    override fun thermal(): ThermalLevel =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ThermalLevel.fromAndroid(pm.currentThermalStatus) else ThermalLevel.UNKNOWN

    /** Registra el aviso de cambios térmicos (API 29+). Sin efecto en versiones anteriores. */
    fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { pm.addThermalStatusListener({ it.run() }) { status -> onThermal(ThermalLevel.fromAndroid(status)) } }
        }
    }
}
