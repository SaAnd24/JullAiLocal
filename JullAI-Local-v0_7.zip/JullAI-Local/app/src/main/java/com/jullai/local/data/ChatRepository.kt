package com.jullai.local.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

/**
 * Operaciones sobre conversaciones y mensajes. Todo lo que toca varias tablas o varias filas va en UNA transacción,
 * para que un cierre inesperado nunca deje el historial a medias.
 *
 * Comportamiento de EDITAR un mensaje propio (decisión de diseño, la más simple y fiable):
 * el mensaje se reemplaza y TODOS los mensajes posteriores se descartan; después se genera una respuesta nueva.
 * No hay ramas. Regenerar solo afecta a la última respuesta.
 */
class ChatRepository(
    private val db: AppDatabase,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    fun conversations(): Flow<List<ConversationEntity>> = db.conversations().observeAll()
    fun conversation(id: Long): Flow<ConversationEntity?> = db.conversations().observe(id)
    fun messages(conversationId: Long): Flow<List<MessageEntity>> = db.messages().observe(conversationId)

    suspend fun getConversation(id: Long): ConversationEntity? = db.conversations().get(id)
    suspend fun history(conversationId: Long): List<MessageEntity> = db.messages().list(conversationId)
    suspend fun getMessage(id: Long): MessageEntity? = db.messages().get(id)

    suspend fun createConversation(defaults: ConversationDefaults, modelFileName: String?): Long {
        val now = clock()
        return db.conversations().insert(
            ConversationEntity(
                title = DEFAULT_TITLE,
                modelFileName = modelFileName,
                systemPrompt = defaults.systemPrompt,
                temperature = defaults.temperature,
                topP = defaults.topP,
                maxTokens = defaults.maxTokens,
                contextLength = defaults.contextLength,
                createdAt = now,
                updatedAt = now,
            ),
        )
    }

    suspend fun rename(id: Long, title: String) {
        val clean = title.trim().replace('\n', ' ').take(MAX_TITLE).ifBlank { DEFAULT_TITLE }
        db.conversations().rename(id, clean, clock())
    }

    /** Borra la conversación y (por CASCADE) todos sus mensajes. */
    suspend fun delete(id: Long) = db.conversations().delete(id)

    /** Guarda cambios de modelo/parámetros de la conversación (no toca el historial). */
    suspend fun updateSettings(conversation: ConversationEntity) {
        db.conversations().update(conversation.copy(updatedAt = clock()))
    }

    /**
     * Guarda el mensaje del usuario ANTES de generar y crea el hueco de la respuesta (estado GENERATING).
     * Si es el primer mensaje, usa su inicio como título. Devuelve (id del mensaje, id de la respuesta).
     */
    suspend fun appendUserTurn(conversationId: Long, text: String): Pair<Long, Long> = db.withTransaction {
        val now = clock()
        val next = db.messages().maxOrder(conversationId) + 1
        val userId = db.messages().insert(
            MessageEntity(
                conversationId = conversationId, role = MessageRole.USER, content = text,
                orderIndex = next, createdAt = now, state = MessageState.COMPLETE,
            ),
        )
        val assistantId = db.messages().insert(
            MessageEntity(
                conversationId = conversationId, role = MessageRole.ASSISTANT, content = "",
                orderIndex = next + 1, createdAt = now, state = MessageState.GENERATING,
            ),
        )
        val conv = db.conversations().get(conversationId)
        if (conv != null && conv.title == DEFAULT_TITLE && next == 0) {
            db.conversations().rename(conversationId, titleFrom(text), now)
        } else {
            db.conversations().touch(conversationId, now)
        }
        userId to assistantId
    }

    /**
     * Editar un mensaje del usuario: reemplaza su texto, descarta todo lo posterior y crea una respuesta nueva vacía.
     * Devuelve el id de la respuesta nueva, o null si el mensaje no existe o no es del usuario.
     */
    suspend fun editUserMessage(messageId: Long, newText: String): Long? = db.withTransaction {
        val msg = db.messages().get(messageId) ?: return@withTransaction null
        if (msg.role != MessageRole.USER) return@withTransaction null
        val now = clock()
        db.messages().updateContent(messageId, newText)
        db.messages().deleteAfter(msg.conversationId, msg.orderIndex)
        val id = db.messages().insert(
            MessageEntity(
                conversationId = msg.conversationId, role = MessageRole.ASSISTANT, content = "",
                orderIndex = msg.orderIndex + 1, createdAt = now, state = MessageState.GENERATING,
            ),
        )
        db.conversations().touch(msg.conversationId, now)
        id
    }

    /** Regenerar: la respuesta (la última) se vacía y vuelve a estado GENERATING. Devuelve false si no procede. */
    suspend fun resetAssistantForRegeneration(messageId: Long): Boolean = db.withTransaction {
        val msg = db.messages().get(messageId) ?: return@withTransaction false
        if (msg.role != MessageRole.ASSISTANT) return@withTransaction false
        if (db.messages().maxOrder(msg.conversationId) != msg.orderIndex) return@withTransaction false  // solo la última
        db.messages().updateContentAndState(messageId, "", MessageState.GENERATING)
        db.conversations().touch(msg.conversationId, clock())
        true
    }

    /** Guardado periódico de la respuesta parcial mientras se genera. */
    suspend fun savePartial(messageId: Long, content: String) = db.messages().updateContent(messageId, content)

    suspend fun finish(messageId: Long, content: String, state: String) {
        db.withTransaction {
            db.messages().updateContentAndState(messageId, content, state)
            db.messages().get(messageId)?.let { db.conversations().touch(it.conversationId, clock()) }
        }
    }

    /** Se llama al arrancar la app: lo que estaba "generándose" se marca como interrumpido (el texto se conserva). */
    suspend fun markInterruptedOnStart(): Int = db.messages().markGeneratingAsInterrupted()

    companion object {
        const val DEFAULT_TITLE = "Nueva conversación"
        const val MAX_TITLE = 60

        fun titleFrom(text: String): String {
            val oneLine = text.trim().replace(Regex("\\s+"), " ")
            if (oneLine.isEmpty()) return DEFAULT_TITLE
            return if (oneLine.length <= 40) oneLine else oneLine.take(40).trimEnd() + "…"
        }
    }
}
