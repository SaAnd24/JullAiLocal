package com.jullai.local.world

/** Estado de un paso de preparación. */
object PrepStatus {
    const val PENDIENTE = "PENDIENTE"
    const val EN_CURSO = "EN_CURSO"
    const val LISTO = "LISTO"
    const val FALLIDO = "FALLIDO"
    const val OMITIDO = "OMITIDO"
}

/** Hechos reales (leídos de la base de datos) a partir de los que se calcula la preparación. Nada se simula. */
class PrepFacts(
    val worldExists: Boolean,
    val worldName: String,
    val activeEntries: Int,
    val hasWorldRules: Boolean,
    val researchRunning: Boolean,
    val researchFailed: Boolean,
    val characterName: String,
    val characterHasSheet: Boolean,
    val locationEntries: Int,
    val scenarioText: String,
    val hasFirstMessage: Boolean,
)

class PrepStep(val step: Int, val title: String, val status: String, val detail: String)

class PrepReport(val steps: List<PrepStep>) {
    val done: Int get() = steps.count { it.status == PrepStatus.LISTO }
    val failed: Int get() = steps.count { it.status == PrepStatus.FALLIDO }
    val pending: Int get() = steps.count { it.status == PrepStatus.PENDIENTE || it.status == PrepStatus.EN_CURSO }
    val total: Int get() = steps.size

    /** Se puede empezar cuando el mundo, el reparto inicial y la primera escena están listos (pasos 1, 3 y 5). */
    val canStart: Boolean get() = listOf(1, 3, 5).all { n -> steps.firstOrNull { it.step == n }?.status == PrepStatus.LISTO }

    /** Texto honesto de progreso: tareas terminadas, pendientes o fallidas (no un porcentaje inventado). */
    fun summary(): String = "$done de $total tareas terminadas" + (if (pending > 0) " · $pending pendientes" else "") + (if (failed > 0) " · $failed fallidas" else "")
}

object Preparation {
    const val MIN_ESSENTIAL_ENTRIES = 3

    val TITLES = listOf(
        1 to "Leer la configuración del mundo",
        2 to "Obtener o crear el conocimiento esencial",
        3 to "Preparar los personajes principales",
        4 to "Preparar las localizaciones iniciales",
        5 to "Construir la primera escena",
    )

    fun evaluate(f: PrepFacts): PrepReport {
        val s1 = if (f.worldExists) PrepStep(1, TITLES[0].second, PrepStatus.LISTO, "Mundo «${f.worldName}» leído.")
        else PrepStep(1, TITLES[0].second, PrepStatus.FALLIDO, "El mundo de esta partida ya no existe. Vuelve a importarlo o elige otro.")

        val s2 = when {
            !f.worldExists -> PrepStep(2, TITLES[1].second, PrepStatus.PENDIENTE, "Depende del paso 1.")
            f.activeEntries >= Preparation.MIN_ESSENTIAL_ENTRIES -> PrepStep(2, TITLES[1].second, PrepStatus.LISTO, "${f.activeEntries} entradas en la enciclopedia.")
            f.researchRunning -> PrepStep(2, TITLES[1].second, PrepStatus.EN_CURSO, "Investigación en curso (puedes empezar sin esperar).")
            f.researchFailed && f.activeEntries == 0 -> PrepStep(2, TITLES[1].second, PrepStatus.FALLIDO, "La investigación no obtuvo entradas válidas. Añade entradas a mano o importa una fuente.")
            f.hasWorldRules -> PrepStep(2, TITLES[1].second, PrepStatus.LISTO, "Solo hay las reglas del mundo (${f.activeEntries} entradas). Suficiente para jugar; puedes ampliarlo después.")
            else -> PrepStep(2, TITLES[1].second, PrepStatus.PENDIENTE, "El mundo no tiene entradas ni reglas. Añade algunas o investiga.")
        }

        val s3 = when {
            f.characterName.isBlank() -> PrepStep(3, TITLES[2].second, PrepStatus.FALLIDO, "La partida no tiene un personaje principal.")
            f.characterHasSheet -> PrepStep(3, TITLES[2].second, PrepStatus.LISTO, "Ficha de ${f.characterName} lista.")
            else -> PrepStep(3, TITLES[2].second, PrepStatus.PENDIENTE, "La ficha de ${f.characterName} está casi vacía: completa su personalidad o su historia.")
        }

        val s4 = when {
            f.locationEntries > 0 -> PrepStep(4, TITLES[3].second, PrepStatus.LISTO, "${f.locationEntries} localizaciones.")
            else -> PrepStep(4, TITLES[3].second, PrepStatus.PENDIENTE, "Sin localizaciones: no es obligatorio; la escena usará un fondo neutral.")
        }

        val canScene = f.worldExists && s3.status == PrepStatus.LISTO && (s2.status == PrepStatus.LISTO || s2.status == PrepStatus.EN_CURSO)
        val s5 = when {
            f.scenarioText.isNotBlank() || f.hasFirstMessage -> PrepStep(5, TITLES[4].second, PrepStatus.LISTO, "Primera escena preparada.")
            canScene -> PrepStep(5, TITLES[4].second, PrepStatus.PENDIENTE, "Se puede construir ahora.")
            else -> PrepStep(5, TITLES[4].second, PrepStatus.PENDIENTE, "Faltan pasos anteriores.")
        }
        return PrepReport(listOf(s1, s2, s3, s4, s5))
    }

    /** Texto de la primera escena a partir del mundo (determinista; sin modelo). El usuario puede editarlo. */
    fun composeFirstScene(worldName: String, setting: String, era: String, locationName: String, characterName: String, userName: String): String = buildString {
        append("La historia comienza en el mundo de $worldName")
        if (era.isNotBlank()) append(", en $era")
        append(".")
        if (setting.isNotBlank()) append(" ").append(setting.trim().trimEnd('.')).append(".")
        if (locationName.isNotBlank()) append(" La escena transcurre en $locationName.")
        append(" $userName se encuentra con $characterName.")
    }
}
