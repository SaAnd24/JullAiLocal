package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.jullai.local.ModelsViewModel
import com.jullai.local.engine.EngineState
import com.jullai.local.engine.StoredModel

/** Modelos: importar, validar, elegir, cargar y liberar. El diagnóstico queda plegado. */
@Composable
fun ModelsScreen(vm: ModelsViewModel, onPickModel: () -> Unit, onBack: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val clipboard = LocalClipboardManager.current
    var showDiag by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<StoredModel?>(null) }
    val busy = ui.busyMessage != null || ui.importing || ui.downloading
    val generating = ui.engineState == EngineState.GENERATING
    val ready = ui.engineState == EngineState.READY || generating

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Modelos", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
            ui.error?.let { msg ->
                Column(Modifier.padding(top = 8.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(6.dp)).padding(12.dp)) {
                    BasicText(msg, style = Type.Cuerpo.copy(color = Ink.Granate))
                    Box(Modifier.padding(top = 8.dp)) { InkButton("Entendido", vm::dismissError, primary = false) }
                }
            }
            ui.notice?.let { msg ->
                Column(Modifier.padding(top = 8.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(6.dp)).padding(12.dp)) {
                    BasicText(msg, style = Type.Cuerpo.copy(color = Ink.Oro))
                    Box(Modifier.padding(top = 8.dp)) { InkButton("Cerrar", vm::dismissNotice, primary = false) }
                }
            }

            SectionTitle("Descargar modelo recomendado")
            val cat = com.jullai.local.engine.ModelCatalog.DEFAULT
            BasicText(cat.name + "\n" + cat.description, style = Type.Cuerpo)
            BasicText(
                "Se descarga desde Hugging Face solo cuando pulsas el botón (necesita internet y bastante espacio). " +
                    (if (ui.remoteSizeMb > 0) "Tamaño según el servidor: ${ui.remoteSizeMb} MB. " else "") + "Espacio libre: ${ui.freeStorageMb} MB. " +
                    "Si se corta la conexión puedes reanudar sin empezar de cero; mantén la app abierta mientras descarga. " + cat.license,
                style = Type.Nota, modifier = Modifier.padding(top = 4.dp),
            )
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton(if (ui.partialMb > 0) "Reanudar descarga (${ui.partialMb} MB)" else "Descargar", { vm.downloadModel() }, enabled = !busy && !ui.downloading && !generating)
                if (ui.downloading) InkButton("Pausar", vm::pauseDownload, primary = false)
                else if (ui.remoteSizeMb < 0 && ui.partialMb == 0L) InkButton("Ver tamaño", vm::probeDownloadSize, primary = false, enabled = !busy)
                if (!ui.downloading && ui.partialMb > 0) InkButton("Descartar parcial", vm::discardPartialDownload, primary = false)
            }
            if (ui.downloading) {
                Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(6.dp).background(Ink.Pizarra, RoundedCornerShape(3.dp))) {
                    Box(Modifier.fillMaxWidth(ui.downloadProgress.coerceIn(0f, 1f)).height(6.dp).background(Ink.Oro, RoundedCornerShape(3.dp)))
                }
                BasicText("Descargando… ${ui.downloadText}", style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
            }

            SectionTitle("Importar")
            BasicText(
                "Los modelos se copian al almacenamiento privado de la app. No se piden permisos de almacenamiento. " +
                    "Espacio libre: ${ui.freeStorageMb} MB.",
                style = Type.Nota,
            )
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Importar GGUF", onPickModel, enabled = !busy && !generating)
                if (ui.importing) InkButton("Cancelar importación", vm::cancelImport, primary = false)
            }
            if (ui.importing) {
                Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(6.dp).background(Ink.Pizarra, RoundedCornerShape(3.dp))) {
                    Box(Modifier.fillMaxWidth(ui.importProgress.coerceIn(0f, 1f)).height(6.dp).background(Ink.Oro, RoundedCornerShape(3.dp)))
                }
                BasicText("Copiando… ${(ui.importProgress * 100).toInt()} %", style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
            }

            SectionTitle("Tus modelos")
            if (ui.models.isEmpty() && !ui.importing) {
                BasicText("Aún no hay modelos. Importa un archivo .gguf (por ejemplo Qwen3-1.7B en Q4_K_M).", style = Type.Cuerpo)
            }
            ui.models.forEach { m ->
                ModelRow(
                    model = m,
                    selected = ui.selected?.fileName == m.fileName,
                    loaded = ui.loaded?.model?.fileName == m.fileName,
                    onSelect = { vm.select(m) },
                )
            }
            ui.selected?.let { sel ->
                Column(Modifier.padding(top = 12.dp)) {
                    ui.selectedInfo?.let { i ->
                        BasicText(
                            buildString {
                                append(i.description.ifBlank { i.name.ifBlank { sel.displayName } })
                                append("\nArquitectura: ${i.architecture} · capas ${i.nLayer} · contexto entrenado ${i.nCtxTrain}")
                                append("\nPlantilla de chat incluida: ${if (i.hasChatTemplate) "sí" else "no (se usará ChatML)"}")
                                if (i.license.isNotBlank()) append("\nLicencia declarada: ${i.license}")
                            },
                            style = Type.Nota,
                        )
                    } ?: BasicText("Validando el modelo con el motor…", style = Type.Nota)
                    if (ui.memoryEstimate.isNotBlank()) BasicText(ui.memoryEstimate, style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InkButton("Predeterminado", { vm.setDefault(sel) }, primary = false, enabled = !sel.isDefault && !busy)
                        InkButton("Eliminar", { confirmDelete = sel }, danger = true, enabled = !busy && !generating)
                    }
                }
            }

            SectionTitle("Motor")
            BasicText("Estado: ${stateLabel(ui.engineState)}", style = Type.Cuerpo)
            ui.busyMessage?.let { BasicText(it, style = Type.Nota) }
            ui.loaded?.let {
                BasicText("Cargado: ${it.model.displayName} · contexto ${it.contextLength} · ${it.threads} hilos", style = Type.Nota)
            }
            BasicText(
                "El chat carga el modelo solo cuando envías un mensaje. Aquí puedes cargarlo antes o liberar la memoria.",
                style = Type.Nota, modifier = Modifier.padding(top = 4.dp),
            )
            Stepper(
                "Contexto (tokens)", "${ui.contextLength}",
                { vm.setContextLength((ui.contextLength - 512).coerceAtLeast(512)) },
                { vm.setContextLength((ui.contextLength + 512).coerceAtMost(8192)) },
                enabled = !generating,
            )
            Stepper(
                "Hilos de CPU", "${ui.threads}",
                { vm.setThreads((ui.threads - 1).coerceAtLeast(1)) },
                { vm.setThreads((ui.threads + 1).coerceAtMost(8)) },
                enabled = !generating,
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Cargar modelo", vm::loadSelected, enabled = ui.selected != null && !busy && !generating)
                InkButton("Liberar memoria", vm::unload, primary = false, enabled = (ready || ui.engineState == EngineState.ERROR) && !generating)
            }

            SectionTitle("Diagnóstico")
            InkLink(if (showDiag) "▾ Ocultar diagnóstico" else "▸ Mostrar diagnóstico", { showDiag = !showDiag })
            if (showDiag) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 6.dp)) {
                    InkButton("Actualizar registro", vm::refreshLog, primary = false)
                    InkButton("Copiar registro", { clipboard.setText(AnnotatedString(ui.systemInfo + "\n\n" + ui.nativeLog)) }, primary = false)
                }
                if (ui.systemInfo.isNotBlank()) {
                    SelectionContainer { BasicText(ui.systemInfo, style = Type.Mono, modifier = Modifier.padding(top = 8.dp)) }
                }
                if (ui.nativeLog.isNotBlank()) {
                    SelectionContainer { BasicText(ui.nativeLog, style = Type.Mono, modifier = Modifier.padding(top = 8.dp)) }
                }
            }
            Box(Modifier.height(32.dp))
        }
    }

    confirmDelete?.let { m ->
        InkDialog("Eliminar modelo", { confirmDelete = null }) {
            BasicText(
                "Se borrará el archivo «${m.displayName}» de este teléfono. Tus conversaciones y su historial se conservan; " +
                    "podrás elegir otro modelo para continuarlas.",
                style = Type.Cuerpo,
            )
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Eliminar", { vm.deleteModel(m); confirmDelete = null }, danger = true)
                InkButton("Cancelar", { confirmDelete = null }, primary = false)
            }
        }
    }
}

@Composable
private fun ModelRow(model: StoredModel, selected: Boolean, loaded: Boolean, onSelect: () -> Unit) {
    Column(
        Modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .background(if (selected) Ink.Pizarra else Ink.Tinta, RoundedCornerShape(6.dp))
            .clickable(onClick = onSelect)
            .padding(12.dp),
    ) {
        BasicText(
            model.displayName + (if (model.isDefault) "  ·  predeterminado" else "") + (if (loaded) "  ·  cargado" else ""),
            style = Type.Cuerpo.copy(color = if (selected) Ink.Oro else Ink.Marfil),
        )
        BasicText("${model.sizeBytes / (1024 * 1024)} MB · sha256 ${model.sha256.take(10)}…", style = Type.Nota)
    }
}

private fun stateLabel(s: EngineState): String = when (s) {
    EngineState.IDLE -> "sin modelo cargado"
    EngineState.LOADING -> "cargando…"
    EngineState.READY -> "listo"
    EngineState.GENERATING -> "generando…"
    EngineState.ERROR -> "error (ver mensaje)"
}
