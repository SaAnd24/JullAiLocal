package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.BasicText
import androidx.compose.ui.semantics.Role

/** Sistema visual propio: biblioteca de ficción oscura. No usa Material. */
object Ink {
    val Tinta = Color(0xFF141217)
    val Pizarra = Color(0xFF27232B)
    val Marfil = Color(0xFFF0E9DF)
    val MarfilTenue = Color(0xFFB9B2A8)
    val Granate = Color(0xFFB86C68)
    val Oro = Color(0xFFD8B779)
    val Linea = Color(0xFF3A353F)
}

object Type {
    val Titulo = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Ink.Marfil)
    val Seccion = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink.Oro)
    val Cuerpo = TextStyle(fontFamily = FontFamily.Serif, fontSize = 16.sp, lineHeight = 23.sp, color = Ink.Marfil)
    val Nota = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, color = Ink.MarfilTenue)
    val Mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp, color = Ink.MarfilTenue)
    val Boton = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Ink.Tinta)
}

@Composable
fun Divider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Ink.Linea))
}

@Composable
fun SectionTitle(text: String) {
    Column(Modifier.padding(top = 20.dp, bottom = 8.dp)) {
        BasicText(text, style = Type.Seccion)
        Box(Modifier.padding(top = 6.dp)) { Divider() }
    }
}

/** Botón sobrio: relleno oro (acción principal) o contorno (secundaria). */
@Composable
fun InkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    enabled: Boolean = true,
    danger: Boolean = false,
) {
    val shape = RoundedCornerShape(6.dp)
    val bg = when {
        !enabled -> Ink.Pizarra
        danger -> Ink.Granate
        primary -> Ink.Oro
        else -> Color.Transparent
    }
    val fg = when {
        !enabled -> Ink.MarfilTenue.copy(alpha = 0.5f)
        primary || danger -> Ink.Tinta
        else -> Ink.Marfil
    }
    Box(
        modifier
            .background(bg, shape)
            .then(if (!primary && !danger) Modifier.border(1.dp, if (enabled) Ink.Oro else Ink.Linea, shape) else Modifier)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        BasicText(text, style = Type.Boton.copy(color = fg))
    }
}

@Composable
fun InkField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    minHeight: Int = 44,
    enabled: Boolean = true,
    maxHeight: Int = 220,
) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier
            .background(Ink.Pizarra, shape)
            .border(1.dp, Ink.Linea, shape)
            .padding(12.dp),
    ) {
        Box(Modifier.heightIn(min = minHeight.dp, max = maxHeight.dp)) {
            if (value.isEmpty()) BasicText(placeholder, style = Type.Cuerpo.copy(color = Ink.MarfilTenue.copy(alpha = 0.6f)))
            BasicTextField(
                value = value,
                onValueChange = onChange,
                enabled = enabled,
                textStyle = Type.Cuerpo,
                cursorBrush = SolidColor(Ink.Oro),
                keyboardOptions = KeyboardOptions.Default,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** Ajuste numérico con − / +. Evita depender de componentes Material. */
@Composable
fun Stepper(
    label: String,
    valueText: String,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    enabled: Boolean = true,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            BasicText(label, style = Type.Cuerpo)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("-", onMinus, primary = false, enabled = enabled)
            Box(Modifier.padding(horizontal = 4.dp)) { BasicText(valueText, style = Type.Cuerpo.copy(color = Ink.Oro)) }
            InkButton("+", onPlus, primary = false, enabled = enabled)
        }
    }
}


/** Enlace de texto pequeño para acciones secundarias (copiar, editar...). */
@Composable
fun InkLink(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, danger: Boolean = false) {
    val color = when {
        !enabled -> Ink.MarfilTenue.copy(alpha = 0.4f)
        danger -> Ink.Granate
        else -> Ink.Oro
    }
    Box(
        modifier
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
    ) {
        BasicText(text, style = Type.Nota.copy(color = color, fontWeight = FontWeight.Medium))
    }
}

/** Fila con interruptor Sí/No. */
@Composable
fun InkToggleRow(label: String, value: Boolean, onToggle: (Boolean) -> Unit, enabled: Boolean = true) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onToggle(!value) }.padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) { BasicText(label, style = Type.Cuerpo) }
        Spacer(Modifier.width(12.dp))
        BasicText(if (value) "Sí" else "No", style = Type.Cuerpo.copy(color = if (enabled) Ink.Oro else Ink.MarfilTenue))
    }
}

/** Diálogo propio (sin Material). */
@Composable
fun InkDialog(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Ink.Tinta, shape)
                .border(1.dp, Ink.Linea, shape)
                .padding(18.dp),
        ) {
            BasicText(title, style = Type.Seccion)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

/** Cabecera de pantalla: botón de volver, título y acciones opcionales a la derecha. */
@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            InkLink("‹ Volver", onBack)
            Spacer(Modifier.width(8.dp))
        }
        Box(Modifier.weight(1f)) { BasicText(title, style = Type.Seccion.copy(fontSize = 20.sp), maxLines = 1) }
        trailing()
    }
    Divider()
}
