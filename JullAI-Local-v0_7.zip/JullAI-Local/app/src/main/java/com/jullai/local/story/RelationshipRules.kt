package com.jullai.local.story

import kotlin.math.abs

/** Cuatro dimensiones independientes de 1 a 100. Un valor alto en una NO implica un valor alto en las demás. */
data class RelValues(val trust: Int, val affection: Int, val respect: Int, val romantic: Int) {
    operator fun get(dim: String): Int = when (dim) {
        RelDim.TRUST -> trust
        RelDim.AFFECTION -> affection
        RelDim.RESPECT -> respect
        RelDim.ROMANTIC -> romantic
        else -> throw IllegalArgumentException("Dimensión desconocida: $dim")
    }

    companion object {
        /** Punto de partida neutro para una relación nueva: poca confianza y casi nada de interés romántico. */
        val INITIAL = RelValues(trust = 25, affection = 25, respect = 30, romantic = 5)
    }
}

data class RelDelta(val trust: Int = 0, val affection: Int = 0, val respect: Int = 0, val romantic: Int = 0) {
    fun isZero() = trust == 0 && affection == 0 && respect == 0 && romantic == 0
    fun sumAbs() = abs(trust) + abs(affection) + abs(respect) + abs(romantic)
}

object RelDim {
    const val TRUST = "confianza"
    const val AFFECTION = "afecto"
    const val RESPECT = "respeto"
    const val ROMANTIC = "romantico"
    val ALL = listOf(TRUST, AFFECTION, RESPECT, ROMANTIC)

    fun label(d: String) = when (d) {
        TRUST -> "Confianza"
        AFFECTION -> "Afecto"
        RESPECT -> "Respeto"
        ROMANTIC -> "Interés romántico"
        else -> d
    }
}

class RelValidation(
    val ok: Boolean,
    /** Cambio realmente aplicable (ya recortado y ajustado a 1..100). */
    val applied: RelDelta,
    val after: RelValues,
    /** Motivo de rechazo (si no ok) o avisos de recorte (si ok). */
    val notes: List<String>,
)

/**
 * La aplicación, no el texto del modelo, decide cuánto cambia una relación. El modelo solo PROPONE un acontecimiento
 * con motivo y efectos; aquí se validan con límites y se registra la procedencia.
 */
object RelationshipRules {
    const val MIN = 1
    const val MAX = 100
    /** Máximo por dimensión en un solo acontecimiento. */
    const val MAX_STEP = 6
    /** El interés romántico cambia más despacio. */
    const val MAX_STEP_ROMANTIC = 3
    /** Un acontecimiento no puede mover más de esto en total. */
    const val MAX_TOTAL = 10
    /** Un acontecimiento no puede tocar las cuatro dimensiones a la vez. */
    const val MAX_DIMENSIONS = 2
    const val MIN_REASON = 3

    fun clampValue(v: Int) = v.coerceIn(MIN, MAX)

    fun clampValues(v: RelValues) = RelValues(clampValue(v.trust), clampValue(v.affection), clampValue(v.respect), clampValue(v.romantic))

    /** Validación de una PROPUESTA del modelo (o de un cambio relativo). */
    fun validateProposal(current: RelValues, proposed: RelDelta, reason: String): RelValidation {
        val notes = ArrayList<String>()
        if (reason.trim().length < MIN_REASON) return RelValidation(false, RelDelta(), current, listOf("Falta el motivo del cambio."))

        fun lim(dim: String, v: Int): Int {
            val max = if (dim == RelDim.ROMANTIC) MAX_STEP_ROMANTIC else MAX_STEP
            val c = v.coerceIn(-max, max)
            if (c != v) notes.add("${RelDim.label(dim)}: cambio recortado de $v a $c.")
            return c
        }
        val raw = linkedMapOf(
            RelDim.TRUST to lim(RelDim.TRUST, proposed.trust),
            RelDim.AFFECTION to lim(RelDim.AFFECTION, proposed.affection),
            RelDim.RESPECT to lim(RelDim.RESPECT, proposed.respect),
            RelDim.ROMANTIC to lim(RelDim.ROMANTIC, proposed.romantic),
        )
        // Como máximo MAX_DIMENSIONS dimensiones: se conservan las de mayor cambio.
        val nonZero = raw.entries.filter { it.value != 0 }.sortedByDescending { abs(it.value) }
        if (nonZero.size > MAX_DIMENSIONS) {
            nonZero.drop(MAX_DIMENSIONS).forEach { raw[it.key] = 0 }
            notes.add("Se aplican solo las $MAX_DIMENSIONS dimensiones con mayor cambio.")
        }
        // Tope total.
        var total = raw.values.sumOf { abs(it) }
        val totalBefore = total
        while (total > MAX_TOTAL) {
            val big = raw.entries.filter { it.value != 0 }.maxByOrNull { abs(it.value) } ?: break
            raw[big.key] = big.value + if (big.value > 0) -1 else 1
            total--
        }
        if (total < totalBefore) notes.add("Cambio total recortado a $MAX_TOTAL.")

        val after = RelValues(
            clampValue(current.trust + raw.getValue(RelDim.TRUST)),
            clampValue(current.affection + raw.getValue(RelDim.AFFECTION)),
            clampValue(current.respect + raw.getValue(RelDim.RESPECT)),
            clampValue(current.romantic + raw.getValue(RelDim.ROMANTIC)),
        )
        val applied = RelDelta(after.trust - current.trust, after.affection - current.affection, after.respect - current.respect, after.romantic - current.romantic)
        if (applied.isZero()) return RelValidation(false, applied, current, notes + "El cambio no tiene efecto (valores en el límite o a cero).")
        return RelValidation(true, applied, after, notes)
    }

    /** Edición manual del usuario: valores absolutos 1..100 sin límite de paso. El historial guarda la diferencia. */
    fun manualSet(current: RelValues, target: RelValues): Pair<RelValues, RelDelta> {
        val t = clampValues(target)
        return t to RelDelta(t.trust - current.trust, t.affection - current.affection, t.respect - current.respect, t.romantic - current.romantic)
    }
}
