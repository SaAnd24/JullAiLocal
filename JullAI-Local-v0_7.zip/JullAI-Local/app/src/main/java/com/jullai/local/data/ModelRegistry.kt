package com.jullai.local.data

import androidx.room.withTransaction
import com.jullai.local.engine.StoredModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import java.io.File

/** Registro de modelos importados (tabla `models`). Sustituye al registry.json del Hito 1. */
class ModelRegistry(private val db: AppDatabase) {
    private val dao get() = db.models()

    fun observe(): Flow<List<StoredModel>> = dao.observeAll().map { list -> list.map { it.toStored() } }

    suspend fun list(): List<StoredModel> = dao.all().map { it.toStored() }

    suspend fun findBySha(sha: String): StoredModel? = dao.bySha(sha)?.toStored()

    suspend fun find(fileName: String): StoredModel? = dao.byFile(fileName)?.toStored()

    suspend fun count(): Int = dao.count()

    suspend fun add(model: StoredModel) {
        dao.insertIgnore(model.toEntity())
    }

    suspend fun setDefault(model: StoredModel) = dao.setDefaultOnly(model.fileName)

    /**
     * Quita el modelo del registro. Las conversaciones y partidas de roleplay que lo usaban se conservan (pasan a "sin modelo fijado").
     * Si era el predeterminado, el más antiguo restante pasa a serlo. Todo en una sola transacción.
     */
    suspend fun remove(fileName: String) {
        db.withTransaction {
            val wasDefault = dao.byFile(fileName)?.isDefault == true
            dao.delete(fileName)
            db.conversations().clearModel(fileName)
            db.roleSessions().clearModel(fileName)
            if (wasDefault) dao.all().firstOrNull()?.let { dao.setDefaultOnly(it.fileName) }
        }
    }

    /**
     * Migra models/registry.json (Hito 1) a Room SIN perder modelos ya importados.
     * El archivo viejo no se borra: se renombra a registry.json.migrated. Si no se puede leer, se deja intacto.
     * Es idempotente: se puede llamar en cada arranque.
     * @return cuántos modelos se migraron (0 si no había nada que migrar)
     */
    suspend fun migrateLegacyRegistry(modelsDir: File): Int {
        val legacy = File(modelsDir, LEGACY_FILE)
        if (!legacy.exists()) return 0
        val parsed = try {
            parseLegacy(legacy.readText())
        } catch (e: Exception) {
            return 0   // registro ilegible: no se toca, para poder recuperarlo a mano
        }
        var migrated = 0
        db.withTransaction {
            val hadDefault = dao.all().any { it.isDefault }
            parsed.filter { File(modelsDir, it.fileName).exists() }.forEach { m ->
                val entity = m.toEntity().let { if (hadDefault) it.copy(isDefault = false) else it }
                if (dao.insertIgnore(entity) != -1L) migrated++
            }
        }
        legacy.renameTo(File(modelsDir, "$LEGACY_FILE.migrated"))
        return migrated
    }

    companion object {
        const val LEGACY_FILE = "registry.json"

        fun parseLegacy(text: String): List<StoredModel> {
            val arr = JSONArray(text)
            return (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                StoredModel(
                    fileName = o.getString("fileName"),
                    displayName = o.getString("displayName"),
                    sizeBytes = o.getLong("sizeBytes"),
                    sha256 = o.getString("sha256"),
                    importedAtMillis = o.getLong("importedAt"),
                    isDefault = o.optBoolean("isDefault", false),
                )
            }
        }
    }
}

internal fun ModelEntity.toStored() = StoredModel(fileName, displayName, sizeBytes, sha256, importedAt, isDefault)
internal fun StoredModel.toEntity() = ModelEntity(fileName, displayName, sizeBytes, sha256, importedAtMillis, isDefault)
