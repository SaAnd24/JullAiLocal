package com.jullai.local.imaging

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/** Lo que el coordinador necesita del motor de texto (lo implementa un adaptador sobre EngineController). */
interface TextSide {
    fun isGenerating(): Boolean
    fun isLoaded(): Boolean
    /** Libera el modelo de texto solo si no está generando. true = liberado (o ya no estaba cargado). */
    suspend fun unloadIfIdle(): Boolean
}

enum class CoordPhase { IDLE, FREEING_TEXT, LOADING_IMAGE, GENERATING, BLOCKED }

data class CoordState(
    val phase: CoordPhase = CoordPhase.IDLE,
    val detail: String = "",
    /** El modelo de texto se liberó para dejar sitio a la imagen: se recargará solo al enviar la próxima acción. */
    val textReloadPending: Boolean = false,
)

enum class DeferCode { TEXT_BUSY, TEXT_PRIORITY, LOW_MEMORY, THERMAL, NO_ENGINE }

class ImageJob(
    val request: GenerationRequest,
    val modelPath: String,
    val modelBytes: Long,
    val onProgress: (GenProgress) -> Unit = {},
)

sealed interface JobOutcome {
    class Done(val result: GenerationResult) : JobOutcome
    /** No se ejecutó (o se paró) por una causa recuperable: la tarea se puede reintentar luego. */
    class Deferred(val code: DeferCode, val reason: String) : JobOutcome
    class Failed(val code: ImageEngineException.Code, val message: String) : JobOutcome
    /** Cancelada a petición (usuario, nueva acción de texto, presión de memoria o temperatura). */
    class Cancelled(val reason: String, val byUser: Boolean) : JobOutcome
}

/**
 * Árbitro único entre el motor de texto y el de imagen. Reglas:
 *  - El texto tiene prioridad: no se genera una imagen mientras el texto genera, y una acción nueva del jugador cancela/aplaza la imagen.
 *  - Antes de cargar el modelo visual se libera el de texto (no conviven en 8 GB). Se recarga solo cuando hace falta.
 *  - No se toca ningún mensaje ni el estado de la partida: la conversación vive en la base de datos y el contexto se reconstruye de ahí.
 *  - Una imagen a la vez. Temperatura y memoria se consultan antes de empezar y vigilan durante la ejecución.
 */
class ResourceCoordinator(
    private val engine: ImageEngine,
    private val text: TextSide,
    private val device: DeviceGate,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val jobLock = Mutex()
    private val _state = MutableStateFlow(CoordState())
    val state: StateFlow<CoordState> = _state.asStateFlow()

    @Volatile private var running = false
    @Volatile private var cancelReason: String? = null
    @Volatile private var cancelByUser = false
    @Volatile private var textHoldUntil = 0L
    @Volatile private var loadedPath: String? = null
    @Volatile private var textReload = false

    val isBusy: Boolean get() = running

    private fun set(phase: CoordPhase, detail: String = "") { _state.value = CoordState(phase, detail, textReload) }

    /** ¿Hay texto generándose o acaba el jugador de pedirlo? Mientras sea así, la cola visual espera. */
    fun textHasPriority(): Boolean = text.isGenerating() || clock() < textHoldUntil

    suspend fun run(job: ImageJob): JobOutcome {
        if (textHasPriority()) return JobOutcome.Deferred(DeferCode.TEXT_PRIORITY, "El texto tiene prioridad: la imagen espera a que termine tu respuesta.")
        return jobLock.withLock { runLocked(job) }
    }

    private suspend fun runLocked(job: ImageJob): JobOutcome {
        if (textHasPriority()) return JobOutcome.Deferred(DeferCode.TEXT_PRIORITY, "El texto tiene prioridad: la imagen espera a que termine tu respuesta.")
        val caps = engine.capabilities()
        val bad = RequestValidator.validate(job.request, caps)
        if (bad != null) return JobOutcome.Failed(ImageEngineException.Code.UNSUPPORTED, bad)

        when (DevicePolicy.thermal(device.thermal(), running = false)) {
            GateAction.DEFER -> return JobOutcome.Deferred(DeferCode.THERMAL, "El teléfono está caliente (${ThermalLevel.label(device.thermal())}). La imagen se aplaza hasta que baje la temperatura.")
            else -> Unit
        }
        val needed = DevicePolicy.memoryNeeded(job.modelBytes, job.request.width, job.request.height, job.request.vaeTiling)

        cancelReason = null
        cancelByUser = false
        running = true
        try {
            // Paso 4 del flujo: liberar el modelo de texto para dejar la memoria al visual.
            if (text.isLoaded()) {
                set(CoordPhase.FREEING_TEXT, "Liberando el modelo de texto…")
                if (!text.unloadIfIdle()) {
                    set(CoordPhase.IDLE)
                    return JobOutcome.Deferred(DeferCode.TEXT_BUSY, "No se pudo liberar el modelo de texto porque está ocupado. Detén la respuesta de texto y reintenta.")
                }
                textReload = true
            }
            val mem = device.memory()
            if (DevicePolicy.memory(mem, needed, running = false) == GateAction.DEFER) {
                set(CoordPhase.BLOCKED, "Memoria insuficiente")
                return JobOutcome.Deferred(
                    DeferCode.LOW_MEMORY,
                    "Memoria insuficiente: hay ${DevicePolicy.humanMb(mem.availableBytes)} libres y se estiman ${DevicePolicy.humanMb(needed)} (cálculo aproximado). " +
                        "Cierra otras apps, baja la resolución o usa un modelo más pequeño.",
                )
            }
            if (cancelReason != null) return JobOutcome.Cancelled(cancelReason!!, cancelByUser)

            if (loadedPath != job.modelPath) {
                set(CoordPhase.LOADING_IMAGE, "Cargando el modelo de imagen…")
                engine.release()
                loadedPath = null
                engine.loadModel(job.modelPath, job.request.threads)
                loadedPath = job.modelPath
            }
            if (cancelReason != null) return JobOutcome.Cancelled(cancelReason!!, cancelByUser)

            set(CoordPhase.GENERATING, "Generando la imagen…")
            val result = engine.generate(job.request) { p ->
                job.onProgress(p)
                // Vigilancia durante la ejecución.
                if (DevicePolicy.thermal(device.thermal(), running = true) == GateAction.CANCEL) requestCancel("Temperatura crítica: se cancela la imagen para proteger el teléfono.")
                if (DevicePolicy.memory(device.memory(), needed, running = true) == GateAction.CANCEL) requestCancel("El sistema avisa de poca memoria: se cancela la imagen.")
            }
            return JobOutcome.Done(result)
        } catch (e: CancellationException) {
            engine.cancel()
            throw e
        } catch (e: ImageEngineException) {
            if (e.code == ImageEngineException.Code.OUT_OF_MEMORY || e.code == ImageEngineException.Code.INVALID_MODEL) loadedPath = null
            return when (e.code) {
                ImageEngineException.Code.CANCELLED -> JobOutcome.Cancelled(cancelReason ?: "Cancelada.", cancelByUser)
                ImageEngineException.Code.BUSY -> JobOutcome.Deferred(DeferCode.NO_ENGINE, e.message ?: "El motor está ocupado.")
                else -> JobOutcome.Failed(e.code, e.message ?: "Error del motor de imágenes.")
            }
        } finally {
            running = false
            set(CoordPhase.IDLE)
        }
    }

    /**
     * Carga el modelo en el motor y lo libera enseguida: es la validación REAL de un checkpoint importado. Respeta las mismas reglas
     * (texto con prioridad, memoria, temperatura). Devuelve null si el motor lo cargó; si no, el motivo en español.
     */
    suspend fun probeLoad(path: String, modelBytes: Long, threads: Int): String? {
        if (textHasPriority()) return "El texto tiene prioridad: espera a que termine la respuesta."
        return jobLock.withLock {
            if (textHasPriority()) return@withLock "El texto tiene prioridad: espera a que termine la respuesta."
            if (DevicePolicy.thermal(device.thermal(), running = false) == GateAction.DEFER) return@withLock "El teléfono está caliente; reintenta cuando baje la temperatura."
            running = true
            try {
                if (text.isLoaded()) {
                    set(CoordPhase.FREEING_TEXT, "Liberando el modelo de texto…")
                    if (!text.unloadIfIdle()) return@withLock "No se pudo liberar el modelo de texto (ocupado)."
                    textReload = true
                }
                val needed = DevicePolicy.memoryNeeded(modelBytes, 256, 256, true)
                val mem = device.memory()
                if (DevicePolicy.memory(mem, needed, running = false) == GateAction.DEFER) return@withLock "Memoria insuficiente: hay ${DevicePolicy.humanMb(mem.availableBytes)} libres y se estiman ${DevicePolicy.humanMb(needed)} (cálculo aproximado)."
                set(CoordPhase.LOADING_IMAGE, "Comprobando el modelo con el motor…")
                engine.release(); loadedPath = null
                try { engine.loadModel(path, threads); null } catch (e: ImageEngineException) { e.message ?: "El motor no aceptó el modelo." } finally { engine.release() }
            } finally {
                running = false
                set(CoordPhase.IDLE)
            }
        }
    }

    /** Pide cancelar la imagen en curso (si el motor lo permite). */
    fun requestCancel(reason: String, byUser: Boolean = false): Boolean {
        if (!running) return false
        cancelReason = reason
        cancelByUser = byUser
        return engine.cancel()
    }

    /** Libera el motor visual (p. ej. al vaciarse la cola). No hace nada si hay una imagen en curso. */
    suspend fun releaseIfIdle() {
        if (running) return
        jobLock.withLock {
            if (!running) { engine.release(); loadedPath = null; set(CoordPhase.IDLE) }
        }
    }

    /**
     * El jugador va a usar el motor de texto: se cancela la imagen y se libera el motor visual ANTES de cargar el texto.
     * Devuelve false si la imagen no terminó a tiempo (el motor no admite cancelar o tarda): en ese caso NO se debe cargar el texto
     * y hay que avisar al usuario. Nunca pierde mensajes: no los toca.
     */
    suspend fun yieldToText(timeoutMs: Long = 45_000): Boolean {
        textHoldUntil = clock() + 15_000
        if (running) requestCancel("El jugador envió una acción: el texto tiene prioridad.")
        val ok = withTimeoutOrNull(timeoutMs) {
            jobLock.withLock {
                engine.release()
                loadedPath = null
            }
            true
        } ?: false
        if (!ok) set(CoordPhase.BLOCKED, "La imagen sigue en curso y no se pudo cancelar. Detén la generación de imagen antes de continuar con el texto.")
        else set(CoordPhase.IDLE)
        return ok
    }

    /** Aviso de presión de memoria del sistema (ComponentCallbacks2.onTrimMemory). */
    fun onMemoryPressure(critical: Boolean) {
        if (critical && running) requestCancel("El sistema necesita memoria: se cancela la imagen.")
    }

    /** Aviso de cambio térmico (listener de PowerManager en Android 10+). */
    fun onThermal(level: ThermalLevel) {
        if (DevicePolicy.thermal(level, running = running) == GateAction.CANCEL) requestCancel("Temperatura crítica: se cancela la imagen para proteger el teléfono.")
    }

    fun clearTextReloadFlag() { textReload = false; _state.value = _state.value.copy(textReloadPending = false) }
}
