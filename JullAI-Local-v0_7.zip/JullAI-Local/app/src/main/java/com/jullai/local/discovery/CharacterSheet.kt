package com.jullai.local.discovery

import com.jullai.local.story.TextNorm
import com.jullai.local.world.Confidence
import com.jullai.local.world.DraftEntry
import com.jullai.local.world.EntryOrigin
import com.jullai.local.world.EntryState
import com.jullai.local.world.EntryType
import com.jullai.local.world.SourceText
import com.jullai.local.world.UntrustedText
import com.jullai.local.world.WikiExtractor
import com.jullai.local.world.WorldLimits

/**
 * Construye fichas de personaje a partir del texto REAL recuperado (nada se inventa). Cada ficha se reparte en entradas con su propio nivel de spoiler:
 *  - PERSONAJE (spoiler 0): introducción, apariencia, personalidad, habilidades, relaciones;
 *  - «<nombre> — historia» (ACONTECIMIENTO, spoiler 2): biografía y trama;
 *  - «<nombre> — notas de aficionados» (confianza «interpretación de aficionados»): curiosidades y teorías.
 * Lo que la fuente no dice queda sin rellenar: «desconocido» no se convierte en «inventado».
 */
object CharacterSheet {
    const val L_ACTOR = "Intérprete"
    const val L_APPEARANCE = "Apariencia"
    const val L_PERSONALITY = "Personalidad"
    const val L_ABILITIES = "Habilidades"
    const val L_RELATIONS = "Relaciones"
    val LABELS = listOf(L_ACTOR, L_APPEARANCE, L_PERSONALITY, L_ABILITIES, L_RELATIONS)

    private val APPEARANCE = setOf("appearance", "physical appearance", "physical description", "apariencia", "aspecto", "aspecto fisico", "descripcion fisica", "descripcion")
    private val PERSONALITY = setOf("personality", "personality and traits", "traits", "personalidad", "caracter", "carácter", "personalidad y caracter")
    private val ABILITIES = setOf("abilities", "skills", "skills and abilities", "powers", "powers and abilities", "habilidades", "poderes", "capacidades", "habilidades y poderes")
    private val RELATIONS = setOf("relationships", "relations", "family", "allies", "relaciones", "familia", "aliados", "relaciones personales")
    private val HISTORY = setOf("history", "biography", "background", "backstory", "early life", "plot", "story", "storyline", "historia", "biografia", "trasfondo", "argumento", "trama", "pasado", "vida temprana", "apariciones")
    private val FANDOM_NOTES = setOf("trivia", "curiosidades", "theories", "teorias", "speculation", "especulacion", "notes", "notas")

    fun isListPage(title: String): Boolean {
        val f = TextNorm.fold(title)
        return f.contains("characters") || f.contains("personajes") || f.startsWith("list of") || f.startsWith("lista de") || f.startsWith("anexo")
    }

    /** Página dedicada a un personaje → entradas. [name] es el nombre canónico elegido por el planificador. */
    fun fromPage(name: String, aliases: List<String>, actor: String, text: String, sourceRef: String, sourceId: Long?): List<DraftEntry> {
        val clean = UntrustedText.sanitize(text, WorldLimits.MAX_SOURCE_CHARS)
        if (name.isBlank() || clean.length < 40) return emptyList()
        val secs = SourceText.sections(clean)
        val intro = secs.firstOrNull { it.first.isEmpty() }?.second.orEmpty().ifBlank { secs.firstOrNull()?.second.orEmpty() }
        if (intro.isBlank()) return emptyList()
        fun body(names: Set<String>) = secs.filter { it.first.isNotEmpty() && TextNorm.fold(it.first).trim() in names.map { n -> TextNorm.fold(n) } }
            .joinToString(" ") { it.second }.let { WikiExtractor.excerpt(it, 320) }
        val ref = sourceRef.take(WorldLimits.SOURCE_REF)
        val lines = ArrayList<String>()
        if (actor.isNotBlank()) lines.add("$L_ACTOR: ${UntrustedText.oneLine(actor, 60)}")
        for ((label, set) in listOf(L_APPEARANCE to APPEARANCE, L_PERSONALITY to PERSONALITY, L_ABILITIES to ABILITIES, L_RELATIONS to RELATIONS)) {
            val b = body(set)
            if (b.isNotBlank()) lines.add("$label: $b")
        }
        val out = ArrayList<DraftEntry>()
        out.add(
            DraftEntry(
                type = EntryType.PERSONAJE, name = UntrustedText.oneLine(name, WorldLimits.NAME), aliases = aliases.map { UntrustedText.oneLine(it, 60) }.filter { it.isNotBlank() }.take(8),
                summary = WikiExtractor.excerpt(intro, WorldLimits.SUMMARY), details = joinKeepLines(lines, WorldLimits.DETAILS),
                confidence = Confidence.CONFIRMADO, origin = EntryOrigin.FUENTE, state = EntryState.ACTIVO,
                evidence = WikiExtractor.excerpt(intro, WorldLimits.EVIDENCE), sourceRef = ref, sourceId = sourceId, spoilerLevel = 0,
            ),
        )
        val fullHistory = secs.filter { it.first.isNotEmpty() && TextNorm.fold(it.first).trim() in HISTORY.map { n -> TextNorm.fold(n) } }.joinToString(" ") { it.second }
        if (fullHistory.isNotBlank()) out.add(
            DraftEntry(
                type = EntryType.ACONTECIMIENTO, name = UntrustedText.oneLine("$name — historia", WorldLimits.NAME), summary = WikiExtractor.excerpt(fullHistory, WorldLimits.SUMMARY),
                details = WikiExtractor.excerpt(fullHistory, WorldLimits.DETAILS), confidence = Confidence.CONFIRMADO, origin = EntryOrigin.FUENTE, state = EntryState.ACTIVO,
                evidence = WikiExtractor.excerpt(fullHistory, WorldLimits.EVIDENCE), sourceRef = ref, sourceId = sourceId, spoilerLevel = 2, related = listOf(name),
            ),
        )
        val notes = secs.filter { it.first.isNotEmpty() && TextNorm.fold(it.first).trim() in FANDOM_NOTES.map { n -> TextNorm.fold(n) } }.joinToString(" ") { it.second }
        if (notes.isNotBlank()) out.add(
            DraftEntry(
                type = EntryType.OTRO, name = UntrustedText.oneLine("$name — notas de aficionados", WorldLimits.NAME), summary = WikiExtractor.excerpt(notes, WorldLimits.SUMMARY),
                confidence = Confidence.AFICIONADOS, origin = EntryOrigin.FUENTE, state = EntryState.ACTIVO, sourceRef = ref, sourceId = sourceId, spoilerLevel = 1, related = listOf(name),
            ),
        )
        return out
    }

    /** Sección de un listado de personajes → ficha mínima (introducción de la sección). */
    fun fromListSection(name: String, aliases: List<String>, actor: String, body: String, sourceRef: String, sourceId: Long?): DraftEntry? {
        val clean = UntrustedText.sanitize(body, WorldLimits.MAX_SOURCE_CHARS)
        if (clean.length < 30) return null
        return DraftEntry(
            type = EntryType.PERSONAJE, name = UntrustedText.oneLine(name, WorldLimits.NAME), aliases = aliases.map { UntrustedText.oneLine(it, 60) }.filter { it.isNotBlank() }.take(8),
            summary = WikiExtractor.excerpt(clean, WorldLimits.SUMMARY), details = if (actor.isNotBlank()) "$L_ACTOR: ${UntrustedText.oneLine(actor, 60)}" else "",
            confidence = Confidence.CONFIRMADO, origin = EntryOrigin.FUENTE, state = EntryState.ACTIVO,
            evidence = WikiExtractor.excerpt(clean, WorldLimits.EVIDENCE), sourceRef = sourceRef.take(WorldLimits.SOURCE_REF), sourceId = sourceId, spoilerLevel = 0,
        )
    }

    /** Sección de [pageText] cuyo título coincide con [name] o un alias. */
    fun findSection(pageText: String, name: String, aliases: List<String>): String? {
        val keys = (listOf(name) + aliases).map { TextNorm.fold(it).trim() }.filter { it.isNotEmpty() }
        return SourceText.sections(pageText).firstOrNull { TextNorm.fold(it.first.substringBefore('(')).trim() in keys && it.second.length >= 30 }?.second
    }

    /** Une líneas «Etiqueta: texto» sin cortar ninguna a medias: las que no caben se omiten enteras. */
    private fun joinKeepLines(lines: List<String>, max: Int): String {
        val sb = StringBuilder()
        for (l in lines) { if (sb.length + l.length + 1 > max) continue; if (sb.isNotEmpty()) sb.append('\n'); sb.append(l) }
        return sb.toString()
    }

    /** «Apariencia: …\nPersonalidad: …» → mapa etiqueta → texto. */
    fun parseDetails(details: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (line in details.lines()) {
            val i = line.indexOf(':')
            if (i <= 0) continue
            val label = line.substring(0, i).trim()
            if (label in LABELS) out[label] = line.substring(i + 1).trim()
        }
        return out
    }
}
