package com.jullai.local.data

/** Valores iniciales de una conversación nueva (salen de los Ajustes). */
data class ConversationDefaults(
    val systemPrompt: String = "",
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val maxTokens: Int = 512,
    val contextLength: Int = 2048,
)

/** Ajustes globales de la app. Los valores por defecto de conversación solo afectan a conversaciones NUEVAS. */
data class AppSettings(
    val threads: Int = 4,
    val defaultSystemPrompt: String = "Eres un asistente útil. Respondes en el idioma del usuario, con claridad y sin inventar datos.",
    val defaultTemperature: Float = 0.7f,
    val defaultTopP: Float = 0.9f,
    val defaultMaxTokens: Int = 512,
    val defaultContext: Int = 2048,
    val reuseKvCache: Boolean = true,
    // --- Roleplay (v0.3) ---
    val rpSystemPrompt: String = DEFAULT_RP_SYSTEM,
    val rpNarrativeRules: String = DEFAULT_RP_RULES,
    val rpContext: Int = 4096,
    val rpMaxTokens: Int = 384,
    val rpTemperature: Float = 0.85f,
    val rpTopP: Float = 0.92f,
    val rpStopOnUserTurn: Boolean = true,
    val rpLastUserName: String = "Viajero",
    // --- Memoria narrativa y perfil del jugador (v0.4) ---
    val memEnabled: Boolean = true,
    /** MANUAL | CADA_N | CAPITULO (ver AutoMode). Por defecto SOLO a petición: no hay una segunda inferencia en cada turno. */
    val memAutoMode: String = "MANUAL",
    val memEveryTurns: Int = 12,
    val novelOnClose: Boolean = false,
    /** Perfil global reutilizable del jugador: cada partida guarda su propia copia independiente. */
    val playerProfileName: String = "",
    val playerProfilePersona: String = "",
) {
    fun conversationDefaults() = ConversationDefaults(
        systemPrompt = defaultSystemPrompt,
        temperature = defaultTemperature,
        topP = defaultTopP,
        maxTokens = defaultMaxTokens,
        contextLength = defaultContext,
    )

    fun toMap(): Map<String, String> = mapOf(
        K_THREADS to threads.toString(),
        K_SYSTEM to defaultSystemPrompt,
        K_TEMP to defaultTemperature.toString(),
        K_TOPP to defaultTopP.toString(),
        K_MAXTOK to defaultMaxTokens.toString(),
        K_CTX to defaultContext.toString(),
        K_KV to reuseKvCache.toString(),
        K_RP_SYSTEM to rpSystemPrompt,
        K_RP_RULES to rpNarrativeRules,
        K_RP_CTX to rpContext.toString(),
        K_RP_MAXTOK to rpMaxTokens.toString(),
        K_RP_TEMP to rpTemperature.toString(),
        K_RP_TOPP to rpTopP.toString(),
        K_RP_STOP to rpStopOnUserTurn.toString(),
        K_RP_USER to rpLastUserName,
        K_MEM_ENABLED to memEnabled.toString(),
        K_MEM_AUTO to memAutoMode,
        K_MEM_EVERY to memEveryTurns.toString(),
        K_NOVEL_CLOSE to novelOnClose.toString(),
        K_PROFILE_NAME to playerProfileName,
        K_PROFILE_PERSONA to playerProfilePersona,
    )

    companion object {
        const val K_THREADS = "threads"
        const val K_SYSTEM = "default_system_prompt"
        const val K_TEMP = "default_temperature"
        const val K_TOPP = "default_top_p"
        const val K_MAXTOK = "default_max_tokens"
        const val K_CTX = "default_context"
        const val K_KV = "reuse_kv_cache"
        const val K_RP_SYSTEM = "rp_system_prompt"
        const val K_RP_RULES = "rp_narrative_rules"
        const val K_RP_CTX = "rp_context"
        const val K_RP_MAXTOK = "rp_max_tokens"
        const val K_RP_TEMP = "rp_temperature"
        const val K_RP_TOPP = "rp_top_p"
        const val K_RP_STOP = "rp_stop_on_user_turn"
        const val K_RP_USER = "rp_last_user_name"
        const val K_MEM_ENABLED = "mem_enabled"
        const val K_MEM_AUTO = "mem_auto_mode"
        const val K_MEM_EVERY = "mem_every_turns"
        const val K_NOVEL_CLOSE = "novel_on_close"
        const val K_PROFILE_NAME = "profile_name"
        const val K_PROFILE_PERSONA = "profile_persona"

        const val DEFAULT_RP_SYSTEM =
            "Eres el narrador y el intérprete de {{char}} en una ficción interactiva con {{user}}. Interpretas a {{char}} y a los " +
                "personajes secundarios que aparezcan, pero nunca hablas, piensas ni decides por {{user}}. Mantén la personalidad, la forma de " +
                "hablar y los conocimientos de cada personaje. Escribe en el idioma de {{user}}. Las acciones van entre *asteriscos*. " +
                "Avanza la escena con detalles concretos y deja a {{user}} espacio para responder."
        const val DEFAULT_RP_RULES =
            "- No escribas acciones, pensamientos ni diálogos de {{user}}.\n" +
                "- Un personaje solo sabe lo que ha visto, oído o se le ha contado; no trates un secreto como si todos lo conocieran.\n" +
                "- Respeta los hechos ya ocurridos en la historia; no los contradigas.\n" +
                "- Si no sabes algo del mundo, improvisa de forma coherente sin presentarlo como canon."

        fun fromMap(m: Map<String, String>): AppSettings {
            val d = AppSettings()
            return AppSettings(
                threads = m[K_THREADS]?.toIntOrNull()?.coerceIn(1, 8) ?: d.threads,
                defaultSystemPrompt = m[K_SYSTEM] ?: d.defaultSystemPrompt,
                defaultTemperature = m[K_TEMP]?.toFloatOrNull()?.coerceIn(0f, 2f) ?: d.defaultTemperature,
                defaultTopP = m[K_TOPP]?.toFloatOrNull()?.coerceIn(0.1f, 1f) ?: d.defaultTopP,
                defaultMaxTokens = m[K_MAXTOK]?.toIntOrNull()?.coerceIn(16, 2048) ?: d.defaultMaxTokens,
                defaultContext = m[K_CTX]?.toIntOrNull()?.coerceIn(512, 8192) ?: d.defaultContext,
                reuseKvCache = m[K_KV]?.toBooleanStrictOrNull() ?: d.reuseKvCache,
                rpSystemPrompt = m[K_RP_SYSTEM] ?: d.rpSystemPrompt,
                rpNarrativeRules = m[K_RP_RULES] ?: d.rpNarrativeRules,
                rpContext = m[K_RP_CTX]?.toIntOrNull()?.coerceIn(512, 8192) ?: d.rpContext,
                rpMaxTokens = m[K_RP_MAXTOK]?.toIntOrNull()?.coerceIn(16, 2048) ?: d.rpMaxTokens,
                rpTemperature = m[K_RP_TEMP]?.toFloatOrNull()?.coerceIn(0f, 2f) ?: d.rpTemperature,
                rpTopP = m[K_RP_TOPP]?.toFloatOrNull()?.coerceIn(0.1f, 1f) ?: d.rpTopP,
                rpStopOnUserTurn = m[K_RP_STOP]?.toBooleanStrictOrNull() ?: d.rpStopOnUserTurn,
                rpLastUserName = m[K_RP_USER]?.takeIf { it.isNotBlank() }?.take(40) ?: d.rpLastUserName,
                memEnabled = m[K_MEM_ENABLED]?.toBooleanStrictOrNull() ?: d.memEnabled,
                memAutoMode = m[K_MEM_AUTO]?.takeIf { it in listOf("MANUAL", "CADA_N", "CAPITULO") } ?: d.memAutoMode,
                memEveryTurns = m[K_MEM_EVERY]?.toIntOrNull()?.coerceIn(3, 60) ?: d.memEveryTurns,
                novelOnClose = m[K_NOVEL_CLOSE]?.toBooleanStrictOrNull() ?: d.novelOnClose,
                playerProfileName = m[K_PROFILE_NAME]?.take(40) ?: d.playerProfileName,
                playerProfilePersona = m[K_PROFILE_PERSONA]?.take(4000) ?: d.playerProfilePersona,
            )
        }
    }
}
