package com.jullai.local.story

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Versión legible de la partida («biblia»). Es SOLO LECTURA: al importar un .jullai este archivo no se procesa. */
object BibleMarkdown {
    private fun date(ms: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms)) + " UTC"

    fun render(b: Bible): String = buildString {
        val c = b.character
        val s = b.session
        append("# ").append(s.title).append("\n\n")
        append("> Biblia de la partida exportada por JullAI Local ").append(b.manifest.appVersion).append(" el ").append(date(b.manifest.exportedAt)).append(".\n")
        append("> **Este archivo es solo de lectura.** Si lo editas, los cambios NO se importan: la importación solo usa los archivos de `data/`.\n")
        append("> Las notas privadas del creador no aparecen aquí (sí están en `data/personaje.json`, que es tu copia).\n\n")

        append("## Personaje: ").append(c.name).append("\n\n")
        if (c.aliases.isNotEmpty()) append("**También conocido como:** ").append(c.aliases.joinToString(", ")).append("\n\n")
        fun field(label: String, v: String) { if (v.isNotBlank()) append("**").append(label).append(":** ").append(v.trim()).append("\n\n") }
        field("Descripción", c.appearance); field("Personalidad", c.personality); field("Forma de hablar", c.speechStyle)
        field("Historia", c.history); field("Motivaciones", c.motivations); field("Gustos y aversiones", c.likesDislikes)
        field("Relación inicial", c.initialRelationship)

        append("## Escena\n\n")
        append("**Tu nombre en la historia:** ").append(s.userName).append("\n\n")
        field("Tu personaje", s.userPersona); field("Escenario", s.scenarioText); field("Reglas narrativas", s.narrativeRules)

        append("## Resumen actual\n\n").append(s.summary.ifBlank { "(sin resumen)" }.trim()).append("\n\n")

        val pinned = b.memories.filter { it.state == ItemState.ACTIVO && it.pinned }
        val active = b.memories.filter { it.state == ItemState.ACTIVO && !it.pinned }
        append("## Recuerdos permanentes\n\n")
        if (pinned.isEmpty() && active.isEmpty()) append("(ninguno)\n\n")
        for (m in pinned + active.sortedByDescending { it.importance }) {
            append("- ").append(if (m.pinned) "📌 " else "").append(m.content.trim().replace('\n', ' '))
            val extra = listOfNotNull(m.narrativeDate.ifBlank { null }, "importancia ${m.importance}/5", Verification.label(m.verification))
            append(" _(").append(extra.joinToString(" · ")).append(")_\n")
        }
        append('\n')
        val pending = b.memories.filter { it.state == ItemState.PROPUESTO }
        if (pending.isNotEmpty()) {
            append("### Propuestas pendientes de revisar\n\n")
            pending.forEach { append("- ").append(it.content.trim().replace('\n', ' ')).append(" _(").append(Verification.label(it.verification)).append(")_\n") }
            append('\n')
        }

        append("## Cronología\n\n")
        val tl = b.timeline.filter { it.state == ItemState.ACTIVO }.sortedBy { it.orderKey }
        if (tl.isEmpty()) append("(vacía)\n\n")
        tl.forEach { append("- ").append(if (it.narrativeDate.isNotBlank()) "**${it.narrativeDate}** — " else "").append(it.text.trim().replace('\n', ' ')).append('\n') }
        if (tl.isNotEmpty()) append('\n')

        append("## Relaciones\n\n")
        if (b.relationships.isEmpty()) append("(ninguna registrada)\n\n")
        for (r in b.relationships) {
            append("### ").append(r.a).append(" → ").append(r.b).append("\n\n")
            append("| Dimensión | Valor (1-100) |\n|---|---|\n")
            append("| Confianza | ").append(r.trust).append(" |\n| Afecto | ").append(r.affection).append(" |\n")
            append("| Respeto | ").append(r.respect).append(" |\n| Interés romántico | ").append(r.romantic).append(" |\n\n")
            if (r.status.isNotBlank()) append("Situación: ").append(r.status).append("\n\n")
            val hist = b.relEvents.filter { it.srcRelationshipId == r.srcId && it.state == EventState.APLICADO }.sortedBy { it.createdAt }.takeLast(10)
            if (hist.isNotEmpty()) {
                append("Últimos cambios:\n\n")
                hist.forEach { e ->
                    val ch = listOf("confianza" to e.dTrust, "afecto" to e.dAffection, "respeto" to e.dRespect, "romántico" to e.dRomantic)
                        .filter { it.second != 0 }.joinToString(", ") { "${it.first} ${if (it.second > 0) "+" else ""}${it.second}" }
                    append("- ").append(date(e.createdAt)).append(": ").append(ch).append(" — ").append(e.reason.trim()).append(" _(").append(e.origin.lowercase()).append(")_\n")
                }
                append('\n')
            }
        }

        if (b.volumes.isNotEmpty() || b.chapters.isNotEmpty()) {
            append("## Volúmenes y capítulos\n\n")
            for (v in b.volumes.sortedBy { it.number }) {
                append("### Volumen ").append(v.number).append(if (v.title.isNotBlank()) ": ${v.title}" else "").append(" (").append(v.state.lowercase()).append(")\n\n")
                if (v.continuitySummary.isNotBlank()) append("**Resumen de continuidad**\n\n").append(v.continuitySummary.trim()).append("\n\n")
                for (ch in b.chapters.filter { it.srcVolumeId == v.srcId }.sortedBy { it.number }) {
                    append("#### Capítulo ").append(ch.number).append(if (ch.title.isNotBlank()) ": ${ch.title}" else "").append(" (").append(ch.state.lowercase()).append(")\n\n")
                    if (ch.summary.isNotBlank()) append("_Resumen:_ ").append(ch.summary.trim()).append("\n\n")
                    if (ch.novelText.isNotBlank()) append(ch.novelText.trim()).append("\n\n")
                }
            }
        }

        if (b.knowledge.isNotEmpty()) {
            append("## Conocimiento de la historia (¡contiene secretos!)\n\n")
            b.knowledge.groupBy { it.scope }.forEach { (scope, items) ->
                append("**").append(scope).append("**\n\n")
                items.forEach { append("- ").append(it.text.trim().replace('\n', ' ')).append('\n') }
                append('\n')
            }
        }
        append("---\nMensajes: ").append(b.messages.size).append(" (registro completo en `data/mensajes.json`). Los modelos GGUF nunca se incluyen en este archivo.\n")
    }
}
