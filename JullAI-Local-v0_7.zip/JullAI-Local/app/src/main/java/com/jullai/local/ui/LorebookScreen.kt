package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.data.LoreEntryEntity
import com.jullai.local.roleplay.CharactersViewModel

/** Editor de un lorebook: datos generales y entradas con palabras clave. */
@Composable
fun LorebookScreen(vm: CharactersViewModel, bookId: Long, onBack: () -> Unit) {
    LaunchedEffect(bookId) { vm.showLorebook(bookId) }
    val book by vm.currentBook.collectAsState()
    val entries by vm.currentEntries.collectAsState()
    val message by vm.message.collectAsState()
    var editing by remember { mutableStateOf<LoreEntryEntity?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Lorebook", onBack)
        val b = book
        if (b == null) {
            BasicText("Cargando…", style = Type.Nota, modifier = Modifier.padding(20.dp))
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
                var name by remember(b.id) { mutableStateOf(b.name) }
                var desc by remember(b.id) { mutableStateOf(b.description) }
                var depth by remember(b.id) { mutableStateOf(b.scanDepth) }
                LabeledField("Nombre", name, { name = it }, minHeight = 24)
                LabeledField("Descripción", desc, { desc = it }, minHeight = 24)
                Stepper("Mensajes que se revisan", "$depth", { depth = (depth - 1).coerceAtLeast(1) }, { depth = (depth + 1).coerceAtMost(50) })
                BasicText(
                    "En cada respuesta se buscan las claves en los últimos $depth mensajes. Se compara como texto (sin distinguir mayúsculas " +
                        "ni tildes; no hay expresiones regulares). Solo las entradas activadas viajan al modelo, nunca el lorebook completo.",
                    style = Type.Nota,
                )
                Box(Modifier.padding(top = 8.dp)) {
                    InkButton("Guardar datos", { vm.saveBookInfo(b.id, name, desc, depth) }, enabled = name != b.name || desc != b.description || depth != b.scanDepth)
                }

                SectionTitle("Entradas (${entries.size})")
                Box(Modifier.padding(bottom = 6.dp)) {
                    InkButton("Nueva entrada", { editing = LoreEntryEntity(lorebookId = b.id, insertionOrder = (entries.maxOfOrNull { it.insertionOrder } ?: 90) + 10) })
                }
                entries.forEach { e ->
                    Column(Modifier.padding(vertical = 5.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(8.dp)).padding(12.dp)) {
                        val title = e.name.ifBlank { e.keys.lineSequence().firstOrNull { it.isNotBlank() } ?: "(entrada sin nombre)" }
                        BasicText(title + if (!e.enabled) "  · desactivada" else "", style = Type.Cuerpo.copy(color = if (e.enabled) Ink.Oro else Ink.MarfilTenue))
                        BasicText(
                            (if (e.constant) "Siempre activa" else "Claves: " + e.keys.lines().filter { it.isNotBlank() }.joinToString(", ")) + " · prioridad ${e.priority}",
                            style = Type.Nota, maxLines = 2,
                        )
                        BasicText(e.content.take(160) + if (e.content.length > 160) "…" else "", style = Type.Nota, maxLines = 3, modifier = Modifier.padding(top = 2.dp))
                        Row {
                            InkLink("Editar", { editing = e })
                            InkLink("Eliminar", { vm.deleteEntry(e.id) }, danger = true)
                        }
                    }
                }
                Box(Modifier.padding(bottom = 40.dp))
            }
        }
    }

    editing?.let { e -> EntryDialog(e, onSave = { vm.saveEntry(it); editing = null }, onDismiss = { editing = null }) }
    message?.let { m ->
        InkDialog("Aviso", { vm.dismissMessage() }) {
            BasicText(m, style = Type.Cuerpo)
            Box(Modifier.padding(top = 14.dp)) { InkButton("Aceptar", { vm.dismissMessage() }) }
        }
    }
}

@Composable
private fun EntryDialog(initial: LoreEntryEntity, onSave: (LoreEntryEntity) -> Unit, onDismiss: () -> Unit) {
    var e by remember { mutableStateOf(initial) }
    InkDialog(if (initial.id == 0L) "Nueva entrada" else "Editar entrada", onDismiss) {
        Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
            LabeledField("Nombre (solo para ti)", e.name, { e = e.copy(name = it) }, minHeight = 24)
            LabeledField("Claves", e.keys, { e = e.copy(keys = it) }, hint = "Una por línea. La entrada se activa si aparece cualquiera.", minHeight = 44)
            LabeledField("Claves secundarias", e.secondaryKeys, { e = e.copy(secondaryKeys = it) }, hint = "Solo si «Exigir secundaria» está activado.", minHeight = 24)
            LabeledField("Contenido", e.content, { e = e.copy(content = it) }, hint = "Lo que el modelo debe saber cuando se active.", minHeight = 80, maxHeight = 260)
            Stepper("Prioridad (mayor se conserva antes)", "${e.priority}", { e = e.copy(priority = (e.priority - 5).coerceAtLeast(-1000)) }, { e = e.copy(priority = (e.priority + 5).coerceAtMost(1000)) })
            Stepper("Orden de aparición", "${e.insertionOrder}", { e = e.copy(insertionOrder = (e.insertionOrder - 10).coerceAtLeast(-100000)) }, { e = e.copy(insertionOrder = (e.insertionOrder + 10).coerceAtMost(100000)) })
            InkToggleRow("Activada", e.enabled, { e = e.copy(enabled = it) })
            InkToggleRow("Siempre activa (sin claves)", e.constant, { e = e.copy(constant = it) })
            InkToggleRow("Exigir clave secundaria", e.selective, { e = e.copy(selective = it) })
            InkToggleRow("Distinguir mayúsculas y tildes", e.caseSensitive, { e = e.copy(caseSensitive = it) })
        }
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Guardar", { onSave(e) })
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}
