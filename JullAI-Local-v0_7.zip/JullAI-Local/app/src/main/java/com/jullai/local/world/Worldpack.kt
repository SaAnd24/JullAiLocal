package com.jullai.local.world

import com.jullai.local.roleplay.J
import com.jullai.local.roleplay.JArr
import com.jullai.local.roleplay.JBool
import com.jullai.local.roleplay.JNull
import com.jullai.local.roleplay.JNum
import com.jullai.local.roleplay.JObj
import com.jullai.local.roleplay.JStr
import com.jullai.local.roleplay.JsonException
import com.jullai.local.roleplay.MiniJson
import com.jullai.local.story.TextNorm
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/*
 * Formato «.worldpack» (v1): el MUNDO BASE (enciclopedia), no una partida. Una partida sigue exportándose como «.jullai».
 * ZIP con: manifest.json (obligatorio), world.json (obligatorio), lore.md, characters.json, locations.json, timeline.json,
 * entries.json (resto de tipos) y sources.json. Sin libros, guiones ni textos largos de terceros: datos estructurados,
 * referencias y resúmenes breves. Detalle en docs/FORMATO_WORLDPACK.md.
 */

class PackWorld(
    val uuid: String, val name: String, val description: String, val language: String, val setting: String, val era: String,
    val rules: String, val narrativeLimits: String, val spoilerLevel: String, val castMode: String, val continuityMode: String,
    val researchDepth: String, val preferredSources: String, val priorityCharacters: String, val priorityPlaces: String, val revision: Int,
)

class PackSource(
    val kind: String, val uri: String, val title: String, val status: String, val license: String, val provenance: String, val consultedAt: Long?,
)

class PackEntry(
    val type: String, val name: String, val aliases: List<String>, val summary: String, val details: String, val confidence: String,
    val origin: String, val sourceIndex: Int?, val sourceRef: String, val evidence: String, val factKey: String, val contradictionGroup: String,
    val related: List<String>, val spoilerLevel: Int, val eraTag: String, val state: String,
)

/** Ajustes de la partida respecto al mundo (solo viajan en la instantánea de un .jullai). */
class PackLink(val castMode: String, val continuityMode: String, val spoilerLevel: String, val startEra: String)

class WorldPack(
    val appVersion: String, val exportedAt: Long, val world: PackWorld, val entries: List<PackEntry>, val sources: List<PackSource>,
    val warnings: List<String> = emptyList(), val link: PackLink? = null,
)

class WorldpackException(message: String) : Exception(message)

/** Lectura SEGURA del contenedor ZIP: lista cerrada de nombres, sin rutas peligrosas, sin duplicados, tamaños contados al leer. */
object WorldpackSafety {
    class Limits(val maxEntries: Int = 16, val maxFileBytes: Int = 8 * 1024 * 1024, val maxTotalBytes: Long = 24L * 1024 * 1024)

    const val MANIFEST = "manifest.json"
    const val WORLD = "world.json"
    const val LORE = "lore.md"
    const val CHARACTERS = "characters.json"
    const val LOCATIONS = "locations.json"
    const val TIMELINE = "timeline.json"
    const val ENTRIES = "entries.json"
    const val SOURCES = "sources.json"
    val ALLOWED = listOf(MANIFEST, WORLD, LORE, CHARACTERS, LOCATIONS, TIMELINE, ENTRIES, SOURCES)
    val REQUIRED = listOf(MANIFEST, WORLD)

    fun checkName(raw: String): String {
        if (raw.isEmpty() || raw.length > 60) throw WorldpackException("El archivo contiene un nombre interno no válido.")
        if (raw.startsWith("/") || raw.contains('\\') || raw.contains(':') || raw.contains('\u0000') || raw.split('/').any { it == ".." || it == "." || it.isEmpty() })
            throw WorldpackException("El archivo contiene rutas no permitidas («$raw»). Se rechaza por seguridad (ZIP-slip).")
        if (raw !in ALLOWED) throw WorldpackException("El archivo contiene un elemento inesperado («$raw»). No parece un .worldpack de esta app.")
        return raw
    }

    fun read(input: InputStream, limits: Limits = Limits()): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        val seen = HashSet<String>()
        var total = 0L
        var entries = 0
        try {
            ZipInputStream(input).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) throw WorldpackException("El archivo contiene carpetas inesperadas («${e.name}»).")
                    if (++entries > limits.maxEntries) throw WorldpackException("El archivo contiene demasiados elementos (máximo ${limits.maxEntries}).")
                    val name = checkName(e.name)
                    if (!seen.add(name.lowercase())) throw WorldpackException("El archivo contiene el elemento «$name» repetido. Se rechaza por seguridad.")
                    val buf = ByteArrayOutputStream()
                    val chunk = ByteArray(16 * 1024)
                    var n = 0
                    while (true) {
                        val r = zin.read(chunk)
                        if (r < 0) break
                        n += r; total += r
                        if (n > limits.maxFileBytes) throw WorldpackException("El elemento «$name» es demasiado grande (límite ${limits.maxFileBytes / (1024 * 1024)} MB).")
                        if (total > limits.maxTotalBytes) throw WorldpackException("El archivo descomprimido es demasiado grande (límite ${limits.maxTotalBytes / (1024 * 1024)} MB).")
                        buf.write(chunk, 0, r)
                    }
                    out[name] = buf.toByteArray()
                }
            }
        } catch (e: WorldpackException) {
            throw e
        } catch (e: ZipException) {
            throw WorldpackException("El archivo no es un .worldpack válido o está dañado (${e.message}).")
        } catch (e: java.io.EOFException) {
            throw WorldpackException("El archivo está incompleto o dañado.")
        } catch (e: java.io.IOException) {
            throw WorldpackException("No se pudo leer el archivo (${e.message}).")
        }
        if (out.isEmpty()) throw WorldpackException("El archivo está vacío o no es un .worldpack.")
        return out
    }
}

object WorldpackCodec {
    const val FORMAT = "jullai-worldpack"
    const val FORMAT_VERSION = 1
    const val APP_VERSION = "0.5.0"

    // ===================== ESCRITURA =====================

    fun write(pack: WorldPack, out: OutputStream) {
        val files = encode(pack)
        ZipOutputStream(out).use { z ->
            z.setLevel(6)
            for ((name, bytes) in files) {
                val e = ZipEntry(name)
                e.time = pack.exportedAt
                z.putNextEntry(e); z.write(bytes); z.closeEntry()
            }
        }
    }

    fun encode(p: WorldPack): LinkedHashMap<String, ByteArray> {
        val files = LinkedHashMap<String, ByteArray>()
        val chars = p.entries.filter { it.type == EntryType.PERSONAJE || it.type == EntryType.ALIAS || it.type == EntryType.RELACION }
        val places = p.entries.filter { it.type == EntryType.LUGAR }
        val time = p.entries.filter { it.type == EntryType.ACONTECIMIENTO }
        val rest = p.entries.filter { it !in chars && it !in places && it !in time }
        files[WorldpackSafety.WORLD] = text(worldJson(p.world))
        files[WorldpackSafety.CHARACTERS] = text(obj("entradas" to arr(chars.map { entryJson(it) })))
        files[WorldpackSafety.LOCATIONS] = text(obj("entradas" to arr(places.map { entryJson(it) })))
        files[WorldpackSafety.TIMELINE] = text(obj("entradas" to arr(time.map { entryJson(it) })))
        files[WorldpackSafety.ENTRIES] = text(obj("entradas" to arr(rest.map { entryJson(it) })))
        files[WorldpackSafety.SOURCES] = text(obj("fuentes" to arr(p.sources.map { sourceJson(it) })))
        files[WorldpackSafety.LORE] = lore(p).toByteArray(Charsets.UTF_8)
        val manifest = obj(
            "format" to JStr(FORMAT), "formatVersion" to num(FORMAT_VERSION), "minReaderFormat" to num(1),
            "appVersion" to JStr(APP_VERSION), "exportedAt" to JNum(p.exportedAt.toDouble()), "title" to JStr(p.world.name),
            "worldUuid" to JStr(p.world.uuid), "worldRevision" to num(p.world.revision),
            "counts" to obj("entradas" to num(p.entries.size), "fuentes" to num(p.sources.size)),
            "files" to JObj(LinkedHashMap<String, J>().also { m -> for ((n, b) in files) m[n] = obj("bytes" to num(b.size), "sha256" to JStr(sha256(b))) }),
        )
        val result = LinkedHashMap<String, ByteArray>()
        result[WorldpackSafety.MANIFEST] = text(manifest)
        result.putAll(files)
        return result
    }

    /** Instantánea para incrustar en un .jullai (data/mundo.json): el mismo contenido en un único JSON. */
    fun encodeSnapshot(p: WorldPack): ByteArray = text(
        obj(
            "format" to JStr(FORMAT + "-snapshot"), "formatVersion" to num(FORMAT_VERSION), "exportedAt" to JNum(p.exportedAt.toDouble()),
            "world" to worldJson(p.world), "entradas" to arr(p.entries.map { entryJson(it) }), "fuentes" to arr(p.sources.map { sourceJson(it) }),
            "link" to (p.link?.let { obj("castMode" to JStr(it.castMode), "continuityMode" to JStr(it.continuityMode), "spoilerLevel" to JStr(it.spoilerLevel), "startEra" to JStr(it.startEra)) } ?: JNull),
        ),
    )

    // ===================== LECTURA =====================

    fun read(input: InputStream, limits: WorldpackSafety.Limits = WorldpackSafety.Limits()): WorldPack = decode(WorldpackSafety.read(input, limits))

    fun decode(files: Map<String, ByteArray>): WorldPack {
        for (r in WorldpackSafety.REQUIRED) if (r !in files) throw WorldpackException("Falta $r: no es un .worldpack completo.")
        val manifest = parse(files.getValue(WorldpackSafety.MANIFEST), WorldpackSafety.MANIFEST)
        val mr = Rd(manifest, "manifest.json")
        if (mr.str("format", 40, req = true) != FORMAT) throw WorldpackException("manifest.json: no es un archivo «$FORMAT».")
        val version = mr.int("formatVersion", 1, 10_000, null)
        val minReader = mr.int("minReaderFormat", 1, 10_000, version)
        if (minReader > FORMAT_VERSION) throw WorldpackException("Este archivo se creó con una versión más nueva de JullAI (formato $version). Actualiza la app para importarlo.")
        val declared = (manifest.fields["files"] as? JObj)?.fields ?: throw WorldpackException("manifest.json: falta «files».")
        for (name in files.keys) {
            if (name == WorldpackSafety.MANIFEST) continue
            val d = declared[name] as? JObj ?: throw WorldpackException("El archivo contiene «$name» que el manifiesto no declara.")
            val dr = Rd(d, "manifest.files.$name")
            val bytes = files.getValue(name)
            if (dr.int("bytes", 0, Int.MAX_VALUE, null) != bytes.size || dr.str("sha256", 64, req = true) != sha256(bytes))
                throw WorldpackException("«$name» no coincide con su suma de verificación: el archivo está dañado o fue modificado.")
        }
        for (name in declared.keys) if (name !in files) throw WorldpackException("Falta «$name», que declara el manifiesto: el archivo está incompleto.")

        val world = decodeWorld(Rd(parse(files.getValue(WorldpackSafety.WORLD), WorldpackSafety.WORLD), "world.json"))
        val warnings = ArrayList<String>()
        val sources = files[WorldpackSafety.SOURCES]?.let { b ->
            list(parse(b, WorldpackSafety.SOURCES), "fuentes", WorldLimits.MAX_SOURCES_PER_WORLD, "fuentes") { r -> decodeSource(r) }
        } ?: emptyList()
        val entries = ArrayList<PackEntry>()
        for (fname in listOf(WorldpackSafety.CHARACTERS, WorldpackSafety.LOCATIONS, WorldpackSafety.TIMELINE, WorldpackSafety.ENTRIES)) {
            val bytes = files[fname] ?: continue
            entries.addAll(list(parse(bytes, fname), "entradas", WorldLimits.MAX_ENTRIES_PER_WORLD, "entradas") { decodeEntry(it, sources.size) })
        }
        if (entries.size > WorldLimits.MAX_ENTRIES_PER_WORLD) throw WorldpackException("El archivo tiene demasiadas entradas (${entries.size}; máximo ${WorldLimits.MAX_ENTRIES_PER_WORLD}).")
        val keys = entries.map { Dedup.key(it.type, it.name, it.factKey, it.sourceIndex?.toString() ?: it.origin) }
        if (keys.toSet().size != keys.size) throw WorldpackException("El archivo tiene entradas duplicadas (mismo tipo, nombre, hecho y fuente).")
        val counts = (manifest.fields["counts"] as? JObj)?.fields.orEmpty()
        (counts["entradas"] as? JNum)?.let { if (it.v.toInt() != entries.size) throw WorldpackException("El número de entradas no coincide con el manifiesto (${entries.size} en lugar de ${it.v.toInt()}): el archivo está incompleto o fue modificado.") }
        (counts["fuentes"] as? JNum)?.let { if (it.v.toInt() != sources.size) throw WorldpackException("El número de fuentes no coincide con el manifiesto: el archivo está incompleto o fue modificado.") }
        return WorldPack(mr.str("appVersion", 40, def = "?"), mr.long("exportedAt", 0, Long.MAX_VALUE, 0), world, entries, sources, warnings)
    }

    fun decodeSnapshot(bytes: ByteArray): WorldPack {
        val root = parse(bytes, "data/mundo.json")
        val r = Rd(root, "mundo")
        if (r.str("format", 60, req = true) != FORMAT + "-snapshot") throw WorldpackException("data/mundo.json: formato no reconocido.")
        val v = r.int("formatVersion", 1, 10_000, null)
        if (v > FORMAT_VERSION) throw WorldpackException("La instantánea del mundo es de una versión más nueva de la app.")
        val world = decodeWorld(Rd(root.fields["world"] as? JObj ?: throw WorldpackException("data/mundo.json: falta «world»."), "mundo.world"))
        val sources = list(root, "fuentes", WorldLimits.MAX_SOURCES_PER_WORLD, "fuentes") { decodeSource(it) }
        val entries = list(root, "entradas", WorldLimits.MAX_ENTRIES_PER_WORLD, "entradas") { decodeEntry(it, sources.size) }
        val keys = entries.map { Dedup.key(it.type, it.name, it.factKey, it.sourceIndex?.toString() ?: it.origin) }
        if (keys.toSet().size != keys.size) throw WorldpackException("data/mundo.json: entradas duplicadas.")
        val link = (root.fields["link"] as? JObj)?.let { l ->
            val lr = Rd(l, "mundo.link")
            PackLink(
                lr.oneOf("castMode", CastMode.ALL.toSet(), world.castMode), lr.oneOf("continuityMode", Continuity.ALL.toSet(), world.continuityMode),
                lr.oneOf("spoilerLevel", SpoilerLevel.ALL.toSet(), world.spoilerLevel), lr.str("startEra", 200),
            )
        }
        return WorldPack(APP, r.long("exportedAt", 0, Long.MAX_VALUE, 0), world, entries, sources, link = link)
    }
    private const val APP = "snapshot"

    // ---------------- JSON ↔ modelos ----------------

    private fun worldJson(w: PackWorld) = obj(
        "uuid" to JStr(w.uuid), "name" to JStr(w.name), "description" to JStr(w.description), "language" to JStr(w.language), "setting" to JStr(w.setting),
        "era" to JStr(w.era), "rules" to JStr(w.rules), "narrativeLimits" to JStr(w.narrativeLimits), "spoilerLevel" to JStr(w.spoilerLevel),
        "castMode" to JStr(w.castMode), "continuityMode" to JStr(w.continuityMode), "researchDepth" to JStr(w.researchDepth),
        "preferredSources" to JStr(w.preferredSources), "priorityCharacters" to JStr(w.priorityCharacters), "priorityPlaces" to JStr(w.priorityPlaces),
        "revision" to num(w.revision),
    )

    private fun decodeWorld(r: Rd): PackWorld {
        val uuid = r.str("uuid", 64, req = true)
        if (!Regex("[A-Za-z0-9-]{8,64}").matches(uuid)) r.fail("«uuid» no válido.")
        return PackWorld(
            uuid, r.str("name", WorldLimits.NAME, req = true), r.str("description", WorldLimits.DESCRIPTION), r.str("language", 16, def = "es"),
            r.str("setting", 300), r.str("era", 200), r.str("rules", WorldLimits.RULES), r.str("narrativeLimits", WorldLimits.RULES),
            r.oneOf("spoilerLevel", SpoilerLevel.ALL.toSet(), SpoilerLevel.SIN), r.oneOf("castMode", CastMode.ALL.toSet(), CastMode.MIXTO),
            r.oneOf("continuityMode", Continuity.ALL.toSet(), Continuity.FLEXIBLE), r.oneOf("researchDepth", ResearchDepth.ALL.toSet(), ResearchDepth.BASICA),
            r.str("preferredSources", 600), r.str("priorityCharacters", 600), r.str("priorityPlaces", 600), r.int("revision", 1, 1_000_000, 1),
        )
    }

    private fun sourceJson(s: PackSource) = obj(
        "kind" to JStr(s.kind), "uri" to JStr(s.uri), "title" to JStr(s.title), "status" to JStr(s.status), "license" to JStr(s.license),
        "provenance" to JStr(s.provenance), "consultedAt" to (s.consultedAt?.let { JNum(it.toDouble()) } ?: JNull),
    )

    private fun decodeSource(r: Rd): PackSource {
        val uri = r.str("uri", 500, req = true)
        // Solo se conservan referencias http(s) o nombres de archivo: nunca esquemas como file:, javascript: o content:.
        if (uri.contains("://") && !uri.startsWith("https://") && !uri.startsWith("http://")) r.fail("«uri» con un esquema no permitido.")
        return PackSource(
            r.oneOf("kind", setOf(SourceKind.MEDIAWIKI, SourceKind.URL, SourceKind.ARCHIVO, SourceKind.MANUAL), SourceKind.URL), uri,
            r.str("title", 200), r.oneOf("status", setOf(SourceStatus.PENDIENTE, SourceStatus.PROCESADA, SourceStatus.FALLIDA, SourceStatus.NO_COMPATIBLE), SourceStatus.PENDIENTE),
            r.str("license", 200), r.str("provenance", 400), r.nullLong("consultedAt"),
        )
    }

    private fun entryJson(e: PackEntry) = obj(
        "type" to JStr(e.type), "name" to JStr(e.name), "aliases" to JArr(e.aliases.map { JStr(it) }), "summary" to JStr(e.summary), "details" to JStr(e.details),
        "confidence" to JStr(e.confidence), "origin" to JStr(e.origin), "sourceIndex" to (e.sourceIndex?.let { num(it) } ?: JNull), "sourceRef" to JStr(e.sourceRef),
        "evidence" to JStr(e.evidence), "factKey" to JStr(e.factKey), "contradictionGroup" to JStr(e.contradictionGroup),
        "related" to JArr(e.related.map { JStr(it) }), "spoilerLevel" to num(e.spoilerLevel), "eraTag" to JStr(e.eraTag), "state" to JStr(e.state),
    )

    private fun decodeEntry(r: Rd, sourceCount: Int): PackEntry {
        val idx = r.nullInt("sourceIndex", 0, Int.MAX_VALUE)
        if (idx != null && idx >= sourceCount) r.fail("«sourceIndex» apunta a una fuente que no existe.")
        val confidence = r.oneOf("confidence", Confidence.ALL.toSet(), Confidence.LIMITADA)
        return PackEntry(
            r.oneOf("type", EntryType.ALL.toSet(), EntryType.OTRO), r.str("name", WorldLimits.NAME, req = true),
            r.strList("aliases", 10, 80), r.str("summary", WorldLimits.SUMMARY), r.str("details", WorldLimits.DETAILS), confidence,
            r.oneOf("origin", EntryOrigin.ALL.toSet(), EntryOrigin.IMPORTADO), idx, r.str("sourceRef", WorldLimits.SOURCE_REF),
            r.str("evidence", WorldLimits.EVIDENCE), r.str("factKey", WorldLimits.FACT_KEY), r.str("contradictionGroup", 80),
            r.strList("related", 10, 80), r.int("spoilerLevel", 0, 3, 0), r.str("eraTag", 80),
            r.oneOf("state", setOf(EntryState.ACTIVO, EntryState.PROPUESTO), EntryState.ACTIVO),
        )
    }

    /** Resumen legible (lore.md). Es solo de lectura: al importar no se interpreta. */
    private fun lore(p: WorldPack): String = buildString {
        appendLine("# ${p.world.name}")
        if (p.world.description.isNotBlank()) appendLine("\n${p.world.description}")
        appendLine("\nIdioma: ${p.world.language} · Continuidad: ${Continuity.label(p.world.continuityMode)} · Spoilers: ${SpoilerLevel.label(p.world.spoilerLevel)}")
        if (p.world.rules.isNotBlank()) appendLine("\n## Reglas\n${p.world.rules}")
        for (t in EntryType.ALL) {
            val list = p.entries.filter { it.type == t }
            if (list.isEmpty()) continue
            appendLine("\n## ${EntryType.label(t)}")
            for (e in list.sortedBy { it.name.lowercase() }) appendLine("- **${e.name}** [${Confidence.label(e.confidence)}]: ${e.summary.replace('\n', ' ')}")
        }
        if (p.sources.isNotEmpty()) {
            appendLine("\n## Fuentes")
            p.sources.forEachIndexed { i, s -> appendLine("${i + 1}. ${s.title.ifBlank { s.uri }} — ${s.uri}${if (s.license.isNotBlank()) " (${s.license})" else ""}") }
        }
    }

    // ---------------- ayudas ----------------

    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    private fun text(j: J) = MiniJson.write(j, pretty = true).toByteArray(Charsets.UTF_8)
    private fun num(v: Int): J = JNum(v.toDouble())
    private fun arr(l: List<J>): J = JArr(l)
    private fun obj(vararg p: Pair<String, J>): JObj = JObj(linkedMapOf(*p))

    private fun parse(bytes: ByteArray, name: String): JObj {
        val s = try { String(bytes, Charsets.UTF_8) } catch (e: Exception) { throw WorldpackException("$name: no es texto UTF-8.") }
        val j = try { MiniJson.parse(s) } catch (e: JsonException) { throw WorldpackException("$name: ${e.message}") }
        return j as? JObj ?: throw WorldpackException("$name: se esperaba un objeto JSON.")
    }

    private fun <T> list(file: JObj, key: String, max: Int, what: String, f: (Rd) -> T): List<T> {
        val items = (file.fields[key] as? JArr)?.items ?: return emptyList()
        if (items.size > max) throw WorldpackException("El archivo tiene demasiadas $what (${items.size}; máximo $max).")
        return items.mapIndexed { i, it -> f(Rd(it as? JObj ?: throw WorldpackException("$key[$i]: se esperaba un objeto."), "$key[$i]")) }
    }

    /** Lector con validación: todo valor externo pasa por aquí. El texto se limpia con [UntrustedText]. */
    private class Rd(val o: JObj, val path: String) {
        fun fail(msg: String): Nothing = throw WorldpackException("$path: $msg")

        fun str(k: String, max: Int, req: Boolean = false, def: String = ""): String {
            val v = o.fields[k]
            if (v == null || v is JNull) { if (req) fail("falta «$k»."); return def }
            val s = (v as? JStr)?.v ?: fail("«$k» debe ser texto.")
            if (req && s.isBlank()) fail("«$k» está vacío.")
            return if (max >= 200) UntrustedText.sanitize(s, max) else UntrustedText.oneLine(s, max)
        }

        fun long(k: String, min: Long, max: Long, def: Long?): Long {
            val v = o.fields[k]
            if (v == null || v is JNull) return def ?: fail("falta «$k».")
            val d = (v as? JNum)?.v ?: fail("«$k» debe ser un número.")
            if (d.isNaN() || d < min || d > max) fail("«$k» fuera de rango.")
            return d.toLong()
        }

        fun int(k: String, min: Int, max: Int, def: Int?): Int = long(k, min.toLong(), max.toLong(), def?.toLong()).toInt()
        fun nullLong(k: String): Long? = if (o.fields[k] == null || o.fields[k] is JNull) null else long(k, 0, Long.MAX_VALUE, null)
        fun nullInt(k: String, min: Int, max: Int): Int? = if (o.fields[k] == null || o.fields[k] is JNull) null else int(k, min, max, null)

        fun strList(k: String, maxItems: Int, maxLen: Int): List<String> {
            val v = o.fields[k] ?: return emptyList()
            if (v is JNull) return emptyList()
            val items = (v as? JArr)?.items ?: fail("«$k» debe ser una lista.")
            if (items.size > maxItems) fail("«$k» tiene demasiados elementos.")
            return items.map { UntrustedText.oneLine((it as? JStr)?.v ?: fail("«$k» solo admite texto."), maxLen) }.filter { it.isNotBlank() }
        }

        fun oneOf(k: String, allowed: Set<String>, def: String): String {
            val v = o.fields[k]
            if (v == null || v is JNull) return def
            val s = (v as? JStr)?.v ?: fail("«$k» debe ser texto.")
            if (s !in allowed) fail("«$k» tiene un valor no permitido («${s.take(30)}»).")
            return s
        }
    }
}
