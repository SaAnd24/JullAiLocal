package com.jullai.local.story

/**
 * Constantes y modelos puros (sin Android ni Room) de la memoria narrativa de la v0.4.
 * Los textos de estas constantes se guardan tal cual en la base de datos y en los archivos .jullai: no se renombran.
 */

/** Nivel de confianza de un recuerdo. Una inferencia del modelo NUNCA pasa a «confirmado» sin que el usuario lo decida. */
object Verification {
    const val CONFIRMADO = "CONFIRMADO_POR_USUARIO"
    const val EXTRAIDO = "EXTRAIDO_AUTOMATICO"
    const val INFERIDO = "INFERIDO"
    val ALL = setOf(CONFIRMADO, EXTRAIDO, INFERIDO)

    fun label(v: String) = when (v) {
        CONFIRMADO -> "Confirmado por ti"
        EXTRAIDO -> "Extraído automáticamente"
        INFERIDO -> "Inferido por el modelo"
        else -> v
    }
}

/** Ciclo de vida de recuerdos y acontecimientos: solo «ACTIVO» llega al modelo. */
object ItemState {
    const val ACTIVO = "ACTIVO"
    const val PROPUESTO = "PROPUESTO"
    const val DESCARTADO = "DESCARTADO"
    val ALL = setOf(ACTIVO, PROPUESTO, DESCARTADO)
}

/** De dónde salió un recuerdo, acontecimiento o resumen (procedencia). */
object Origin {
    const val USUARIO = "USUARIO"
    const val EXTRACCION = "EXTRACCION"
    const val INFERENCIA = "INFERENCIA"
    const val MODELO = "MODELO"
    const val RESTAURADO = "RESTAURADO"
    const val CIERRE_VOLUMEN = "CIERRE_VOLUMEN"
    const val INICIAL = "INICIAL"
    val MEMORY = setOf(USUARIO, EXTRACCION, INFERENCIA)
    val TIMELINE = setOf(USUARIO, EXTRACCION, INFERENCIA)
    val SUMMARY = setOf(USUARIO, MODELO, RESTAURADO, CIERRE_VOLUMEN)
    val RELATION_EVENT = setOf(USUARIO, MODELO, INICIAL)
}

object EventState {
    const val PROPUESTO = "PROPUESTO"
    const val APLICADO = "APLICADO"
    const val RECHAZADO = "RECHAZADO"
    val ALL = setOf(PROPUESTO, APLICADO, RECHAZADO)
}

object ChapterState {
    const val ABIERTO = "ABIERTO"
    const val CERRADO = "CERRADO"
    val ALL = setOf(ABIERTO, CERRADO)
}

object VolumeState {
    const val ABIERTO = "ABIERTO"
    const val ARCHIVADO = "ARCHIVADO"
    val ALL = setOf(ABIERTO, ARCHIVADO)
}

object NovelState {
    const val NINGUNA = "NINGUNA"
    const val GENERADA = "GENERADA"
    const val EDITADA = "EDITADA"
    val ALL = setOf(NINGUNA, GENERADA, EDITADA)
}

/** Cuándo se ejecuta el mantenimiento (resumen + propuestas) con el modelo. Por defecto SOLO a petición. */
object AutoMode {
    const val MANUAL = "MANUAL"
    const val CADA_N = "CADA_N"
    const val CAPITULO = "CAPITULO"
    val ALL = listOf(MANUAL, CADA_N, CAPITULO)
    fun label(m: String) = when (m) {
        MANUAL -> "Solo cuando yo lo pida"
        CADA_N -> "Cada cierto número de turnos"
        CAPITULO -> "Al cerrar un capítulo"
        else -> m
    }
}

/** Límites de tamaño: protegen la base de datos, el contexto y los archivos importados. */
object StoryLimits {
    const val MEMORY_CHARS = 600
    const val NAME_CHARS = 60
    const val DATE_CHARS = 60
    const val TIMELINE_CHARS = 400
    const val SUMMARY_CHARS = 6000
    const val NOTE_CHARS = 300
    const val REASON_CHARS = 240
    const val TITLE_CHARS = 120
    const val NOVEL_CHARS = 200_000
    const val MAX_MEMORIES = 5000
    const val MAX_TIMELINE = 5000
    const val MAX_SUMMARIES = 500
    const val MAX_RELATIONSHIPS = 200
    const val MAX_RELATION_EVENTS = 20_000
    const val MAX_VOLUMES = 200
    const val MAX_CHAPTERS = 2000
    const val MAX_MESSAGES = 200_000
    const val MAX_KNOWLEDGE = 5000
    const val MAX_LORE_ENTRIES = 5000
    const val MAX_MESSAGE_CHARS = 200_000
}

// ---------------- Elementos puros usados por el recuperador y el constructor de contexto ----------------

data class MemoryItem(
    val id: Long,
    val content: String,
    val importance: Int,
    val narrativeDate: String = "",
    val pinned: Boolean = false,
    val related: List<String> = emptyList(),
    val verification: String = Verification.CONFIRMADO,
    val updatedAt: Long = 0,
)

data class TimelineItem(
    val id: Long,
    val text: String,
    val narrativeDate: String = "",
    val orderKey: Int = 0,
    val characters: List<String> = emptyList(),
)

data class RelationItem(
    val id: Long,
    val a: String,
    val b: String,
    val trust: Int,
    val affection: Int,
    val respect: Int,
    val romantic: Int,
    val status: String = "",
)
