package com.jullai.local

import android.app.Application
import android.content.ComponentCallbacks2
import com.jullai.local.data.AppDatabase
import com.jullai.local.data.ChatRepository
import com.jullai.local.data.ModelRegistry
import com.jullai.local.data.PortraitStore
import com.jullai.local.data.RoleplayRepository
import com.jullai.local.data.StoryRepository
import com.jullai.local.data.BibleService
import com.jullai.local.data.SourceStore
import com.jullai.local.data.WorldRepository
import com.jullai.local.research.AutoDiscovery
import com.jullai.local.research.MediaWikiProvider
import com.jullai.local.research.PoliteWikiClient
import com.jullai.local.research.PoliteHttp
import com.jullai.local.research.ResearchEngine
import com.jullai.local.research.ResearchManager
import com.jullai.local.research.UrlConnectionTransport
import com.jullai.local.research.UrlProvider
import com.jullai.local.roleplay.StoryJobs
import com.jullai.local.data.SettingsRepository
import com.jullai.local.engine.EngineController
import com.jullai.local.engine.LlamaEngine
import com.jullai.local.engine.ModelStore
import com.jullai.local.imaging.AndroidDeviceGate
import com.jullai.local.imaging.EngineTextSide
import com.jullai.local.imaging.ImageModelStore
import com.jullai.local.imaging.ImageQueue
import com.jullai.local.imaging.ImageRepository
import com.jullai.local.imaging.ImageSettingsStore
import com.jullai.local.imaging.ResourceCoordinator
import com.jullai.local.imaging.SdCppImageEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Objetos de vida larga (los comparten todas las pantallas). Viven mientras viva el proceso, de modo que
 * el modelo cargado se mantiene al cambiar de pantalla o al girar el teléfono.
 */
class AppContainer(val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val db: AppDatabase = AppDatabase.build(app)
    val registry = ModelRegistry(db)
    val chatRepository = ChatRepository(db)
    val roleplayRepository = RoleplayRepository(db)
    val storyRepository = StoryRepository(db)
    val bibleService = BibleService(db)
    val portraits = PortraitStore(app)
    // v0.5: mundos, fuentes e investigación (la red solo se usa si el usuario lanza una investigación)
    val sourceStore = SourceStore(java.io.File(app.filesDir, "world_sources"))
    val worldRepository = WorldRepository(db, sourceStore)
    private val http by lazy { PoliteHttp(UrlConnectionTransport()) }
    private val mediaWiki by lazy { MediaWikiProvider(http) }
    private val wikiClient by lazy { PoliteWikiClient(http) }
    val researchEngine by lazy {
        ResearchEngine(
            worldRepository, listOf(mediaWiki, UrlProvider(http)), mediaWiki,
            AutoDiscovery(wikiClient, saveImage = { bytes -> portraits.save(bytes) }),
        )
    }
    val researchManager by lazy { ResearchManager(app, this) }
    val settingsRepository = SettingsRepository(db, scope)

    val engine = LlamaEngine()
    val store = ModelStore(app, registry)
    val controller = EngineController(engine, store)
    // ---- v0.6: imágenes locales. Motor visual SEPARADO del de texto; un coordinador común arbitra la memoria ----
    val imageRepository = ImageRepository(db)
    val imageSettings = ImageSettingsStore(db, scope)
    val imageModels = ImageModelStore(app)
    val imageEngine = SdCppImageEngine(abi = android.os.Build.SUPPORTED_ABIS.firstOrNull().orEmpty())
    val deviceGate = AndroidDeviceGate(app) { level -> coordinator.onThermal(level) }
    val coordinator: ResourceCoordinator by lazy { ResourceCoordinator(imageEngine, EngineTextSide(controller), deviceGate) }
    val imageQueue: ImageQueue by lazy {
        ImageQueue(
            repo = imageRepository, coordinator = coordinator,
            engineInfo = { imageEngine.id to (runCatching { com.jullai.local.imaging.nativebridge.SdBridge.nativeVersion() }.getOrDefault("—")) },
            capabilities = { imageEngine.capabilities() }, settings = { imageSettings.settings.value },
            modelFile = { imageModels.file(it) },
            saveImage = { r -> portraits.saveRgb(r.rgb, r.width, r.height) },
            readReference = { f, w, h -> portraits.loadRgb(f, w, h) },
            assetFile = { id -> db.visualAssets().get(id)?.file },
            scope = scope,
        )
    }
    val storyJobs by lazy { StoryJobs(this) }
    /** Trabajo de memoria con el modelo (mantenimiento, novela...) en curso. Un envío del usuario lo cancela: el juego manda. */
    @Volatile var storyJob: Job? = null

    init {
        // El texto tiene prioridad: antes de cargarlo se detiene y libera el motor de imágenes (ver ResourceCoordinator.yieldToText).
        controller.beforeLoad = {
            if (!coordinator.yieldToText()) error("La generación de imagen sigue en curso y no se pudo detener a tiempo. Detenla en «Estudio de imágenes → Cola» y vuelve a intentarlo.")
        }
        deviceGate.start()
        scope.launch {
            // v0.6: tareas de imagen que estaban en curso vuelven a pendiente (se reintentan desde su principio; no se lanza nada solo).
            runCatching { imageQueue.onAppStart() }
            // Si el ajuste «ejecutar automáticamente» está activo, la cola arranca cuando el texto queda libre.
            engine.state.collect { st ->
                if ((st == com.jullai.local.engine.EngineState.READY || st == com.jullai.local.engine.EngineState.IDLE) && imageSettings.settings.value.autoRun && imageSettings.settings.value.enabled) {
                    if (runCatching { imageRepository.openCount() }.getOrDefault(0) > 0) imageQueue.kick()
                }
            }
        }
        scope.launch {
            // Respuestas que quedaron "generándose" por un cierre inesperado → "interrumpidas" (el texto se conserva).
            runCatching { chatRepository.markInterruptedOnStart() }
            runCatching { roleplayRepository.markInterruptedOnStart() }
            // v0.5: investigaciones que quedaron pendientes por una interrupción se vuelven a planificar (sin repetir lo ya procesado).
            runCatching { researchManager.resumePending() }
            // Registro de modelos del Hito 1 (registry.json) → Room, sin perder modelos ya importados.
            runCatching { registry.migrateLegacyRegistry(store.directory) }
        }
    }

    /** Presión de memoria del sistema: si la app ya no está en primer plano y no genera, se libera el modelo. */
    @Suppress("DEPRECATION")
    fun onTrimMemory(level: Int) {
        val critical = level == ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
        coordinator.onMemoryPressure(critical)
        if (critical) scope.launch { controller.unloadIfIdle() }
    }

    /** Al cerrar la app (la actividad termina de verdad): se detiene la generación y se liberan los recursos nativos. */
    fun releaseNative() {
        engine.cancel()
        coordinator.requestCancel("La app se cierra.", byUser = true)
        scope.launch { imageEngine.release() }
        scope.launch { controller.unload() }
    }
}
