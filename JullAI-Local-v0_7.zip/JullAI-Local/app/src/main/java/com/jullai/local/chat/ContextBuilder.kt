package com.jullai.local.chat

import com.jullai.local.engine.ChatMessage

/** El mensaje actual no cabe ni él solo en el contexto configurado. */
class ContextOverflowException(message: String) : Exception(message)

data class ContextResult(
    /** Mensajes finales (con el sistema primero si lo hay) que se envían a la plantilla del modelo. */
    val messages: List<ChatMessage>,
    /** Prompt ya con la plantilla del modelo aplicada. */
    val prompt: String,
    val promptTokens: Int,
    /** Cuántos mensajes antiguos del historial se dejaron fuera por falta de espacio. */
    val droppedMessages: Int,
)

/**
 * Constructor de contexto del chat general (v0.2): instrucciones del sistema + los mensajes más recientes que quepan,
 * reservando espacio para la respuesta. Si no caben todos se descartan los MÁS ANTIGUOS (todavía sin resumen).
 *
 * Es lógica pura: recibe funciones para contar tokens y aplicar la plantilla, así se puede probar sin el motor.
 */
object ContextBuilder {
    /** Coste aproximado de las marcas de plantilla por mensaje (rol, separadores). La verificación final usa el prompt real. */
    const val PER_MESSAGE_OVERHEAD = 12
    const val SAFETY_TOKENS = 32

    /** Tokens que se reservan para la respuesta: el máximo pedido, pero nunca más de la mitad del contexto. */
    fun responseReserve(contextLength: Int, maxResponseTokens: Int): Int =
        maxResponseTokens.coerceAtMost(contextLength / 2).coerceAtLeast(1)

    suspend fun build(
        systemPrompt: String,
        history: List<ChatMessage>,
        contextLength: Int,
        maxResponseTokens: Int,
        countTokens: suspend (String) -> Int,
        applyTemplate: suspend (List<ChatMessage>) -> String,
    ): ContextResult {
        require(history.isNotEmpty()) { "No hay mensajes que enviar." }
        val reserve = responseReserve(contextLength, maxResponseTokens)
        val limit = contextLength - reserve                    // máximo de tokens para el prompt
        val budget = limit - SAFETY_TOKENS
        if (budget <= 0) throw ContextOverflowException("El contexto es demasiado pequeño para la respuesta pedida. Aumenta el contexto o reduce los tokens de respuesta.")

        val system = systemPrompt.trim()
        val systemCost = if (system.isEmpty()) 0 else countTokens(system) + PER_MESSAGE_OVERHEAD

        // 1) Selección aproximada: de lo más reciente a lo más antiguo, mientras quepa.
        var used = systemCost
        var firstKept = history.size
        for (i in history.indices.reversed()) {
            val cost = countTokens(history[i].content) + PER_MESSAGE_OVERHEAD
            if (used + cost > budget && firstKept < history.size) break
            used += cost
            firstKept = i
        }
        firstKept = skipLeadingAssistant(history, firstKept)

        // 2) Verificación con el prompt REAL; si se pasa, se descarta el mensaje más antiguo y se repite.
        while (true) {
            val kept = history.subList(firstKept, history.size)
            val messages = buildList {
                if (system.isNotEmpty()) add(ChatMessage("system", system))
                addAll(kept)
            }
            val prompt = applyTemplate(messages)
            val tokens = countTokens(prompt)
            if (tokens <= limit) {
                return ContextResult(messages, prompt, tokens, firstKept)
            }
            if (kept.size <= 1) {
                throw ContextOverflowException(
                    "Tu mensaje ($tokens tokens con las instrucciones) no cabe en el contexto de $contextLength tokens " +
                        "reservando $reserve para la respuesta. Acórtalo o aumenta el contexto.",
                )
            }
            firstKept = skipLeadingAssistant(history, firstKept + 1)
            if (firstKept >= history.size) firstKept = history.size - 1
        }
    }

    /** La conversación enviada debe empezar por un mensaje del usuario (algunas plantillas fallan si no). */
    private fun skipLeadingAssistant(history: List<ChatMessage>, start: Int): Int {
        var i = start
        while (i < history.size - 1 && history[i].role == "assistant") i++
        return i
    }
}
