package com.jullai.local.roleplay

import java.text.Normalizer
import java.util.Locale

// ======================= Lorebook =======================

data class LoreEntry(
    val id: Long = 0,
    val name: String = "",
    val keys: List<String> = emptyList(),
    val secondaryKeys: List<String> = emptyList(),
    val content: String = "",
    val enabled: Boolean = true,
    val constant: Boolean = false,
    val selective: Boolean = false,
    val caseSensitive: Boolean = false,
    val priority: Int = 10,
    val insertionOrder: Int = 100,
)

/** Activación por palabras clave. Coincidencia por texto literal (sin regex). Sin distinguir mayúsculas ni tildes salvo que la entrada lo pida. */
object LoreMatcher {
    fun normalize(s: String, caseSensitive: Boolean): String {
        if (caseSensitive) return s
        val d = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return d.filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }
    }

    private fun anyKey(scanCs: String, scanCi: String, keys: List<String>, cs: Boolean): Boolean =
        keys.any { k ->
            val key = k.trim()
            key.isNotEmpty() && (if (cs) scanCs.contains(key) else scanCi.contains(normalize(key, false)))
        }

    /** Entradas activadas por [scanText] (los últimos mensajes de la escena). Las constantes siempre se activan. */
    fun activate(entries: List<LoreEntry>, scanText: String): List<LoreEntry> {
        val ci = normalize(scanText, false)
        return entries.filter { e ->
            when {
                !e.enabled || e.content.isBlank() -> false
                e.constant -> true
                e.keys.isEmpty() -> false
                !anyKey(scanText, ci, e.keys, e.caseSensitive) -> false
                e.selective && e.secondaryKeys.isNotEmpty() -> anyKey(scanText, ci, e.secondaryKeys, e.caseSensitive)
                else -> true
            }
        }
    }
}

// ======================= Conocimiento narrativo =======================

/** Separación del control narrativo: quién sabe qué. */
object KnowledgeScope {
    const val USER = "USUARIO_SABE"
    const val CHARACTER = "PERSONAJE_SABE"
    const val PUBLIC = "PUBLICO"
    const val SECRET = "SECRETO"
    const val FACT = "HECHO"
    const val INVENTION = "INVENCION"

    /** Orden de importancia cuando falta espacio (lo primero se conserva). */
    val PRIORITY = listOf(SECRET, FACT, INVENTION, CHARACTER, USER, PUBLIC)
    /** Orden de aparición en el prompt. */
    val DISPLAY = listOf(PUBLIC, USER, CHARACTER, SECRET, FACT, INVENTION)

    fun label(scope: String) = when (scope) {
        USER -> "Lo que {{user}} sabe"
        CHARACTER -> "Lo que {{char}} sabe"
        PUBLIC -> "Información pública (la sabe cualquiera en este mundo)"
        SECRET -> "Secretos (no los reveles ni los des por sabidos por otros personajes, salvo que la historia ya lo haya establecido)"
        FACT -> "Hechos ocurridos en esta partida (respétalos, no los contradigas)"
        INVENTION -> "Invenciones de esta historia alternativa (valen en esta partida; no son canon del universo)"
        else -> scope
    }

    fun shortLabel(scope: String) = when (scope) {
        USER -> "Lo sabe el usuario"
        CHARACTER -> "Lo sabe el personaje"
        PUBLIC -> "Público"
        SECRET -> "Secreto"
        FACT -> "Hecho de la partida"
        INVENTION -> "Invención"
        else -> scope
    }
}

data class KnowledgeItem(val scope: String, val text: String)

// ======================= Swipes (respuestas alternativas) =======================

object Swipes {
    const val MAX = 40

    fun parse(json: String): List<String> = try {
        (MiniJson.parse(json) as? JArr)?.items?.mapNotNull { (it as? JStr)?.v } ?: emptyList()
    } catch (e: JsonException) {
        emptyList()
    }

    fun toJson(items: List<String>): String = MiniJson.write(jstrList(items))

    /** Conjunto efectivo: el texto guardado en `content` manda sobre la posición activa (así un guardado parcial no se pierde). */
    fun effective(content: String, swipesJson: String, index: Int): Pair<List<String>, Int> {
        val items = parse(swipesJson).toMutableList()
        if (items.isEmpty()) return listOf(content) to 0
        val idx = index.coerceIn(0, items.size - 1)
        items[idx] = content
        return items to idx
    }

    /** Añade una alternativa vacía y la activa. Si se llega al máximo, se descarta la más antigua que no sea la activa. */
    fun withNew(items: List<String>, index: Int): Pair<List<String>, Int> {
        val list = items.toMutableList()
        if (list.size >= MAX) {
            val drop = if (index == 0) 1 else 0
            list.removeAt(drop)
        }
        list.add("")
        return list to list.size - 1
    }
}

// ======================= Texto de rol (*acciones*) =======================

data class RpSpan(val text: String, val italic: Boolean, val bold: Boolean = false)

object RpText {
    /** Parte el texto en tramos normales, *en cursiva* y **en negrita**. Un asterisco sin pareja se muestra tal cual. */
    fun spans(text: String): List<RpSpan> {
        val out = ArrayList<RpSpan>()
        var i = 0
        val sb = StringBuilder()
        fun flush() { if (sb.isNotEmpty()) { out.add(RpSpan(sb.toString(), false)); sb.clear() } }
        while (i < text.length) {
            val c = text[i]
            if (c == '*') {
                if (i + 1 < text.length && text[i + 1] == '*') {
                    val close = text.indexOf("**", i + 2)
                    if (close > i + 2 && !text.substring(i + 2, close).contains("\n\n")) {
                        flush(); out.add(RpSpan(text.substring(i + 2, close), false, bold = true)); i = close + 2; continue
                    }
                } else {
                    val close = text.indexOf('*', i + 1)
                    if (close > i + 1 && !text.substring(i + 1, close).contains("\n\n")) {
                        flush(); out.add(RpSpan(text.substring(i + 1, close), true)); i = close + 1; continue
                    }
                }
            }
            sb.append(c)
            i++
        }
        flush()
        return out
    }
}

// ======================= Corte si el modelo habla por el usuario =======================

/** Detecta que el modelo empezó a escribir un turno del usuario («\nNombre:») para cortar ahí. */
class UserTurnStop(userName: String) {
    private val markers = userName.trim().takeIf { it.isNotEmpty() }?.let { n -> listOf("\n$n:", "\n$n :", "\n**$n:**", "\n$n：") } ?: emptyList()

    /** Devuelve la posición donde cortar el texto, o -1. */
    fun cutIndex(text: String): Int {
        var best = -1
        for (m in markers) {
            val p = text.indexOf(m, ignoreCase = true)
            if (p >= 0 && (best < 0 || p < best)) best = p
        }
        return best
    }
}
