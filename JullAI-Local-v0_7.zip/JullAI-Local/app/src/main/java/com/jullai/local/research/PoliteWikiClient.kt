package com.jullai.local.research

import com.jullai.local.discovery.WikiClient
import com.jullai.local.discovery.WikiFetchException
import com.jullai.local.discovery.WikiHosts
import java.net.URI

/**
 * Cliente de la investigación automática sobre PoliteHttp (límite de ritmo por servidor, User-Agent propio, Retry-After, redirecciones validadas).
 * Solo habla con la lista cerrada de WikiHosts. Tras cualquier redirección se vuelve a comprobar que el destino sigue dentro de esa lista.
 */
class PoliteWikiClient(private val http: PoliteHttp) : WikiClient {
    override suspend fun api(api: String, query: String): String {
        if (!WikiHosts.isTrustedApi(api)) throw WikiFetchException("Servidor no permitido para la investigación automática.", false)
        val r = get("$api?$query", 1_500_000, "application/json")
        if (!trustedFinal(r.finalUrl)) throw WikiFetchException("La wiki redirigió a un servidor no permitido.", false)
        return String(r.body, Charsets.UTF_8)
    }

    override suspend fun fandomUrl(url: String): String {
        val u = try { URI(url) } catch (e: Exception) { throw WikiFetchException("Dirección no válida.", false) }
        if (u.scheme != "https" || u.userInfo != null || u.port != -1 || u.host?.lowercase()?.endsWith(".fandom.com") != true || u.path?.startsWith("/api/v1/") != true)
            throw WikiFetchException("Servidor no permitido para la investigación automática.", false)
        val r = get(url, 600_000, "application/json")
        if (r.finalUrl.let { f -> runCatching { URI(f).host?.lowercase()?.endsWith(".fandom.com") }.getOrNull() } != true) throw WikiFetchException("Redirección no permitida.", false)
        return String(r.body, Charsets.UTF_8)
    }

    override suspend fun bytes(url: String, maxBytes: Int): ByteArray {
        if (!WikiHosts.isTrustedImageUrl(url)) throw WikiFetchException("Servidor de imágenes no permitido.", false)
        val r = get(url, maxBytes + 1, "image/png,image/jpeg,image/webp;q=0.9,*/*;q=0.1")
        if (!WikiHosts.isTrustedImageUrl(r.finalUrl)) throw WikiFetchException("La imagen redirigió a un servidor no permitido.", false)
        if (r.truncated || r.body.size > maxBytes) throw WikiFetchException("La imagen es demasiado grande.", false)
        return r.body
    }

    private suspend fun get(url: String, max: Int, accept: String): HttpResponse = try {
        http.get(url, max, accept)
    } catch (e: HttpFailure) {
        throw WikiFetchException(e.message ?: "Error de red.", e.retryable)
    }

    private fun trustedFinal(finalUrl: String): Boolean {
        val base = finalUrl.substringBefore('?')
        return WikiHosts.isTrustedApi(base) || runCatching { URI(finalUrl).let { it.scheme == "https" && it.host?.lowercase()?.endsWith(".fandom.com") == true && it.path?.startsWith("/api/v1/") == true } }.getOrDefault(false)
    }
}
