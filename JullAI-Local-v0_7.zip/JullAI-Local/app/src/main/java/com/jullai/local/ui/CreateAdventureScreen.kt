package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.roleplay.CharactersViewModel
import com.jullai.local.roleplay.WorldViewModel
import com.jullai.local.world.CastMode
import com.jullai.local.world.Continuity
import com.jullai.local.world.EntryState
import com.jullai.local.world.EntryType
import com.jullai.local.world.ResearchDepth
import com.jullai.local.world.ResearchPhase
import com.jullai.local.world.SpoilerLevel
import com.jullai.local.world.TaskStatus

/**
 * «Crear aventura»: el usuario dice de qué obra quiere vivir una aventura y la app, por sí sola, identifica la obra, busca sus fuentes,
 * investiga el universo, guarda las imágenes de los personajes canónicos y prepara el reparto. Todo el progreso mostrado es REAL
 * (sale de la tarea de investigación guardada); nada se anuncia antes de que ocurra.
 */
@Composable
fun CreateAdventureScreen(
    worldVm: WorldViewModel,
    charactersVm: CharactersViewModel,
    hasModel: Boolean,
    defaultUserName: String,
    onOpenModels: () -> Unit,
    onOpenWorld: (Long) -> Unit,
    onBack: () -> Unit,
    onStarted: (Long) -> Unit,
) {
    var title by rememberSaveable { mutableStateOf("") }
    var cast by rememberSaveable { mutableStateOf(CastMode.MIXTO) }
    var continuity by rememberSaveable { mutableStateOf(Continuity.FLEXIBLE) }
    var depth by rememberSaveable { mutableStateOf(ResearchDepth.MEDIA) }
    var worldId by rememberSaveable { mutableStateOf(0L) }
    var picking by rememberSaveable { mutableStateOf(false) }
    var chosen by rememberSaveable { mutableStateOf("") }
    var userName by rememberSaveable { mutableStateOf(defaultUserName) }
    var scenario by rememberSaveable { mutableStateOf("") }
    val notice by worldVm.notice.collectAsState()

    val tasks by worldVm.tasks(worldId).collectAsState(emptyList())
    val entries by worldVm.entries(worldId).collectAsState(emptyList())
    val castList by worldVm.cast(worldId).collectAsState(emptyList())
    val images by worldVm.canonImages(worldId).collectAsState(emptyList())
    val identity by worldVm.identity(worldId).collectAsState(null)
    val world by worldVm.world(worldId).collectAsState(null)
    val task = tasks.maxByOrNull { it.id }
    val running = task != null && !TaskStatus.isFinal(task.status)
    val characterEntries = entries.count { it.type == EntryType.PERSONAJE && it.state == EntryState.ACTIVO && it.spoilerLevel == 0 }
    val savedImages = images.count { it.state == "OK" }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Crear aventura", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
            notice?.let {
                Column(Modifier.padding(top = 8.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(6.dp)).padding(12.dp)) {
                    BasicText(it, style = Type.Cuerpo.copy(color = Ink.Oro))
                    Box(Modifier.padding(top = 8.dp)) { InkButton("Cerrar", worldVm::dismissNotice, primary = false) }
                }
            }
            if (worldId == 0L) {
                SectionTitle("¿Qué universo quieres vivir?")
                BasicText("Escribe el nombre de una serie, película, libro, anime, cómic, videojuego o saga. La app buscará sola información pública sobre ella (Wikipedia, Wikidata y wikis de Fandom) y las imágenes de sus personajes.", style = Type.Cuerpo)
                LabeledField("Obra o universo", title, { title = it }, placeholder = "Ej.: The Walking Dead")
                BasicText("Tipo de aventura", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InkChip("Con personajes del canon", cast == CastMode.CANONICO, { cast = CastMode.CANONICO })
                    InkChip("Mixto", cast == CastMode.MIXTO, { cast = CastMode.MIXTO })
                }
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InkChip("Personajes originales", cast == CastMode.ORIGINAL, { cast = CastMode.ORIGINAL })
                }
                BasicText("Fidelidad al canon", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Continuity.ALL.forEach { InkChip(Continuity.label(it).substringBefore(" ("), continuity == it, { continuity = it }) } }
                BasicText(Continuity.rule(continuity), style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
                BasicText("Cuánto investigar", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { ResearchDepth.ALL.forEach { InkChip(ResearchDepth.label(it), depth == it, { depth = it }) } }
                BasicText("Más profundidad = más personajes y páginas, pero tarda más y usa más datos. Necesita internet SOLO para esto; después todo funciona sin conexión.", style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
                if (!hasModel) {
                    BasicText("Aún no tienes un modelo de texto. Puedes investigar igualmente, pero para jugar necesitarás uno.", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 10.dp))
                    InkLink("Ir a Modelos (descargar o importar)", onOpenModels)
                }
                Box(Modifier.padding(top = 14.dp)) {
                    InkButton("Buscar y preparar", { worldVm.createAdventureWorld(title.trim(), cast, continuity, depth) { worldId = it } }, enabled = title.trim().length >= 2)
                }
            } else {
                SectionTitle(world?.name ?: title)
                val ident = identity
                if (ident != null) {
                    BasicText("Identificada: ${ident.title}" + (if (ident.description.isNotBlank()) " — ${ident.description}" else ""), style = Type.Cuerpo)
                    if (ident.fandomSub.isNotBlank() || ident.fandomTitle.isNotBlank()) BasicText("Wiki de Fandom: ${ident.fandomSub.ifBlank { "encontrada" }}", style = Type.Nota)
                } else if (running) BasicText("Buscando la obra…", style = Type.Nota)

                Column(Modifier.padding(top = 10.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(6.dp)).padding(12.dp)) {
                    if (task == null) BasicText("Preparando la investigación…", style = Type.Cuerpo)
                    else {
                        BasicText("${TaskStatus.label(task.status)} · ${ResearchPhase.label(task.phase)}", style = Type.Cuerpo.copy(color = Ink.Oro))
                        if (task.progressTotal > 0) {
                            Box(Modifier.padding(top = 8.dp).fillMaxWidth().height(6.dp).background(Ink.Tinta, RoundedCornerShape(3.dp))) {
                                Box(Modifier.fillMaxWidth((task.progressDone.toFloat() / task.progressTotal).coerceIn(0f, 1f)).height(6.dp).background(Ink.Oro, RoundedCornerShape(3.dp)))
                            }
                        }
                        BasicText("Fuentes leídas: ${task.sourcesOk} · con error: ${task.sourcesFailed} · entradas nuevas: ${task.entriesCreated} · personajes: $characterEntries · imágenes guardadas: $savedImages", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
                        if (task.note.isNotBlank()) BasicText(task.note, style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
                        if (!running && task.lastError.isNotBlank() && task.status != TaskStatus.COMPLETADA) BasicText(task.lastError, style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 4.dp))
                    }
                }
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (running && task != null) InkButton("Cancelar", { worldVm.cancelResearch(task.id) }, primary = false)
                    if (!running && task != null && task.status != TaskStatus.COMPLETADA) InkButton("Reintentar / reanudar", { worldVm.startResearch(worldId) }, primary = false)
                    InkLink("Ver el universo", { onOpenWorld(worldId) })
                    if (savedImages > 0 && !running) InkLink("Borrar imágenes en caché", { worldVm.purgeCanonImages(worldId) }, danger = true)
                }
                if (task != null && !running && task.status == TaskStatus.SIN_RESULTADOS) {
                    BasicText("No se pudo obtener información útil. Comprueba el nombre, tu conexión o añade una wiki o texto a mano en la pantalla del universo.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
                }
                if (running) BasicText("Puedes salir de esta pantalla: la investigación sigue en segundo plano y se reanuda si Android la interrumpe. Con poca batería o sin red Android puede retrasarla.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))

                if (characterEntries >= 1 && !picking) {
                    Box(Modifier.padding(top = 14.dp)) {
                        InkButton(if (running) "Elegir personaje con lo encontrado hasta ahora" else "Elegir personaje", { worldVm.castFromWorld(worldId) { picking = true } })
                    }
                }
                if (picking) {
                    SectionTitle("Tu personaje")
                    if (castList.isEmpty()) BasicText("Creando personajes…", style = Type.Nota)
                    castList.forEach { c ->
                        Row(
                            Modifier.padding(top = 8.dp).fillMaxWidth().background(if (chosen == c.name) Ink.Pizarra else Ink.Tinta, RoundedCornerShape(6.dp)).clickable { chosen = c.name }.padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            PortraitImage(worldVm.portraitStore, c.portraitFile, c.name, Modifier.size(56.dp))
                            Column(Modifier.weight(1f)) {
                                BasicText(c.name, style = Type.Cuerpo.copy(color = if (chosen == c.name) Ink.Oro else Ink.Marfil))
                                BasicText(c.appearance.ifBlank { c.history }.take(110), style = Type.Nota)
                            }
                        }
                    }
                    LabeledField("Tu nombre", userName, { userName = it })
                    LabeledField("Escena inicial (opcional)", scenario, { scenario = it }, minHeight = 60, hint = "Si lo dejas vacío, la historia empieza con lo que dice el universo.")
                    val pick = castList.firstOrNull { it.name == chosen }
                    Box(Modifier.padding(top = 14.dp)) {
                        InkButton("Empezar aventura", {
                            val w = world
                            if (pick != null && w != null) charactersVm.startSession(pick, scenario, userName.ifBlank { "Viajero" }, "", null) { sid ->
                                worldVm.bindSession(sid, w, w.castMode, w.continuityMode, SpoilerLevel.SIN, "")
                                onStarted(sid)
                            }
                        }, enabled = pick != null && world != null)
                    }
                    if (!hasModel) BasicText("Sin modelo de texto no se puede generar la historia. Descarga o importa uno en Modelos.", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 6.dp))
                }
            }
            Box(Modifier.height(32.dp))
        }
    }
}
