package com.jullai.local.story

/**
 * Modelo puro de una partida portátil «.jullai». Los identificadores `src*` son los del dispositivo que exportó y SOLO sirven
 * para relacionar elementos dentro del archivo: al importar se generan identificadores nuevos (nunca se pisa nada existente).
 */

data class BibleAssetRef(val id: String, val path: String, val kind: String, val bytes: Int, val sha256: String)

data class BibleManifest(
    val format: String = FORMAT,
    val formatVersion: Int = FORMAT_VERSION,
    /** Versión más antigua de la app que puede leer este archivo sin perder datos. */
    val minReaderFormat: Int = 1,
    val appVersion: String,
    val exportedAt: Long,
    val title: String,
    val counts: Map<String, Int>,
    val assets: List<BibleAssetRef>,
) {
    companion object {
        const val FORMAT = "jullai-biblia"
        const val FORMAT_VERSION = 1
    }
}

data class BLoreEntry(
    val name: String, val keys: List<String>, val secondaryKeys: List<String>, val content: String, val enabled: Boolean,
    val constant: Boolean, val selective: Boolean, val caseSensitive: Boolean, val priority: Int, val insertionOrder: Int,
)

data class BLorebook(val name: String, val description: String, val scanDepth: Int, val entries: List<BLoreEntry>)

data class BCharacter(
    val name: String, val aliases: List<String>, val appearance: String, val personality: String, val speechStyle: String,
    val history: String, val motivations: String, val likesDislikes: String, val behaviorInstructions: String,
    val initialRelationship: String, val scenario: String, val firstMessage: String, val alternateGreetings: List<String>,
    val dialogueExamples: String, val privateNotes: String, val tags: List<String>, val creator: String,
    /** Identificador del retrato dentro de [BibleManifest.assets], o null. */
    val portraitAsset: String?,
)

data class BSession(
    val title: String, val scenarioText: String, val userName: String, val userPersona: String, val narrativeRules: String,
    val summary: String, val temperature: Float, val topP: Float, val maxTokens: Int, val contextLength: Int,
    val createdAt: Long, val updatedAt: Long,
    /** Último mensaje ya analizado por el mantenimiento de memoria (-1 = ninguno). */
    val coveredOrder: Int,
)

data class BMessage(
    val srcId: Long, val role: String, val content: String, val orderIndex: Int, val createdAt: Long, val state: String,
    val swipes: List<String>, val swipeIndex: Int,
)

data class BKnowledge(val scope: String, val text: String, val createdAt: Long)

data class BMemory(
    val srcId: Long, val content: String, val importance: Int, val narrativeDate: String, val origin: String, val verification: String,
    val state: String, val pinned: Boolean, val related: List<String>, val sourceMessageSrcId: Long?, val sourceNote: String,
    val createdAt: Long, val updatedAt: Long,
)

data class BSummary(val version: Int, val text: String, val source: String, val coversUpToOrder: Int, val note: String, val createdAt: Long)

data class BTimeline(
    val srcId: Long, val text: String, val narrativeDate: String, val orderKey: Int, val characters: List<String>, val origin: String,
    val state: String, val sourceMessageSrcId: Long?, val createdAt: Long,
)

data class BRelationship(
    val srcId: Long, val a: String, val b: String, val trust: Int, val affection: Int, val respect: Int, val romantic: Int,
    val status: String, val note: String, val createdAt: Long, val updatedAt: Long,
)

data class BRelEvent(
    val srcRelationshipId: Long, val state: String, val origin: String, val reason: String,
    val dTrust: Int, val dAffection: Int, val dRespect: Int, val dRomantic: Int,
    val trustAfter: Int?, val affectionAfter: Int?, val respectAfter: Int?, val romanticAfter: Int?,
    val sourceMessageSrcId: Long?, val createdAt: Long,
)

data class BVolume(
    val srcId: Long, val number: Int, val title: String, val state: String, val continuitySummary: String, val createdAt: Long, val closedAt: Long?,
)

data class BChapter(
    val srcId: Long, val srcVolumeId: Long, val number: Int, val title: String, val state: String, val startOrder: Int, val endOrder: Int?,
    val summary: String, val novelText: String, val novelState: String, val createdAt: Long, val closedAt: Long?,
)

class Bible(
    val manifest: BibleManifest,
    val character: BCharacter,
    val lorebook: BLorebook?,
    val session: BSession,
    val messages: List<BMessage>,
    val knowledge: List<BKnowledge>,
    val memories: List<BMemory>,
    val summaries: List<BSummary>,
    val timeline: List<BTimeline>,
    val relationships: List<BRelationship>,
    val relEvents: List<BRelEvent>,
    val volumes: List<BVolume>,
    val chapters: List<BChapter>,
    /** Contenido de los recursos por identificador (retratos ya reducidos). */
    val assets: Map<String, ByteArray>,
    val warnings: List<String> = emptyList(),
    /** v0.5: instantánea opcional del mundo (data/mundo.json). Null en los .jullai de la 0.4. */
    val worldSnapshot: ByteArray? = null,
) {
    fun withWorldSnapshot(snapshot: ByteArray?) = Bible(
        manifest, character, lorebook, session, messages, knowledge, memories, summaries, timeline, relationships, relEvents,
        volumes, chapters, assets, warnings, snapshot,
    )
}

/** Resumen para la pantalla de confirmación: se muestra ANTES de tocar ningún dato. */
data class BiblePreview(
    val title: String,
    val characterName: String,
    val userName: String,
    val messages: Int,
    val memories: Int,
    val pendingProposals: Int,
    val timeline: Int,
    val relationships: Int,
    val chapters: Int,
    val volumes: Int,
    val hasPortrait: Boolean,
    val hasLorebook: Boolean,
    val appVersion: String,
    val exportedAt: Long,
    val warnings: List<String>,
) {
    companion object {
        fun of(b: Bible) = BiblePreview(
            title = b.session.title, characterName = b.character.name, userName = b.session.userName,
            messages = b.messages.size, memories = b.memories.count { it.state == ItemState.ACTIVO },
            pendingProposals = b.memories.count { it.state == ItemState.PROPUESTO } + b.timeline.count { it.state == ItemState.PROPUESTO } +
                b.relEvents.count { it.state == EventState.PROPUESTO },
            timeline = b.timeline.count { it.state == ItemState.ACTIVO }, relationships = b.relationships.size,
            chapters = b.chapters.size, volumes = b.volumes.size, hasPortrait = b.character.portraitAsset != null && b.assets.containsKey(b.character.portraitAsset),
            hasLorebook = b.lorebook != null, appVersion = b.manifest.appVersion, exportedAt = b.manifest.exportedAt, warnings = b.warnings,
        )
    }
}

class BibleException(message: String) : Exception(message)
