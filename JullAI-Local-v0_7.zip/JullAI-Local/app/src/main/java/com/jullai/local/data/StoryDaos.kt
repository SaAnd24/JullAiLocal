package com.jullai.local.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Insert
    suspend fun insert(m: MemoryEntity): Long

    @Insert
    suspend fun insertAll(list: List<MemoryEntity>)

    @Update
    suspend fun update(m: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM memories WHERE id = :id")
    suspend fun get(id: Long): MemoryEntity?

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId AND state = 'ACTIVO' ORDER BY pinned DESC, importance DESC, updatedAt DESC, id DESC")
    fun observeActive(sessionId: Long): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId AND state = 'PROPUESTO' ORDER BY id ASC")
    fun observePending(sessionId: Long): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId AND state = 'ACTIVO' ORDER BY pinned DESC, importance DESC, updatedAt DESC, id DESC")
    suspend fun listActive(sessionId: Long): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId ORDER BY id ASC")
    suspend fun listAll(sessionId: Long): List<MemoryEntity>

    @Query("SELECT COUNT(*) FROM memories WHERE sessionId = :sessionId AND state = 'ACTIVO'")
    suspend fun countActive(sessionId: Long): Int

    /** Textos de TODOS los estados (también descartados): sirven para no volver a proponer lo ya descartado. */
    @Query("SELECT content FROM memories WHERE sessionId = :sessionId")
    suspend fun allTexts(sessionId: Long): List<String>

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId AND state = 'ACTIVO' AND (pinned = 1 OR importance >= 4) ORDER BY pinned DESC, importance DESC, updatedAt DESC LIMIT :limit")
    suspend fun topActive(sessionId: Long, limit: Int): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId AND state = 'ACTIVO' AND id IN (:ids)")
    suspend fun activeByIds(sessionId: Long, ids: List<Long>): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE sessionId = :sessionId AND state = 'ACTIVO' AND (content LIKE :pattern ESCAPE '\\' OR relatedNames LIKE :pattern ESCAPE '\\') ORDER BY pinned DESC, importance DESC, updatedAt DESC LIMIT :limit")
    suspend fun searchLike(sessionId: Long, pattern: String, limit: Int): List<MemoryEntity>
}

@Dao
interface SummaryDao {
    @Insert
    suspend fun insert(s: SummaryEntity): Long

    @Query("SELECT * FROM summaries WHERE sessionId = :sessionId ORDER BY version DESC")
    fun observe(sessionId: Long): Flow<List<SummaryEntity>>

    @Query("SELECT * FROM summaries WHERE sessionId = :sessionId ORDER BY version DESC")
    suspend fun list(sessionId: Long): List<SummaryEntity>

    @Query("SELECT * FROM summaries WHERE sessionId = :sessionId AND version = :version")
    suspend fun get(sessionId: Long, version: Int): SummaryEntity?

    @Query("SELECT COALESCE(MAX(version), 0) FROM summaries WHERE sessionId = :sessionId")
    suspend fun maxVersion(sessionId: Long): Int
}

@Dao
interface TimelineDao {
    @Insert
    suspend fun insert(e: TimelineEventEntity): Long

    @Insert
    suspend fun insertAll(list: List<TimelineEventEntity>)

    @Update
    suspend fun update(e: TimelineEventEntity)

    @Query("DELETE FROM timeline_events WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM timeline_events WHERE id = :id")
    suspend fun get(id: Long): TimelineEventEntity?

    @Query("SELECT * FROM timeline_events WHERE sessionId = :sessionId AND state = 'ACTIVO' ORDER BY orderKey ASC, id ASC")
    fun observeActive(sessionId: Long): Flow<List<TimelineEventEntity>>

    @Query("SELECT * FROM timeline_events WHERE sessionId = :sessionId AND state = 'PROPUESTO' ORDER BY id ASC")
    fun observePending(sessionId: Long): Flow<List<TimelineEventEntity>>

    @Query("SELECT * FROM timeline_events WHERE sessionId = :sessionId AND state = 'ACTIVO' ORDER BY orderKey ASC, id ASC")
    suspend fun listActive(sessionId: Long): List<TimelineEventEntity>

    @Query("SELECT * FROM timeline_events WHERE sessionId = :sessionId ORDER BY orderKey ASC, id ASC")
    suspend fun listAll(sessionId: Long): List<TimelineEventEntity>

    @Query("SELECT COALESCE(MAX(orderKey), 0) FROM timeline_events WHERE sessionId = :sessionId")
    suspend fun maxOrderKey(sessionId: Long): Int

    @Query("SELECT text FROM timeline_events WHERE sessionId = :sessionId")
    suspend fun allTexts(sessionId: Long): List<String>
}

@Dao
interface RelationshipDao {
    @Insert
    suspend fun insert(r: RelationshipEntity): Long

    @Insert
    suspend fun insertAll(list: List<RelationshipEntity>)

    @Update
    suspend fun update(r: RelationshipEntity)

    @Query("DELETE FROM relationships WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM relationships WHERE id = :id")
    suspend fun get(id: Long): RelationshipEntity?

    @Query("SELECT * FROM relationships WHERE sessionId = :sessionId ORDER BY id ASC")
    fun observe(sessionId: Long): Flow<List<RelationshipEntity>>

    @Query("SELECT * FROM relationships WHERE sessionId = :sessionId ORDER BY id ASC")
    suspend fun list(sessionId: Long): List<RelationshipEntity>

    @Query("SELECT * FROM relationships WHERE sessionId = :sessionId AND aName = :a AND bName = :b")
    suspend fun find(sessionId: Long, a: String, b: String): RelationshipEntity?
}

@Dao
interface RelationshipEventDao {
    @Insert
    suspend fun insert(e: RelationshipEventEntity): Long

    @Insert
    suspend fun insertAll(list: List<RelationshipEventEntity>)

    @Update
    suspend fun update(e: RelationshipEventEntity)

    @Query("SELECT * FROM relationship_events WHERE id = :id")
    suspend fun get(id: Long): RelationshipEventEntity?

    @Query("SELECT * FROM relationship_events WHERE sessionId = :sessionId ORDER BY createdAt DESC, id DESC")
    fun observe(sessionId: Long): Flow<List<RelationshipEventEntity>>

    @Query("SELECT * FROM relationship_events WHERE sessionId = :sessionId ORDER BY createdAt ASC, id ASC")
    suspend fun list(sessionId: Long): List<RelationshipEventEntity>

    @Query("SELECT * FROM relationship_events WHERE relationshipId = :relationshipId ORDER BY createdAt DESC, id DESC")
    suspend fun listFor(relationshipId: Long): List<RelationshipEventEntity>
}

@Dao
interface VolumeDao {
    @Insert
    suspend fun insert(v: VolumeEntity): Long

    @Update
    suspend fun update(v: VolumeEntity)

    @Query("DELETE FROM volumes WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM volumes WHERE id = :id")
    suspend fun get(id: Long): VolumeEntity?

    @Query("SELECT * FROM volumes WHERE sessionId = :sessionId ORDER BY number ASC")
    fun observe(sessionId: Long): Flow<List<VolumeEntity>>

    @Query("SELECT * FROM volumes WHERE sessionId = :sessionId ORDER BY number ASC")
    suspend fun list(sessionId: Long): List<VolumeEntity>

    @Query("SELECT * FROM volumes WHERE sessionId = :sessionId AND state = 'ABIERTO' ORDER BY number DESC LIMIT 1")
    suspend fun open(sessionId: Long): VolumeEntity?

    @Query("SELECT COALESCE(MAX(number), 0) FROM volumes WHERE sessionId = :sessionId")
    suspend fun maxNumber(sessionId: Long): Int
}

@Dao
interface ChapterDao {
    @Insert
    suspend fun insert(c: ChapterEntity): Long

    @Update
    suspend fun update(c: ChapterEntity)

    @Query("DELETE FROM chapters WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun get(id: Long): ChapterEntity?

    @Query("SELECT * FROM chapters WHERE sessionId = :sessionId ORDER BY number ASC")
    fun observe(sessionId: Long): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE sessionId = :sessionId ORDER BY number ASC")
    suspend fun list(sessionId: Long): List<ChapterEntity>

    @Query("SELECT * FROM chapters WHERE sessionId = :sessionId AND state = 'ABIERTO' ORDER BY number DESC LIMIT 1")
    suspend fun open(sessionId: Long): ChapterEntity?

    @Query("SELECT COALESCE(MAX(number), 0) FROM chapters WHERE sessionId = :sessionId")
    suspend fun maxNumber(sessionId: Long): Int

    @Query("SELECT * FROM chapters WHERE volumeId = :volumeId ORDER BY number ASC")
    suspend fun forVolume(volumeId: Long): List<ChapterEntity>
}

@Dao
interface MemoryProgressDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: MemoryProgressEntity)

    @Query("SELECT * FROM memory_progress WHERE sessionId = :sessionId")
    suspend fun get(sessionId: Long): MemoryProgressEntity?

    @Query("SELECT * FROM memory_progress WHERE sessionId = :sessionId")
    fun observe(sessionId: Long): Flow<MemoryProgressEntity?>
}

/** Consultas de solo lectura sobre el registro original de mensajes (role_messages) para la memoria y los capítulos. */
@Dao
interface MessageRangeDao {
    @Query("SELECT * FROM role_messages WHERE sessionId = :sessionId AND orderIndex > :after AND content != '' ORDER BY orderIndex ASC")
    suspend fun listAfter(sessionId: Long, after: Int): List<RoleMessageEntity>

    @Query("SELECT * FROM role_messages WHERE sessionId = :sessionId AND orderIndex >= :from AND orderIndex <= :to AND content != '' ORDER BY orderIndex ASC")
    suspend fun range(sessionId: Long, from: Int, to: Int): List<RoleMessageEntity>

    @Query("SELECT COUNT(*) FROM role_messages WHERE sessionId = :sessionId AND role = 'user' AND orderIndex > :after")
    suspend fun countUserAfter(sessionId: Long, after: Int): Int

    @Query("SELECT COUNT(*) FROM role_messages WHERE sessionId = :sessionId AND role = 'user' AND orderIndex > :after")
    fun observeUserAfter(sessionId: Long, after: Int): Flow<Int>

    @Query("SELECT COALESCE(MAX(orderIndex), -1) FROM role_messages WHERE sessionId = :sessionId")
    suspend fun maxOrder(sessionId: Long): Int

    @Query("SELECT * FROM role_messages WHERE id = :id")
    suspend fun get(id: Long): RoleMessageEntity?

    @Query("SELECT id FROM role_messages WHERE sessionId = :sessionId")
    suspend fun ids(sessionId: Long): List<Long>

    @Insert
    suspend fun insertAll(list: List<RoleMessageEntity>): List<Long>
}

@Dao
interface SessionLookupDao {
    @Query("SELECT title FROM role_sessions")
    suspend fun titles(): List<String>
}
