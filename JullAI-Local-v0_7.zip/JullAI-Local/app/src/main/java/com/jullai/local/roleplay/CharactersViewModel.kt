package com.jullai.local.roleplay

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.AppContainer
import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.LoreEntryEntity
import com.jullai.local.data.LorebookEntity
import com.jullai.local.data.ScenarioEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Tarjeta leída y validada, pendiente de que el usuario confirme la importación. */
class ImportPreview(val card: ParsedCard, val portraitBytes: ByteArray?, val sourceName: String)

/** Biblioteca de personajes: importar/exportar, editor de fichas, lorebooks y arranque de partidas. */
@OptIn(ExperimentalCoroutinesApi::class)
class CharactersViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.roleplayRepository
    private val portraits = c.portraits
    val portraitStore get() = c.portraits
    /** Perfil global del jugador (nombre, personaje). Cada partida guarda su propia copia. */
    val playerProfile: kotlinx.coroutines.flow.StateFlow<com.jullai.local.data.AppSettings> get() = c.settingsRepository.settings

    val characters: StateFlow<List<CharacterEntity>> =
        repo.characters().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lorebooks: StateFlow<List<LorebookEntity>> =
        repo.lorebooks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _preview = MutableStateFlow<ImportPreview?>(null)
    val preview: StateFlow<ImportPreview?> = _preview.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun dismissMessage() { _message.value = null }
    fun dismissPreview() { _preview.value = null }

    // ---------------- Importar ----------------

    private fun readLimited(uri: Uri, max: Int): ByteArray {
        val input = c.app.contentResolver.openInputStream(uri) ?: throw CardException("No se pudo abrir el archivo.")
        input.use { s ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > max) throw CardException("El archivo es demasiado grande (más de ${max / 1_000_000} MB).")
            }
            return out.toByteArray()
        }
    }

    /** Lee un archivo (PNG con tarjeta, o JSON) y muestra una vista previa. NO guarda nada todavía. */
    fun previewImport(uri: Uri) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val result = withContext(Dispatchers.IO) {
                    val bytes = readLimited(uri, CardLimits.MAX_PNG_BYTES)
                    if (PngCard.isPng(bytes)) {
                        ImportPreview(CardParser.parseJson(PngCard.extractJson(bytes)), bytes, uri.lastPathSegment ?: "tarjeta.png")
                    } else {
                        val head = String(bytes, 0, minOf(bytes.size, 64), Charsets.UTF_8).trimStart('﻿', ' ', '\n', '\r', '\t')
                        if (!head.startsWith("{")) throw CardException("Este archivo no es una tarjeta: usa un PNG con tarjeta o un archivo JSON.")
                        ImportPreview(CardParser.parseBytes(bytes), null, uri.lastPathSegment ?: "tarjeta.json")
                    }
                }
                _preview.value = result
            } catch (e: CardException) {
                _message.value = "No se pudo importar: ${e.message}"
            } catch (e: Exception) {
                _message.value = "No se pudo leer el archivo: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun confirmImport() {
        val p = _preview.value ?: return
        _preview.value = null
        viewModelScope.launch {
            _busy.value = true
            try {
                val portrait = p.portraitBytes?.let { b -> withContext(Dispatchers.IO) { runCatching { portraits.save(b) }.getOrNull() } }
                repo.importCard(p.card, portrait)
                _message.value = "Importado: ${p.card.character.name}" + if (p.portraitBytes != null && portrait == null) " (el retrato no se pudo leer)" else ""
            } catch (e: Exception) {
                _message.value = "No se pudo guardar el personaje: ${e.message}"
            } finally {
                _busy.value = false
            }
        }
    }

    // ---------------- Exportar / duplicar / eliminar ----------------

    fun exportTo(characterId: Long, uri: Uri) {
        viewModelScope.launch {
            try {
                val json = repo.exportJson(characterId) ?: throw IllegalStateException("El personaje ya no existe.")
                withContext(Dispatchers.IO) {
                    c.app.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        ?: throw IllegalStateException("No se pudo abrir el destino.")
                }
                _message.value = "Personaje exportado."
            } catch (e: Exception) {
                _message.value = "No se pudo exportar: ${e.message}"
            }
        }
    }

    fun duplicate(id: Long) {
        viewModelScope.launch {
            try {
                val src = repo.character(id) ?: return@launch
                val copy = withContext(Dispatchers.IO) { portraits.copy(src.portraitFile) }
                repo.duplicateCharacter(id, copy)
            } catch (e: Exception) {
                _message.value = "No se pudo duplicar: ${e.message}"
            }
        }
    }

    suspend fun sessionCountOf(id: Long): Int = repo.sessionCountOf(id)

    fun delete(id: Long) {
        viewModelScope.launch {
            try {
                val portrait = repo.deleteCharacter(id)
                withContext(Dispatchers.IO) { portraits.delete(portrait) }
            } catch (e: Exception) {
                _message.value = "No se pudo eliminar: ${e.message}"
            }
        }
    }

    // ---------------- Editor ----------------

    private val _draft = MutableStateFlow<CharacterEntity?>(null)
    val draft: StateFlow<CharacterEntity?> = _draft.asStateFlow()
    private var originalPortrait: String? = null
    private var originalLorebook: Long? = null
    private val newPortraits = ArrayList<String>()

    /** id = 0 → personaje nuevo. */
    fun openEditor(id: Long) {
        val cur = _draft.value
        if (cur != null && cur.id == id) return       // al volver del lorebook se conserva lo escrito
        viewModelScope.launch {
            val e = if (id == 0L) CharacterEntity(name = "", createdAt = 0, updatedAt = 0) else repo.character(id)
            if (e == null) { _message.value = "El personaje ya no existe."; return@launch }
            newPortraits.clear()
            originalPortrait = e.portraitFile
            originalLorebook = e.lorebookId
            _draft.value = e
        }
    }

    fun edit(change: (CharacterEntity) -> CharacterEntity) { _draft.value = _draft.value?.let(change) }

    fun pickPortrait(uri: Uri) {
        viewModelScope.launch {
            try {
                val name = withContext(Dispatchers.IO) {
                    val bytes = readLimited(uri, CardLimits.MAX_PNG_BYTES)
                    try { portraits.save(bytes) } catch (e: IllegalArgumentException) { throw CardException(e.message ?: "Imagen no válida.") }
                }
                newPortraits.add(name)
                _draft.value = _draft.value?.copy(portraitFile = name)
            } catch (e: CardException) {
                _message.value = e.message
            } catch (e: Exception) {
                _message.value = "No se pudo cargar la imagen: ${e.message}"
            }
        }
    }

    fun removePortrait() { _draft.value = _draft.value?.copy(portraitFile = null) }

    /** Guarda la ficha. Devuelve el id por el callback; si falta el nombre, muestra un aviso y no guarda. */
    fun saveDraft(onSaved: (Long) -> Unit) {
        val d = _draft.value ?: return
        if (d.name.isBlank()) { _message.value = "Escribe un nombre para el personaje."; return }
        viewModelScope.launch {
            try {
                val clean = d.copy(name = d.name.trim().take(120), alternateGreetings = d.alternateGreetings.ifBlank { "[]" })
                val id = repo.saveCharacter(clean)
                // Retratos que ya no se usan (el anterior reemplazado y los elegidos y descartados).
                val keep = clean.portraitFile
                withContext(Dispatchers.IO) {
                    (newPortraits + listOfNotNull(originalPortrait)).distinct().filter { it != keep }.forEach { portraits.delete(it) }
                }
                originalLorebook?.let { if (it != clean.lorebookId) repo.deleteLorebookIfUnused(it) }
                newPortraits.clear()
                _draft.value = null
                onSaved(id)
            } catch (e: Exception) {
                _message.value = "No se pudo guardar: ${e.message}"
            }
        }
    }

    /** Descarta los cambios: los retratos nuevos elegidos y no guardados se borran del disco. */
    fun discardDraft() {
        val toDelete = newPortraits.toList()
        newPortraits.clear()
        _draft.value = null
        viewModelScope.launch(Dispatchers.IO) { toDelete.forEach { portraits.delete(it) } }
    }

    // ---------------- Lorebook (del personaje en edición) ----------------

    fun createLorebookForDraft() {
        val d = _draft.value ?: return
        viewModelScope.launch {
            val id = repo.createLorebook("Lorebook de " + d.name.ifBlank { "personaje nuevo" })
            _draft.value = _draft.value?.copy(lorebookId = id)
        }
    }

    fun useLorebook(id: Long) { _draft.value = _draft.value?.copy(lorebookId = id) }
    fun detachLorebook() { _draft.value = _draft.value?.copy(lorebookId = null) }

    fun lorebook(id: Long): StateFlow<LorebookEntity?> =
        repo.lorebook(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _bookId = MutableStateFlow<Long?>(null)
    fun showLorebook(id: Long?) { _bookId.value = id }
    val currentBook: StateFlow<LorebookEntity?> = _bookId
        .flatMapLatest { id -> if (id == null) flowOf(null) else repo.lorebook(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val currentEntries: StateFlow<List<LoreEntryEntity>> = _bookId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.loreEntries(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveBookInfo(id: Long, name: String, description: String, scanDepth: Int) {
        viewModelScope.launch { repo.renameLorebook(id, name, description, scanDepth) }
    }

    fun saveEntry(e: LoreEntryEntity) {
        if (e.content.isBlank()) { _message.value = "La entrada necesita contenido."; return }
        if (!e.constant && splitKeys(e.keys).isEmpty()) { _message.value = "La entrada necesita al menos una clave (o márcala como «siempre activa»)."; return }
        viewModelScope.launch { repo.saveLoreEntry(e.copy(content = e.content.trim().take(CardLimits.MAX_LORE_CONTENT_CHARS))) }
    }

    fun deleteEntry(id: Long) { viewModelScope.launch { repo.deleteLoreEntry(id) } }

    private fun splitKeys(s: String) = s.split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    // ---------------- Escenarios y arranque de partidas ----------------

    suspend fun scenariosOf(characterId: Long): List<ScenarioEntity> = repo.scenariosOf(characterId)
    fun deleteScenario(id: Long, then: () -> Unit) { viewModelScope.launch { repo.deleteScenario(id); then() } }

    /** Crea la partida y abre el chat de rol. Si [saveScenarioAs] no es null, el escenario escrito se guarda para reutilizarlo. */
    fun startSession(character: CharacterEntity, scenarioText: String, userName: String, persona: String, saveScenarioAs: String?, onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            try {
                if (saveScenarioAs != null && scenarioText.isNotBlank()) repo.addScenario(character.id, saveScenarioAs, scenarioText)
                val models = c.registry.list()
                val model = models.firstOrNull { it.isDefault } ?: models.firstOrNull()
                val settings = c.settingsRepository.settings.value
                val id = repo.startSession(character, scenarioText, userName, persona, settings, model?.fileName)
                c.settingsRepository.update { it.copy(rpLastUserName = userName.trim().take(40).ifBlank { it.rpLastUserName }) }
                onCreated(id)
            } catch (e: Exception) {
                _message.value = "No se pudo crear la partida: ${e.message}"
            }
        }
    }
}
