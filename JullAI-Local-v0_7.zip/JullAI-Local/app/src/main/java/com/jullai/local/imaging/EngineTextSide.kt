package com.jullai.local.imaging

import com.jullai.local.engine.EngineController
import com.jullai.local.engine.EngineState

/** Adaptador: el coordinador ve el motor de texto (llama.cpp) solo a través de [TextSide]. LlamaEngine/LlamaBridge no se tocan. */
class EngineTextSide(private val controller: EngineController) : TextSide {
    override fun isGenerating(): Boolean = controller.state.value.let { it == EngineState.GENERATING || it == EngineState.LOADING }
    override fun isLoaded(): Boolean = controller.loaded.value != null
    override suspend fun unloadIfIdle(): Boolean = if (!isLoaded()) true else controller.unloadIfIdle()
}
