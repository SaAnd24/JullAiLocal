package com.jullai.local.discovery

import com.jullai.local.story.TextNorm

/** Fallo de red o de la API, ya con mensaje en español. [retryable] = merece la pena reintentar más tarde. */
class WikiFetchException(message: String, val retryable: Boolean) : Exception(message)

/**
 * Acceso a la red que necesita el descubrimiento. En la app lo implementa PoliteHttp (límite de ritmo, User-Agent, redirecciones validadas);
 * en las pruebas, un cliente falso con respuestas fijas. [api] debe ser una API de la lista cerrada (WikiHosts.isTrustedApi).
 */
interface WikiClient {
    suspend fun api(api: String, query: String): String
    /** Solo para la API v1 de Fandom (miniaturas): dirección completa dentro de *.fandom.com. */
    suspend fun fandomUrl(url: String): String
    suspend fun bytes(url: String, maxBytes: Int): ByteArray
}

/** Resultado de buscar una obra. */
sealed class Resolution {
    /** Una opción clara: se puede continuar sin preguntar. [alternatives] son las demás, por si el usuario quiere cambiar. */
    class Auto(val pick: WorkCandidate, val alternatives: List<WorkCandidate>) : Resolution()
    /** Varias continuidades plausibles y distintas (serie, cómic, juego…): hay que preguntar. */
    class Ask(val options: List<WorkCandidate>) : Resolution()
    object NotFound : Resolution()
    class Failed(val message: String, val retryable: Boolean) : Resolution()
}

/** Datos reunidos sobre la obra elegida. Todo lo que no se pudo comprobar queda vacío, nunca inventado. */
data class WorkIdentity(
    val qid: String,
    val title: String,
    val kind: String,
    val lang: String,
    val description: String,
    /** Idioma → título del artículo de Wikipedia. */
    val wikipedia: Map<String, String>,
    val fandomSub: String,
    val fandomTitle: String,
    /** Personajes según Wikidata (P674), solo etiquetas. */
    val wikidataCharacters: List<String>,
    val notes: List<String>,
)

class UniverseResolver(private val client: WikiClient) {

    /**
     * Busca la obra en Wikipedia (en los idiomas dados) y decide si se puede continuar sin preguntar.
     * Pregunta solo cuando hay candidatos plausibles de TIPOS distintos (p. ej. serie y cómic con el mismo nombre).
     */
    suspend fun search(query: String, langs: List<String>): Resolution {
        val q = query.trim()
        if (q.length < 2) return Resolution.NotFound
        val all = ArrayList<WorkCandidate>()
        var lastError: WikiFetchException? = null
        var okRequests = 0
        for (lang in langs.distinct().take(3)) {
            val api = try { WikiHosts.wikipedia(lang) } catch (e: IllegalArgumentException) { continue }
            try {
                val json = client.api(api, WikiQuery.searchWorks(q))
                if (WikiParsers.apiError(json) != null) continue
                okRequests++
                all.addAll(WikiParsers.workCandidates(json, api, lang))
            } catch (e: WikiFetchException) { lastError = e }
        }
        if (okRequests == 0 && lastError != null) return Resolution.Failed(lastError.message ?: "No se pudo consultar Wikipedia.", lastError.retryable)
        return decide(q, all, langs)
    }

    companion object {
        /** Lógica de decisión pura (se prueba sin red). */
        fun decide(query: String, candidates: List<WorkCandidate>, langs: List<String>): Resolution {
            val works = candidates.filter { it.kind in WorkKind.WORKS }
            if (works.isEmpty()) return Resolution.NotFound
            // La misma obra en dos idiomas (mismo identificador de Wikidata) es UNA candidata: se queda la del primer idioma preferido.
            val byEntity = LinkedHashMap<String, WorkCandidate>()
            for (c in works.sortedBy { langs.indexOf(it.lang).let { i -> if (i < 0) 99 else i } * 100 + it.rank }) {
                val key = if (c.qid.isNotEmpty()) c.qid else "t:" + TextNorm.fold(baseTitle(c.title)) + ":" + c.kind
                if (key !in byEntity) byEntity[key] = c
            }
            val scored = byEntity.values.map { it to score(query, it) }.sortedByDescending { it.second }
            val top = scored.first()
            val plausible = scored.filter { it.second >= top.second - 4 }.map { it.first }
            val distinctKinds = plausible.map { it.kind }.toSet()
            return if (plausible.size >= 2 && distinctKinds.size >= 2) Resolution.Ask(plausible.take(5))
            else Resolution.Auto(top.first, scored.drop(1).map { it.first }.take(4))
        }

        fun baseTitle(title: String) = title.substringBefore('(').trim()

        fun score(query: String, c: WorkCandidate): Int {
            val q = TextNorm.fold(query).trim()
            val t = TextNorm.fold(baseTitle(c.title)).trim()
            var s = (10 - c.rank).coerceAtLeast(0)
            if (t == q) s += 10
            else if (q.isNotEmpty() && (t.contains(q) || q.contains(t))) s += 4
            val qTokens = TextNorm.tokens(query)
            if (qTokens.isNotEmpty() && qTokens.all { TextNorm.fold(c.title).contains(it) }) s += 3
            // Una franquicia general es menos concreta que la obra: queda algo por debajo si hay una obra con el mismo nombre.
            if (c.kind == WorkKind.FRANQUICIA) s -= 1
            return s
        }
    }

    /** Completa la identidad con Wikidata (enlaces a Wikipedia, identificador de Fandom, personajes). Todo es opcional: si falla, se devuelve lo básico. */
    suspend fun identify(c: WorkCandidate): WorkIdentity {
        val notes = ArrayList<String>()
        val wp = LinkedHashMap<String, String>().also { it[c.lang] = c.title }
        var fandomSub = ""
        var fandomTitle = ""
        val chars = ArrayList<String>()
        if (c.qid.isNotEmpty()) {
            try {
                val json = client.api(WikiHosts.WIKIDATA, WikiQuery.wikidataEntities(listOf(c.qid), "claims|sitelinks"))
                if (WikiParsers.apiError(json) == null) {
                    for (lang in listOf("es", "en")) WikiParsers.sitelinks(json, c.qid)[lang]?.let { if (lang !in wp) wp[lang] = it }
                    WikiParsers.claimString(json, c.qid, "P6262")?.let { id -> WikiParsers.splitFandomId(id)?.let { (sub, title) -> fandomSub = sub; fandomTitle = title } }
                    val ids = WikiParsers.claimEntityIds(json, c.qid, "P674").take(60)
                    if (ids.isNotEmpty()) {
                        val l = client.api(WikiHosts.WIKIDATA, WikiQuery.wikidataEntities(ids, "labels"))
                        if (WikiParsers.apiError(l) == null) { val m = WikiParsers.labels(l); ids.forEach { id -> m[id]?.let { chars.add(it) } } }
                    }
                }
            } catch (e: WikiFetchException) {
                notes.add("Wikidata no respondió (${e.message}); se continúa solo con Wikipedia.")
            }
        } else notes.add("La obra no tiene identificador de Wikidata; se usa solo Wikipedia.")
        return WorkIdentity(c.qid, c.title.substringBefore('(').trim().ifBlank { c.title }, c.kind, c.lang, c.shortDescription.ifBlank { c.intro.take(160) }, wp, fandomSub, fandomTitle, chars, notes)
    }
}
