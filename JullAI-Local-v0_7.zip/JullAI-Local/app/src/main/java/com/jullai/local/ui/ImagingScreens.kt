package com.jullai.local.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.data.ImageMetaEntity
import com.jullai.local.data.ImageModelEntity
import com.jullai.local.data.VisualAssetEntity
import com.jullai.local.imaging.CostEstimate
import com.jullai.local.imaging.ImageModelKinds
import com.jullai.local.imaging.ImageSettings
import com.jullai.local.imaging.ImageSizes
import com.jullai.local.imaging.ImagingViewModel
import com.jullai.local.imaging.IllustrationMode
import com.jullai.local.imaging.ModelCompat
import com.jullai.local.imaging.QualityPreset
import com.jullai.local.imaging.TaskStatus
import com.jullai.local.world.AssetKind
import com.jullai.local.world.Emotion

/** Estudio de imágenes locales: generar, cola, modelos y ajustes. Todo lo que se muestra sale de datos reales (motor, cola, base de datos). */
@Composable
fun ImageStudioScreen(vm: ImagingViewModel, onBack: () -> Unit, onGallery: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val notice by vm.notice.collectAsState()
    val busy by vm.busy.collectAsState()
    LaunchedEffect(Unit) { vm.refreshDiagnostics() }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Estudio de imágenes", onBack) { InkLink("Galería", onGallery) }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Generar", "Cola", "Modelos", "Ajustes").forEachIndexed { i, t -> InkChip(t, tab == i, { tab = i }) }
        }
        busy?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) }
        notice?.let {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                BasicText(it, style = Type.Nota, modifier = Modifier.weight(1f))
                InkLink("Cerrar", { vm.clearNotice() })
            }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
            when (tab) {
                0 -> GenerateTab(vm)
                1 -> QueueTab(vm)
                2 -> ModelsTab(vm)
                else -> SettingsTab(vm)
            }
        }
    }
}

@Composable
private fun GenerateTab(vm: ImagingViewModel) {
    val f by vm.form.collectAsState()
    val characters by vm.characters.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val progress by vm.progress.collectAsState()
    val s by vm.settings.collectAsState()
    val caps = remember { vm.capabilities() }
    val history by produceState(emptyList<Pair<Double, Long>>(), tasks.count { it.status == TaskStatus.LISTA }) { value = vm.costHistoryLoader()() }
    var showProfile by remember { mutableStateOf(false) }
    val task = tasks.firstOrNull { it.id == f.sourceTaskId }
    val preset = QualityPreset.byId(f.presetId)
    val rel = CostEstimate.relative(f.steps, f.size.width, f.size.height, preset.cfg)

    if (!vm.hasModel()) BasicText("Todavía no hay un modelo de imagen. Importa un checkpoint Stable Diffusion 1.x en «Modelos». La historia funciona igual sin imágenes.", style = Type.Nota.copy(color = Ink.Granate))

    SectionTitle("Qué guardar")
    ChipFlow(AssetKind.ALL, { it == f.kind }, { AssetKind.label(it) }, { vm.setKind(it) }, perRow = 3)
    SectionTitle("Personaje (opcional)")
    ChipFlow(listOf(0L) + characters.map { it.id }, { (it == 0L && f.characterId == null) || it == f.characterId }, { id -> if (id == 0L) "Ninguno" else characters.firstOrNull { it.id == id }?.name ?: "?" }, { id -> vm.edit { it.copy(characterId = id.takeIf { x -> x != 0L }) } }, perRow = 3)
    if (f.characterId != null) Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        InkButton("Perfil visual", { showProfile = true }, primary = false)
        InkButton("Rellenar el prompt desde la ficha", { vm.fillFromProfile() }, primary = false)
    }
    if (f.kind == AssetKind.EXPRESION) { SectionTitle("Emoción"); ChipFlow(Emotion.ALL, { it == f.emotion }, { Emotion.label(it) }, { e -> vm.edit { it.copy(emotion = e) } }) }
    if (f.kind == AssetKind.POSE) LabeledField("Pose", f.pose, { p -> vm.edit { it.copy(pose = p) } }, placeholder = "BRAZOS_CRUZADOS, SENTADO…")
    if (f.kind == AssetKind.FONDO || f.kind == AssetKind.ILUSTRACION) LabeledField("Localización (nombre exacto del lugar)", f.location, { l -> vm.edit { it.copy(location = l) } })

    SectionTitle("Calidad")
    ChipFlow(QualityPreset.entries.map { it.id }, { it == f.presetId }, { QualityPreset.byId(it).label }, { vm.applyPreset(it) }, perRow = 1)
    if (preset.needsLcmLora) BasicText("LCM necesita una LoRA LCM de SD 1.5 importada y marcada como predeterminada en «Modelos»; sin ella se usa el bajo consumo normal.", style = Type.Nota)
    BasicText("Resolución", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
    ChipFlow(ImageSizes.ALL.map { "${it.width}x${it.height}" }, { it == "${f.size.width}x${f.size.height}" }, { k -> ImageSizes.ALL.first { "${it.width}x${it.height}" == k }.label }, { k -> ImageSizes.ALL.firstOrNull { "${it.width}x${it.height}" == k }?.let { z -> vm.edit { it.copy(size = z) } } }, perRow = 1)
    Stepper("Pasos", "${f.steps}", { vm.edit { it.copy(steps = (it.steps - 1).coerceAtLeast(1)) } }, { vm.edit { it.copy(steps = (it.steps + 1).coerceAtMost(50)) } })
    BasicText(
        "Coste relativo: ${"%.1f".format(rel)}× el modo de bajo consumo por defecto (pasos × píxeles)." +
            (CostEstimate.secondsFromHistory(rel, history)?.let { " Con tus generaciones anteriores serían unos $it s (estimación, no garantía)." } ?: " Aún no hay generaciones tuyas para estimar segundos."),
        style = Type.Nota,
    )
    LabeledField("Semilla (vacío = aleatoria)", f.seedText, { t -> vm.edit { it.copy(seedText = t.filter { c -> c.isDigit() }.take(10)) } })

    LabeledField("Prompt", f.prompt, { p -> vm.edit { it.copy(prompt = p) } }, placeholder = "Descripción de la imagen (los modelos SD 1.5 entienden mejor el inglés)", minHeight = 80)
    if (caps.negativePrompt) {
        LabeledField("Prompt negativo", f.negative, { p -> vm.edit { it.copy(negative = p) } }, hint = if (preset.cfg <= 1f) "Con CFG 1 (LCM) el prompt negativo no tiene efecto." else null, minHeight = 60)
    } else BasicText("Este motor compilado no expone prompt negativo.", style = Type.Nota)

    Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        InkButton("Generar", { vm.generate(false) }, enabled = s.enabled && f.prompt.isNotBlank())
        InkButton("Regenerar (otra semilla)", { vm.generate(true) }, primary = false, enabled = s.enabled && f.prompt.isNotBlank())
    }
    if (task != null) {
        SectionTitle("Resultado")
        BasicText("${TaskStatus.label(task.status)}" + (if (task.status == TaskStatus.EN_CURSO) progress?.let { " · paso ${it.step} de ${it.steps}" }.orEmpty() else ""), style = Type.Cuerpo)
        if (task.error.isNotBlank()) BasicText(task.error, style = Type.Nota.copy(color = Ink.Granate))
        if (task.note.isNotBlank() && task.status != TaskStatus.LISTA) BasicText(task.note, style = Type.Nota)
        if (task.status == TaskStatus.EN_CURSO) InkButton("Cancelar", { vm.cancelTask(task.id) }, danger = true, modifier = Modifier.padding(top = 6.dp))
        val file = vm.assets.collectAsState().value.firstOrNull { it.id == task.resultAssetId }?.file
        if (file != null) PortraitImage(vm.store, file, "Resultado", Modifier.fillMaxWidth().aspectRatio(f.size.width.toFloat() / f.size.height).padding(top = 8.dp), maxSide = 1024)
        if (task.status == TaskStatus.LISTA) BasicText("Guardada en la galería como ${AssetKind.label(task.kind).lowercase()}. Allí puedes reasignarla.", style = Type.Nota)
    }
    if (showProfile && f.characterId != null) ProfileDialog(vm, f.characterId!!, onClose = { showProfile = false })
}

@Composable
private fun ProfileDialog(vm: ImagingViewModel, characterId: Long, onClose: () -> Unit) {
    val ch = vm.characters.collectAsState().value.firstOrNull { it.id == characterId }
    val loaded by produceState<com.jullai.local.data.VisualProfileEntity?>(null, characterId) { value = vm.profileOf(characterId) }
    var phys by remember(loaded) { mutableStateOf(loaded?.physicalDescription.orEmpty()) }
    var style by remember(loaded) { mutableStateOf(loaded?.styleDescription.orEmpty()) }
    var outfits by remember(loaded) { mutableStateOf(loaded?.outfits.orEmpty()) }
    var neg by remember(loaded) { mutableStateOf(loaded?.negativeDefaults.orEmpty()) }
    var ref by remember(loaded) { mutableStateOf(loaded?.referenceAssetId) }
    InkDialog("Perfil visual de ${ch?.name ?: "personaje"}", onClose) {
        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
            BasicText("Descríbelo con rasgos concretos (pelo, ojos, edad, complexión). No se confía en el nombre del personaje: aunque sea conocido, el modelo no garantiza su cara.", style = Type.Nota)
            LabeledField("Descripción física estable", phys, { phys = it }, minHeight = 70)
            LabeledField("Estilo visual", style, { style = it }, placeholder = "anime style illustration")
            LabeledField("Ropa por etapa (una línea «etapa|ropa»; sin etapa = por defecto)", outfits, { outfits = it }, minHeight = 60)
            LabeledField("Negativos propios", neg, { neg = it })
            val cands = vm.assets.collectAsState().value.filter { it.characterId == characterId }
            if (cands.isNotEmpty()) {
                BasicText("Imagen de referencia principal", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                ChipFlow(cands.map { it.id }, { it == ref }, { id -> cands.first { it.id == id }.label.ifBlank { "#$id" }.take(18) }, { ref = it }, perRow = 2)
            }
            BasicText("Si el motor lo permite, las expresiones y poses se generan a partir de esa referencia (image-to-image). No se promete que conserve exactamente el mismo rostro ni la ropa.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
        }
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Guardar", { vm.saveProfile(characterId, phys, style, outfits, neg, ref ?: vm.suggestedReference(characterId)); onClose() })
            InkButton("Cerrar", onClose, primary = false)
        }
    }
}

@Composable
private fun QueueTab(vm: ImagingViewModel) {
    val tasks by vm.tasks.collectAsState()
    val running by vm.queueRunning.collectAsState()
    val progress by vm.progress.collectAsState()
    val msg by vm.queueMessage.collectAsState()
    val coord by vm.coord.collectAsState()
    val cur by vm.currentTask.collectAsState()
    BasicText("La cola ejecuta UNA tarea cada vez y nunca mientras el texto está generando. Los estados son reales; no hay porcentajes inventados.", style = Type.Nota)
    if (coord.detail.isNotBlank()) BasicText(coord.detail, style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 6.dp))
    if (coord.textReloadPending) BasicText("El modelo de texto se liberó para dejar sitio a la imagen. Se recargará solo al enviar tu próxima acción (la conversación está guardada).", style = Type.Nota)
    if (msg.isNotBlank()) BasicText(msg, style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        InkButton("Generar ahora", { vm.startQueue() }, enabled = !running && tasks.any { it.status == TaskStatus.PENDIENTE || it.status == TaskStatus.APLAZADA })
        InkButton("Cancelar todo", { vm.cancelAll() }, primary = false, enabled = tasks.any { it.status in listOf(TaskStatus.PENDIENTE, TaskStatus.EN_CURSO, TaskStatus.APLAZADA) })
        InkLink("Limpiar terminadas", { vm.clearFinished() })
    }
    if (tasks.isEmpty()) BasicText("No hay tareas.", style = Type.Cuerpo, modifier = Modifier.padding(top = 12.dp))
    tasks.forEach { t ->
        Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
            Row {
                BasicText("${t.priority}· ${t.label.ifBlank { AssetKind.label(t.kind) }}", style = Type.Cuerpo, modifier = Modifier.weight(1f))
                BasicText(TaskStatus.label(t.status) + if (t.id == cur) progress?.let { " ${it.step}/${it.steps}" }.orEmpty() else "", style = Type.Nota.copy(color = Ink.Oro))
            }
            BasicText("${t.width}×${t.height} · ${t.steps} pasos · intentos ${t.attempts}", style = Type.Nota)
            if (t.error.isNotBlank()) BasicText(t.error, style = Type.Nota.copy(color = Ink.Granate))
            else if (t.note.isNotBlank()) BasicText(t.note, style = Type.Nota)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (t.status in listOf(TaskStatus.PENDIENTE, TaskStatus.EN_CURSO, TaskStatus.APLAZADA)) InkLink("Cancelar", { vm.cancelTask(t.id) }, danger = true)
                if (t.status in listOf(TaskStatus.FALLIDA, TaskStatus.CANCELADA, TaskStatus.APLAZADA)) InkLink("Reintentar", { vm.retryTask(t.id) })
            }
            Divider()
        }
    }
}

@Composable
private fun ModelsTab(vm: ImagingViewModel) {
    val diag by vm.diag.collectAsState()
    val models by vm.models.collectAsState()
    val copied by vm.importedBytes.collectAsState()
    val pickCk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri, ImageModelKinds.CHECKPOINT) }
    val pickLora = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri, ImageModelKinds.LORA) }

    SectionTitle("Motor")
    val d = diag
    if (d == null) BasicText("Comprobando…", style = Type.Nota) else {
        BasicText(if (d.available) "stable-diffusion.cpp disponible" else "No disponible", style = Type.Seccion.copy(color = if (d.available) Ink.Oro else Ink.Granate))
        d.problem?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Granate)) }
        d.details.forEach { BasicText(it, style = Type.Nota) }
        BasicText("ABI: ${d.abi}", style = Type.Nota)
    }
    InkLink("Volver a comprobar", { vm.refreshDiagnostics() })

    SectionTitle("Modelos de imagen")
    BasicText("Formatos admitidos: .safetensors o .gguf de Stable Diffusion 1.x en un solo archivo (con VAE integrado). Los .ckpt NO se admiten (pueden ejecutar código). SDXL, FLUX y SD 2.x no se ofrecen. La licencia del modelo es asunto tuyo y distinta de la del motor: usa solo modelos que tengas autorizados. Los pesos no van en la app.", style = Type.Nota)
    if (copied > 0) BasicText("Copiado: ${copied / (1024 * 1024)} MB…", style = Type.Nota.copy(color = Ink.Oro))
    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        InkButton("Importar checkpoint", { pickCk.launch(arrayOf("*/*")) })
        InkButton("Importar LoRA (LCM)", { pickLora.launch(arrayOf("*/*")) }, primary = false)
    }
    if (models.isEmpty()) BasicText("No hay modelos importados.", style = Type.Cuerpo, modifier = Modifier.padding(top = 10.dp))
    BasicText("La LoRA marcada como «usar» solo se aplica con los preajustes LCM. Debe ser una LoRA LCM de SD 1.5: el motor no puede comprobar si encaja con tu checkpoint hasta aplicarla, y la calidad hay que juzgarla a ojo.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
    models.forEach { m -> ModelRow(vm, m) }
}

@Composable
private fun ModelRow(vm: ImagingViewModel, m: ImageModelEntity) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        BasicText((if (m.kind == ImageModelKinds.LORA) "LoRA · " else "Checkpoint · ") + m.displayName + if (m.isDefault) "  ★ predeterminado" else "", style = Type.Cuerpo)
        BasicText("${m.format.lowercase()} · ${m.architecture} · ${m.sizeBytes / (1024 * 1024)} MB", style = Type.Nota)
        BasicText(
            when (m.compat) { ModelCompat.OK -> "Cargado correctamente por el motor"; ModelCompat.REJECTED -> "Rechazado por el motor"; else -> "Estructura reconocida; sin comprobar con el motor" },
            style = Type.Nota.copy(color = if (m.compat == ModelCompat.REJECTED) Ink.Granate else Ink.Oro),
        )
        if (m.note.isNotBlank()) BasicText(m.note, style = Type.Nota)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (m.kind == ImageModelKinds.CHECKPOINT) InkLink("Comprobar con el motor", { vm.validateModel(m) })
            if (!m.isDefault && m.compat != ModelCompat.REJECTED) InkLink("Usar", { vm.setDefault(m) })
            if (m.isDefault && m.kind == ImageModelKinds.LORA) InkLink("Dejar de usar", { vm.clearDefaultLora() })
            InkLink("Eliminar", { confirm = true }, danger = true)
        }
        Divider()
    }
    if (confirm) InkDialog("Eliminar «${m.displayName}»", { confirm = false }) {
        BasicText("Se borra el archivo del modelo de la app. Las imágenes ya generadas se conservan.", style = Type.Cuerpo)
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Eliminar", { vm.deleteModel(m); confirm = false }, danger = true)
            InkButton("Cancelar", { confirm = false }, primary = false)
        }
    }
}

@Composable
private fun SettingsTab(vm: ImagingViewModel) {
    val s by vm.settings.collectAsState()
    val caps = remember { vm.capabilities() }
    fun upd(f: (ImageSettings) -> ImageSettings) = vm.updateSettings(f)
    SectionTitle("Imágenes")
    InkToggleRow("Generación de imágenes activada", s.enabled, { v -> upd { it.copy(enabled = v) } })
    BasicText("Si la desactivas, la historia sigue funcionando igual con retratos y fondos que ya tengas.", style = Type.Nota)
    InkToggleRow("Ejecutar la cola automáticamente cuando el texto esté libre", s.autoRun, { v -> upd { it.copy(autoRun = v) } })
    BasicText("Desactivado por defecto: así nada se lanza solo y calienta el teléfono. Con él apagado, pulsa «Generar ahora» en la cola.", style = Type.Nota)
    SectionTitle("Calidad por defecto de la preparación y las ilustraciones")
    ChipFlow(QualityPreset.entries.map { it.id }, { it == s.preset }, { QualityPreset.byId(it).label }, { id -> upd { it.copy(preset = id) } }, perRow = 1)
    SectionTitle("Ilustraciones de escenas importantes")
    ChipFlow(IllustrationMode.ALL, { it == s.illustrationMode }, { IllustrationMode.label(it) }, { m -> upd { it.copy(illustrationMode = m) } }, perRow = 1)
    Stepper("Pausa mínima entre ilustraciones automáticas (turnos)", "${s.minGapTurns}", { upd { it.copy(minGapTurns = (it.minGapTurns - 1).coerceAtLeast(2)) } }, { upd { it.copy(minGapTurns = (it.minGapTurns + 1).coerceAtMost(100)) } })
    BasicText("Una respuesta normal nunca genera una imagen. Siempre puedes pedir una a mano desde la novela visual.", style = Type.Nota)
    SectionTitle("Rendimiento")
    Stepper("Hilos de CPU para imágenes", "${s.threads}", { upd { it.copy(threads = (it.threads - 1).coerceAtLeast(1)) } }, { upd { it.copy(threads = (it.threads + 1).coerceAtMost(8)) } })
    InkToggleRow("VAE por mosaicos (menos memoria)", s.vaeTiling, { v -> upd { it.copy(vaeTiling = v) } }, enabled = caps.vaeTiling)
    if (!caps.vaeTiling) BasicText("No disponible en el motor compilado.", style = Type.Nota)
    InkToggleRow("Usar la imagen de referencia del personaje (image-to-image)", s.useReference, { v -> upd { it.copy(useReference = v) } }, enabled = caps.imageToImage)
    if (!caps.imageToImage) BasicText("No disponible en el motor compilado.", style = Type.Nota)
    Stepper("Fuerza de la LoRA", "%.1f".format(s.loraStrength), { upd { it.copy(loraStrength = (it.loraStrength - 0.1f).coerceAtLeast(0f)) } }, { upd { it.copy(loraStrength = (it.loraStrength + 0.1f).coerceAtMost(2f)) } }, enabled = caps.lora)
    BasicText("Control térmico: Android 10+ informa del estado; en versiones anteriores solo se vigila la memoria. Con temperatura alta no se empieza ninguna imagen; con crítica se cancela la que corre.", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
}

// ------------------------------------------------------------------------------------------------
// Galería
// ------------------------------------------------------------------------------------------------

@Composable
fun ImageGalleryScreen(vm: ImagingViewModel, onBack: () -> Unit, onStudio: () -> Unit) {
    val assets by vm.assets.collectAsState()
    val metas by vm.metas.collectAsState()
    var filter by rememberSaveable { mutableStateOf("TODOS") }
    var open by remember { mutableStateOf<VisualAssetEntity?>(null) }
    val generated = remember(metas) { metas.map { it.assetId }.toSet() }
    val shown = assets.filter { filter == "TODOS" || it.kind == filter }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Galería de recursos", onBack) { InkLink("Estudio", onStudio) }
        Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            ChipFlow(listOf("TODOS") + AssetKind.ALL, { it == filter }, { if (it == "TODOS") "Todos" else AssetKind.label(it) }, { filter = it }, perRow = 3)
            BasicText("${shown.size} recurso(s) · ${shown.count { it.id in generated }} generados en el teléfono, el resto importados.", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
        }
        if (shown.isEmpty()) BasicText("No hay recursos de este tipo.", style = Type.Cuerpo, modifier = Modifier.padding(20.dp))
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { a ->
                Column(Modifier.clickable { open = a }) {
                    PortraitImage(vm.store, a.file, a.label.ifBlank { AssetKind.label(a.kind) }, Modifier.fillMaxWidth().aspectRatio(0.75f), maxSide = 384)
                    BasicText(a.label.ifBlank { AssetKind.label(a.kind) }, style = Type.Nota, maxLines = 1)
                }
            }
        }
    }
    open?.let { a -> AssetDialog(vm, a, onClose = { open = null }, onStudio = { open = null; onStudio() }) }
}

@Composable
private fun AssetDialog(vm: ImagingViewModel, a: VisualAssetEntity, onClose: () -> Unit, onStudio: () -> Unit) {
    val meta by produceState<ImageMetaEntity?>(null, a.id) { value = vm.metaOf(a.id) }
    val characters by vm.characters.collectAsState()
    var kind by remember(a.id) { mutableStateOf(a.kind) }
    var charId by remember(a.id) { mutableStateOf(a.characterId) }
    var location by remember(a.id) { mutableStateOf(a.locationRef) }
    var emotion by remember(a.id) { mutableStateOf(a.emotion) }
    var label by remember(a.id) { mutableStateOf(a.label) }
    var confirm by remember { mutableStateOf(false) }
    InkDialog(AssetKind.label(a.kind), onClose) {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
            PortraitImage(vm.store, a.file, a.label, Modifier.fillMaxWidth().aspectRatio(0.8f), maxSide = 1024)
            val m = meta
            if (m != null) {
                BasicText("Generada en el teléfono · ${m.engineId} ${m.engineVersion.take(8)} · ${m.modelName}" + if (m.loraName.isNotBlank()) " + ${m.loraName}" else "", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 8.dp))
                BasicText("${m.width}×${m.height} · ${m.steps} pasos · CFG ${m.cfg} · ${m.sampler} · semilla ${m.seed} · ${m.durationMs / 1000} s · preajuste ${m.preset}", style = Type.Nota)
                BasicText("Prompt: ${m.prompt}", style = Type.Nota)
            } else BasicText("Importada por ti (sin parámetros de generación).", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
            LabeledField("Nombre", label, { label = it })
            BasicText("Guardar como", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
            ChipFlow(AssetKind.ALL, { it == kind }, { AssetKind.label(it) }, { kind = it })
            BasicText("Personaje", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
            ChipFlow(listOf(0L) + characters.map { it.id }, { (it == 0L && charId == null) || it == charId }, { id -> if (id == 0L) "Ninguno" else characters.firstOrNull { it.id == id }?.name ?: "?" }, { id -> charId = id.takeIf { it != 0L } }, perRow = 3)
            if (kind == AssetKind.FONDO || kind == AssetKind.ILUSTRACION) LabeledField("Localización", location, { location = it })
            if (kind == AssetKind.EXPRESION || kind == AssetKind.RETRATO) { BasicText("Emoción", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp)); ChipFlow(listOf("") + Emotion.ALL, { it == emotion }, { if (it.isEmpty()) "Ninguna" else Emotion.label(it) }, { emotion = it }) }
        }
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InkButton("Guardar cambios", { vm.reassign(a, kind, charId, location, emotion, label); onClose() })
            if (meta != null) InkButton("Reutilizar en el estudio", { vm.reuseParams(meta!!, kind); onStudio() }, primary = false)
        }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InkLink("Eliminar", { confirm = true }, danger = true)
            InkLink("Cerrar", onClose)
        }
    }
    if (confirm) InkDialog("Eliminar recurso", { confirm = false }) {
        BasicText("Se borra la imagen de la app. Si la usa una escena, se mostrará una alternativa neutral.", style = Type.Cuerpo)
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Eliminar", { vm.deleteAsset(a); confirm = false; onClose() }, danger = true)
            InkButton("Cancelar", { confirm = false }, primary = false)
        }
    }
}
