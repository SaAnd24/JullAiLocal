package com.jullai.local.discovery

import com.jullai.local.story.TextNorm
import com.jullai.local.world.WikiParse

object PageRole {
    const val PRINCIPAL = "PRINCIPAL"
    const val LISTA = "LISTA"
    const val PERSONAJE = "PERSONAJE"
    const val LUGAR = "LUGAR"
}

/** Una página concreta de una wiki. */
data class PageRef(val api: String, val title: String, val role: String)

data class PlannedCharacter(val name: String, val aliases: List<String>, val tier: Int, val pages: List<PageRef>, val actor: String, val fromList: Boolean)

/** Lo que la investigación automática va a consultar. Nada aquí se ha descargado todavía salvo lo imprescindible para planificar. */
class DiscoveryPlan(
    val identity: WorkIdentity,
    val fandomApi: String?,
    val lorePages: List<PageRef>,
    val characters: List<PlannedCharacter>,
    val places: List<PageRef>,
    val notes: List<String>,
    /** Hubo fallos temporales (red, saturación): conviene reintentar más tarde si el plan salió pobre. */
    val hadRetryableFailure: Boolean,
)

/**
 * Descubre por sí sola dónde está la información de una obra: artículos de Wikipedia, la wiki de Fandom correspondiente (validada en vivo),
 * listados de personajes y categorías de personajes y lugares. No hace scraping ni usa buscadores: solo APIs de MediaWiki/Wikidata de la lista cerrada.
 * Cada paso es independiente: si uno falla, los demás siguen y el motivo queda en [DiscoveryPlan.notes].
 */
class SourcePlanner(private val client: WikiClient) {
    private val notes = ArrayList<String>()
    private var retryable = false

    private suspend fun <T> safe(what: String, block: suspend () -> T): T? = try { block() } catch (e: WikiFetchException) {
        if (e.retryable) retryable = true
        notes.add("$what: ${e.message}")
        null
    }

    suspend fun plan(identity: WorkIdentity, depth: String, langs: List<String>): DiscoveryPlan {
        notes.clear(); retryable = false
        notes.addAll(identity.notes)
        val lore = ArrayList<PageRef>()

        // 1) Artículos de Wikipedia (idiomas preferidos que existan).
        val wpOrder = (langs + identity.wikipedia.keys).distinct().filter { it in identity.wikipedia }.take(2)
        for (l in wpOrder) lore.add(PageRef(WikiHosts.wikipedia(l), identity.wikipedia.getValue(l), PageRole.PRINCIPAL))
        val mainWp = lore.firstOrNull()

        // 2) Wiki de Fandom (se prueba y se valida; nunca se da por supuesta).
        val fandom = findFandom(identity)
        if (fandom == null) notes.add("No se encontró una wiki de Fandom para esta obra: se usará solo Wikipedia (puedes añadir una wiki a mano).")
        if (fandom != null && fandom.second.isNotBlank()) lore.add(PageRef(fandom.first, fandom.second, PageRole.PRINCIPAL))

        // 3) Listados de personajes en Wikipedia.
        val listPages = ArrayList<PageRef>()
        for (l in wpOrder) {
            val api = WikiHosts.wikipedia(l)
            val term = if (l == "es") "personajes de ${identity.title}" else "${identity.title} characters"
            val titles = safe("Búsqueda de listados de personajes ($l)") { WikiParsers.searchTitles(client.api(api, WikiQuery.searchTitles(term, 6))) }.orEmpty()
            val keyTokens = TextNorm.tokens(identity.title)
            for (t in titles) {
                val f = TextNorm.fold(t)
                if (!(f.contains("character") || f.contains("personaje"))) continue
                if (keyTokens.isNotEmpty() && keyTokens.count { f.contains(it) } * 2 < keyTokens.size) continue
                if (listPages.none { it.title == t }) listPages.add(PageRef(api, t, PageRole.LISTA))
                if (listPages.count { it.api == api } >= 2) break
            }
        }
        lore.addAll(listPages)

        // 4) Nombres de personajes de varias fuentes, en orden de prioridad.
        val limit = CharacterNames.limitFor(depth)
        val lists = ArrayList<List<CharacterCandidate>>()
        if (fandom != null) lists.add(fandomCategories(fandom.first, depth))
        for (lp in listPages) {
            val secs = safe("Secciones de «${lp.title}»") { WikiParsers.sections(client.api(lp.api, WikiQuery.sections(lp.title))) }.orEmpty()
            lists.add(CharacterNames.fromSections(secs, source = "listado"))
        }
        if (mainWp != null) {
            val text = safe("Texto del artículo «${mainWp.title}»") { WikiParse.extractPages(client.api(mainWp.api, WikiQuery.articleText(mainWp.title))).firstOrNull()?.text }
            if (text != null) lists.add(CharacterNames.fromCastText(text, source = "reparto"))
        }
        if (identity.wikidataCharacters.isNotEmpty()) lists.add(CharacterNames.fromTitles(identity.wikidataCharacters, 1, source = "wikidata"))
        val merged = CharacterNames.merge(lists).take(limit * 3)

        // 5) ¿Qué personajes tienen página propia? (se comprueba; no se supone). Los demás solo valen si salen de un listado o del reparto.
        val pagesByName = HashMap<String, MutableList<PageRef>>()
        if (merged.isNotEmpty()) {
            if (fandom != null) existing(fandom.first, merged.map { it.name })?.let { m -> for ((n, t) in m) pagesByName.getOrPut(n) { ArrayList() }.add(PageRef(fandom.first, t, PageRole.PERSONAJE)) }
            val wp = mainWp?.api
            if (wp != null) {
                val rest = merged.filter { it.name !in pagesByName && it.name.trim().contains(' ') }.map { it.name }
                if (rest.isNotEmpty()) existing(wp, rest)?.let { m -> for ((n, t) in m) pagesByName.getOrPut(n) { ArrayList() }.add(PageRef(wp, t, PageRole.PERSONAJE)) }
            }
        }
        val planned = merged.mapNotNull { c ->
            val pages = pagesByName[c.name].orEmpty()
            val fromList = c.sources.any { it == "listado" || it == "reparto" }
            if (pages.isEmpty() && !fromList) null else PlannedCharacter(c.name, c.aliases, c.tier, pages, c.actor, fromList && pages.isEmpty())
        }.take(limit)
        if (planned.isEmpty()) notes.add("No se pudo identificar ningún personaje automáticamente. Puedes escribir sus nombres en «Personajes prioritarios» o añadir una wiki.")

        // 6) Lugares (categorías de la wiki de Fandom).
        val places = ArrayList<PageRef>()
        if (fandom != null) {
            val max = when (depth) { "PROFUNDA" -> 20; "MEDIA" -> 8; else -> 3 }
            for (cat in listOf("Locations", "Places", "Lugares", "Ubicaciones")) {
                if (places.size >= max) break
                val titles = safe("Categoría «$cat»") { WikiParsers.categoryMembers(client.api(fandom.first, WikiQuery.categoryMembers(cat, max))) }.orEmpty()
                for (t in titles) { if (places.size < max && CharacterNames.looksLikeTitleOfCharacter(t) && places.none { it.title == t }) places.add(PageRef(fandom.first, t, PageRole.LUGAR)) }
            }
        }
        return DiscoveryPlan(identity, fandom?.first, lore, planned, places, notes.toList().distinct(), retryable)
    }

    /** Busca una wiki de Fandom válida: primero la que declara Wikidata, luego variantes del título. Devuelve (api, título de portada) o null. */
    private suspend fun findFandom(identity: WorkIdentity): Pair<String, String>? {
        val subs = ArrayList<String>()
        if (identity.fandomSub.isNotBlank()) subs.add(identity.fandomSub)
        subs.addAll(WikiHosts.fandomGuesses(identity.title))
        for (sub in subs.distinct().take(5)) {
            val api = WikiHosts.fandom(sub) ?: continue
            val ok = try {
                val info = client.api(api, WikiQuery.siteInfo())
                WikiParsers.apiError(info) == null && com.jullai.local.world.WikiParse.siteInfo(info)?.siteName?.isNotBlank() == true
            } catch (e: WikiFetchException) { if (e.retryable) retryable = true; false }
            if (!ok) continue
            // La wiki existe, pero ¿es de esta obra? Debe tener una página que se parezca al título.
            val hit = safe("Búsqueda en $sub.fandom.com") { WikiParsers.searchTitles(client.api(api, WikiQuery.searchTitles(identity.fandomTitle.ifBlank { identity.title }, 5))) }.orEmpty()
                .map { it to TextNorm.similarity(it, identity.fandomTitle.ifBlank { identity.title }) }.filter { it.second >= 0.34 }.maxByOrNull { it.second }
            if (hit != null || identity.fandomSub == sub) return api to (hit?.first ?: identity.fandomTitle)
            notes.add("La wiki $sub.fandom.com existe pero no parece ser de «${identity.title}»; se descarta.")
        }
        return null
    }

    private suspend fun fandomCategories(api: String, depth: String): List<CharacterCandidate> {
        val per = when (depth) { "PROFUNDA" -> 80; "MEDIA" -> 50; else -> 30 }
        val out = ArrayList<List<CharacterCandidate>>()
        var order = 0
        for ((cat, tier) in listOf("Main characters" to 0, "Main Characters" to 0, "Protagonists" to 0, "Personajes principales" to 0, "Supporting characters" to 1, "Recurring characters" to 1, "Characters" to 3, "Personajes" to 3)) {
            val titles = safe("Categoría «$cat»") { WikiParsers.categoryMembers(client.api(api, WikiQuery.categoryMembers(cat, per))) }.orEmpty()
            if (titles.isEmpty()) continue
            val c = CharacterNames.fromTitles(titles, tier, order, "fandom:$cat")
            order += c.size
            out.add(c)
        }
        return CharacterNames.merge(out)
    }

    /** nombre pedido → título real, solo de páginas que existen y no son desambiguaciones. */
    private suspend fun existing(api: String, names: List<String>): Map<String, String>? {
        val out = LinkedHashMap<String, String>()
        for (chunk in names.chunked(50)) {
            val json = safe("Comprobación de páginas en ${api.substringAfter("https://").substringBefore("/")}") { client.api(api, WikiQuery.exists(chunk)) } ?: continue
            val m = WikiParsers.existingTitles(json)
            for (n in chunk) m[n]?.let { out[n] = it } ?: m[n.replace(' ', '_')]?.let { out[n] = it }
        }
        return out
    }
}
