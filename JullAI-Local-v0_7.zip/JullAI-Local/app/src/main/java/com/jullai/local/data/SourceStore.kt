package com.jullai.local.data

import java.io.File
import java.util.UUID

/**
 * Texto extraído de las fuentes (ya en texto plano y recortado). Vive en el almacenamiento privado de la app, NO en la base de datos,
 * y NO se incluye en .worldpack ni en .jullai (no se redistribuyen textos de terceros).
 */
class SourceStore(private val dir: File) {
    private fun file(name: String): File {
        require(name.isNotEmpty() && !name.contains('/') && !name.contains('\\') && !name.contains("..")) { "Nombre de archivo de fuente no válido." }
        dir.mkdirs()
        return File(dir, name)
    }

    fun save(text: String): String {
        val name = "s_" + UUID.randomUUID().toString().replace("-", "") + ".txt"
        file(name).writeText(text, Charsets.UTF_8)
        return name
    }

    fun read(name: String?): String? = if (name == null) null else runCatching { file(name).takeIf { it.exists() }?.readText(Charsets.UTF_8) }.getOrNull()

    fun delete(name: String?) { if (name != null) runCatching { file(name).delete() } }
}
