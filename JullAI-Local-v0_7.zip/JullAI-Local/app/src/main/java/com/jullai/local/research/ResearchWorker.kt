package com.jullai.local.research

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.jullai.local.JullApp
import com.jullai.local.world.TaskStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit

/**
 * Ejecuta una tarea de investigación con WorkManager: sobrevive a cierres de la app y se reanuda sola si Android lo permite.
 * Requiere conexión. Android decide CUÁNDO se ejecuta (ahorro de batería, Doze): la interfaz lo explica y muestra el estado real.
 * No es un servicio en primer plano: si la tarea es larga, mantener la app abierta ayuda a que termine antes.
 */
class ResearchWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val taskId = inputData.getLong(KEY_TASK, -1L)
        if (taskId < 0) return Result.failure()
        val container = (applicationContext as JullApp).container
        val outcome = container.researchEngine.run(taskId)
        return if (outcome.retry) Result.retry() else Result.success()
    }

    companion object {
        const val KEY_TASK = "taskId"
        fun uniqueName(taskId: Long) = "research-$taskId"
    }
}

/** Planifica, cancela y reanuda tareas. Es la única puerta de entrada para lanzar investigaciones. */
class ResearchManager(private val context: Context, private val container: com.jullai.local.AppContainer) {
    private val wm: WorkManager get() = WorkManager.getInstance(context)

    /** Crea la tarea (si no hay otra activa para ese mundo) y la planifica. Devuelve su id. */
    suspend fun start(worldId: Long): Long {
        container.worldRepository.activeTask(worldId)?.let { enqueue(it.id); return it.id }
        val id = container.worldRepository.createTask(worldId)
        enqueue(id)
        return id
    }

    private suspend fun enqueue(taskId: Long) {
        val req = OneTimeWorkRequestBuilder<ResearchWorker>()
            .setInputData(workDataOf(ResearchWorker.KEY_TASK to taskId))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        wm.enqueueUniqueWork(ResearchWorker.uniqueName(taskId), ExistingWorkPolicy.KEEP, req)
        container.worldRepository.task(taskId)?.let { container.worldRepository.saveTask(it.copy(workId = req.id.toString(), status = TaskStatus.PENDIENTE, note = "En cola: Android la ejecutará cuando haya conexión y recursos.")) }
    }

    /** Cancela: marca la tarea como CANCELADA (el motor lo comprueba entre fuentes) y cancela el trabajo planificado. */
    suspend fun cancel(taskId: Long) {
        val t = container.worldRepository.task(taskId) ?: return
        if (!TaskStatus.isFinal(t.status)) container.worldRepository.saveTask(t.copy(status = TaskStatus.CANCELADA, phase = com.jullai.local.world.ResearchPhase.FIN, note = "Cancelada por el usuario.", finishedAt = System.currentTimeMillis()))
        wm.cancelUniqueWork(ResearchWorker.uniqueName(taskId))
    }

    /** Reintenta una tarea terminada con error/sin resultados creando otra nueva (las fuentes ya procesadas no se repiten). */
    suspend fun retry(worldId: Long): Long = start(worldId)

    /** Al abrir la app: vuelve a planificar las tareas que quedaron pendientes o en curso por una interrupción. */
    suspend fun resumePending() {
        for (t in container.worldRepository.unfinishedTasks()) enqueue(t.id)
    }

    /** Estado de WorkManager traducido a un aviso comprensible (aplazada, esperando red, en curso...). */
    fun workNote(taskId: Long): Flow<String> = wm.getWorkInfosForUniqueWorkFlow(ResearchWorker.uniqueName(taskId)).map { infos ->
        when (infos.firstOrNull()?.state) {
            WorkInfo.State.ENQUEUED -> "Android la tiene en cola y decide cuándo ejecutarla: necesita conexión y puede aplazarla por ahorro de batería. Mantener la app abierta ayuda."
            WorkInfo.State.RUNNING -> "Ejecutándose ahora."
            WorkInfo.State.BLOCKED -> "Bloqueada, esperando a otra tarea."
            WorkInfo.State.SUCCEEDED -> "El trabajo terminó."
            WorkInfo.State.FAILED -> "El trabajo falló."
            WorkInfo.State.CANCELLED -> "El trabajo se canceló."
            null -> "Sin trabajo planificado."
        }
    }
}
