package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.MessageRole
import com.jullai.local.data.MessageState
import com.jullai.local.data.RoleMessageEntity
import com.jullai.local.data.RoleSessionEntity
import com.jullai.local.engine.EngineState
import com.jullai.local.roleplay.KnowledgeScope
import com.jullai.local.roleplay.Macros
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.RpText
import com.jullai.local.roleplay.StoryViewModel
import com.jullai.local.roleplay.Swipes
import kotlinx.coroutines.launch

private fun styled(text: String): AnnotatedString = buildAnnotatedString {
    for (sp in RpText.spans(text)) {
        when {
            sp.italic -> withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = Ink.MarfilTenue)) { append(sp.text) }
            sp.bold -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(sp.text) }
            else -> append(sp.text)
        }
    }
}

@Composable
fun RoleplayScreen(vm: RoleplayViewModel, story: StoryViewModel, sessionId: Long, onBack: () -> Unit) {
    LaunchedEffect(sessionId) { vm.open(sessionId); story.open(sessionId) }

    val sessionState by vm.session.collectAsState()
    val character by vm.character.collectAsState()
    val allMessages by vm.messages.collectAsState()
    val gen by vm.gen.collectAsState()
    val stream by vm.stream.collectAsState()
    val editing by vm.editing.collectAsState()
    val engineState by vm.engineState.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val loading by vm.busyLoading.collectAsState()
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val session: RoleSessionEntity? = sessionState?.takeIf { it.id == sessionId }
    val shown = remember(allMessages, sessionId) { allMessages.filter { it.sessionId == sessionId }.asReversed() }
    val hasUserMessage = remember(allMessages) { allMessages.any { it.role == MessageRole.USER } }

    var input by rememberSaveable(sessionId) { mutableStateOf("") }
    var panel by rememberSaveable { mutableStateOf(false) }
    var editingAssistant by remember { mutableStateOf<RoleMessageEntity?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val saved = remember(sessionId) { vm.scrollFor(sessionId) }
    val listState = rememberLazyListState(saved.first, saved.second)
    val atNewest by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0 } }
    DisposableEffect(sessionId) {
        onDispose { vm.saveScroll(sessionId, listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }
    LaunchedEffect(shown.firstOrNull()?.id) { if (listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0) }
    LaunchedEffect(editing?.id) { editing?.let { input = it.content } }

    val busy = gen.messageId != null
    val generating = engineState == EngineState.GENERATING

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader(
                title = session?.title ?: "Partida",
                onBack = onBack,
                trailing = { InkLink("Ficha ▸", { panel = true }) },
            )
            val status = when {
                loading != null -> loading!!
                generating -> "Motor: generando…"
                loaded != null -> "Motor listo · ${loaded!!.model.displayName} · contexto ${loaded!!.contextLength}"
                busy -> gen.phase
                else -> "Modelo sin cargar: se cargará al enviar tu primer mensaje."
            }
            Row(Modifier.fillMaxWidth().background(Ink.Pizarra).padding(horizontal = 16.dp, vertical = 6.dp)) {
                BasicText(status + if (busy && !generating && loading == null) " · ${gen.phase}" else "", style = Type.Nota)
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (session == null || character == null) {
                    BasicText("Cargando…", style = Type.Nota, modifier = Modifier.padding(20.dp))
                } else if (shown.isEmpty()) {
                    BasicText("Esta partida no tiene saludo. Escribe tú el primer mensaje para empezar la escena.", style = Type.Cuerpo.copy(color = Ink.MarfilTenue), modifier = Modifier.padding(20.dp))
                }
                LazyColumn(
                    state = listState, reverseLayout = true, modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    items(shown, key = { it.id }) { m ->
                        val isLast = m.id == shown.firstOrNull()?.id
                        val active = gen.messageId == m.id || (busy && m.state == MessageState.GENERATING)
                        val body = if (stream?.messageId == m.id) stream!!.text else m.content
                        val ch = character
                        val s = session
                        if (ch != null && s != null) {
                            RpMessageItem(
                                m = m, text = body, active = active, canAct = !busy, isLast = isLast, hasUserMessage = hasUserMessage,
                                charName = ch.name, userName = s.userName, portraitFile = ch.portraitFile, vm = vm,
                                onCopy = { clipboard.setText(AnnotatedString(body)) },
                                onEditUser = { vm.startEdit(m) },
                                onEditAssistant = { editingAssistant = m },
                                onRegenerate = { vm.regenerate() },
                                onContinue = { vm.continueReply() },
                                onSwipe = { vm.swipe(it) },
                                onDeleteLast = { vm.deleteLast() },
                            )
                        }
                    }
                }
                if (!atNewest) {
                    Box(Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                        InkButton("↓ Recientes", { scope.launch { listState.animateScrollToItem(0) } })
                    }
                }
            }

            gen.error?.let { msg ->
                Row(Modifier.fillMaxWidth().background(Ink.Pizarra).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        BasicText(msg, style = Type.Nota.copy(color = Ink.Granate))
                        BasicText("Tu historia está a salvo. Puedes reintentar con «Regenerar».", style = Type.Nota)
                    }
                    InkLink("Cerrar", { vm.dismissError() })
                }
            }
            if (gen.stats.isNotBlank() && !busy) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp)) { BasicText(gen.stats, style = Type.Mono) }
            }
            editing?.let {
                Row(Modifier.fillMaxWidth().background(Ink.Pizarra).padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        BasicText("Editando tu mensaje: al enviarlo se descartan los mensajes posteriores y se genera una respuesta nueva.", style = Type.Nota.copy(color = Ink.Oro))
                    }
                    InkLink("Cancelar", { vm.cancelEdit(); input = "" })
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
                InkField(
                    value = input, onChange = { input = it },
                    placeholder = "Escribe lo que haces o dices… (*acciones* entre asteriscos)",
                    modifier = Modifier.weight(1f), minHeight = 24, maxHeight = 140, enabled = !busy,
                )
                Spacer(Modifier.width(8.dp))
                if (busy) {
                    InkButton("Detener", { vm.stop() }, primary = false)
                } else {
                    InkButton(
                        "Enviar",
                        { val t = input; input = ""; vm.send(t); scope.launch { listState.animateScrollToItem(0) } },
                        enabled = input.isNotBlank() && session != null,
                    )
                }
            }
        }

        if (panel && session != null && character != null) {
            SidePanel(vm, story, session, character!!, busy, onClose = { panel = false }, onRename = { renaming = true }, onDelete = { deleting = true })
        }
    }

    editingAssistant?.let { m ->
        var text by remember(m.id) { mutableStateOf(m.content) }
        InkDialog("Editar respuesta", { editingAssistant = null }) {
            InkField(text, { text = it }, "Texto", Modifier.fillMaxWidth(), minHeight = 80, maxHeight = 300)
            BasicText("Cambia solo esta respuesta (la alternativa que ves ahora). No se genera nada nuevo.", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Guardar", { vm.editAssistant(m, text); editingAssistant = null }, enabled = text.isNotBlank())
                InkButton("Cancelar", { editingAssistant = null }, primary = false)
            }
        }
    }
    if (renaming && session != null) {
        RenameDialog(session.title, { renaming = false }, { vm.rename(session.id, it); renaming = false }, what = "partida")
    }
    if (deleting && session != null) {
        ConfirmDeleteDialog(session.title, { deleting = false }, { deleting = false; vm.delete(session.id) { onBack() } }, what = "partida")
    }
}

@Composable
private fun RpMessageItem(
    m: RoleMessageEntity, text: String, active: Boolean, canAct: Boolean, isLast: Boolean, hasUserMessage: Boolean,
    charName: String, userName: String, portraitFile: String?, vm: RoleplayViewModel,
    onCopy: () -> Unit, onEditUser: () -> Unit, onEditAssistant: () -> Unit, onRegenerate: () -> Unit, onContinue: () -> Unit,
    onSwipe: (Int) -> Unit, onDeleteLast: () -> Unit,
) {
    val isUser = m.role == MessageRole.USER
    val shape = RoundedCornerShape(8.dp)
    Row(Modifier.padding(vertical = 6.dp).fillMaxWidth().background(if (isUser) Ink.Pizarra else Ink.Tinta, shape).padding(10.dp)) {
        if (!isUser) {
            PortraitImage(vm.portraitStore, portraitFile, charName, Modifier.width(44.dp).height(60.dp), maxSide = 128)
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            BasicText(if (isUser) userName else charName, style = Type.Nota.copy(color = if (isUser) Ink.Oro else Ink.Granate))
            SelectionContainer {
                BasicText(
                    if (text.isEmpty()) AnnotatedString(if (active) "…" else "(sin texto)") else styled(text),
                    style = Type.Cuerpo, modifier = Modifier.padding(top = 4.dp),
                )
            }
            if (!isUser && !active) {
                when (m.state) {
                    MessageState.INTERRUPTED, MessageState.GENERATING ->
                        BasicText("⚠ Respuesta interrumpida (se conserva el texto parcial).", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 6.dp))
                    MessageState.ERROR ->
                        BasicText("⚠ Error al generar esta respuesta.", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 6.dp))
                }
            }
            val (items, idx) = remember(m.content, m.swipes, m.swipeIndex) { Swipes.effective(m.content, m.swipes, m.swipeIndex) }
            Row(Modifier.padding(top = 6.dp)) {
                InkLink("Copiar", onCopy, enabled = text.isNotEmpty())
                if (isUser) InkLink("Editar", onEditUser, enabled = canAct)
                if (!isUser) InkLink("Editar", onEditAssistant, enabled = canAct && !active)
                if (isLast && !isUser && items.size > 1) {
                    InkLink("‹", { onSwipe(-1) }, enabled = canAct && idx > 0)
                    Box(Modifier.padding(vertical = 6.dp)) { BasicText("${idx + 1}/${items.size}", style = Type.Nota) }
                    InkLink("›", { onSwipe(1) }, enabled = canAct && idx < items.size - 1)
                }
            }
            if (isLast) {
                Row {
                    if (!isUser && hasUserMessage) {
                        InkLink("Regenerar", onRegenerate, enabled = canAct)
                        InkLink("Continuar", onContinue, enabled = canAct && m.content.isNotBlank())
                    }
                    InkLink("Borrar", onDeleteLast, enabled = canAct, danger = true)
                }
            }
        }
    }
}

// ======================= Panel lateral =======================

@Composable
private fun SidePanel(
    vm: RoleplayViewModel, story: StoryViewModel, session: RoleSessionEntity, ch: CharacterEntity, busy: Boolean,
    onClose: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    Box(Modifier.fillMaxSize().background(Ink.Tinta.copy(alpha = 0.6f)).clickable(onClick = onClose)) {
        Column(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.94f)
                .background(Ink.Tinta).clickable(enabled = false) {},
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                    listOf("Ficha", "Escena", "Memoria", "Relaciones", "Capítulos", "Saber", "Motor").forEachIndexed { i, t ->
                        InkChip(t, tab == i, { tab = i }, Modifier.padding(end = 6.dp))
                    }
                }
                InkLink("Cerrar ✕", onClose)
            }
            Divider()
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
                when (tab) {
                    0 -> SheetTab(vm, ch, session.userName)
                    1 -> SceneTab(vm, story, session, busy)
                    2 -> MemoryTab(story, session, vm.recalled.collectAsState().value, busy)
                    3 -> RelationsTab(story, session, ch.name)
                    4 -> ChaptersTab(story, session, busy)
                    5 -> KnowledgeTab(vm, session)
                    else -> EngineTab(vm, session, busy, onRename, onDelete)
                }
                Box(Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun SheetTab(vm: RoleplayViewModel, ch: CharacterEntity, userName: String) {
    PortraitImage(vm.portraitStore, ch.portraitFile, ch.name, Modifier.fillMaxWidth().aspectRatio(0.8f), maxSide = 768)
    BasicText(ch.name, style = Type.Titulo, modifier = Modifier.padding(top = 10.dp))
    fun m(s: String) = Macros.apply(s, ch.name, userName)
    @Composable fun block(label: String, v: String) {
        if (v.isBlank()) return
        BasicText(label, style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
        SelectionContainer { BasicText(m(v), style = Type.Cuerpo) }
    }
    if (ch.aliases.isNotBlank()) block("Alias", ch.aliases.lines().filter { it.isNotBlank() }.joinToString(", "))
    block("Descripción", ch.appearance)
    block("Personalidad", ch.personality)
    block("Forma de hablar", ch.speechStyle)
    block("Historia", ch.history)
    block("Motivaciones", ch.motivations)
    block("Gustos y aversiones", ch.likesDislikes)
    block("Relación inicial", ch.initialRelationship)
    block("Instrucciones de comportamiento", ch.behaviorInstructions)
    BasicText("La ficha se edita desde Personajes → Editar. Las notas privadas del creador nunca se muestran aquí ni se envían al modelo.", style = Type.Nota, modifier = Modifier.padding(top = 14.dp))
}

@Composable
private fun SceneTab(vm: RoleplayViewModel, story: StoryViewModel, s: RoleSessionEntity, busy: Boolean) {
    var scenario by remember(s.id) { mutableStateOf(s.scenarioText) }
    var rules by remember(s.id) { mutableStateOf(s.narrativeRules) }
    var summary by remember(s.id) { mutableStateOf(s.summary) }
    var userName by remember(s.id) { mutableStateOf(s.userName) }
    var persona by remember(s.id) { mutableStateOf(s.userPersona) }
    val dirty = scenario != s.scenarioText || rules != s.narrativeRules || summary != s.summary || userName != s.userName || persona != s.userPersona
    LabeledField("Escenario actual", scenario, { scenario = it }, minHeight = 60, hint = "Cámbialo cuando la escena cambie.")
    LabeledField("Reglas narrativas activas", rules, { rules = it }, minHeight = 60, maxHeight = 260)
    LabeledField("Resumen de lo ocurrido", summary, { summary = it }, minHeight = 60, maxHeight = 260,
        hint = "Cada vez que lo guardas se crea una versión (ver pestaña Memoria). También puedes pedir un borrador al modelo allí.")
    LabeledField("Tu nombre", userName, { userName = it }, minHeight = 24)
    LabeledField("Tu personaje", persona, { persona = it }, minHeight = 44, maxHeight = 140)
    Box(Modifier.padding(top = 12.dp)) {
        InkButton(
            "Guardar escena",
            { vm.saveScene(summary) { it.copy(scenarioText = scenario, narrativeRules = rules, userName = userName.trim().ifBlank { it.userName }, userPersona = persona) } },
            enabled = dirty && !busy,
        )
    }
}

@Composable
private fun KnowledgeTab(vm: RoleplayViewModel, s: RoleSessionEntity) {
    val items by vm.knowledge.collectAsState()
    var scope by rememberSaveable { mutableStateOf(KnowledgeScope.FACT) }
    var text by remember(s.id) { mutableStateOf("") }
    BasicText(
        "Separa quién sabe qué. Cada bloque llega al modelo con su propia etiqueta, así un secreto no se convierte en conocimiento de todos.",
        style = Type.Nota,
    )
    KnowledgeScope.DISPLAY.forEach { sc ->
        val list = items.filter { it.scope == sc }
        if (list.isNotEmpty()) {
            BasicText(KnowledgeScope.shortLabel(sc), style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 12.dp))
            list.forEach { it ->
                Row(Modifier.fillMaxWidth().padding(top = 4.dp).background(Ink.Pizarra, RoundedCornerShape(6.dp)).padding(10.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.weight(1f)) { SelectionContainer { BasicText(it.text, style = Type.Cuerpo) } }
                    InkLink("Quitar", { vm.deleteKnowledge(it.id) }, danger = true)
                }
            }
        }
    }
    BasicText("Añadir", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 18.dp))
    Column(Modifier.padding(top = 6.dp)) {
        KnowledgeScope.DISPLAY.chunked(3).forEach { row ->
            Row(Modifier.padding(bottom = 6.dp)) { row.forEach { sc -> InkChip(KnowledgeScope.shortLabel(sc), scope == sc, { scope = sc }, Modifier.padding(end = 6.dp)) } }
        }
    }
    InkField(text, { text = it }, "Escribe un dato breve y concreto", Modifier.fillMaxWidth().padding(top = 4.dp), minHeight = 44, maxHeight = 140)
    Box(Modifier.padding(top = 8.dp)) { InkButton("Añadir", { vm.addKnowledge(scope, text); text = "" }, enabled = text.isNotBlank()) }
}

@Composable
private fun EngineTab(vm: RoleplayViewModel, s: RoleSessionEntity, busy: Boolean, onRename: () -> Unit, onDelete: () -> Unit) {
    val models by vm.models.collectAsState()
    val report by vm.report.collectAsState()
    BasicText("Modelo de esta partida", style = Type.Nota)
    if (models.isEmpty()) BasicText("No hay modelos importados. Ve a Biblioteca → Modelos.", style = Type.Cuerpo.copy(color = Ink.Oro))
    models.forEach { mo ->
        val selected = s.modelFileName == mo.fileName
        Box(
            Modifier.padding(top = 4.dp).fillMaxWidth().background(if (selected) Ink.Pizarra else Ink.Tinta, RoundedCornerShape(6.dp))
                .clickable(enabled = !busy) { vm.updateSession { it.copy(modelFileName = mo.fileName) } }.padding(10.dp),
        ) { BasicText(mo.displayName + if (selected) "  ✓" else "", style = Type.Cuerpo.copy(color = if (selected) Ink.Oro else Ink.Marfil)) }
    }
    Stepper("Temperatura", "%.1f".format(s.temperature),
        { vm.updateSession { it.copy(temperature = (Math.round(it.temperature * 10) - 1).coerceAtLeast(0) / 10f) } },
        { vm.updateSession { it.copy(temperature = (Math.round(it.temperature * 10) + 1).coerceAtMost(20) / 10f) } }, enabled = !busy)
    Stepper("Top-p", "%.2f".format(s.topP),
        { vm.updateSession { it.copy(topP = (Math.round(it.topP * 20) - 1).coerceAtLeast(2) / 20f) } },
        { vm.updateSession { it.copy(topP = (Math.round(it.topP * 20) + 1).coerceAtMost(20) / 20f) } }, enabled = !busy)
    Stepper("Máx. tokens de respuesta", "${s.maxTokens}",
        { vm.updateSession { it.copy(maxTokens = (it.maxTokens - 64).coerceAtLeast(16)) } },
        { vm.updateSession { it.copy(maxTokens = (it.maxTokens + 64).coerceAtMost(2048)) } }, enabled = !busy)
    Stepper("Contexto (tokens)", "${s.contextLength}",
        { vm.updateSession { it.copy(contextLength = (it.contextLength - 512).coerceAtLeast(512)) } },
        { vm.updateSession { it.copy(contextLength = (it.contextLength + 512).coerceAtMost(8192)) } }, enabled = !busy)
    BasicText("Cambiar modelo o contexto recarga el modelo al enviar el siguiente mensaje.", style = Type.Nota)

    SectionTitle("Último contexto enviado")
    SelectionContainer { BasicText(report, style = Type.Mono) }

    Row(Modifier.padding(top = 16.dp)) {
        InkLink("Renombrar partida", onRename, enabled = !busy)
        InkLink("Eliminar partida", onDelete, enabled = !busy, danger = true)
    }
}
