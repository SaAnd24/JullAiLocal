package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jullai.local.data.MessageRole
import com.jullai.local.data.MessageState
import com.jullai.local.data.RoleMessageEntity
import com.jullai.local.data.SceneMetaEntity
import com.jullai.local.engine.EngineState
import com.jullai.local.imaging.IllustrationContext
import com.jullai.local.imaging.IllustrationMode
import com.jullai.local.imaging.IllustrationPolicy
import com.jullai.local.imaging.ImagingViewModel
import com.jullai.local.imaging.TaskStatus
import com.jullai.local.imaging.TurnMetaParser
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.StoryViewModel
import com.jullai.local.roleplay.WorldViewModel
import com.jullai.local.story.TextNorm
import com.jullai.local.world.Choices
import com.jullai.local.world.Continuity
import com.jullai.local.world.Emotion
import com.jullai.local.world.VisualEvent

/** Recursos ya resueltos de una escena. Los nulos se sustituyen por una alternativa neutral dibujada por la app. */
private class SceneFiles(val portrait: String?, val background: String?)

/**
 * Presentación de novela visual para partidas de roleplay (v0.5): fondo = localización, personaje que habla destacado,
 * panel de diálogo inferior, continuar / regenerar / historial, acciones libres y elecciones opcionales.
 * No genera imágenes: usa los retratos y fondos importados. Si falta un recurso o un metadato, la escena sigue funcionando.
 * El texto narrativo se muestra tal cual: los metadatos solo deciden qué imagen se ve.
 */
@Composable
fun VisualNovelScreen(
    vm: RoleplayViewModel, story: StoryViewModel, world: WorldViewModel, imaging: ImagingViewModel, sessionId: Long,
    onBack: () -> Unit, onClassic: () -> Unit, onPrep: () -> Unit, onStudio: () -> Unit,
) {
    LaunchedEffect(sessionId) { vm.open(sessionId); story.open(sessionId) }
    val sessionState by vm.session.collectAsState()
    val character by vm.character.collectAsState()
    val all by vm.messages.collectAsState()
    val gen by vm.gen.collectAsState()
    val stream by vm.stream.collectAsState()
    val engineState by vm.engineState.collectAsState()
    val link by world.sessionWorld(sessionId).collectAsState(initial = null)
    val session = sessionState?.takeIf { it.id == sessionId }
    val messages = remember(all, sessionId) { all.filter { it.sessionId == sessionId } }
    val busy = gen.messageId != null
    val generating = engineState == EngineState.GENERATING

    var input by rememberSaveable(sessionId) { mutableStateOf("") }
    var showHistory by rememberSaveable { mutableStateOf(false) }
    var showSheet by rememberSaveable { mutableStateOf(false) }

    val last = messages.lastOrNull { it.role == MessageRole.ASSISTANT }
    val streaming = stream?.takeIf { s -> last != null && s.messageId == last.id }?.text
    // v0.6: si un modelo/ficha escribió metadatos al final del turno, no se muestran (el texto guardado NO se modifica).
    val shownText = TurnMetaParser.parse((streaming ?: last?.content).orEmpty()).displayText
    val complete = last != null && last.state == MessageState.COMPLETE && streaming == null

    // Metadatos visuales: se calculan sin tocar el texto; si fallan, scene = null y se usa la alternativa segura.
    val scene by produceState<SceneMetaEntity?>(null, last?.id, last?.content, complete) {
        value = if (complete && last != null && character != null) world.ensureScene(sessionId, last.id, last.content, character!!.name, TextNorm.lines(character!!.aliases)) else value
    }
    val files by produceState(SceneFiles(null, null), scene?.assetRefs) {
        val refs = scene?.assetRefs.orEmpty().split(',').filter { it.isNotBlank() }
        val p = refs.firstOrNull { it.startsWith("portrait:") }?.substringAfter(':')?.toLongOrNull()?.let { world.assetFile(it) }
        val b = refs.firstOrNull { it.startsWith("background:") }?.substringAfter(':')?.toLongOrNull()?.let { world.assetFile(it) }
        value = SceneFiles(p, b)
    }
    val speaker = scene?.speaker.orEmpty()
    val speakerName = when {
        speaker.isNotBlank() -> speaker
        scene?.eventType == VisualEvent.NARRACION || last == null -> "Narrador"
        else -> character?.name ?: "Narrador"
    }
    val location = scene?.locationRef.orEmpty()
    val choices = remember(shownText, complete) { if (complete) Choices.parse(shownText) else emptyList() }
    val portraitFile = files.portrait ?: if (speakerName == character?.name) character?.portraitFile else null

    // ---- v0.6: ilustraciones guardadas en la historia + cola de imágenes ----
    val imgSettings by imaging.settings.collectAsState()
    val imgTasks by imaging.tasks.collectAsState()
    val imgMetas by imaging.metas.collectAsState()
    val imgAssets by imaging.assets.collectAsState()
    val queueRunning by imaging.queueRunning.collectAsState()
    val queueProgress by imaging.progress.collectAsState()
    var showIllustration by rememberSaveable(last?.id) { mutableStateOf(true) }
    val illustrationFile = remember(imgMetas, imgAssets, last?.id) {
        imgMetas.filter { it.sessionId == sessionId && it.messageId == last?.id && it.slot == "ILUSTRACION" }.maxByOrNull { it.assetId }?.let { m -> imgAssets.firstOrNull { it.id == m.assetId }?.file }
    }
    val illusTask = imgTasks.filter { it.sessionId == sessionId && it.messageId == last?.id && it.kind == "ILUSTRACION" }.maxByOrNull { it.id }
    val illusOpen = illusTask?.status in listOf(TaskStatus.PENDIENTE, TaskStatus.EN_CURSO, TaskStatus.APLAZADA)
    val lastIllusMsg = imgMetas.filter { it.sessionId == sessionId && it.slot == "ILUSTRACION" }.mapNotNull { it.messageId }.maxOrNull()
    val turnsSince = lastIllusMsg?.let { id -> messages.count { it.role == MessageRole.ASSISTANT && it.id > id } }
    val decision = if (complete && last != null && imgSettings.enabled) IllustrationPolicy.decide(
        imgSettings.illustrationMode, imgSettings.minGapTurns,
        IllustrationContext(scene?.important == true, illustrationFile != null, illusOpen, turnsSince, imaging.hasModel()),
    ) else IllustrationPolicy.Decision.NONE
    LaunchedEffect(last?.id, decision) {
        // Solo en modo «EQUILIBRADA» y solo en escenas importantes: se ENCOLA (no se ejecuta sola salvo que el ajuste automático esté activo).
        if (decision == IllustrationPolicy.Decision.ENQUEUE && last != null) imaging.illustrate(sessionId, last.id, shownText, location, run = false)
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Ink.Tinta)) {
        val landscape = maxWidth > maxHeight
        val maxH = maxHeight   // dentro de Column/Row no se puede llamar a maxHeight (alcance de BoxWithConstraints)
        Box(Modifier.fillMaxSize()) {
            // ---- fondo: la localización actual ----
            if (illustrationFile != null && showIllustration) PortraitImage(world.portraitStore, illustrationFile, "Ilustración de la escena", Modifier.fillMaxSize(), maxSide = 1024)
            else if (files.background != null) PortraitImage(world.portraitStore, files.background, location.ifBlank { "Fondo" }, Modifier.fillMaxSize(), maxSide = 1024)
            else Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B1822), Color(0xFF2C2733), Color(0xFF141217)))))
            if (location.isNotBlank() || files.background == null) {
                BasicText(
                    (if (location.isNotBlank()) location else "Fondo neutral (sin imagen de esta localización)"),
                    style = Type.Nota.copy(color = Ink.MarfilTenue), modifier = Modifier.align(Alignment.TopCenter).padding(top = 52.dp),
                )
            }

            val dialogue: @Composable (Modifier) -> Unit = { mod ->
                DialoguePanel(
                    modifier = mod, speaker = speakerName, text = shownText, emotion = scene?.emotion, important = scene?.important == true,
                    safeFallback = scene?.valid == false, busy = busy, generating = generating, phase = gen.phase, error = gen.error,
                    hasText = last != null, choices = choices,
                    illus = IllusUi(
                        canAsk = complete && imgSettings.enabled && !illusOpen && illustrationFile == null, suggest = decision == IllustrationPolicy.Decision.SUGGEST,
                        status = when { illusOpen && illusTask?.status == TaskStatus.EN_CURSO -> "Ilustrando${queueProgress?.let { " · paso ${it.step}/${it.steps}" }.orEmpty()}…"; illusOpen -> "Ilustración en cola (${TaskStatus.label(illusTask!!.status).lowercase()})"; illusTask?.status == TaskStatus.FALLIDA -> "La ilustración falló: ${illusTask?.error.orEmpty().take(120)}"; else -> "" },
                        shown = illustrationFile != null && showIllustration, has = illustrationFile != null,
                        onAsk = { last?.let { imaging.illustrate(sessionId, it.id, shownText, location) } },
                        onToggle = { showIllustration = !showIllustration }, onStudio = onStudio,
                    ), input = input, onInput = { input = it },
                    onSend = { if (input.isNotBlank()) { vm.send(input); input = "" } }, onChoice = { vm.send(it) },
                    onContinue = { vm.continueReply() }, onRegenerate = { vm.regenerate() }, onStop = { vm.stop() },
                    onHistory = { showHistory = true }, onSheet = { showSheet = true },
                )
            }

            if (landscape) {
                Row(Modifier.fillMaxSize().padding(top = 44.dp)) {
                    Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.BottomCenter) { SpeakerPortrait(world, portraitFile, speakerName, Modifier.size(220.dp)) }
                    dialogue(Modifier.weight(1.2f).fillMaxHeight())
                }
            } else {
                Column(Modifier.fillMaxSize().padding(top = 44.dp)) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) { SpeakerPortrait(world, portraitFile, speakerName, Modifier.fillMaxHeight(0.95f).fillMaxWidth(0.62f)) }
                    dialogue(Modifier.fillMaxWidth().heightIn(max = maxH * 0.52f))
                }
            }
            Row(Modifier.fillMaxWidth().background(Color(0xCC141217)).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                InkLink("‹ Volver", onBack)
                BasicText(session?.title ?: "Partida", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.weight(1f).padding(horizontal = 8.dp), maxLines = 1)
                InkLink("Mundo", onPrep)
            }
        }
    }

    if (showHistory) HistoryDialog(messages, character?.name ?: "Personaje", session?.userName ?: "Tú", onClose = { showHistory = false }, onClassic = { showHistory = false; onClassic() })
    if (showSheet) {
        val ch = character
        InkDialog("Ficha y datos de la partida", { showSheet = false }) {
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                BasicText(ch?.name ?: "Personaje", style = Type.Seccion)
                listOf("Apariencia" to ch?.appearance, "Personalidad" to ch?.personality, "Historia" to ch?.history).forEach { (k, v) -> if (!v.isNullOrBlank()) BasicText("$k: ${v.take(300)}", style = Type.Nota, modifier = Modifier.padding(top = 4.dp)) }
                BasicText("Tú: ${session?.userName ?: ""}", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
                link?.let { l ->
                    BasicText("Mundo: ${l.worldName.ifBlank { "(sin nombre)" }} · ${Continuity.label(l.continuityMode)}" + (if (l.worldId == null) " · el mundo ya no existe" else ""), style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 8.dp))
                } ?: BasicText("Esta partida no tiene mundo vinculado (abre «Mundo» arriba).", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
                if (!session?.summary.isNullOrBlank()) BasicText("Resumen: ${session!!.summary.take(400)}", style = Type.Nota, modifier = Modifier.padding(top = 8.dp))
            }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Memoria y relaciones", { showSheet = false; onClassic() }, primary = false)
                InkButton("Cerrar", { showSheet = false })
            }
        }
    }
}

/** Estado de la ilustración de la escena actual, ya calculado con datos reales (cola, galería, ajustes). */
private class IllusUi(
    val canAsk: Boolean, val suggest: Boolean, val status: String, val shown: Boolean, val has: Boolean,
    val onAsk: () -> Unit, val onToggle: () -> Unit, val onStudio: () -> Unit,
)

@Composable
private fun SpeakerPortrait(world: WorldViewModel, file: String?, name: String, modifier: Modifier) {
    if (file != null) PortraitImage(world.portraitStore, file, name, modifier, maxSide = 768)
    else Box(modifier.background(Color(0x332C2733)), contentAlignment = Alignment.Center) {
        // Alternativa neutral diseñada por la app (no es una imagen generada): silueta con la inicial.
        BasicText(name.trim().take(1).uppercase().ifEmpty { "·" }, style = Type.Titulo.copy(color = Ink.MarfilTenue.copy(alpha = 0.6f)))
    }
}

@Composable
private fun DialoguePanel(
    modifier: Modifier, speaker: String, text: String, emotion: String?, important: Boolean, safeFallback: Boolean,
    busy: Boolean, generating: Boolean, phase: String, error: String?, hasText: Boolean, choices: List<String>, illus: IllusUi,
    input: String, onInput: (String) -> Unit, onSend: () -> Unit, onChoice: (String) -> Unit,
    onContinue: () -> Unit, onRegenerate: () -> Unit, onStop: () -> Unit, onHistory: () -> Unit, onSheet: () -> Unit,
) {
    Column(modifier.background(Color(0xE61B1822)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicText(speaker, style = Type.Seccion, modifier = Modifier.weight(1f))
            if (!emotion.isNullOrBlank() && emotion != Emotion.NEUTRAL) BasicText(Emotion.label(emotion), style = Type.Nota)
            if (important) BasicText("  ★ escena importante", style = Type.Nota.copy(color = Ink.Oro))
        }
        Box(Modifier.weight(1f, fill = false).heightIn(min = 60.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                BasicText(if (text.isBlank() && !busy) "Escribe tu primera acción para comenzar." else text.ifBlank { "…" }, style = Type.Cuerpo)
                if (safeFallback) BasicText("(No se pudo identificar quién habla: se muestra la escena por defecto.)", style = Type.Nota)
            }
        }
        if (busy || generating) BasicText(phase.ifBlank { "Generando…" }, style = Type.Nota)
        error?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Granate)) }
        if (choices.isNotEmpty() && !busy) Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { choices.take(3).forEach { InkChip(it.take(26), false, { onChoice(it) }) } }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            InkField(input, onInput, "¿Qué haces o dices? (acción libre)", Modifier.weight(1f), minHeight = 36, maxHeight = 90)
            InkButton(if (busy) "Detener" else "Enviar", if (busy) onStop else onSend, danger = busy, enabled = busy || input.isNotBlank())
        }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            InkLink("Continuar", onContinue, enabled = !busy && hasText)
            InkLink("Regenerar", onRegenerate, enabled = !busy && hasText)
            InkLink("Historial", onHistory)
            InkLink("Ficha", onSheet)
        }
        Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            if (illus.canAsk) InkLink(if (illus.suggest) "★ Ilustrar esta escena" else "Ilustrar", illus.onAsk, enabled = !busy)
            if (illus.has) InkLink(if (illus.shown) "Ocultar ilustración" else "Ver ilustración", illus.onToggle)
            InkLink("Imágenes", illus.onStudio)
        }
        if (illus.status.isNotBlank()) BasicText(illus.status, style = Type.Nota.copy(color = Ink.Oro))
    }
}

@Composable
private fun HistoryDialog(messages: List<RoleMessageEntity>, character: String, user: String, onClose: () -> Unit, onClassic: () -> Unit) {
    InkDialog("Historial", onClose) {
        LazyColumn(Modifier.heightIn(max = 420.dp)) {
            items(messages, key = { it.id }) { m ->
                BasicText((if (m.role == MessageRole.USER) user else character) + ":", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 8.dp))
                BasicText(m.content.ifBlank { "…" }, style = Type.Cuerpo)
            }
        }
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Vista clásica", onClassic, primary = false)
            InkButton("Cerrar", onClose)
        }
    }
}
