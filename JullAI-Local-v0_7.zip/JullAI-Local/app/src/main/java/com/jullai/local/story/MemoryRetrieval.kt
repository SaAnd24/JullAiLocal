package com.jullai.local.story

import com.jullai.local.roleplay.PromptSection
import kotlin.math.ln
import kotlin.math.max

/**
 * Recuperación de memoria (v0.4). Lógica pura y probada: no envía todo al modelo, elige lo relevante dentro de un presupuesto.
 *
 * Orden de decisión: 1) recuerdos fijados, 2) recuerdos relevantes por palabras clave y búsqueda de texto completo,
 * 3) cronología pertinente, 4) relaciones de quienes están en escena. El resumen lo coloca el constructor de contexto.
 */

class RetrievalRequest(
    val sessionId: Long,
    /** Mensajes recientes, del más antiguo al más nuevo. El último pesa el doble. */
    val recent: List<String>,
    /** Nombres de quienes participan en la escena (personaje y usuario). Sus palabras no puntúan como «coincidencia». */
    val participants: List<String>,
    /** Tokens que puede ocupar TODA la memoria recuperada. */
    val budgetTokens: Int,
)

/** Qué datos hay disponibles. La implementación con Room vive en la capa de datos. */
interface StorySource {
    /** Recuerdos ACTIVOS candidatos. Si hay demasiados, la fuente puede preseleccionar con búsqueda de texto. */
    suspend fun candidateMemories(sessionId: Long, queryTokens: List<String>): MemoryCandidates
    suspend fun timeline(sessionId: Long): List<TimelineItem>
    suspend fun relationships(sessionId: Long): List<RelationItem>
}

/** [ftsIds] = ids que devolvió la búsqueda de texto completo (null si no estaba disponible); [backend] describe qué se usó. */
class MemoryCandidates(val items: List<MemoryItem>, val ftsIds: Set<Long>?, val backend: String)

/** Interfaz para poder cambiar de sistema de búsqueda en el futuro (p. ej. por vectores) sin tocar el resto. */
interface MemoryRetriever {
    suspend fun retrieve(request: RetrievalRequest, count: suspend (String) -> Int): RetrievalResult
}

data class PickedMemory(val item: MemoryItem, val why: String, val text: String, val tokens: Int)
data class PickedTimeline(val item: TimelineItem, val why: String, val text: String, val tokens: Int)
data class PickedRelation(val item: RelationItem, val text: String, val tokens: Int)

class RetrievalResult(
    val memories: List<PickedMemory>,
    val timeline: List<PickedTimeline>,
    val relations: List<PickedRelation>,
    /** Descripción corta de lo relevante que NO cupo (para el informe). */
    val notFitting: List<String>,
    val backend: String,
    val budget: Int,
    val candidates: Int,
) {
    val usedTokens: Int get() = memories.sumOf { it.tokens } + timeline.sumOf { it.tokens } + relations.sumOf { it.tokens }

    fun isEmpty() = memories.isEmpty() && timeline.isEmpty() && relations.isEmpty()

    /** Secciones para el constructor de contexto. Orden: relaciones, recuerdos, cronología (si falta espacio, caen primero las últimas). */
    fun toSections(): List<PromptSection> = buildList {
        if (relations.isNotEmpty()) add(
            PromptSection(
                "relations", "Relaciones", "", relations.map { it.text },
                header = "# RELACIONES ACTUALES (valores de 1 a 100; cada dimensión es independiente: confianza o respeto NO implican enamoramiento)",
            ),
        )
        if (memories.isNotEmpty()) add(
            PromptSection(
                "memories", "Recuerdos permanentes", "", memories.map { it.text },
                header = "# RECUERDOS PERMANENTES DE LA HISTORIA (hechos ya establecidos; respétalos)",
            ),
        )
        if (timeline.isNotEmpty()) add(
            PromptSection("timeline", "Cronología", "", timeline.map { it.text }, header = "# CRONOLOGÍA RELEVANTE (en orden temporal)"),
        )
    }

    /** Texto para la pantalla «Qué información se recuperó para esta respuesta». */
    fun describe(): String = buildString {
        append("Búsqueda: $backend · $candidates recuerdos activos revisados · memoria recuperada: $usedTokens de $budget tokens\n")
        if (isEmpty()) append("No se recuperó nada (no hay recuerdos, cronología ni relaciones pertinentes).\n")
        if (memories.isNotEmpty()) {
            append("\nRecuerdos (${memories.size}):\n")
            memories.forEach { append("• ${it.item.content.take(90).replace('\n', ' ')} — ${it.why} (${it.tokens} tok)\n") }
        }
        if (timeline.isNotEmpty()) {
            append("\nCronología (${timeline.size}):\n")
            timeline.forEach { append("• ${it.item.text.take(90).replace('\n', ' ')} — ${it.why} (${it.tokens} tok)\n") }
        }
        if (relations.isNotEmpty()) {
            append("\nRelaciones (${relations.size}):\n")
            relations.forEach { append("• ${it.item.a} → ${it.item.b} (${it.tokens} tok)\n") }
        }
        if (notFitting.isNotEmpty()) {
            append("\nRelevantes que no cupieron en el presupuesto: ${notFitting.size}\n")
            notFitting.take(8).forEach { append("• $it\n") }
        }
    }.trimEnd()
}

object StoryRender {
    fun level(v: Int) = when {
        v <= 20 -> "muy baja"
        v <= 40 -> "baja"
        v <= 60 -> "media"
        v <= 80 -> "alta"
        else -> "muy alta"
    }

    fun memory(m: MemoryItem): String {
        val date = if (m.narrativeDate.isNotBlank()) " (${m.narrativeDate.trim()})" else ""
        return "- " + m.content.trim().replace('\n', ' ') + date
    }

    fun timeline(t: TimelineItem): String {
        val date = if (t.narrativeDate.isNotBlank()) "[${t.narrativeDate.trim()}] " else ""
        return "- $date" + t.text.trim().replace('\n', ' ')
    }

    fun relation(r: RelationItem): String {
        val st = if (r.status.isNotBlank()) " · situación: ${r.status.trim()}" else ""
        return "- ${r.a} hacia ${r.b}: confianza ${r.trust} (${level(r.trust)}), afecto ${r.affection} (${level(r.affection)}), " +
            "respeto ${r.respect} (${level(r.respect)}), interés romántico ${r.romantic} (${level(r.romantic)})$st"
    }
}

/** Recuperador por puntuación: palabras clave (con peso por rareza), nombres, texto completo, importancia y novedad. */
class RankedMemoryRetriever(private val source: StorySource) : MemoryRetriever {
    companion object {
        /** Reparto del presupuesto total. */
        const val RELATIONS_SHARE = 0.25
        const val PINNED_SHARE = 0.60       // los fijados no pueden ocupar más de esto de la memoria de recuerdos
        const val MEMORIES_SHARE = 0.55
        const val TIMELINE_SHARE = 0.30
        const val MAX_BASELINE = 3          // recuerdos importantes sin coincidencia que pueden rellenar hueco
        const val MAX_TIMELINE_PICKS = 6
        const val MAX_RELATIONS = 6
    }

    override suspend fun retrieve(request: RetrievalRequest, count: suspend (String) -> Int): RetrievalResult {
        val budget = max(0, request.budgetTokens)
        val participantFold = request.participants.map { TextNorm.fold(it).trim() }.filter { it.isNotEmpty() }
        val participantTokens = request.participants.flatMap { TextNorm.tokens(it) }.toSet()

        // Palabras de la consulta con peso: el último mensaje pesa el doble.
        val weights = LinkedHashMap<String, Double>()
        request.recent.forEachIndexed { i, text ->
            val w = if (i == request.recent.lastIndex) 2.0 else 1.0
            for (t in TextNorm.tokens(text)) if (t !in participantTokens) weights[t] = max(weights[t] ?: 0.0, w)
        }
        val queryFold = TextNorm.fold(request.recent.joinToString("\n"))
        val queryTokens = weights.keys.toList()

        val cands = source.candidateMemories(request.sessionId, queryTokens)
        val memTokens = cands.items.associate { it.id to TextNorm.keySet(TextNorm.tokens(it.content + " " + it.narrativeDate) + it.related.flatMap { r -> TextNorm.tokens(r) }) }
        val n = max(1, cands.items.size)
        val df = HashMap<String, Int>()
        for (q in weights.keys) {
            val qk = TextNorm.keys(q)
            df[q] = memTokens.values.count { set -> qk.any { it in set } }
        }

        // ---- relaciones (poco texto, mucho valor) ----
        val relBudget = (budget * RELATIONS_SHARE).toInt()
        val relations = pickRelations(source.relationships(request.sessionId), participantFold, queryFold, relBudget, count)
        val relUsed = relations.sumOf { it.tokens }

        // ---- recuerdos ----
        val memBudget = (budget * MEMORIES_SHARE).toInt() + max(0, relBudget - relUsed)
        val notFitting = ArrayList<String>()
        val scored = cands.items.map { m ->
            val set = memTokens[m.id].orEmpty()
            var kw = 0.0
            val hits = ArrayList<String>()
            for ((q, w) in weights) if (TextNorm.keys(q).any { it in set }) {
                kw += w * ln(1.0 + n.toDouble() / (1 + (df[q] ?: 0)))
                hits.add(q)
            }
            val names = m.related.filter { r -> val f = TextNorm.fold(r).trim(); f.isNotEmpty() && f !in participantFold && queryFold.contains(f) }
            val nameBoost = 1.5 * names.size
            val fts = cands.ftsIds?.contains(m.id) == true
            val importance = (m.importance.coerceIn(1, 5) - 1) * 0.35
            Scored(m, kw + nameBoost + (if (fts) 0.8 else 0.0) + importance, kw > 0 || nameBoost > 0 || fts, hits, names, fts)
        }

        val picked = ArrayList<PickedMemory>()
        var used = 0
        val pinnedCap = (memBudget * PINNED_SHARE).toInt()
        var pinnedUsed = 0
        for (s in scored.filter { it.item.pinned }.sortedWith(compareByDescending<Scored> { it.item.importance }.thenByDescending { it.item.updatedAt })) {
            val text = StoryRender.memory(s.item)
            val c = count(text) + 1
            if (pinnedUsed + c > pinnedCap || used + c > memBudget) { notFitting.add("fijado: " + s.item.content.take(60)); continue }
            pinnedUsed += c; used += c
            picked.add(PickedMemory(s.item, "fijado", text, c))
        }
        val maxUpdated = scored.maxOfOrNull { it.item.updatedAt } ?: 0L
        val minUpdated = scored.minOfOrNull { it.item.updatedAt } ?: 0L
        val span = max(1L, maxUpdated - minUpdated).toDouble()
        val rest = scored.filter { !it.item.pinned }
            .map { it to (it.score + 0.3 * (it.item.updatedAt - minUpdated) / span) }
        var baseline = 0
        for ((s, total) in rest.filter { it.first.relevant }.sortedByDescending { it.second }) {
            val text = StoryRender.memory(s.item)
            val c = count(text) + 1
            if (used + c > memBudget) { notFitting.add(s.item.content.take(60)); continue }
            used += c
            picked.add(PickedMemory(s.item, why(s), text, c))
        }
        for ((s, _) in rest.filter { !it.first.relevant && it.first.item.importance >= 4 }.sortedByDescending { it.second }) {
            if (baseline >= MAX_BASELINE) break
            val text = StoryRender.memory(s.item)
            val c = count(text) + 1
            if (used + c > memBudget) break
            used += c; baseline++
            picked.add(PickedMemory(s.item, "importancia alta", text, c))
        }

        // ---- cronología ----
        val tlBudget = minOf(((budget * TIMELINE_SHARE).toInt()), max(0, budget - relUsed - used))
        val timeline = pickTimeline(source.timeline(request.sessionId), weights, participantTokens, queryFold, tlBudget, count)

        return RetrievalResult(picked, timeline, relations, notFitting, cands.backend, budget, cands.items.size)
    }

    private class Scored(val item: MemoryItem, val score: Double, val relevant: Boolean, val hits: List<String>, val names: List<String>, val fts: Boolean)

    private fun why(s: Scored): String {
        val parts = ArrayList<String>()
        if (s.hits.isNotEmpty()) parts.add("palabras: " + s.hits.take(4).joinToString(", "))
        if (s.names.isNotEmpty()) parts.add("nombre: " + s.names.take(2).joinToString(", "))
        if (s.fts && s.hits.isEmpty() && s.names.isEmpty()) parts.add("texto completo")
        return parts.joinToString(" · ").ifEmpty { "relevante" }
    }

    private suspend fun pickRelations(all: List<RelationItem>, participantFold: List<String>, queryFold: String, budget: Int, count: suspend (String) -> Int): List<PickedRelation> {
        if (budget <= 0 || all.isEmpty()) return emptyList()
        fun mentioned(name: String): Boolean {
            val f = TextNorm.fold(name).trim()
            return f.isNotEmpty() && (f in participantFold || queryFold.contains(f))
        }
        val relevant = all.filter { mentioned(it.a) && mentioned(it.b) }.ifEmpty { all.filter { mentioned(it.a) || mentioned(it.b) } }
        val out = ArrayList<PickedRelation>()
        var used = 0
        for (r in relevant.take(MAX_RELATIONS)) {
            val text = StoryRender.relation(r)
            val c = count(text) + 1
            if (used + c > budget) continue
            used += c
            out.add(PickedRelation(r, text, c))
        }
        return out
    }

    private suspend fun pickTimeline(
        all: List<TimelineItem>, weights: Map<String, Double>, participantTokens: Set<String>, queryFold: String,
        budget: Int, count: suspend (String) -> Int,
    ): List<PickedTimeline> {
        if (budget <= 0 || all.isEmpty()) return emptyList()
        val n = max(1, all.size)
        val sets = all.associate { it.id to TextNorm.keySet(TextNorm.tokens(it.text + " " + it.narrativeDate) + it.characters.flatMap { c -> TextNorm.tokens(c) }) }
        val df = HashMap<String, Int>()
        for (q in weights.keys) { val qk = TextNorm.keys(q); df[q] = sets.values.count { set -> qk.any { it in set } } }
        class T(val item: TimelineItem, val score: Double, val hits: List<String>)
        val scored = all.map { e ->
            val set = sets[e.id].orEmpty()
            var kw = 0.0
            val hits = ArrayList<String>()
            for ((q, w) in weights) if (q !in participantTokens && TextNorm.keys(q).any { it in set }) { kw += w * ln(1.0 + n.toDouble() / (1 + (df[q] ?: 0))); hits.add(q) }
            val names = e.characters.count { c -> val f = TextNorm.fold(c).trim(); f.isNotEmpty() && queryFold.contains(f) }
            T(e, kw + 1.2 * names, hits)
        }
        val chosen = LinkedHashMap<Long, Pair<T, String>>()
        for (t in scored.filter { it.score > 0 }.sortedByDescending { it.score }.take(MAX_TIMELINE_PICKS)) chosen[t.item.id] = t to (if (t.hits.isNotEmpty()) "palabras: " + t.hits.take(3).joinToString(", ") else "nombre")
        for (t in scored.sortedByDescending { it.item.orderKey }.take(2)) if (t.item.id !in chosen) chosen[t.item.id] = t to "reciente"
        val out = ArrayList<PickedTimeline>()
        var used = 0
        // Se prioriza por puntuación pero se muestra por orden temporal.
        for ((t, why) in chosen.values.sortedByDescending { it.first.score }) {
            val text = StoryRender.timeline(t.item)
            val c = count(text) + 1
            if (used + c > budget) continue
            used += c
            out.add(PickedTimeline(t.item, why.ifBlank { "relevante" }, text, c))
        }
        return out.sortedBy { it.item.orderKey }
    }
}
