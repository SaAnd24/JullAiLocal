package com.jullai.local.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ModelDao {
    @Query("SELECT * FROM models ORDER BY importedAt ASC")
    fun observeAll(): Flow<List<ModelEntity>>

    @Query("SELECT * FROM models ORDER BY importedAt ASC")
    suspend fun all(): List<ModelEntity>

    @Query("SELECT * FROM models WHERE sha256 = :sha LIMIT 1")
    suspend fun bySha(sha: String): ModelEntity?

    @Query("SELECT * FROM models WHERE fileName = :fileName LIMIT 1")
    suspend fun byFile(fileName: String): ModelEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(model: ModelEntity): Long

    @Query("DELETE FROM models WHERE fileName = :fileName")
    suspend fun delete(fileName: String)

    @Query("UPDATE models SET isDefault = (fileName = :fileName)")
    suspend fun setDefaultOnly(fileName: String)

    @Query("SELECT COUNT(*) FROM models")
    suspend fun count(): Int
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC, id DESC")
    fun observeAll(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    fun observe(id: Long): Flow<ConversationEntity?>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun get(id: Long): ConversationEntity?

    @Insert
    suspend fun insert(conversation: ConversationEntity): Long

    @Update
    suspend fun update(conversation: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE conversations SET title = :title, updatedAt = :now WHERE id = :id")
    suspend fun rename(id: Long, title: String, now: Long)

    @Query("UPDATE conversations SET updatedAt = :now WHERE id = :id")
    suspend fun touch(id: Long, now: Long)

    @Query("UPDATE conversations SET modelFileName = NULL WHERE modelFileName = :fileName")
    suspend fun clearModel(fileName: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY orderIndex ASC")
    fun observe(conversationId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY orderIndex ASC")
    suspend fun list(conversationId: Long): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun get(id: Long): MessageEntity?

    @Query("SELECT COALESCE(MAX(orderIndex), -1) FROM messages WHERE conversationId = :conversationId")
    suspend fun maxOrder(conversationId: Long): Int

    @Query("SELECT COUNT(*) FROM messages WHERE conversationId = :conversationId")
    suspend fun count(conversationId: Long): Int

    @Insert
    suspend fun insert(message: MessageEntity): Long

    @Query("UPDATE messages SET content = :content, state = :state WHERE id = :id")
    suspend fun updateContentAndState(id: Long, content: String, state: String)

    @Query("UPDATE messages SET content = :content WHERE id = :id")
    suspend fun updateContent(id: Long, content: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId AND orderIndex > :orderIndex")
    suspend fun deleteAfter(conversationId: Long, orderIndex: Int)

    /** Respuestas que quedaron "generándose" porque la app se cerró: se marcan como interrumpidas (el texto se conserva). */
    @Query("UPDATE messages SET state = 'INTERRUPTED' WHERE state = 'GENERATING'")
    suspend fun markGeneratingAsInterrupted(): Int
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM settings")
    fun observeAll(): Flow<List<SettingEntity>>

    @Query("SELECT * FROM settings")
    suspend fun all(): List<SettingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putAll(items: List<SettingEntity>)
}
