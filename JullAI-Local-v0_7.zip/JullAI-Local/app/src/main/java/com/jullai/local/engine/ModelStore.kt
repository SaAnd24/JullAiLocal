package com.jullai.local.engine

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import com.jullai.local.data.ModelRegistry
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID
import kotlin.coroutines.coroutineContext

data class StoredModel(
    val fileName: String,
    val displayName: String,
    val sizeBytes: Long,
    val sha256: String,
    val importedAtMillis: Long,
    val isDefault: Boolean,
)

class ImportException(message: String) : IOException(message)

/**
 * Administra los archivos GGUF importados en el almacenamiento PRIVADO de la app (sin permisos de almacenamiento).
 * El registro de modelos vive en Room (tabla `models`, ver [ModelRegistry]); aquí solo se manejan archivos.
 * Los pesos nunca van en la base de datos ni en el APK.
 */
class ModelStore(private val context: Context, private val registry: ModelRegistry) {
    private val dir: File = File(context.filesDir, "models").apply { mkdirs() }

    /** Carpeta de modelos (para migrar el registry.json del Hito 1). */
    val directory: File get() = dir

    init {
        // Limpieza de importaciones interrumpidas (cierre inesperado de la app).
        dir.listFiles { f -> f.name.endsWith(".part") && !f.name.endsWith(".dl.part") }?.forEach { it.delete() }
    }

    fun file(model: StoredModel): File = File(dir, model.fileName)

    fun freeBytes(): Long = StatFs(dir.path).availableBytes

    suspend fun setDefault(model: StoredModel) = registry.setDefault(model)

    /** Borra el archivo y su registro. Las conversaciones que lo usaban se conservan (ver ModelRegistry.remove). */
    suspend fun delete(model: StoredModel) {
        withContext(Dispatchers.IO) { File(dir, model.fileName).delete() }
        registry.remove(model.fileName)
    }

    /**
     * Importa un GGUF desde un Uri del selector de archivos.
     * Pasos: comprobar cabecera -> comprobar espacio -> copiar con progreso (y SHA-256) -> detectar duplicado
     * -> validar con el motor -> registrar. Si algo falla o se cancela, se borra el archivo parcial.
     * [validate] debe lanzar una excepción si el motor no puede leer el modelo.
     */
    suspend fun importFrom(
        uri: Uri,
        validate: suspend (File) -> Unit,
        onProgress: (copied: Long, total: Long) -> Unit,
    ): StoredModel = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var displayName = "modelo.gguf"
        var total = -1L
        resolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) c.getString(ni)?.let { displayName = it }
                if (si >= 0 && !c.isNull(si)) total = c.getLong(si)
            }
        }
        val safeName = sanitizeFileName(displayName)

        resolver.openInputStream(uri)?.use { probe ->
            when (val check = GgufHeader.check(probe)) {
                is GgufCheck.Invalid -> throw ImportException(check.reason)
                is GgufCheck.Ok -> Unit
            }
        } ?: throw ImportException("No se pudo abrir el archivo seleccionado.")

        if (total > 0 && total + SAFETY_MARGIN > freeBytes()) {
            throw ImportException(
                "No hay espacio suficiente: el modelo ocupa ${total / MB} MB y quedan ${freeBytes() / MB} MB libres.",
            )
        }

        val part = File(dir, "${UUID.randomUUID()}.part")
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            resolver.openInputStream(uri)!!.use { input ->
                part.outputStream().buffered(BUF).use { out ->
                    val buf = ByteArray(BUF)
                    var copied = 0L
                    var lastReport = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        digest.update(buf, 0, n)
                        copied += n
                        if (copied - lastReport >= REPORT_EVERY) {
                            onProgress(copied, total)
                            lastReport = copied
                        }
                    }
                    out.flush()
                    onProgress(copied, if (total > 0) total else copied)
                }
            }
            val sha = digest.digest().joinToString("") { "%02x".format(it) }

            val existing = registry.findBySha(sha)
            if (existing != null) {
                throw ImportException("Este modelo ya está importado como \"${existing.displayName}\".")
            }

            coroutineContext.ensureActive()
            validate(part)

            var finalName = safeName
            var n = 1
            while (File(dir, finalName).exists()) {
                finalName = safeName.removeSuffix(".gguf") + "-" + (++n) + ".gguf"
            }
            val dest = File(dir, finalName)
            if (!part.renameTo(dest)) throw ImportException("No se pudo guardar el modelo importado.")

            val entry = StoredModel(
                fileName = finalName,
                displayName = safeName.removeSuffix(".gguf"),
                sizeBytes = dest.length(),
                sha256 = sha,
                importedAtMillis = System.currentTimeMillis(),
                isDefault = registry.count() == 0,
            )
            registry.add(entry)
            entry
        } finally {
            if (part.exists()) part.delete()   // cancelación, error o duplicado: no deja residuos
        }
    }

    /** Descargador seguro hacia la carpeta privada de modelos. */
    fun downloader(): ModelDownloader = ModelDownloader(dir, ::freeBytes)

    /**
     * Registra un modelo ya descargado y validado (archivo completo dentro de la carpeta de modelos). Si el motor no puede leerlo se borra;
     * si ya existía el mismo contenido, se conserva el anterior y se borra la copia nueva. Nunca reemplaza un modelo registrado.
     */
    suspend fun registerDownloaded(file: File, sha256: String, validate: suspend (File) -> Unit): StoredModel = withContext(Dispatchers.IO) {
        try {
            registry.findBySha(sha256)?.let { file.delete(); throw ImportException("Este modelo ya está instalado como \"${it.displayName}\".") }
            validate(file)
        } catch (e: Exception) { if (file.exists() && registry.findBySha(sha256) == null) file.delete(); throw e }
        val entry = StoredModel(file.name, file.name.removeSuffix(".gguf"), file.length(), sha256, System.currentTimeMillis(), registry.count() == 0)
        registry.add(entry)
        entry
    }

    companion object {
        private const val BUF = 1 shl 20
        private const val REPORT_EVERY = 8L * 1024 * 1024
        private const val MB = 1024L * 1024
        private const val SAFETY_MARGIN = 64L * MB

        fun sanitizeFileName(raw: String): String = ModelFileNames.sanitize(raw)
    }
}
