package com.jullai.local.world

import com.jullai.local.story.TextNorm

/** Datos conocidos de un personaje o lugar (nombre y alias) para reconocerlos en el texto. */
class NamedRef(val key: String, val name: String, val aliases: List<String> = emptyList())

class SceneInput(
    val text: String,
    val characters: List<NamedRef>,
    val locations: List<NamedRef>,
    val defaultSpeaker: String,
    val previousLocation: String,
)

/** Metadatos visuales de un turno. [valid] = false indica que se usó una alternativa segura porque algo no se pudo extraer. */
data class SceneDraft(
    val location: String,
    val speaker: String,
    val emotion: String,
    val pose: String,
    val eventType: String,
    val important: Boolean,
    val valid: Boolean,
)

object Emotion {
    const val NEUTRAL = "NEUTRAL"
    const val ALEGRIA = "ALEGRIA"
    const val TRISTEZA = "TRISTEZA"
    const val ENFADO = "ENFADO"
    const val MIEDO = "MIEDO"
    const val SORPRESA = "SORPRESA"
    const val VERGUENZA = "VERGUENZA"
    const val SERIO = "SERIO"
    val ALL = listOf(NEUTRAL, ALEGRIA, TRISTEZA, ENFADO, MIEDO, SORPRESA, VERGUENZA, SERIO)

    fun label(e: String) = when (e) {
        ALEGRIA -> "Alegría"; TRISTEZA -> "Tristeza"; ENFADO -> "Enfado"; MIEDO -> "Miedo"; SORPRESA -> "Sorpresa"
        VERGUENZA -> "Vergüenza"; SERIO -> "Serio"; else -> "Neutral"
    }
}

/**
 * Extrae metadatos visuales del texto narrativo SIN llamar al modelo y SIN modificar el texto: reglas deterministas y validadas
 * contra los personajes y lugares que existen de verdad. Si algo no se puede validar, devuelve una alternativa segura
 * (narrador, sin emoción, mismo lugar que antes) con valid = false. Nunca lanza.
 */
object SceneDirector {
    private val EMOTIONS = mapOf(
        Emotion.ALEGRIA to listOf("sonrie", "sonrisa", "rie", "risa", "carcajad", "feliz", "alegre", "alegria", "contento", "radiante"),
        Emotion.TRISTEZA to listOf("llora", "lagrima", "triste", "tristeza", "solloz", "suspira", "melancol", "desconsolad"),
        Emotion.ENFADO to listOf("furios", "enfad", "grita", "ira", "rabia", "gruñe", "gruñ", "apreta los punos", "indignad"),
        Emotion.MIEDO to listOf("temblor", "tiembla", "asustad", "miedo", "terror", "palid", "pavor", "aterrad"),
        Emotion.SORPRESA to listOf("sorprendid", "asombr", "jadea", "abre los ojos", "boquiabiert", "atonit"),
        Emotion.VERGUENZA to listOf("sonroj", "ruboriz", "verguenza", "avergonzad", "mejillas rojas"),
        Emotion.SERIO to listOf("serio", "seria", "frunce", "ceño", "ceno", "severa", "severo", "gelid"),
    )
    private val POSES = listOf(
        "BRAZOS_CRUZADOS" to listOf("brazos cruzados", "cruza los brazos"),
        "SENTADO" to listOf("se sienta", "sentad", "toma asiento"),
        "ACERCANDOSE" to listOf("se acerca", "da un paso hacia", "se inclina hacia"),
        "DE_PIE" to listOf("de pie", "se levanta", "se pone en pie"),
    )
    private val IMPORTANT = listOf("beso", "muere", "muerte", "revela", "secreto", "traicion", "confiesa", "sangre", "explosion", "juramento", "te quiero", "adios para siempre")
    private val QUOTES = Regex("(—[^—\\n]{2,300}|«[^»\\n]{2,300}»|\"[^\"\\n]{2,300}\"|“[^”\\n]{2,300}”)")

    fun direct(i: SceneInput): SceneDraft = try { doDirect(i) } catch (e: Exception) {
        SceneDraft(i.previousLocation, "", Emotion.NEUTRAL, "", VisualEvent.NARRACION, false, false)
    }

    private fun doDirect(i: SceneInput): SceneDraft {
        val text = i.text
        val folded = TextNorm.fold(text)
        val quote = QUOTES.find(text)
        val hasDialogue = quote != null

        var speaker = ""
        var valid = true
        if (quote != null) {
            val startF = TextNorm.fold(text.substring(0, quote.range.first)).length
            val endF = TextNorm.fold(text.substring(0, quote.range.last + 1)).length
            speaker = nearestCharacter(folded, i.characters, startF, endF)
            if (speaker.isEmpty()) {
                speaker = i.defaultSpeaker
                valid = i.defaultSpeaker.isNotBlank()
            }
        }

        // Lugar: el último lugar conocido mencionado; si no hay ninguno, se conserva el anterior.
        var location = i.previousLocation
        var bestPos = -1
        for (l in i.locations) for (n in listOf(l.name) + l.aliases) {
            val f = TextNorm.fold(n).trim()
            if (f.length < 3) continue
            val pos = lastWord(folded, f)
            if (pos > bestPos) { bestPos = pos; location = l.name }
        }
        val changed = location.isNotBlank() && location != i.previousLocation

        // Emoción: la que más palabras aporta; empate o nada → neutral.
        val scores = EMOTIONS.mapValues { (_, words) -> words.count { folded.contains(TextNorm.fold(it)) } }
        val top = scores.maxByOrNull { it.value }
        val second = scores.values.sortedDescending().getOrElse(1) { 0 }
        val emotion = if (top != null && top.value > 0 && top.value > second) top.key else Emotion.NEUTRAL
        val pose = POSES.firstOrNull { (_, ws) -> ws.any { folded.contains(it) } }?.first ?: ""
        val important = IMPORTANT.count { folded.contains(it) } >= 1 || (changed && emotion != Emotion.NEUTRAL)
        val event = when {
            important -> VisualEvent.IMPORTANTE
            changed -> VisualEvent.CAMBIO_LUGAR
            hasDialogue -> VisualEvent.DIALOGO
            else -> VisualEvent.NARRACION
        }
        return SceneDraft(location, speaker, emotion, pose, event, important, valid)
    }

    /** Personaje cuyo nombre aparece más cerca del diálogo (justo después o justo antes). Vacío si ninguno. */
    private fun nearestCharacter(folded: String, chars: List<NamedRef>, start: Int, end: Int): String {
        var best = ""
        var bestDist = Int.MAX_VALUE
        for (c in chars) for (n in listOf(c.name) + c.aliases) {
            val f = TextNorm.fold(n).trim()
            if (f.length < 2) continue
            var from = 0
            while (true) {
                val p = folded.indexOf(f, from)
                if (p < 0) break
                from = p + 1
                val before = if (p == 0) ' ' else folded[p - 1]
                val after = if (p + f.length >= folded.length) ' ' else folded[p + f.length]
                if (before.isLetterOrDigit() || after.isLetterOrDigit()) continue
                val dist = when {
                    p >= end -> p - end            // «—Hola —dijo Aria»
                    p + f.length <= start -> start - (p + f.length)   // «Aria dijo: —Hola»
                    else -> 0                       // dentro del diálogo (lo nombran): peor señal
                }
                val inside = p < end && p + f.length > start
                val d = if (inside) 400 + dist else dist
                if (d < bestDist && d <= 120) { bestDist = d; best = c.name }
            }
        }
        return best
    }

    private fun lastWord(haystack: String, needle: String): Int {
        var last = -1
        var from = 0
        while (true) {
            val p = haystack.indexOf(needle, from)
            if (p < 0) return last
            from = p + 1
            val before = if (p == 0) ' ' else haystack[p - 1]
            val after = if (p + needle.length >= haystack.length) ' ' else haystack[p + needle.length]
            if (!before.isLetterOrDigit() && !after.isLetterOrDigit()) last = p
        }
    }
}

/** Recurso visual registrado (retrato o fondo) tal y como lo ve el selector. */
class AssetInfo(val id: Long, val kind: String, val characterKey: String, val locationRef: String, val emotion: String, val label: String)

class AssetChoice(val portraitId: Long?, val backgroundId: Long?, val portraitIsExact: Boolean)

/** Elige recursos del registro. Si falta alguno, devuelve null para ese elemento: la interfaz dibuja una alternativa neutral. */
object AssetResolver {
    fun choose(draft: SceneDraft, speakerKey: String, locationKey: String, assets: List<AssetInfo>): AssetChoice {
        // v0.6: las expresiones generadas/importadas (EXPRESION) cuentan como retratos con emoción.
        val portraits = assets.filter { (it.kind == AssetKind.RETRATO || it.kind == AssetKind.EXPRESION) && speakerKey.isNotBlank() && it.characterKey == speakerKey }
        val exact = portraits.firstOrNull { it.emotion.equals(draft.emotion, ignoreCase = true) && draft.emotion != Emotion.NEUTRAL }
        val portrait = exact ?: portraits.firstOrNull { it.emotion.isBlank() || it.emotion == Emotion.NEUTRAL } ?: portraits.firstOrNull()
        val bg = assets.firstOrNull { it.kind == AssetKind.FONDO && locationKey.isNotBlank() && TextNorm.fold(it.locationRef) == TextNorm.fold(locationKey) }
        return AssetChoice(portrait?.id, bg?.id, exact != null)
    }
}
