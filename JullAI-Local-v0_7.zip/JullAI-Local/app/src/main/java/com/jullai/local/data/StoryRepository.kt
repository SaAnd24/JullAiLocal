package com.jullai.local.data

import androidx.room.withTransaction
import androidx.sqlite.db.SimpleSQLiteQuery
import com.jullai.local.story.ChapterState
import com.jullai.local.story.Dedup
import com.jullai.local.story.EventState
import com.jullai.local.story.ItemState
import com.jullai.local.story.MemoryCandidates
import com.jullai.local.story.MemoryItem
import com.jullai.local.story.NovelState
import com.jullai.local.story.Origin
import com.jullai.local.story.ProposedEvent
import com.jullai.local.story.ProposedMemory
import com.jullai.local.story.ProposedRelation
import com.jullai.local.story.RelDelta
import com.jullai.local.story.RelValues
import com.jullai.local.story.RelationItem
import com.jullai.local.story.RelationshipRules
import com.jullai.local.story.StorySource
import com.jullai.local.story.StoryLimits
import com.jullai.local.story.TextNorm
import com.jullai.local.story.TimelineItem
import com.jullai.local.story.Verification
import com.jullai.local.story.VolumeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/** Error de una operación de memoria con mensaje ya en español para mostrar al usuario. */
class StoryException(message: String) : Exception(message)

fun MemoryEntity.toItem() = MemoryItem(
    id = id, content = content, importance = importance, narrativeDate = narrativeDate, pinned = pinned,
    related = TextNorm.lines(relatedNames), verification = verification, updatedAt = updatedAt,
)

fun TimelineEventEntity.toItem() = TimelineItem(id, text, narrativeDate, orderKey, TextNorm.lines(characterNames))

fun RelationshipEntity.toItem() = RelationItem(id, aName, bName, trust, affection, respect, romantic, status)

fun RelationshipEntity.values() = RelValues(trust, affection, respect, romantic)

/**
 * Memoria narrativa, relaciones, capítulos y volúmenes (v0.4). Todo lo que toca varias tablas va en UNA transacción.
 *
 * Principios:
 *  - Una propuesta automática (extraída o inferida) entra como PROPUESTO y no llega al modelo hasta que el usuario la acepta.
 *  - Nada automático modifica ni borra un recuerdo existente (ni fijado ni confirmado): solo se AÑADEN propuestas.
 *  - El registro original de mensajes (role_messages) nunca se reescribe desde aquí.
 */
class StoryRepository(
    private val db: AppDatabase,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : StorySource {
    companion object {
        const val MAX_PENDING = 60
        /** Por debajo de este número de recuerdos activos se revisan todos; por encima se preselecciona con la búsqueda de texto. */
        const val SCAN_ALL_LIMIT = 400
    }

    // ============================ Recuerdos ============================

    fun observeMemories(sessionId: Long): Flow<List<MemoryEntity>> = db.memories().observeActive(sessionId)
    fun observePendingMemories(sessionId: Long): Flow<List<MemoryEntity>> = db.memories().observePending(sessionId)

    suspend fun addMemory(sessionId: Long, content: String, importance: Int, narrativeDate: String, related: List<String>, pinned: Boolean): Long {
        val text = TextNorm.clean(content, StoryLimits.MEMORY_CHARS)
        if (text.length < 3) throw StoryException("El recuerdo está vacío.")
        return db.withTransaction {
            if (db.memories().listAll(sessionId).size >= StoryLimits.MAX_MEMORIES) throw StoryException("Se alcanzó el máximo de recuerdos de esta partida.")
            val now = clock()
            db.memories().insert(
                MemoryEntity(
                    sessionId = sessionId, content = text, importance = importance.coerceIn(1, 5),
                    narrativeDate = TextNorm.clean(narrativeDate, StoryLimits.DATE_CHARS), origin = Origin.USUARIO, verification = Verification.CONFIRMADO,
                    state = ItemState.ACTIVO, pinned = pinned, relatedNames = cleanNames(related), createdAt = now, updatedAt = now,
                ),
            )
        }
    }

    /** Edita el contenido. Un recuerdo pendiente sigue pendiente; uno activo sigue activo. Para confirmar una propuesta usa [acceptMemory]. */
    suspend fun editMemory(id: Long, content: String, importance: Int, narrativeDate: String, related: List<String>) {
        val text = TextNorm.clean(content, StoryLimits.MEMORY_CHARS)
        if (text.length < 3) throw StoryException("El recuerdo está vacío.")
        db.withTransaction {
            val m = db.memories().get(id) ?: throw StoryException("Ese recuerdo ya no existe.")
            db.memories().update(
                m.copy(
                    content = text, importance = importance.coerceIn(1, 5), narrativeDate = TextNorm.clean(narrativeDate, StoryLimits.DATE_CHARS),
                    relatedNames = cleanNames(related), updatedAt = clock(),
                ),
            )
        }
    }

    suspend fun setPinned(id: Long, pinned: Boolean) {
        db.withTransaction {
            val m = db.memories().get(id) ?: return@withTransaction
            if (m.state != ItemState.ACTIVO) throw StoryException("Solo se pueden fijar recuerdos activos. Acepta primero la propuesta.")
            db.memories().update(m.copy(pinned = pinned, updatedAt = clock()))
        }
    }

    /** Aceptar una propuesta es una decisión explícita del usuario: pasa a ACTIVO y a «confirmado por el usuario». */
    suspend fun acceptMemory(id: Long, editedContent: String? = null) {
        db.withTransaction {
            val m = db.memories().get(id) ?: return@withTransaction
            if (m.state != ItemState.PROPUESTO) return@withTransaction
            val text = editedContent?.let { TextNorm.clean(it, StoryLimits.MEMORY_CHARS) }?.takeIf { it.length >= 3 } ?: m.content
            db.memories().update(m.copy(content = text, state = ItemState.ACTIVO, verification = Verification.CONFIRMADO, updatedAt = clock()))
        }
    }

    /** Descartar una propuesta la deja guardada como DESCARTADO (así no se vuelve a proponer lo mismo). */
    suspend fun discardMemory(id: Long) {
        db.withTransaction {
            val m = db.memories().get(id) ?: return@withTransaction
            if (m.state == ItemState.PROPUESTO) db.memories().update(m.copy(state = ItemState.DESCARTADO, updatedAt = clock()))
        }
    }

    suspend fun deleteMemory(id: Long) = db.memories().delete(id)

    /**
     * Añade propuestas del modelo SIN tocar nada existente. Se omiten las parecidas a lo que ya hay (también a lo descartado).
     * Devuelve cuántas se añadieron.
     */
    suspend fun proposeMemories(sessionId: Long, list: List<ProposedMemory>, sourceMessageId: Long?, note: String): Int = db.withTransaction {
        val existing = db.memories().allTexts(sessionId)
        val room = (MAX_PENDING - db.memories().listAll(sessionId).count { it.state == ItemState.PROPUESTO }).coerceAtLeast(0)
        val fresh = Dedup.filterNew(list, { it.content }, existing).take(room)
        val now = clock()
        for (p in fresh) {
            db.memories().insert(
                MemoryEntity(
                    sessionId = sessionId, content = TextNorm.clean(p.content, StoryLimits.MEMORY_CHARS), importance = p.importance.coerceIn(1, 5),
                    origin = if (p.inferred) Origin.INFERENCIA else Origin.EXTRACCION,
                    verification = if (p.inferred) Verification.INFERIDO else Verification.EXTRAIDO,
                    state = ItemState.PROPUESTO, sourceMessageId = sourceMessageId, sourceNote = TextNorm.clean(note, StoryLimits.NOTE_CHARS),
                    createdAt = now, updatedAt = now,
                ),
            )
        }
        fresh.size
    }

    private fun cleanNames(l: List<String>) = l.map { TextNorm.clean(it, StoryLimits.NAME_CHARS) }.filter { it.isNotEmpty() }.distinct().take(20).joinToString("\n")

    // ============================ Cronología ============================

    fun observeTimeline(sessionId: Long): Flow<List<TimelineEventEntity>> = db.timeline().observeActive(sessionId)
    fun observePendingTimeline(sessionId: Long): Flow<List<TimelineEventEntity>> = db.timeline().observePending(sessionId)

    suspend fun addEvent(sessionId: Long, text: String, narrativeDate: String, characters: List<String>, orderKey: Int?): Long {
        val t = TextNorm.clean(text, StoryLimits.TIMELINE_CHARS)
        if (t.length < 3) throw StoryException("El acontecimiento está vacío.")
        return db.withTransaction {
            val key = orderKey ?: (db.timeline().maxOrderKey(sessionId) + 10)
            db.timeline().insert(
                TimelineEventEntity(
                    sessionId = sessionId, text = t, narrativeDate = TextNorm.clean(narrativeDate, StoryLimits.DATE_CHARS), orderKey = key,
                    characterNames = cleanNames(characters), origin = Origin.USUARIO, state = ItemState.ACTIVO, createdAt = clock(),
                ),
            )
        }
    }

    suspend fun editEvent(id: Long, text: String, narrativeDate: String, characters: List<String>, orderKey: Int) {
        val t = TextNorm.clean(text, StoryLimits.TIMELINE_CHARS)
        if (t.length < 3) throw StoryException("El acontecimiento está vacío.")
        db.withTransaction {
            val e = db.timeline().get(id) ?: return@withTransaction
            db.timeline().update(e.copy(text = t, narrativeDate = TextNorm.clean(narrativeDate, StoryLimits.DATE_CHARS), characterNames = cleanNames(characters), orderKey = orderKey))
        }
    }

    suspend fun deleteEvent(id: Long) = db.timeline().delete(id)

    suspend fun acceptEvent(id: Long) {
        db.withTransaction {
            val e = db.timeline().get(id) ?: return@withTransaction
            if (e.state == ItemState.PROPUESTO) db.timeline().update(e.copy(state = ItemState.ACTIVO, orderKey = db.timeline().maxOrderKey(e.sessionId) + 10))
        }
    }

    suspend fun discardEvent(id: Long) {
        db.withTransaction {
            val e = db.timeline().get(id) ?: return@withTransaction
            if (e.state == ItemState.PROPUESTO) db.timeline().update(e.copy(state = ItemState.DESCARTADO))
        }
    }

    suspend fun proposeEvents(sessionId: Long, list: List<ProposedEvent>, sourceMessageId: Long?): Int = db.withTransaction {
        val existing = db.timeline().allTexts(sessionId)
        val fresh = Dedup.filterNew(list, { it.text }, existing).take(MAX_PENDING)
        val now = clock()
        var key = db.timeline().maxOrderKey(sessionId)
        for (p in fresh) {
            key += 10
            db.timeline().insert(
                TimelineEventEntity(
                    sessionId = sessionId, text = p.text, narrativeDate = p.date, orderKey = key, origin = Origin.EXTRACCION,
                    state = ItemState.PROPUESTO, sourceMessageId = sourceMessageId, createdAt = now,
                ),
            )
        }
        fresh.size
    }

    // ============================ Resúmenes con versiones ============================

    fun observeSummaries(sessionId: Long): Flow<List<SummaryEntity>> = db.summaries().observe(sessionId)

    /**
     * Guarda una versión nueva y la deja como resumen vigente de la partida (role_sessions.summary, lo que usa el contexto).
     * Si es el primer resumen versionado y ya había texto escrito a mano en la 0.3, ese texto se conserva como versión 1.
     */
    suspend fun saveSummary(sessionId: Long, text: String, source: String, coversUpTo: Int = -1, note: String = ""): Int = db.withTransaction {
        val s = db.roleSessions().get(sessionId) ?: throw StoryException("La partida ya no existe.")
        val clean = TextNorm.clean(text, StoryLimits.SUMMARY_CHARS)
        val now = clock()
        var v = db.summaries().maxVersion(sessionId)
        if (v == 0 && s.summary.isNotBlank() && s.summary.trim() != clean) {
            v = 1
            db.summaries().insert(SummaryEntity(sessionId = sessionId, version = 1, text = s.summary, source = Origin.USUARIO, note = "Resumen anterior (v0.3)", createdAt = now))
        }
        v += 1
        db.summaries().insert(SummaryEntity(sessionId = sessionId, version = v, text = clean, source = source, coversUpToOrder = coversUpTo, note = TextNorm.clean(note, StoryLimits.NOTE_CHARS), createdAt = now))
        db.roleSessions().setSummary(sessionId, clean, now)
        v
    }

    /** Restaurar = crear una versión nueva con el texto antiguo (el historial nunca se reescribe). */
    suspend fun restoreSummary(sessionId: Long, version: Int): Int {
        val old = db.summaries().get(sessionId, version) ?: throw StoryException("Esa versión del resumen ya no existe.")
        return saveSummary(sessionId, old.text, Origin.RESTAURADO, old.coversUpToOrder, "Restaurada la versión $version")
    }

    // ============================ Progreso del mantenimiento ============================

    suspend fun coveredOrder(sessionId: Long): Int = db.memoryProgress().get(sessionId)?.coveredOrder ?: -1
    suspend fun userTurnsSince(sessionId: Long): Int = db.messageRange().countUserAfter(sessionId, coveredOrder(sessionId))
    suspend fun setCovered(sessionId: Long, order: Int) = db.memoryProgress().upsert(MemoryProgressEntity(sessionId, order, clock()))
    suspend fun linesAfter(sessionId: Long, after: Int): List<RoleMessageEntity> = db.messageRange().listAfter(sessionId, after)

    // ============================ Relaciones ============================

    fun observeRelationships(sessionId: Long): Flow<List<RelationshipEntity>> = db.relationships().observe(sessionId)
    fun observeRelationEvents(sessionId: Long): Flow<List<RelationshipEventEntity>> = db.relationshipEvents().observe(sessionId)

    /** Crea «personaje → usuario» con valores iniciales neutros si la partida aún no tiene relaciones. */
    suspend fun ensureDefaultRelationship(sessionId: Long, characterName: String, userName: String) {
        db.withTransaction {
            if (db.relationships().list(sessionId).isNotEmpty()) return@withTransaction
            createRelationship(sessionId, characterName, userName)
        }
    }

    private suspend fun createRelationship(sessionId: Long, a: String, b: String): Long {
        val now = clock()
        val v = RelValues.INITIAL
        val id = db.relationships().insert(RelationshipEntity(sessionId = sessionId, aName = a, bName = b, trust = v.trust, affection = v.affection, respect = v.respect, romantic = v.romantic, createdAt = now, updatedAt = now))
        db.relationshipEvents().insert(
            RelationshipEventEntity(
                relationshipId = id, sessionId = sessionId, state = EventState.APLICADO, origin = Origin.INICIAL, reason = "Valores iniciales",
                trustAfter = v.trust, affectionAfter = v.affection, respectAfter = v.respect, romanticAfter = v.romantic, createdAt = now,
            ),
        )
        return id
    }

    suspend fun addRelationship(sessionId: Long, a: String, b: String): Long {
        val an = TextNorm.clean(a, StoryLimits.NAME_CHARS); val bn = TextNorm.clean(b, StoryLimits.NAME_CHARS)
        if (an.isEmpty() || bn.isEmpty() || TextNorm.fold(an) == TextNorm.fold(bn)) throw StoryException("Indica dos nombres distintos.")
        return db.withTransaction {
            if (db.relationships().list(sessionId).size >= StoryLimits.MAX_RELATIONSHIPS) throw StoryException("Demasiadas relaciones en esta partida.")
            if (db.relationships().find(sessionId, an, bn) != null) throw StoryException("Esa relación ya existe.")
            createRelationship(sessionId, an, bn)
        }
    }

    suspend fun deleteRelationship(id: Long) = db.relationships().delete(id)

    /** Corrección manual del usuario: valores absolutos de 1 a 100 y el motivo queda en el historial. */
    suspend fun setRelationshipManually(id: Long, target: RelValues, status: String, reason: String) {
        db.withTransaction {
            val r = db.relationships().get(id) ?: throw StoryException("Esa relación ya no existe.")
            val (after, delta) = RelationshipRules.manualSet(r.values(), target)
            val now = clock()
            db.relationships().update(r.copy(trust = after.trust, affection = after.affection, respect = after.respect, romantic = after.romantic, status = TextNorm.clean(status, 120), updatedAt = now))
            if (!delta.isZero()) {
                db.relationshipEvents().insert(
                    RelationshipEventEntity(
                        relationshipId = id, sessionId = r.sessionId, state = EventState.APLICADO, origin = Origin.USUARIO,
                        reason = TextNorm.clean(reason, StoryLimits.REASON_CHARS).ifBlank { "Corrección manual" },
                        dTrust = delta.trust, dAffection = delta.affection, dRespect = delta.respect, dRomantic = delta.romantic,
                        trustAfter = after.trust, affectionAfter = after.affection, respectAfter = after.respect, romanticAfter = after.romantic, createdAt = now,
                    ),
                )
            }
        }
    }

    /**
     * Guarda propuestas del modelo como acontecimientos PENDIENTES. Solo se aceptan nombres que ya tienen una relación en la
     * partida; el cambio se valida con límites y se guarda ya recortado. Devuelve cuántas se guardaron.
     */
    suspend fun proposeRelationChanges(sessionId: Long, list: List<ProposedRelation>, sourceMessageId: Long?): Int = db.withTransaction {
        val rels = db.relationships().list(sessionId)
        var n = 0
        for (p in list) {
            val r = rels.firstOrNull { TextNorm.fold(it.aName).trim() == TextNorm.fold(p.a).trim() && TextNorm.fold(it.bName).trim() == TextNorm.fold(p.b).trim() } ?: continue
            val v = RelationshipRules.validateProposal(r.values(), p.delta, p.reason)
            if (!v.ok) continue
            db.relationshipEvents().insert(
                RelationshipEventEntity(
                    relationshipId = r.id, sessionId = sessionId, state = EventState.PROPUESTO, origin = Origin.MODELO, reason = p.reason,
                    dTrust = v.applied.trust, dAffection = v.applied.affection, dRespect = v.applied.respect, dRomantic = v.applied.romantic,
                    sourceMessageId = sourceMessageId, createdAt = clock(),
                ),
            )
            n++
        }
        n
    }

    /** Acepta una propuesta: se vuelve a validar contra los valores ACTUALES (pudieron cambiar desde que se propuso). */
    suspend fun acceptRelationEvent(eventId: Long): String? = db.withTransaction {
        val e = db.relationshipEvents().get(eventId) ?: return@withTransaction "Esa propuesta ya no existe."
        if (e.state != EventState.PROPUESTO) return@withTransaction null
        val r = db.relationships().get(e.relationshipId) ?: return@withTransaction "La relación ya no existe."
        val v = RelationshipRules.validateProposal(r.values(), RelDelta(e.dTrust, e.dAffection, e.dRespect, e.dRomantic), e.reason)
        if (!v.ok) return@withTransaction v.notes.joinToString(" ").ifBlank { "El cambio ya no se puede aplicar." }
        val now = clock()
        db.relationships().update(r.copy(trust = v.after.trust, affection = v.after.affection, respect = v.after.respect, romantic = v.after.romantic, updatedAt = now))
        db.relationshipEvents().update(
            e.copy(
                state = EventState.APLICADO, dTrust = v.applied.trust, dAffection = v.applied.affection, dRespect = v.applied.respect, dRomantic = v.applied.romantic,
                trustAfter = v.after.trust, affectionAfter = v.after.affection, respectAfter = v.after.respect, romanticAfter = v.after.romantic,
            ),
        )
        null
    }

    suspend fun rejectRelationEvent(eventId: Long) {
        db.withTransaction {
            val e = db.relationshipEvents().get(eventId) ?: return@withTransaction
            if (e.state == EventState.PROPUESTO) db.relationshipEvents().update(e.copy(state = EventState.RECHAZADO))
        }
    }

    // ============================ Volúmenes y capítulos ============================

    fun observeVolumes(sessionId: Long): Flow<List<VolumeEntity>> = db.volumes().observe(sessionId)
    fun observeChapters(sessionId: Long): Flow<List<ChapterEntity>> = db.chapters().observe(sessionId)

    /** Las partidas de la 0.3 no tienen estructura: se crea al abrirla (volumen 1 abierto con el capítulo 1 desde el primer mensaje). */
    suspend fun ensureStructure(sessionId: Long) {
        db.withTransaction {
            if (db.volumes().list(sessionId).isNotEmpty()) return@withTransaction
            val now = clock()
            val v = db.volumes().insert(VolumeEntity(sessionId = sessionId, number = 1, title = "", createdAt = now))
            db.chapters().insert(ChapterEntity(sessionId = sessionId, volumeId = v, number = 1, startOrder = 0, createdAt = now))
        }
    }

    suspend fun renameChapter(id: Long, title: String) {
        val c = db.chapters().get(id) ?: return
        db.chapters().update(c.copy(title = TextNorm.clean(title, StoryLimits.TITLE_CHARS)))
    }

    suspend fun renameVolume(id: Long, title: String) {
        val v = db.volumes().get(id) ?: return
        db.volumes().update(v.copy(title = TextNorm.clean(title, StoryLimits.TITLE_CHARS)))
    }

    /** Cierra el capítulo abierto en el último mensaje. Con [openNext] abre el siguiente al instante. */
    suspend fun closeChapter(sessionId: Long, openNext: Boolean): Long? = db.withTransaction {
        val open = db.chapters().open(sessionId) ?: throw StoryException("No hay ningún capítulo abierto.")
        val last = db.messageRange().maxOrder(sessionId)
        if (last < open.startOrder) throw StoryException("El capítulo está vacío: aún no tiene mensajes.")
        val now = clock()
        db.chapters().update(open.copy(state = ChapterState.CERRADO, endOrder = last, closedAt = now))
        if (!openNext) return@withTransaction null
        db.chapters().insert(ChapterEntity(sessionId = sessionId, volumeId = open.volumeId, number = db.chapters().maxNumber(sessionId) + 1, startOrder = last + 1, createdAt = now))
    }

    /** Abre un capítulo nuevo (solo si no hay ninguno abierto) en el volumen abierto. */
    suspend fun openChapter(sessionId: Long): Long = db.withTransaction {
        if (db.chapters().open(sessionId) != null) throw StoryException("Ya hay un capítulo abierto. Ciérralo primero.")
        val vol = db.volumes().open(sessionId) ?: throw StoryException("No hay ningún volumen abierto.")
        db.chapters().insert(ChapterEntity(sessionId = sessionId, volumeId = vol.id, number = db.chapters().maxNumber(sessionId) + 1, startOrder = db.messageRange().maxOrder(sessionId) + 1, createdAt = clock()))
    }

    /** Reabre el ÚLTIMO capítulo si está cerrado y no hay otro abierto (para seguir escribiendo en él). */
    suspend fun reopenChapter(chapterId: Long) {
        db.withTransaction {
            val c = db.chapters().get(chapterId) ?: throw StoryException("Ese capítulo ya no existe.")
            if (c.state != ChapterState.CERRADO) return@withTransaction
            val all = db.chapters().list(c.sessionId)
            if (all.any { it.state == ChapterState.ABIERTO }) throw StoryException("Ya hay un capítulo abierto. Ciérralo o elimínalo si está vacío.")
            if (all.maxOf { it.number } != c.number) throw StoryException("Solo se puede reabrir el último capítulo.")
            val vol = db.volumes().get(c.volumeId)
            if (vol?.state != VolumeState.ABIERTO) throw StoryException("Ese capítulo pertenece a un volumen archivado. Restaura primero el volumen.")
            db.chapters().update(c.copy(state = ChapterState.ABIERTO, endOrder = null, closedAt = null))
        }
    }

    suspend fun deleteEmptyOpenChapter(sessionId: Long) {
        db.withTransaction {
            val open = db.chapters().open(sessionId) ?: return@withTransaction
            if (db.messageRange().maxOrder(sessionId) >= open.startOrder) throw StoryException("El capítulo ya tiene mensajes: ciérralo en lugar de eliminarlo.")
            db.chapters().delete(open.id)
        }
    }

    suspend fun saveChapterSummary(id: Long, text: String) {
        val c = db.chapters().get(id) ?: return
        db.chapters().update(c.copy(summary = TextNorm.clean(text, StoryLimits.SUMMARY_CHARS)))
    }

    /** Texto novelado generado por el modelo (no modifica nada más). */
    suspend fun saveNovelGenerated(id: Long, text: String) {
        val c = db.chapters().get(id) ?: return
        db.chapters().update(c.copy(novelText = TextNorm.clean(text, StoryLimits.NOVEL_CHARS), novelState = NovelState.GENERADA))
    }

    suspend fun saveNovelEdited(id: Long, text: String) {
        val c = db.chapters().get(id) ?: return
        db.chapters().update(c.copy(novelText = TextNorm.clean(text, StoryLimits.NOVEL_CHARS), novelState = if (text.isBlank()) NovelState.NINGUNA else NovelState.EDITADA))
    }

    suspend fun chapterMessages(c: ChapterEntity): List<RoleMessageEntity> =
        db.messageRange().range(c.sessionId, c.startOrder, c.endOrder ?: db.messageRange().maxOrder(c.sessionId))

    /**
     * Cierra el volumen abierto: cierra su capítulo abierto (o lo elimina si está vacío), archiva el volumen con su resumen de
     * continuidad y abre el volumen siguiente con un capítulo nuevo. Recuerdos, cronología, relaciones y mensajes se CONSERVAN.
     * El resumen de continuidad pasa a ser el resumen vigente de la partida (nueva versión).
     */
    suspend fun closeVolume(sessionId: Long, continuity: String): Long = db.withTransaction {
        val vol = db.volumes().open(sessionId) ?: throw StoryException("No hay ningún volumen abierto.")
        val text = TextNorm.clean(continuity, StoryLimits.SUMMARY_CHARS)
        if (text.isBlank()) throw StoryException("El resumen de continuidad no puede estar vacío.")
        val now = clock()
        val last = db.messageRange().maxOrder(sessionId)
        db.chapters().open(sessionId)?.let { open ->
            if (last >= open.startOrder) db.chapters().update(open.copy(state = ChapterState.CERRADO, endOrder = last, closedAt = now)) else db.chapters().delete(open.id)
        }
        db.volumes().update(vol.copy(state = VolumeState.ARCHIVADO, continuitySummary = text, closedAt = now))
        val next = db.volumes().insert(VolumeEntity(sessionId = sessionId, number = vol.number + 1, createdAt = now))
        db.chapters().insert(ChapterEntity(sessionId = sessionId, volumeId = next, number = db.chapters().maxNumber(sessionId) + 1, startOrder = last + 1, createdAt = now))
        saveSummary(sessionId, text, Origin.CIERRE_VOLUMEN, last, "Cierre del volumen ${vol.number}")
        next
    }

    /**
     * Deshace el cierre del ÚLTIMO volumen archivado, siempre que el volumen siguiente siga vacío (sin mensajes nuevos).
     * Elimina el volumen siguiente (vacío) y reabre el archivado. El resumen de la partida NO cambia: restáuralo desde sus versiones si quieres.
     */
    suspend fun reopenVolume(volumeId: Long) {
        db.withTransaction {
            val v = db.volumes().get(volumeId) ?: throw StoryException("Ese volumen ya no existe.")
            if (v.state != VolumeState.ARCHIVADO) return@withTransaction
            val all = db.volumes().list(v.sessionId)
            val next = all.firstOrNull { it.number == v.number + 1 } ?: throw StoryException("No se puede reabrir este volumen.")
            if (all.any { it.number > next.number }) throw StoryException("Solo se puede reabrir el último volumen archivado.")
            val last = db.messageRange().maxOrder(v.sessionId)
            if (db.chapters().forVolume(next.id).any { it.state == ChapterState.CERRADO || last >= it.startOrder })
                throw StoryException("El volumen siguiente ya tiene mensajes: no se puede deshacer el cierre.")
            db.volumes().delete(next.id)   // sus capítulos (vacíos) se borran en cascada
            db.volumes().update(v.copy(state = VolumeState.ABIERTO, closedAt = null))
            // El último capítulo del volumen se reabre para poder continuar.
            db.chapters().forVolume(v.id).maxByOrNull { it.number }?.let { db.chapters().update(it.copy(state = ChapterState.ABIERTO, endOrder = null, closedAt = null)) }
        }
    }

    // ============================ Lecturas para los trabajos con el modelo ============================

    /** Textos de recuerdos activos (fijados e importantes primero) para decirle al modelo qué NO repetir. */
    suspend fun knownMemoryTexts(sessionId: Long, limit: Int): List<String> = db.memories().listActive(sessionId).take(limit).map { it.content }
    suspend fun recentEventTexts(sessionId: Long, n: Int): List<String> = db.timeline().listActive(sessionId).takeLast(n).map { (if (it.narrativeDate.isNotBlank()) "${it.narrativeDate}: " else "") + it.text }
    suspend fun openVolume(sessionId: Long): VolumeEntity? = db.volumes().open(sessionId)
    suspend fun chaptersOfVolume(volumeId: Long): List<ChapterEntity> = db.chapters().forVolume(volumeId)
    suspend fun chapter(id: Long): ChapterEntity? = db.chapters().get(id)
    suspend fun relationItems(sessionId: Long): List<RelationItem> = db.relationships().list(sessionId).map { it.toItem() }
    suspend fun pendingCount(sessionId: Long): Int =
        db.memories().listAll(sessionId).count { it.state == ItemState.PROPUESTO } + db.timeline().listAll(sessionId).count { it.state == ItemState.PROPUESTO } +
            db.relationshipEvents().list(sessionId).count { it.state == EventState.PROPUESTO }

    // ============================ StorySource (para el recuperador) ============================

    override suspend fun candidateMemories(sessionId: Long, queryTokens: List<String>): MemoryCandidates {
        val total = db.memories().countActive(sessionId)
        val fts = if (FtsSupport.available) ftsIds(sessionId, queryTokens) else null
        val backend = if (fts != null) "texto completo (FTS4) + palabras clave" else "palabras clave (FTS4 no disponible)"
        if (total <= SCAN_ALL_LIMIT) return MemoryCandidates(db.memories().listActive(sessionId).map { it.toItem() }, fts, backend)
        // Muchos recuerdos: solo los fijados/importantes y los que encuentra la búsqueda.
        val picked = LinkedHashMap<Long, MemoryEntity>()
        db.memories().topActive(sessionId, 150).forEach { picked[it.id] = it }
        val ids = fts?.toList() ?: emptyList()
        if (ids.isNotEmpty()) db.memories().activeByIds(sessionId, ids.take(300)).forEach { picked[it.id] = it }
        else for (t in queryTokens.take(8)) db.memories().searchLike(sessionId, "%" + escapeLike(t) + "%", 40).forEach { picked[it.id] = it }
        return MemoryCandidates(picked.values.map { it.toItem() }, fts, backend + " · preselección ($total recuerdos)")
    }

    override suspend fun timeline(sessionId: Long): List<TimelineItem> = db.timeline().listActive(sessionId).map { it.toItem() }
    override suspend fun relationships(sessionId: Long): List<RelationItem> = db.relationships().list(sessionId).map { it.toItem() }

    private suspend fun ftsIds(sessionId: Long, tokens: List<String>): Set<Long>? = withContext(Dispatchers.IO) {
        val expr = FtsSupport.matchExpression(tokens.flatMap { TextNorm.keys(it) }) ?: return@withContext emptySet()
        try {
            val out = HashSet<Long>()
            db.query(
                SimpleSQLiteQuery(
                    "SELECT m.id FROM memories m WHERE m.sessionId = ? AND m.state = 'ACTIVO' AND m.id IN " +
                        "(SELECT docid FROM ${FtsSupport.TABLE} WHERE ${FtsSupport.TABLE} MATCH ?)",
                    arrayOf<Any>(sessionId, expr),
                ),
            ).use { c -> while (c.moveToNext()) out.add(c.getLong(0)) }
            out
        } catch (e: Exception) {
            null   // la búsqueda de texto completo falló: se usa el respaldo
        }
    }

    /** Búsqueda que ve el usuario en la pantalla de recuerdos: FTS4 si hay, si no LIKE. */
    suspend fun searchMemories(sessionId: Long, query: String, limit: Int = 50): List<MemoryEntity> {
        val tokens = TextNorm.tokens(query)
        if (tokens.isEmpty()) return emptyList()
        val ids = if (FtsSupport.available) ftsIds(sessionId, tokens) else null
        if (ids != null) return db.memories().activeByIds(sessionId, ids.take(limit))
        val out = LinkedHashMap<Long, MemoryEntity>()
        for (t in tokens.take(6)) db.memories().searchLike(sessionId, "%" + escapeLike(t) + "%", limit).forEach { out[it.id] = it }
        return out.values.take(limit)
    }

    private fun escapeLike(s: String) = s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
}
