package com.jullai.local.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.jullai.local.chat.ChatViewModel
import com.jullai.local.data.ConversationEntity
import com.jullai.local.data.MessageEntity
import com.jullai.local.data.MessageRole
import com.jullai.local.data.MessageState
import com.jullai.local.engine.EngineState
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(vm: ChatViewModel, conversationId: Long, onBack: () -> Unit) {
    LaunchedEffect(conversationId) { vm.open(conversationId) }

    val convState by vm.current.collectAsState()
    val allMessages by vm.messages.collectAsState()
    val gen by vm.gen.collectAsState()
    val stream by vm.stream.collectAsState()
    val editing by vm.editing.collectAsState()
    val engineState by vm.engineState.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val loading by vm.busyLoading.collectAsState()
    val models by vm.models.collectAsState()
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val conv: ConversationEntity? = convState?.takeIf { it.id == conversationId }
    // Más reciente primero: la lista se dibuja con reverseLayout, así el final queda anclado abajo mientras el texto crece.
    val shown = remember(allMessages, conversationId) {
        allMessages.filter { it.conversationId == conversationId }.asReversed()
    }

    var input by rememberSaveable(conversationId) { mutableStateOf("") }
    var showOptions by rememberSaveable { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }

    val saved = remember(conversationId) { vm.scrollFor(conversationId) }
    val listState = rememberLazyListState(saved.first, saved.second)
    val atNewest by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0 } }

    DisposableEffect(conversationId) {
        onDispose { vm.saveScroll(conversationId, listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }
    // Si llega un mensaje nuevo y el lector estaba cerca del final, se sigue la conversación.
    LaunchedEffect(shown.firstOrNull()?.id) {
        if (listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0)
    }
    LaunchedEffect(editing?.id) {
        editing?.let { input = it.content }
    }

    val busy = gen.messageId != null
    val generating = engineState == EngineState.GENERATING

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = conv?.title ?: "Conversación",
            onBack = onBack,
            trailing = { InkLink(if (showOptions) "Opciones ▴" else "Opciones ▾", { showOptions = !showOptions }) },
        )
        // Estado del motor, siempre visible.
        val status = when {
            loading != null -> loading!!
            generating -> "Motor: generando…"
            loaded != null -> "Motor listo · ${loaded!!.model.displayName} · contexto ${loaded!!.contextLength}"
            busy -> gen.phase
            else -> "Modelo sin cargar: se cargará al enviar el primer mensaje."
        }
        Row(Modifier.fillMaxWidth().background(Ink.Pizarra).padding(horizontal = 16.dp, vertical = 6.dp)) {
            BasicText(status + if (busy && !generating && loading == null) " · ${gen.phase}" else "", style = Type.Nota)
        }

        if (showOptions && conv != null) {
            OptionsPanel(
                vm = vm, conv = conv, models = models.map { it.fileName to it.displayName },
                disabled = busy,
                onRename = { renaming = true },
                onDelete = { deleting = true },
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (conv == null) {
                BasicText("Cargando…", style = Type.Nota, modifier = Modifier.padding(20.dp))
            } else if (shown.isEmpty()) {
                BasicText(
                    "Escribe tu primer mensaje abajo. Todo se procesa en este teléfono.",
                    style = Type.Cuerpo.copy(color = Ink.MarfilTenue),
                    modifier = Modifier.padding(20.dp),
                )
            }
            LazyColumn(
                state = listState,
                reverseLayout = true,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            ) {
                items(shown, key = { it.id }) { m ->
                    val isLast = m.id == shown.firstOrNull()?.id
                    val active = gen.messageId == m.id || (busy && m.state == MessageState.GENERATING)
                    MessageItem(
                        m = m,
                        text = if (stream?.messageId == m.id) stream!!.text else m.content,
                        active = active,
                        canAct = !busy,
                        isLastAssistant = isLast && m.role == MessageRole.ASSISTANT,
                        onCopy = { clipboard.setText(AnnotatedString(if (stream?.messageId == m.id) stream!!.text else m.content)) },
                        onEdit = { vm.startEdit(m) },
                        onRegenerate = { vm.regenerate() },
                    )
                }
            }
            if (!atNewest) {
                Box(Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                    InkButton("↓ Recientes", { scope.launch { listState.animateScrollToItem(0) } })
                }
            }
        }

        gen.error?.let { msg ->
            Row(
                Modifier.fillMaxWidth().background(Ink.Pizarra).padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    BasicText(msg, style = Type.Nota.copy(color = Ink.Granate))
                    BasicText("Tu historial está a salvo. Puedes reintentar con «Regenerar».", style = Type.Nota)
                }
                InkLink("Cerrar", { vm.dismissError() })
            }
        }
        if (gen.stats.isNotBlank() && !busy) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp)) { BasicText(gen.stats, style = Type.Mono) }
        }

        editing?.let {
            Row(
                Modifier.fillMaxWidth().background(Ink.Pizarra).padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    BasicText("Editando un mensaje: al enviarlo se descartan las respuestas posteriores y se genera una nueva.", style = Type.Nota.copy(color = Ink.Oro))
                }
                InkLink("Cancelar", { vm.cancelEdit(); input = "" })
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            InkField(
                value = input,
                onChange = { input = it },
                placeholder = "Escribe tu mensaje…",
                modifier = Modifier.weight(1f),
                minHeight = 24,
                maxHeight = 140,
                enabled = !busy,
            )
            Spacer(Modifier.width(8.dp))
            if (busy) {
                InkButton("Detener", { vm.stop() }, primary = false)
            } else {
                InkButton(
                    "Enviar",
                    {
                        val text = input
                        input = ""
                        vm.send(text)
                        scope.launch { listState.animateScrollToItem(0) }
                    },
                    enabled = input.isNotBlank() && conv != null,
                )
            }
        }
    }

    if (renaming && conv != null) {
        RenameDialog(conv.title, { renaming = false }, { vm.rename(conv.id, it); renaming = false })
    }
    if (deleting && conv != null) {
        ConfirmDeleteDialog(conv.title, { deleting = false }, { deleting = false; vm.delete(conv.id) { onBack() } })
    }
}

@Composable
private fun MessageItem(
    m: MessageEntity,
    text: String,
    active: Boolean,
    canAct: Boolean,
    isLastAssistant: Boolean,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onRegenerate: () -> Unit,
) {
    val isUser = m.role == MessageRole.USER
    val shape = RoundedCornerShape(8.dp)
    Column(
        Modifier
            .padding(vertical = 6.dp)
            .fillMaxWidth()
            .background(if (isUser) Ink.Pizarra else Ink.Tinta, shape)
            .padding(12.dp),
    ) {
        BasicText(
            if (isUser) "Tú" else "JullAI",
            style = Type.Nota.copy(color = if (isUser) Ink.Oro else Ink.Granate),
        )
        SelectionContainer {
            BasicText(
                if (text.isEmpty()) (if (active) "…" else "(sin texto)") else text,
                style = Type.Cuerpo,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        if (!isUser && !active) {
            when (m.state) {
                MessageState.INTERRUPTED, MessageState.GENERATING ->
                    BasicText("⚠ Respuesta interrumpida (se conserva el texto parcial).", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 6.dp))
                MessageState.ERROR ->
                    BasicText("⚠ Error al generar esta respuesta.", style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 6.dp))
            }
        }
        Row(Modifier.padding(top = 6.dp)) {
            InkLink("Copiar", onCopy, enabled = text.isNotEmpty())
            if (isUser) InkLink("Editar", onEdit, enabled = canAct)
            if (isLastAssistant) InkLink("Regenerar", onRegenerate, enabled = canAct)
        }
    }
}

@Composable
private fun OptionsPanel(
    vm: ChatViewModel,
    conv: ConversationEntity,
    models: List<Pair<String, String>>,
    disabled: Boolean,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    var systemDraft by remember(conv.id, conv.systemPrompt) { mutableStateOf(conv.systemPrompt) }
    Column(
        Modifier
            .fillMaxWidth()
            .background(Ink.Pizarra)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        BasicText("Modelo de esta conversación", style = Type.Nota)
        if (models.isEmpty()) {
            BasicText("No hay modelos importados. Ve a Biblioteca → Modelos.", style = Type.Cuerpo.copy(color = Ink.Oro))
        }
        models.forEach { (file, name) ->
            val selected = conv.modelFileName == file
            Box(
                Modifier
                    .padding(top = 4.dp)
                    .fillMaxWidth()
                    .background(if (selected) Ink.Tinta else Ink.Pizarra, RoundedCornerShape(6.dp))
                    .clickable(enabled = !disabled) { vm.updateConversation { it.copy(modelFileName = file) } }
                    .padding(10.dp),
            ) {
                BasicText(name + if (selected) "  ✓" else "", style = Type.Cuerpo.copy(color = if (selected) Ink.Oro else Ink.Marfil))
            }
        }
        Stepper(
            "Temperatura", "%.1f".format(conv.temperature),
            { vm.updateConversation { it.copy(temperature = (Math.round(it.temperature * 10) - 1).coerceAtLeast(0) / 10f) } },
            { vm.updateConversation { it.copy(temperature = (Math.round(it.temperature * 10) + 1).coerceAtMost(20) / 10f) } },
            enabled = !disabled,
        )
        Stepper(
            "Top-p", "%.2f".format(conv.topP),
            { vm.updateConversation { it.copy(topP = (Math.round(it.topP * 20) - 1).coerceAtLeast(2) / 20f) } },
            { vm.updateConversation { it.copy(topP = (Math.round(it.topP * 20) + 1).coerceAtMost(20) / 20f) } },
            enabled = !disabled,
        )
        Stepper(
            "Máx. tokens de respuesta", "${conv.maxTokens}",
            { vm.updateConversation { it.copy(maxTokens = (it.maxTokens - 64).coerceAtLeast(16)) } },
            { vm.updateConversation { it.copy(maxTokens = (it.maxTokens + 64).coerceAtMost(2048)) } },
            enabled = !disabled,
        )
        Stepper(
            "Contexto (tokens)", "${conv.contextLength}",
            { vm.updateConversation { it.copy(contextLength = (it.contextLength - 512).coerceAtLeast(512)) } },
            { vm.updateConversation { it.copy(contextLength = (it.contextLength + 512).coerceAtMost(8192)) } },
            enabled = !disabled,
        )
        BasicText("Cambiar modelo o contexto recarga el modelo al enviar el siguiente mensaje.", style = Type.Nota)
        BasicText("Instrucciones del sistema", style = Type.Nota, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
        InkField(systemDraft, { systemDraft = it }, "Instrucciones del sistema (opcional)", Modifier.fillMaxWidth(), minHeight = 44, maxHeight = 120, enabled = !disabled)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Guardar instrucciones", { vm.updateConversation { it.copy(systemPrompt = systemDraft) } }, enabled = !disabled && systemDraft != conv.systemPrompt)
        }
        Row(Modifier.padding(top = 4.dp)) {
            InkLink("Renombrar", onRename, enabled = !disabled)
            InkLink("Eliminar conversación", onDelete, enabled = !disabled, danger = true)
        }
    }
}
