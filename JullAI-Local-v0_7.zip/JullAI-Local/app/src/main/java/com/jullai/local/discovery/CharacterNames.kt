package com.jullai.local.discovery

import com.jullai.local.story.TextNorm
import com.jullai.local.world.SourceText
import com.jullai.local.world.UntrustedText

/**
 * Un personaje candidato. [tier] 0 = principal, 1 = recurrente/secundario, 2 = otro con página propia, 3 = solo aparece en listados largos.
 * [order] conserva el orden de aparición para desempatar. Nada de esto es canon por sí solo: son nombres para ir a buscar sus páginas.
 */
data class CharacterCandidate(
    val name: String,
    val aliases: List<String> = emptyList(),
    val tier: Int,
    val order: Int,
    val sources: Set<String> = emptySet(),
    val actor: String = "",
)

/** Detección de nombres de personaje a partir de secciones, listados de reparto y títulos de categorías. Lógica pura y determinista. */
object CharacterNames {
    private val GENERIC = setOf(
        "cast", "main cast", "recurring cast", "guest cast", "reparto", "reparto principal", "main characters", "recurring characters", "supporting characters",
        "minor characters", "other characters", "characters", "personajes", "personajes principales", "personajes secundarios", "personajes recurrentes",
        "production", "produccion", "reception", "recepcion", "references", "referencias", "see also", "vease tambien", "external links", "enlaces externos",
        "notes", "notas", "overview", "resumen", "plot", "trama", "argumento", "sinopsis", "premise", "premisa", "episodes", "episodios", "seasons", "temporadas",
        "release", "estreno", "music", "musica", "awards", "premios", "legacy", "legado", "themes", "temas", "development", "desarrollo", "casting", "filming",
        "rodaje", "marketing", "home media", "ratings", "audiencias", "critical response", "adaptations", "adaptaciones", "spin-offs", "spin offs", "bibliography",
        "bibliografia", "further reading", "lecturas adicionales", "publication history", "historia de publicacion", "antagonists", "antagonistas", "villains",
        "protagonists", "protagonistas", "allies", "aliados", "groups", "grupos", "organizations", "organizaciones", "locations", "lugares", "ubicaciones",
        "other media", "otros medios", "merchandise", "merchandising", "trivia", "curiosidades", "gallery", "galeria", "etymology", "etimologia", "appearances",
        "apariciones", "history", "historia", "personality", "personalidad", "appearance", "apariencia", "abilities", "habilidades", "relationships", "relaciones",
    ).map { TextNorm.fold(it) }.toSet()

    private val BAD_WORDS = setOf("season", "temporada", "episode", "episodio", "list", "lista", "characters", "personajes", "category", "categoria", "template", "plantilla", "portal", "wiki", "film", "pelicula", "series", "serie")
    private val PARTICLES = setOf("de", "del", "la", "las", "los", "el", "van", "von", "der", "den", "le", "les", "da", "di", "du", "dos", "das", "bin", "ibn", "al", "of", "the", "y", "and", "mc", "st", "st.")
    private val MAIN_HINTS = listOf("main", "principal", "protagonist", "regular", "starring", "reparto principal")
    private val SECOND_HINTS = listOf("recurring", "recurrente", "supporting", "secundari", "antagonist", "villain", "antagonista", "allies", "aliad")

    /** ¿Parece un nombre propio de persona o criatura? (1 a 5 palabras, con mayúsculas, sin números ni palabras de encabezado). */
    fun looksLikeName(raw: String): Boolean {
        val s = raw.substringBefore('(').trim().trim('"', '\'', '“', '”', '«', '»', '.', ',')
        if (s.length < 2 || s.length > 48) return false
        if (s.any { it.isDigit() }) return false
        if (!s.all { it.isLetter() || it == ' ' || it == '\'' || it == '’' || it == '-' || it == '.' }) return false
        val f = TextNorm.fold(s)
        if (f in GENERIC) return false
        val words = s.split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty() || words.size > 5) return false
        if (words.any { TextNorm.fold(it).trim('.') in BAD_WORDS }) return false
        if (!words.first().first().isUpperCase()) return false
        return words.all { w -> w.first().isUpperCase() || TextNorm.fold(w) in PARTICLES }
    }

    /** Quita desambiguaciones («Rick Grimes (TV series)» → «Rick Grimes»). */
    fun baseName(title: String): String = UntrustedText.oneLine(title.substringBefore('(').trim().trimEnd(','), 80)

    fun tierOfHeading(heading: String): Int {
        val f = TextNorm.fold(heading)
        return when {
            MAIN_HINTS.any { f.contains(TextNorm.fold(it)) } -> 0
            SECOND_HINTS.any { f.contains(TextNorm.fold(it)) } -> 1
            else -> 2
        }
    }

    /** Encabezados que son nombres de personaje, según el nivel y el encabezado de primer nivel bajo el que cuelgan. */
    fun fromSections(sections: List<SectionRef>, startOrder: Int = 0, source: String = "secciones"): List<CharacterCandidate> {
        val out = ArrayList<CharacterCandidate>()
        var tier = 2
        var order = startOrder
        val seen = HashSet<String>()
        for (s in sections) {
            if (s.level <= 2) {
                // Un encabezado de primer nivel que no es un nombre fija el nivel de importancia de lo que cuelga de él.
                if (!looksLikeName(s.title) || TextNorm.fold(s.title) in GENERIC) { tier = tierOfHeading(s.title); continue }
            }
            if (!looksLikeName(s.title)) continue
            val name = baseName(s.title)
            if (seen.add(TextNorm.fold(name))) out.add(CharacterCandidate(name, tier = tier, order = order++, sources = setOf(source)))
        }
        return out
    }

    /** Líneas «Actor as Personaje» / «Actor como Personaje» de las secciones de reparto de un artículo (texto plano con «== Título ==»). */
    fun fromCastText(articleText: String, startOrder: Int = 0, source: String = "reparto"): List<CharacterCandidate> {
        val out = ArrayList<CharacterCandidate>()
        val seen = HashSet<String>()
        var order = startOrder
        val castHeads = listOf("cast", "reparto", "characters", "personajes", "starring", "main cast", "voice cast", "doblaje")
        val pat = Regex("^[\\s•*·\\-–]*([^\\n]{3,60}?)\\s+(?:as|como|interpreta a|interpretando a|plays|voiced|doblado)\\s+([^\\n]{2,60}?)\\s*(?:[,;:(–—]|\\s-\\s|$)", RegexOption.MULTILINE)
        for ((title, body) in SourceText.sections(articleText)) {
            val f = TextNorm.fold(title)
            if (castHeads.none { f.contains(it) }) continue
            val tier = tierOfHeading(title).let { if (it == 2) 1 else it }
            for (m in pat.findAll(body)) {
                val actor = m.groupValues[1].trim()
                val role = m.groupValues[2].trim().trim('"', '“', '”', '«', '»')
                if (!looksLikeName(actor) || actor.split(' ').size < 2) continue
                if (!looksLikeName(role)) continue
                val name = baseName(role)
                if (seen.add(TextNorm.fold(name))) out.add(CharacterCandidate(name, tier = tier, order = order++, sources = setOf(source), actor = actor))
            }
        }
        return out
    }

    /** Títulos de una categoría («Category:Main characters») → candidatos con el nivel indicado. Se descartan títulos que no parecen nombres. */
    fun fromTitles(titles: List<String>, tier: Int, startOrder: Int = 0, source: String): List<CharacterCandidate> {
        val out = ArrayList<CharacterCandidate>()
        val seen = HashSet<String>()
        var order = startOrder
        for (t in titles) {
            if (!looksLikeTitleOfCharacter(t)) continue
            val name = baseName(t)
            if (name.isBlank()) continue
            if (seen.add(TextNorm.fold(name))) out.add(CharacterCandidate(name, tier = tier, order = order++, sources = setOf(source)))
        }
        return out
    }

    /** Un título de página de categoría puede ser cualquier cosa («Season 3», «Rick Grimes/Gallery»): aquí se descarta lo que claramente no es un personaje. */
    fun looksLikeTitleOfCharacter(title: String): Boolean {
        val t = title.trim()
        if (t.isEmpty() || t.contains('/') || t.contains(':')) return false
        val f = TextNorm.fold(t)
        if (f.startsWith("list of") || f.startsWith("lista de") || f.startsWith("anexo")) return false
        return looksLikeName(t) || (t.substringBefore('(').trim().let { b -> b.isNotEmpty() && b.length <= 48 && b.first().isUpperCase() && b.none { it.isDigit() } && f !in GENERIC && b.split(' ').size <= 5 && b.split(' ').none { w -> TextNorm.fold(w) in BAD_WORDS } })
    }

    /**
     * Une varias listas (en orden de prioridad), sin duplicados: «Rick» se funde en «Rick Grimes» (alias) si comparten una palabra completa
     * y la corta es un solo token. Devuelve la lista ordenada por (nivel, orden de aparición).
     */
    fun merge(lists: List<List<CharacterCandidate>>): List<CharacterCandidate> {
        val all = ArrayList<CharacterCandidate>()
        var n = 0
        for (l in lists) for (c in l) all.add(c.copy(order = n++))
        val result = ArrayList<CharacterCandidate>()
        for (c in all) {
            val key = TextNorm.fold(c.name).trim()
            val tokens = tokens(key)
            val dup = result.indexOfFirst { r ->
                val rk = TextNorm.fold(r.name).trim()
                rk == key || sameFirstOrLast(tokens, tokens(rk))
            }
            if (dup < 0) { result.add(c); continue }
            val r = result[dup]
            val keepLonger = if (tokens(TextNorm.fold(r.name)).size >= tokens.size) r.name else c.name
            val other = if (keepLonger == r.name) c.name else r.name
            result[dup] = r.copy(
                name = keepLonger,
                aliases = (r.aliases + c.aliases + (if (TextNorm.fold(other) != TextNorm.fold(keepLonger)) listOf(other) else emptyList())).distinctBy { TextNorm.fold(it) }.take(8),
                tier = minOf(r.tier, c.tier), order = minOf(r.order, c.order), sources = r.sources + c.sources, actor = r.actor.ifBlank { c.actor },
            )
        }
        return result.sortedWith(compareBy({ it.tier }, { it.order }))
    }

    private fun tokens(folded: String) = folded.split(' ', '-').filter { it.length >= 2 && it !in PARTICLES }

    /** «rick» y «rick grimes»: uno solo con un token que coincide con el primer o el último del otro. */
    private fun sameFirstOrLast(a: List<String>, b: List<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        val (short, long) = if (a.size <= b.size) a to b else b to a
        if (short.size != 1 || long.size < 2) return false
        return short[0] == long.first() || short[0] == long.last()
    }

    /** Cuántos personajes se preparan según la profundidad de investigación. */
    fun limitFor(depth: String): Int = when (depth) { "PROFUNDA" -> 45; "MEDIA" -> 20; else -> 8 }
}
