package com.jullai.local.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.data.ChapterEntity
import com.jullai.local.data.MemoryEntity
import com.jullai.local.data.RelationshipEntity
import com.jullai.local.data.RoleSessionEntity
import com.jullai.local.data.TimelineEventEntity
import com.jullai.local.data.VolumeEntity
import com.jullai.local.roleplay.StoryViewModel
import com.jullai.local.story.ChapterState
import com.jullai.local.story.EventState
import com.jullai.local.story.ItemState
import com.jullai.local.story.RelValues
import com.jullai.local.story.Verification
import com.jullai.local.story.VolumeState
import java.text.DateFormat
import java.util.Date

// ======================= Piezas comunes =======================

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp).background(Ink.Pizarra, RoundedCornerShape(6.dp)).padding(10.dp)) { content() }
}

private fun names(s: String): List<String> = s.split(',', '\n').map { it.trim() }.filter { it.isNotEmpty() }

/** Estado del trabajo con el modelo (mantenimiento, novela...) con botón de detener. Se muestra en las tres pestañas. */
@Composable
private fun JobBar(story: StoryViewModel, sessionId: Long) {
    val st by story.jobStatus.collectAsState()
    val notice by story.notice.collectAsState()
    if (st.running && st.sessionId == sessionId) {
        Card {
            BasicText("Trabajando con el modelo (${st.kind}): ${st.progress}", style = Type.Nota.copy(color = Ink.Oro))
            Row { InkLink("Detener", { story.cancelJob() }, danger = true) }
        }
    } else if (st.sessionId == sessionId && (st.message.isNotBlank() || st.error != null)) {
        Card {
            BasicText(st.error ?: st.message, style = Type.Nota.copy(color = if (st.error != null) Ink.Granate else Ink.Marfil))
            Row { InkLink("Entendido", { story.dismissJob() }) }
        }
    }
    notice?.let { n ->
        Card {
            BasicText(n, style = Type.Nota.copy(color = Ink.Granate))
            Row { InkLink("Entendido", { story.dismissNotice() }) }
        }
    }
}

// ======================= Memoria =======================

@Composable
fun MemoryTab(story: StoryViewModel, session: RoleSessionEntity, recalled: String, busy: Boolean) {
    val memories by story.memories.collectAsState()
    val pending by story.pendingMemories.collectAsState()
    val timeline by story.timeline.collectAsState()
    val pendingTl by story.pendingTimeline.collectAsState()
    val summaries by story.summaries.collectAsState()
    val draft by story.summaryDraft.collectAsState()
    val results by story.searchResults.collectAsState()
    val job by story.jobStatus.collectAsState()

    var editing by remember { mutableStateOf<MemoryEntity?>(null) }
    var editingEvent by remember { mutableStateOf<TimelineEventEntity?>(null) }
    var query by remember(session.id) { mutableStateOf("") }
    var newText by remember(session.id) { mutableStateOf("") }
    var newDate by remember(session.id) { mutableStateOf("") }
    var newNames by remember(session.id) { mutableStateOf("") }
    var newImportance by remember(session.id) { mutableStateOf(3) }
    var newPinned by remember(session.id) { mutableStateOf(false) }
    var newEvent by remember(session.id) { mutableStateOf("") }
    var newEventDate by remember(session.id) { mutableStateOf("") }
    var draftText by remember(draft?.text) { mutableStateOf(draft?.text ?: "") }

    JobBar(story, session.id)
    BasicText(
        "Lo que aquí guardes llega al modelo cuando es relevante. Solo los recuerdos activos se usan; las propuestas esperan tu decisión.",
        style = Type.Nota,
    )
    Box(Modifier.padding(top = 8.dp)) {
        InkButton("Analizar la historia con el modelo", { story.runMaintenance() }, enabled = !busy && !job.running)
    }
    BasicText(
        "Lee los mensajes nuevos y propone un resumen, recuerdos, sucesos y cambios de relación. Nada se guarda sin que lo aceptes.",
        style = Type.Nota, modifier = Modifier.padding(top = 4.dp),
    )

    val d = draft
    if (d != null && d.sessionId == session.id) {
        SectionTitle("Borrador de resumen")
        BasicText(
            if (d.formatOk) "El modelo propone este resumen. Corrígelo si hace falta y guárdalo."
            else "El modelo no siguió el formato. Este es su texto en bruto: corrígelo a mano o descártalo.",
            style = Type.Nota.copy(color = if (d.formatOk) Ink.MarfilTenue else Ink.Granate),
        )
        InkField(draftText, { draftText = it }, "Resumen", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 80, maxHeight = 320)
        Row(Modifier.padding(top = 6.dp)) {
            InkButton("Guardar como resumen", { story.acceptSummaryDraft(draftText) }, enabled = draftText.isNotBlank())
            Box(Modifier.padding(start = 8.dp)) { InkButton("Descartar", { story.discardSummaryDraft() }, primary = false) }
        }
    }

    if (pending.isNotEmpty() || pendingTl.isNotEmpty()) {
        SectionTitle("Propuestas por revisar (${pending.size + pendingTl.size})")
        pending.forEach { m ->
            Card {
                BasicText(Verification.label(m.verification) + " · importancia ${m.importance}", style = Type.Nota.copy(color = Ink.Oro))
                SelectionContainer { BasicText(m.content, style = Type.Cuerpo) }
                if (m.narrativeDate.isNotBlank()) BasicText(m.narrativeDate, style = Type.Nota)
                Row {
                    InkLink("Aceptar", { story.acceptMemory(m) })
                    InkLink("Editar", { editing = m })
                    InkLink("Descartar", { story.discardMemory(m) }, danger = true)
                }
            }
        }
        pendingTl.forEach { e ->
            Card {
                BasicText("Suceso propuesto" + if (e.narrativeDate.isNotBlank()) " · ${e.narrativeDate}" else "", style = Type.Nota.copy(color = Ink.Oro))
                SelectionContainer { BasicText(e.text, style = Type.Cuerpo) }
                Row {
                    InkLink("Aceptar", { story.acceptEvent(e) })
                    InkLink("Descartar", { story.discardEvent(e) }, danger = true)
                }
            }
        }
    }

    SectionTitle("Recuerdos (${memories.size})")
    InkField(query, { query = it; if (it.isBlank()) story.clearSearch() }, "Buscar en los recuerdos", Modifier.fillMaxWidth(), minHeight = 24)
    Row(Modifier.padding(top = 4.dp)) {
        InkLink("Buscar", { story.search(query) }, enabled = query.isNotBlank())
        if (results != null) InkLink("Quitar búsqueda", { query = ""; story.clearSearch() })
    }
    val shown = results ?: memories
    if (results != null) BasicText("${shown.size} resultado(s)", style = Type.Nota)
    if (shown.isEmpty()) BasicText(if (results != null) "Sin resultados." else "Aún no hay recuerdos. Añade uno abajo o analiza la historia.", style = Type.Nota)
    shown.forEach { m ->
        Card {
            BasicText(
                (if (m.pinned) "📌 Fijado · " else "") + Verification.label(m.verification) + " · importancia ${m.importance}" +
                    (if (m.narrativeDate.isNotBlank()) " · ${m.narrativeDate}" else ""),
                style = Type.Nota.copy(color = Ink.Oro),
            )
            SelectionContainer { BasicText(m.content, style = Type.Cuerpo) }
            if (m.relatedNames.isNotBlank()) BasicText("Con: " + m.relatedNames.lines().filter { it.isNotBlank() }.joinToString(", "), style = Type.Nota)
            Row {
                InkLink(if (m.pinned) "Desfijar" else "Fijar", { story.setPinned(m, !m.pinned) })
                InkLink("Editar", { editing = m })
                InkLink("Borrar", { story.deleteMemory(m) }, danger = true)
            }
        }
    }

    BasicText("Añadir un recuerdo", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 14.dp))
    InkField(newText, { newText = it }, "Un hecho importante y duradero", Modifier.fillMaxWidth().padding(top = 4.dp), minHeight = 44, maxHeight = 140)
    InkField(newDate, { newDate = it }, "Cuándo (opcional): «segundo día, noche»", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
    InkField(newNames, { newNames = it }, "Personajes o lugares relacionados, separados por comas", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
    Stepper("Importancia", "$newImportance", { newImportance = (newImportance - 1).coerceAtLeast(1) }, { newImportance = (newImportance + 1).coerceAtMost(5) })
    InkToggleRow("Fijar (siempre presente en el contexto)", newPinned, { newPinned = it })
    Box(Modifier.padding(top = 4.dp)) {
        InkButton("Guardar recuerdo", {
            story.addMemory(newText, newImportance, newDate, names(newNames), newPinned)
            newText = ""; newDate = ""; newNames = ""; newPinned = false; newImportance = 3
        }, enabled = newText.isNotBlank())
    }

    SectionTitle("Cronología (${timeline.size})")
    timeline.forEach { e ->
        Card {
            if (e.narrativeDate.isNotBlank()) BasicText(e.narrativeDate, style = Type.Nota.copy(color = Ink.Oro))
            SelectionContainer { BasicText(e.text, style = Type.Cuerpo) }
            Row {
                InkLink("Editar", { editingEvent = e })
                InkLink("Borrar", { story.deleteEvent(e) }, danger = true)
            }
        }
    }
    InkField(newEvent, { newEvent = it }, "Un suceso de la historia", Modifier.fillMaxWidth().padding(top = 8.dp), minHeight = 44, maxHeight = 140)
    InkField(newEventDate, { newEventDate = it }, "Cuándo (opcional)", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
    Box(Modifier.padding(top = 6.dp)) {
        InkButton("Añadir a la cronología", { story.addEvent(newEvent, newEventDate, emptyList()); newEvent = ""; newEventDate = "" }, enabled = newEvent.isNotBlank())
    }

    SectionTitle("Versiones del resumen (${summaries.size})")
    BasicText("El resumen vigente se edita en Escena. Cada cambio guarda una versión; restaurar crea una nueva con el texto antiguo.", style = Type.Nota)
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    summaries.sortedByDescending { it.version }.take(12).forEach { s ->
        Card {
            BasicText("v${s.version} · ${s.source.lowercase()} · ${fmt.format(Date(s.createdAt))}" + if (s.note.isNotBlank()) " · ${s.note}" else "", style = Type.Nota.copy(color = Ink.Oro))
            SelectionContainer { BasicText(s.text.take(500) + if (s.text.length > 500) "…" else "", style = Type.Nota.copy(color = Ink.Marfil)) }
            Row { InkLink("Restaurar esta versión", { story.restoreSummary(s.version) }, enabled = s.text != session.summary) }
        }
    }

    SectionTitle("Recuperado en la última respuesta")
    SelectionContainer { BasicText(recalled, style = Type.Mono) }

    editing?.let { m ->
        var t by remember(m.id) { mutableStateOf(m.content) }
        var dt by remember(m.id) { mutableStateOf(m.narrativeDate) }
        var nm by remember(m.id) { mutableStateOf(m.relatedNames.lines().filter { it.isNotBlank() }.joinToString(", ")) }
        var imp by remember(m.id) { mutableStateOf(m.importance) }
        InkDialog("Editar recuerdo", { editing = null }) {
            InkField(t, { t = it }, "Texto", Modifier.fillMaxWidth(), minHeight = 60, maxHeight = 200)
            InkField(dt, { dt = it }, "Cuándo", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
            InkField(nm, { nm = it }, "Relacionados (comas)", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
            Stepper("Importancia", "$imp", { imp = (imp - 1).coerceAtLeast(1) }, { imp = (imp + 1).coerceAtMost(5) })
            BasicText("Al guardar, el recuerdo pasa a «confirmado por ti».", style = Type.Nota)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Guardar", {
                    if (m.state == ItemState.PROPUESTO) story.acceptMemory(m, t)
                    story.editMemory(m, t, imp, dt, names(nm))
                    editing = null
                }, enabled = t.isNotBlank())
                Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { editing = null }, primary = false) }
            }
        }
    }
    editingEvent?.let { e ->
        var t by remember(e.id) { mutableStateOf(e.text) }
        var dt by remember(e.id) { mutableStateOf(e.narrativeDate) }
        InkDialog("Editar suceso", { editingEvent = null }) {
            InkField(t, { t = it }, "Texto", Modifier.fillMaxWidth(), minHeight = 60, maxHeight = 200)
            InkField(dt, { dt = it }, "Cuándo", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Guardar", { story.editEvent(e, t, dt, emptyList()); editingEvent = null }, enabled = t.isNotBlank())
                Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { editingEvent = null }, primary = false) }
            }
        }
    }
}

// ======================= Relaciones =======================

@Composable
fun RelationsTab(story: StoryViewModel, session: RoleSessionEntity, characterName: String) {
    val rels by story.relationships.collectAsState()
    val events by story.relationEvents.collectAsState()
    var editing by remember { mutableStateOf<RelationshipEntity?>(null) }
    var a by remember(session.id) { mutableStateOf("") }
    var b by remember(session.id) { mutableStateOf("") }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

    JobBar(story, session.id)
    BasicText(
        "Cuatro medidas independientes de 1 a 100. El modelo solo puede PROPONER cambios pequeños con un motivo; tú los aceptas o los corriges.",
        style = Type.Nota,
    )
    val pending = events.filter { it.state == EventState.PROPUESTO }
    if (pending.isNotEmpty()) {
        SectionTitle("Cambios propuestos (${pending.size})")
        pending.forEach { e ->
            val r = rels.firstOrNull { it.id == e.relationshipId }
            Card {
                BasicText(r?.let { "${it.aName} → ${it.bName}" } ?: "Relación", style = Type.Nota.copy(color = Ink.Oro))
                BasicText(
                    listOf("Confianza" to e.dTrust, "Afecto" to e.dAffection, "Respeto" to e.dRespect, "Romántico" to e.dRomantic)
                        .filter { it.second != 0 }.joinToString(" · ") { "${it.first} ${if (it.second > 0) "+" else ""}${it.second}" },
                    style = Type.Cuerpo,
                )
                BasicText("Motivo: ${e.reason}", style = Type.Nota)
                Row {
                    InkLink("Aceptar", { story.acceptRelationEvent(e) })
                    InkLink("Rechazar", { story.rejectRelationEvent(e) }, danger = true)
                }
            }
        }
    }
    SectionTitle("Relaciones de esta partida")
    if (rels.isEmpty()) BasicText("Aún no hay relaciones: se crea la del personaje contigo al generar la primera respuesta.", style = Type.Nota)
    rels.forEach { r ->
        Card {
            BasicText("${r.aName} → ${r.bName}" + if (r.status.isNotBlank()) " · ${r.status}" else "", style = Type.Nota.copy(color = Ink.Oro))
            BasicText("Confianza ${r.trust} · Afecto ${r.affection} · Respeto ${r.respect} · Romántico ${r.romantic}", style = Type.Cuerpo)
            val hist = events.filter { it.relationshipId == r.id && it.state == EventState.APLICADO }.sortedByDescending { it.createdAt }.take(5)
            hist.forEach { h ->
                BasicText("${fmt.format(Date(h.createdAt))} · ${h.reason}", style = Type.Nota)
            }
            Row {
                InkLink("Corregir", { editing = r })
                InkLink("Borrar", { story.deleteRelationship(r) }, danger = true)
            }
        }
    }
    BasicText("Añadir una relación", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 14.dp))
    InkField(a, { a = it }, "Quién siente (ej. $characterName)", Modifier.fillMaxWidth().padding(top = 4.dp), minHeight = 24)
    InkField(b, { b = it }, "Hacia quién (ej. ${session.userName})", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
    Box(Modifier.padding(top = 6.dp)) { InkButton("Añadir", { story.addRelationship(a, b); a = ""; b = "" }, enabled = a.isNotBlank() && b.isNotBlank()) }

    editing?.let { r ->
        var t by remember(r.id) { mutableStateOf(r.trust) }
        var af by remember(r.id) { mutableStateOf(r.affection) }
        var rs by remember(r.id) { mutableStateOf(r.respect) }
        var ro by remember(r.id) { mutableStateOf(r.romantic) }
        var st by remember(r.id) { mutableStateOf(r.status) }
        var why by remember(r.id) { mutableStateOf("") }
        InkDialog("Corregir ${r.aName} → ${r.bName}", { editing = null }) {
            Stepper("Confianza", "$t", { t = (t - 5).coerceAtLeast(1) }, { t = (t + 5).coerceAtMost(100) })
            Stepper("Afecto", "$af", { af = (af - 5).coerceAtLeast(1) }, { af = (af + 5).coerceAtMost(100) })
            Stepper("Respeto", "$rs", { rs = (rs - 5).coerceAtLeast(1) }, { rs = (rs + 5).coerceAtMost(100) })
            Stepper("Interés romántico", "$ro", { ro = (ro - 5).coerceAtLeast(1) }, { ro = (ro + 5).coerceAtMost(100) })
            InkField(st, { st = it }, "Estado (ej. aliados recelosos)", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
            InkField(why, { why = it }, "Motivo de la corrección", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 24)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Guardar", { story.setRelationship(r, RelValues(t, af, rs, ro), st, why.ifBlank { "Corrección manual" }); editing = null })
                Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { editing = null }, primary = false) }
            }
        }
    }
}

// ======================= Capítulos y volúmenes =======================

@Composable
fun ChaptersTab(story: StoryViewModel, session: RoleSessionEntity, busy: Boolean) {
    val volumes by story.volumes.collectAsState()
    val chapters by story.chapters.collectAsState()
    val job by story.jobStatus.collectAsState()
    val continuity by story.continuity.collectAsState()
    val transfer by story.transfer.collectAsState()
    var editingNovel by remember { mutableStateOf<ChapterEntity?>(null) }
    var editingSummary by remember { mutableStateOf<ChapterEntity?>(null) }
    var renamingChapter by remember { mutableStateOf<ChapterEntity?>(null) }
    var closingVolume by remember { mutableStateOf(false) }
    var contText by remember(continuity?.text) { mutableStateOf(continuity?.text ?: "") }
    val canJob = !busy && !job.running

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) story.export(uri)
    }

    JobBar(story, session.id)
    BasicText(
        "Tu registro original de mensajes nunca se modifica aquí. El texto novelado es una copia aparte que puedes editar.",
        style = Type.Nota,
    )
    volumes.sortedBy { it.number }.forEach { v ->
        SectionTitle("Volumen ${v.number}" + (if (v.title.isNotBlank()) " · ${v.title}" else "") + (if (v.state == VolumeState.ARCHIVADO) " (archivado)" else ""))
        if (v.state == VolumeState.ARCHIVADO) {
            if (v.continuitySummary.isNotBlank()) {
                BasicText("Resumen de continuidad", style = Type.Nota.copy(color = Ink.Oro))
                SelectionContainer { BasicText(v.continuitySummary, style = Type.Nota.copy(color = Ink.Marfil)) }
            }
            if (v.number == volumes.maxOf { it.number } - 1) Row { InkLink("Deshacer el cierre", { story.reopenVolume(v) }, enabled = !busy) }
        }
        chapters.filter { it.volumeId == v.id }.sortedBy { it.number }.forEach { ch ->
            val open = ch.state == ChapterState.ABIERTO
            Card {
                BasicText(
                    "Capítulo ${ch.number}" + (if (ch.title.isNotBlank()) " · ${ch.title}" else "") + (if (open) " · abierto" else " · cerrado") +
                        " · mensajes ${ch.startOrder + 1}" + (ch.endOrder?.let { " a ${it + 1}" } ?: " en adelante"),
                    style = Type.Nota.copy(color = Ink.Oro),
                )
                if (ch.summary.isNotBlank()) SelectionContainer { BasicText(ch.summary, style = Type.Nota.copy(color = Ink.Marfil)) }
                if (ch.novelText.isNotBlank()) BasicText("Novelado: ${ch.novelState.lowercase()} (${ch.novelText.length} caracteres)", style = Type.Nota)
                Row {
                    InkLink("Título", { renamingChapter = ch })
                    InkLink("Resumen", { editingSummary = ch })
                    if (!open) {
                        InkLink("Resumir con modelo", { story.runChapterSummary(ch) }, enabled = canJob)
                        InkLink("Novelar con modelo", { story.runNovel(ch) }, enabled = canJob)
                    }
                    if (ch.novelText.isNotBlank()) InkLink("Editar novela", { editingNovel = ch })
                }
                if (!open && ch.number == chapters.maxOf { it.number } && chapters.none { it.state == ChapterState.ABIERTO }) {
                    Row { InkLink("Reabrir para seguir escribiendo", { story.reopenChapter(ch) }, enabled = !busy) }
                }
                if (open) {
                    Row {
                        InkLink("Cerrar y abrir siguiente", { story.closeChapter(true) }, enabled = !busy)
                        InkLink("Solo cerrar", { story.closeChapter(false) }, enabled = !busy)
                    }
                }
            }
        }
        if (v.state == VolumeState.ABIERTO) {
            Row(Modifier.padding(top = 6.dp)) {
                if (chapters.none { it.state == ChapterState.ABIERTO }) InkLink("Abrir capítulo nuevo", { story.openChapter() }, enabled = !busy)
                InkLink("Cerrar volumen…", { closingVolume = true }, enabled = !busy)
            }
        }
    }

    val c = continuity
    if (c != null && c.sessionId == session.id) {
        SectionTitle("Cierre del volumen: continuidad")
        BasicText("Este texto será el resumen vigente al abrir el volumen siguiente. Los recuerdos, relaciones y mensajes se conservan.", style = Type.Nota)
        InkField(contText, { contText = it }, "Resumen de continuidad", Modifier.fillMaxWidth().padding(top = 6.dp), minHeight = 100, maxHeight = 360)
        Row(Modifier.padding(top = 6.dp)) {
            InkButton("Cerrar el volumen", { story.confirmCloseVolume(contText) }, enabled = contText.isNotBlank() && !busy)
            Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { story.cancelContinuity() }, primary = false) }
        }
    }

    SectionTitle("Exportar partida")
    BasicText(
        "Crea un archivo .jullai con la partida, la biblia legible, recuerdos, relaciones y retrato. No incluye el modelo GGUF.",
        style = Type.Nota,
    )
    Box(Modifier.padding(top = 6.dp)) {
        InkButton("Exportar .jullai", { exportLauncher.launch(session.title.ifBlank { "partida" }.replace('/', '-').take(60) + ".jullai") }, enabled = !transfer.busy)
    }
    if (transfer.busy) Row { BasicText(transfer.message ?: "", style = Type.Nota); InkLink("Cancelar", { story.cancelTransfer() }, danger = true) }
    transfer.message?.takeIf { !transfer.busy }?.let { BasicText(it, style = Type.Nota, modifier = Modifier.padding(top = 4.dp)) }
    transfer.error?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Granate), modifier = Modifier.padding(top = 4.dp)) }

    if (closingVolume) {
        InkDialog("Cerrar volumen", { closingVolume = false }) {
            BasicText("Se prepara un resumen de continuidad que podrás revisar y editar antes de cerrar. Las relaciones las escribe la app, no el modelo.", style = Type.Nota)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Con el modelo", { story.draftContinuity(true); closingVolume = false }, enabled = canJob)
                Box(Modifier.padding(start = 8.dp)) { InkButton("Borrador manual", { story.draftContinuity(false); closingVolume = false }, primary = false) }
            }
        }
    }
    renamingChapter?.let { ch ->
        var t by remember(ch.id) { mutableStateOf(ch.title) }
        InkDialog("Título del capítulo", { renamingChapter = null }) {
            InkField(t, { t = it }, "Título", Modifier.fillMaxWidth(), minHeight = 24)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Guardar", { story.renameChapter(ch, t); renamingChapter = null })
                Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { renamingChapter = null }, primary = false) }
            }
        }
    }
    editingSummary?.let { ch ->
        var t by remember(ch.id) { mutableStateOf(ch.summary) }
        InkDialog("Resumen del capítulo", { editingSummary = null }) {
            InkField(t, { t = it }, "Resumen", Modifier.fillMaxWidth(), minHeight = 80, maxHeight = 300)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Guardar", { story.saveChapterSummary(ch, t); editingSummary = null })
                Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { editingSummary = null }, primary = false) }
            }
        }
    }
    editingNovel?.let { ch ->
        var t by remember(ch.id) { mutableStateOf(ch.novelText) }
        InkDialog("Texto novelado", { editingNovel = null }) {
            InkField(t, { t = it }, "Texto", Modifier.fillMaxWidth(), minHeight = 160, maxHeight = 420)
            Row(Modifier.padding(top = 10.dp)) {
                InkButton("Guardar", { story.saveNovelEdited(ch, t); editingNovel = null })
                Box(Modifier.padding(start = 8.dp)) { InkButton("Cancelar", { editingNovel = null }, primary = false) }
            }
        }
    }
}
