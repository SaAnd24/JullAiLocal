package com.jullai.local.roleplay

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.AppContainer
import com.jullai.local.data.ChapterEntity
import com.jullai.local.data.MemoryEntity
import com.jullai.local.data.RelationshipEntity
import com.jullai.local.data.RelationshipEventEntity
import com.jullai.local.data.SummaryEntity
import com.jullai.local.data.TimelineEventEntity
import com.jullai.local.data.VolumeEntity
import com.jullai.local.story.Bible
import com.jullai.local.story.BibleCodec
import com.jullai.local.story.BibleException
import com.jullai.local.story.BiblePreview
import com.jullai.local.story.Origin
import com.jullai.local.story.RelValues
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class TransferState(
    val busy: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    /** Vista previa del archivo .jullai leído, pendiente de que confirmes la importación. */
    val preview: BiblePreview? = null,
    /** v0.5: si el .jullai trae una instantánea del mundo, qué pasaría con él (hay que elegir cuando ya existe uno distinto). */
    val worldPlan: com.jullai.local.data.WorldImportPlan? = null,
)

/** Memoria, relaciones, capítulos y exportación/importación de la partida abierta. */
@OptIn(ExperimentalCoroutinesApi::class)
class StoryViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.storyRepository
    private val jobs = c.storyJobs
    private val sessionId = MutableStateFlow<Long?>(null)

    private fun <T> byId(f: (Long) -> kotlinx.coroutines.flow.Flow<List<T>>): StateFlow<List<T>> =
        sessionId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else f(id) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryEntity>> = byId { repo.observeMemories(it) }
    val pendingMemories: StateFlow<List<MemoryEntity>> = byId { repo.observePendingMemories(it) }
    val timeline: StateFlow<List<TimelineEventEntity>> = byId { repo.observeTimeline(it) }
    val pendingTimeline: StateFlow<List<TimelineEventEntity>> = byId { repo.observePendingTimeline(it) }
    val summaries: StateFlow<List<SummaryEntity>> = byId { repo.observeSummaries(it) }
    val relationships: StateFlow<List<RelationshipEntity>> = byId { repo.observeRelationships(it) }
    val relationEvents: StateFlow<List<RelationshipEventEntity>> = byId { repo.observeRelationEvents(it) }
    val volumes: StateFlow<List<VolumeEntity>> = byId { repo.observeVolumes(it) }
    val chapters: StateFlow<List<ChapterEntity>> = byId { repo.observeChapters(it) }

    val jobStatus = jobs.status
    val summaryDraft = jobs.summaryDraft
    val continuity = jobs.continuity

    private val _notice = MutableStateFlow<String?>(null)
    /** Último aviso o error de una acción rápida (guardar, aceptar, cerrar capítulo...). */
    val notice: StateFlow<String?> = _notice.asStateFlow()
    fun dismissNotice() { _notice.value = null }

    private val _search = MutableStateFlow<List<MemoryEntity>?>(null)
    val searchResults: StateFlow<List<MemoryEntity>?> = _search.asStateFlow()

    private val _transfer = MutableStateFlow(TransferState())
    val transfer: StateFlow<TransferState> = _transfer.asStateFlow()
    private var transferJob: Job? = null
    private var pendingBible: Bible? = null
    private var pendingWorld: com.jullai.local.world.WorldPack? = null

    fun open(id: Long) {
        if (sessionId.value != id) { _search.value = null; _notice.value = null }
        sessionId.value = id
        viewModelScope.launch { runCatching { repo.ensureStructure(id) } }
    }

    private fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            try { block() } catch (e: CancellationException) { throw e } catch (e: Exception) { _notice.value = e.message ?: "No se pudo completar la acción." }
        }
    }

    // ---------------- Recuerdos ----------------
    fun addMemory(content: String, importance: Int, date: String, related: List<String>, pinned: Boolean) = act {
        val id = sessionId.value ?: return@act
        repo.addMemory(id, content, importance, date, related, pinned)
    }
    fun editMemory(m: MemoryEntity, content: String, importance: Int, date: String, related: List<String>) = act { repo.editMemory(m.id, content, importance, date, related) }
    fun setPinned(m: MemoryEntity, pinned: Boolean) = act { repo.setPinned(m.id, pinned) }
    fun acceptMemory(m: MemoryEntity, edited: String? = null) = act { repo.acceptMemory(m.id, edited) }
    fun discardMemory(m: MemoryEntity) = act { repo.discardMemory(m.id) }
    fun deleteMemory(m: MemoryEntity) = act { repo.deleteMemory(m.id) }
    fun search(query: String) = act {
        val id = sessionId.value ?: return@act
        _search.value = if (query.isBlank()) null else repo.searchMemories(id, query)
    }
    fun clearSearch() { _search.value = null }

    // ---------------- Cronología ----------------
    fun addEvent(text: String, date: String, characters: List<String>) = act { sessionId.value?.let { repo.addEvent(it, text, date, characters, null) } }
    fun editEvent(e: TimelineEventEntity, text: String, date: String, characters: List<String>) = act { repo.editEvent(e.id, text, date, characters, e.orderKey) }
    fun deleteEvent(e: TimelineEventEntity) = act { repo.deleteEvent(e.id) }
    fun acceptEvent(e: TimelineEventEntity) = act { repo.acceptEvent(e.id) }
    fun discardEvent(e: TimelineEventEntity) = act { repo.discardEvent(e.id) }

    // ---------------- Resumen ----------------
    fun saveSummary(text: String) = act { sessionId.value?.let { repo.saveSummary(it, text, Origin.USUARIO) } }
    fun restoreSummary(version: Int) = act { sessionId.value?.let { repo.restoreSummary(it, version) } }
    fun acceptSummaryDraft(text: String) = act {
        val d = jobs.summaryDraft.value ?: return@act
        repo.saveSummary(d.sessionId, text, Origin.MODELO, d.coversUpTo, d.note)
        jobs.clearSummaryDraft()
    }
    fun discardSummaryDraft() = jobs.clearSummaryDraft()

    // ---------------- Relaciones ----------------
    fun addRelationship(a: String, b: String) = act { sessionId.value?.let { repo.addRelationship(it, a, b) } }
    fun deleteRelationship(r: RelationshipEntity) = act { repo.deleteRelationship(r.id) }
    fun setRelationship(r: RelationshipEntity, v: RelValues, status: String, reason: String) = act { repo.setRelationshipManually(r.id, v, status, reason) }
    fun acceptRelationEvent(e: RelationshipEventEntity) = act { repo.acceptRelationEvent(e.id)?.let { _notice.value = it } }
    fun rejectRelationEvent(e: RelationshipEventEntity) = act { repo.rejectRelationEvent(e.id) }

    // ---------------- Capítulos y volúmenes ----------------
    fun closeChapter(openNext: Boolean) = act { sessionId.value?.let { repo.closeChapter(it, openNext) } }
    fun openChapter() = act { sessionId.value?.let { repo.openChapter(it) } }
    fun reopenChapter(ch: ChapterEntity) = act { repo.reopenChapter(ch.id) }
    fun deleteEmptyChapter() = act { sessionId.value?.let { repo.deleteEmptyOpenChapter(it) } }
    fun renameChapter(ch: ChapterEntity, title: String) = act { repo.renameChapter(ch.id, title) }
    fun renameVolume(v: VolumeEntity, title: String) = act { repo.renameVolume(v.id, title) }
    fun saveChapterSummary(ch: ChapterEntity, text: String) = act { repo.saveChapterSummary(ch.id, text) }
    fun saveNovelEdited(ch: ChapterEntity, text: String) = act { repo.saveNovelEdited(ch.id, text) }
    fun confirmCloseVolume(text: String) = act {
        val id = sessionId.value ?: return@act
        repo.closeVolume(id, text)
        jobs.clearContinuity()
    }
    fun reopenVolume(v: VolumeEntity) = act { repo.reopenVolume(v.id) }
    fun cancelContinuity() = jobs.clearContinuity()

    // ---------------- Trabajos con el modelo ----------------
    fun runMaintenance() { sessionId.value?.let { jobs.startMaintenance(it) } }
    fun runNovel(ch: ChapterEntity) { sessionId.value?.let { jobs.startNovel(it, ch.id) } }
    fun runChapterSummary(ch: ChapterEntity) { sessionId.value?.let { jobs.startChapterSummary(it, ch.id) } }
    fun draftContinuity(useModel: Boolean) { sessionId.value?.let { if (useModel) jobs.startContinuity(it, true) else jobs.continuityManual(it) } }
    fun cancelJob() = jobs.cancel()
    fun dismissJob() = jobs.dismissMessage()

    // ---------------- Exportar / importar .jullai ----------------

    /** Escribe primero en un archivo temporal; solo si todo salió bien se copia al destino. Cancelar no deja nada a medias. */
    fun export(target: Uri) {
        val id = sessionId.value ?: return
        if (transferJob?.isActive == true) return
        _transfer.value = TransferState(busy = true, message = "Exportando…")
        transferJob = viewModelScope.launch {
            val tmp = File(c.app.cacheDir, "export-${System.nanoTime()}.jullai")
            try {
                withContext(Dispatchers.IO) {
                    val bible = c.bibleService.export(id) { name -> runCatching { c.portraits.file(name).readBytes() }.getOrNull() }
                        .withWorldSnapshot(c.worldRepository.snapshotFor(id))   // v0.5: la partida lleva una copia del conocimiento de su mundo
                    ensureActive()
                    tmp.outputStream().use { BibleCodec.write(bible, it) }
                    ensureActive()
                    val out = c.app.contentResolver.openOutputStream(target, "wt") ?: throw IllegalStateException("No se pudo abrir el destino.")
                    out.use { o -> tmp.inputStream().use { it.copyTo(o) } }
                }
                _transfer.value = TransferState(message = "Exportada la partida completa (sin el modelo GGUF).")
            } catch (e: CancellationException) {
                withContext(NonCancellable) { runCatching { c.app.contentResolver.delete(target, null, null) } }
                _transfer.value = TransferState(message = "Exportación cancelada. No se guardó nada.")
                throw e
            } catch (e: Exception) {
                _transfer.value = TransferState(error = "No se pudo exportar: ${e.message}")
            } finally {
                tmp.delete()
            }
        }
    }

    /** Lee y valida el archivo SIN tocar tus datos; después muestra una vista previa para confirmar. */
    fun readFile(source: Uri) {
        if (transferJob?.isActive == true) return
        pendingBible = null
        _transfer.value = TransferState(busy = true, message = "Leyendo y comprobando el archivo…")
        transferJob = viewModelScope.launch {
            try {
                val bible = withContext(Dispatchers.IO) {
                    val input = c.app.contentResolver.openInputStream(source) ?: throw IllegalStateException("No se pudo abrir el archivo.")
                    input.use { BibleCodec.read(it) }
                }
                ensureActive()
                pendingBible = bible
                pendingWorld = null
                var plan: com.jullai.local.data.WorldImportPlan? = null
                bible.worldSnapshot?.let { snap ->
                    // Una instantánea dañada o maliciosa rechaza TODO el archivo antes de tocar datos.
                    val pack = try { com.jullai.local.world.WorldpackCodec.decodeSnapshot(snap) } catch (e: com.jullai.local.world.WorldpackException) { throw BibleException("La instantánea del mundo no es válida: ${e.message}") }
                    pendingWorld = pack
                    plan = c.worldRepository.previewImport(pack)
                }
                _transfer.value = TransferState(preview = BiblePreview.of(bible), worldPlan = plan)
            } catch (e: CancellationException) {
                _transfer.value = TransferState(message = "Lectura cancelada. No se guardó nada.")
                throw e
            } catch (e: BibleException) {
                _transfer.value = TransferState(error = e.message)
            } catch (e: Exception) {
                _transfer.value = TransferState(error = "No se pudo leer el archivo: ${e.message}")
            }
        }
    }

    /** Importa como partida NUEVA (nunca sobrescribe ni borra nada). Devuelve el id por [onDone]. */
    fun confirmImport(onDone: (Long) -> Unit, worldChoice: com.jullai.local.data.WorldImportChoice? = null) {
        val bible = pendingBible ?: return
        if (transferJob?.isActive == true) return
        _transfer.value = TransferState(busy = true, message = "Importando…")
        transferJob = viewModelScope.launch {
            var portrait: String? = null
            try {
                val asset = bible.character.portraitAsset
                val bytes = asset?.let { bible.assets[it] }
                if (bytes != null) portrait = withContext(Dispatchers.IO) { runCatching { c.portraits.save(bytes) }.getOrNull() }
                ensureActive()
                val newId = c.bibleService.import(bible, portrait)
                pendingBible = null
                var msg = "Partida importada como nueva."
                val wp = pendingWorld
                if (wp != null && worldChoice != null) {
                    try { c.worldRepository.attachSnapshot(newId, wp, worldChoice); msg += " Mundo «${wp.world.name}» enlazado." }
                    catch (e: Exception) { msg += " No se pudo enlazar el mundo (${e.message}); la partida se conserva sin mundo." }
                } else if (wp != null) msg += " Importada sin mundo (el conocimiento del mundo no se copió)."
                pendingWorld = null
                _transfer.value = TransferState(message = msg)
                onDone(newId)
            } catch (e: CancellationException) {
                withContext(NonCancellable) { c.portraits.delete(portrait) }
                _transfer.value = TransferState(message = "Importación cancelada. No se guardó nada.")
                throw e
            } catch (e: Exception) {
                c.portraits.delete(portrait)
                _transfer.value = TransferState(error = "No se pudo importar (no se cambió nada): ${e.message}")
            }
        }
    }

    fun cancelTransfer() { transferJob?.cancel(); pendingBible = null; pendingWorld = null; _transfer.value = TransferState() }
    fun dismissTransfer() { if (transferJob?.isActive != true) { pendingBible = null; pendingWorld = null; _transfer.value = TransferState() } }
}
