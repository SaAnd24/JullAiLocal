package com.jullai.local.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.chat.ChatViewModel
import com.jullai.local.data.ConversationEntity
import com.jullai.local.data.SessionListItem
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.StoryViewModel
import java.text.DateFormat
import java.util.Date

/** Biblioteca: conversaciones recientes y acceso a Modelos y Ajustes. */
@Composable
fun LibraryScreen(
    vm: ChatViewModel,
    rpVm: RoleplayViewModel,
    storyVm: StoryViewModel,
    onOpenChat: (Long) -> Unit,
    onOpenModels: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenCharacters: () -> Unit,
    onOpenWorlds: () -> Unit,
    onCreateAdventure: () -> Unit,
    onOpenImages: () -> Unit,
    onOpenSession: (Long) -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val sessions by rpVm.sessions.collectAsState()
    var renamingSession by remember { mutableStateOf<SessionListItem?>(null) }
    var deletingSession by remember { mutableStateOf<SessionListItem?>(null) }
    val conversations by vm.conversations.collectAsState()
    val models by vm.models.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val loading by vm.busyLoading.collectAsState()
    val transfer by storyVm.transfer.collectAsState()
    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) storyVm.readFile(uri) }
    var renaming by remember { mutableStateOf<ConversationEntity?>(null) }
    var deleting by remember { mutableStateOf<ConversationEntity?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("JullAI Local", onBack = null)
        Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            BasicText("Biblioteca de conversaciones", style = Type.Nota)
            BasicText(
                when {
                    loading != null -> loading!!
                    loaded != null -> "Motor listo · ${loaded!!.model.displayName}"
                    else -> "Ningún modelo cargado (se carga solo al enviar un mensaje)"
                },
                style = Type.Nota,
                modifier = Modifier.padding(top = 2.dp),
            )
            Box(Modifier.padding(top = 12.dp)) { InkButton("Crear aventura", onCreateAdventure) }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InkChip("Chat general", tab == 0, { tab = 0 })
                InkChip("Roleplay", tab == 1, { tab = 1 })
            }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (tab == 0) InkButton("Nueva conversación", { vm.newConversation(onOpenChat) })
                else InkButton("Personajes", onOpenCharacters)
                if (tab == 1) InkButton("Mundos", onOpenWorlds, primary = false)
                InkButton("Modelos", onOpenModels, primary = false)
                InkButton("Ajustes", onOpenSettings, primary = false)
            }
            if (tab == 1) {
                Row(Modifier.padding(top = 8.dp)) {
                    InkLink("Estudio de imágenes", onOpenImages)
                    InkLink("Importar partida (.jullai)", { importPicker.launch(arrayOf("*/*")) }, enabled = !transfer.busy)
                    if (transfer.busy) InkLink("Cancelar", { storyVm.cancelTransfer() }, danger = true)
                }
                if (transfer.busy) BasicText(transfer.message ?: "", style = Type.Nota)
                transfer.error?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Granate)) }
                if (transfer.preview == null) transfer.message?.takeIf { !transfer.busy }?.let { BasicText(it, style = Type.Nota) }
            }
            if (models.isEmpty()) {
                BasicText(
                    "Aún no has importado ningún modelo. Abre «Modelos» e importa un archivo .gguf para poder conversar.",
                    style = Type.Cuerpo.copy(color = Ink.Oro),
                    modifier = Modifier.padding(top = 14.dp),
                )
            }
        }
        Divider()
        if (tab == 1) {
            if (sessions.isEmpty()) {
                Box(Modifier.padding(20.dp)) {
                    BasicText("Aún no tienes partidas. Abre «Personajes», crea o importa uno y pulsa «Jugar».", style = Type.Cuerpo)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 10.dp)) {
                    items(sessions, key = { it.session.id }) { item ->
                        SessionRow(item, rpVm, onOpen = { onOpenSession(item.session.id) }, onRename = { renamingSession = item }, onDelete = { deletingSession = item })
                    }
                }
            }
        } else if (conversations.isEmpty()) {
            Box(Modifier.padding(20.dp)) {
                BasicText("Aún no tienes conversaciones. Pulsa «Nueva conversación».", style = Type.Cuerpo)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 10.dp)) {
                items(conversations, key = { it.id }) { conv ->
                    ConversationRow(
                        conv = conv,
                        modelName = models.firstOrNull { it.fileName == conv.modelFileName }?.displayName,
                        onOpen = { onOpenChat(conv.id) },
                        onRename = { renaming = conv },
                        onDelete = { deleting = conv },
                    )
                }
            }
        }
    }

    var worldChoice by rememberSaveable { mutableStateOf("") }
    transfer.preview?.let { pv ->
        val plan = transfer.worldPlan
        val defaultChoice = when { plan == null -> "NINGUNO"; plan.existing == null -> "CREAR"; !plan.needsExplicitChoice -> "USAR_EXISTENTE"; else -> "" }
        val choiceNow = worldChoice.ifEmpty { defaultChoice }
        InkDialog("Importar partida", { storyVm.dismissTransfer(); worldChoice = "" }) {
            BasicText("«${pv.title}» con ${pv.characterName} (tú: ${pv.userName})", style = Type.Cuerpo.copy(color = Ink.Oro))
            BasicText(
                "${pv.messages} mensajes · ${pv.memories} recuerdos · ${pv.timeline} sucesos · ${pv.relationships} relaciones · ${pv.volumes} volúmenes · ${pv.chapters} capítulos" +
                    (if (pv.pendingProposals > 0) " · ${pv.pendingProposals} propuestas pendientes" else "") +
                    (if (pv.hasPortrait) " · con retrato" else "") + (if (pv.hasLorebook) " · con lorebook" else ""),
                style = Type.Nota, modifier = Modifier.padding(top = 6.dp),
            )
            BasicText("Se creará una partida NUEVA con su propio personaje. No se sobrescribe ni se borra nada tuyo. El modelo no viaja en el archivo: elige uno en Motor.", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
            pv.warnings.forEach { w -> BasicText("Aviso: $w", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 4.dp)) }
            if (plan != null) {
                BasicText("Esta partida incluye una copia del mundo «${plan.worldName}» (${plan.entryCount} entradas). Elige cómo enlazarla:", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 8.dp))
                Column(Modifier.padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (plan.existing == null) InkChip("Crear el mundo desde la copia", choiceNow == "CREAR", { worldChoice = "CREAR" })
                    else {
                        InkChip("Usar mi mundo «${plan.existing.name}» tal como está", choiceNow == "USAR_EXISTENTE", { worldChoice = "USAR_EXISTENTE" })
                        InkChip("Combinar: añadir a mi mundo lo que falta (${plan.newEntriesIfMerged})", choiceNow == "COMBINAR", { worldChoice = "COMBINAR" })
                        InkChip("Crear una copia independiente", choiceNow == "COPIA", { worldChoice = "COPIA" })
                    }
                    InkChip("Importar sin mundo", choiceNow == "NINGUNO", { worldChoice = "NINGUNO" })
                }
                BasicText("Nunca se borra ni se sobrescribe un mundo que ya tengas.", style = Type.Nota, modifier = Modifier.padding(top = 4.dp))
            }
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                InkButton("Importar", {
                    val ch = if (choiceNow == "NINGUNO" || choiceNow.isEmpty()) null else com.jullai.local.data.WorldImportChoice.valueOf(choiceNow)
                    storyVm.confirmImport({ id -> onOpenSession(id) }, ch); worldChoice = ""
                }, enabled = plan == null || choiceNow.isNotEmpty())
                InkButton("Cancelar", { storyVm.dismissTransfer(); worldChoice = "" }, primary = false)
            }
        }
    }
    renamingSession?.let { it2 ->
        RenameDialog(initial = it2.session.title, onDismiss = { renamingSession = null }, onSave = { rpVm.rename(it2.session.id, it); renamingSession = null }, what = "partida")
    }
    deletingSession?.let { it2 ->
        ConfirmDeleteDialog(title = it2.session.title, onDismiss = { deletingSession = null }, onConfirm = { rpVm.delete(it2.session.id); deletingSession = null }, what = "partida")
    }
    renaming?.let { conv ->
        RenameDialog(initial = conv.title, onDismiss = { renaming = null }, onSave = { vm.rename(conv.id, it); renaming = null })
    }
    deleting?.let { conv ->
        ConfirmDeleteDialog(title = conv.title, onDismiss = { deleting = null }, onConfirm = { vm.delete(conv.id); deleting = null })
    }
}

@Composable
private fun ConversationRow(
    conv: ConversationEntity,
    modelName: String?,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
) {
    val date = remember(conv.updatedAt) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(conv.updatedAt))
    }
    Column(
        Modifier
            .padding(vertical = 6.dp)
            .fillMaxWidth()
            .background(Ink.Pizarra, RoundedCornerShape(8.dp))
            .padding(top = 12.dp, start = 14.dp, end = 14.dp, bottom = 4.dp),
    ) {
        Column(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
            BasicText(conv.title, style = Type.Cuerpo.copy(color = Ink.Oro), maxLines = 2)
            BasicText(
                date + (if (modelName != null) " · $modelName" else ""),
                style = Type.Nota,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        Row(Modifier.padding(top = 4.dp)) {
            InkLink("Abrir", onOpen)
            InkLink("Renombrar", onRename)
            InkLink("Eliminar", onDelete, danger = true)
        }
    }
}

@Composable
fun RenameDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit, what: String = "conversación") {
    var text by remember { mutableStateOf(initial) }
    InkDialog("Renombrar $what", onDismiss) {
        InkField(text, { text = it }, "Título", Modifier.fillMaxWidth())
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Guardar", { onSave(text) }, enabled = text.isNotBlank())
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}

@Composable
fun ConfirmDeleteDialog(title: String, onDismiss: () -> Unit, onConfirm: () -> Unit, what: String = "conversación") {
    InkDialog("Eliminar $what", onDismiss) {
        BasicText("«$title» y todos sus mensajes se borrarán de este teléfono. No se puede deshacer.", style = Type.Cuerpo)
        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InkButton("Eliminar", onConfirm, danger = true)
            InkButton("Cancelar", onDismiss, primary = false)
        }
    }
}

@Composable
private fun SessionRow(item: SessionListItem, vm: RoleplayViewModel, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val date = remember(item.session.updatedAt) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(item.session.updatedAt))
    }
    Column(Modifier.padding(vertical = 6.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(8.dp)).padding(12.dp)) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
            PortraitImage(vm.portraitStore, item.portraitFile, item.characterName, Modifier.width(44.dp).height(60.dp), maxSide = 128)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                BasicText(item.session.title, style = Type.Cuerpo.copy(color = Ink.Oro), maxLines = 2)
                BasicText("con ${item.characterName} · $date", style = Type.Nota, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Row(Modifier.padding(top = 4.dp)) {
            InkLink("Abrir", onOpen)
            InkLink("Renombrar", onRename)
            InkLink("Eliminar", onDelete, danger = true)
        }
    }
}
