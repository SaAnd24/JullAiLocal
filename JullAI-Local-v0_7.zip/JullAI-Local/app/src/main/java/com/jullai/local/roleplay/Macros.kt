package com.jullai.local.roleplay

/**
 * Sustituye SOLO las marcas {{char}}, {{user}}, <BOT> y <USER> (en una sola pasada: un nombre que contenga
 * «{{user}}» no se vuelve a expandir). Cualquier otra marca de las tarjetas se deja como texto: nada se ejecuta.
 */
object Macros {
    private val regex = Regex("""\{\{\s*(char|user)\s*\}\}|<(BOT|USER)>""", RegexOption.IGNORE_CASE)

    fun apply(text: String, charName: String, userName: String): String {
        if (text.isEmpty() || (!text.contains("{{") && !text.contains('<'))) return text
        return regex.replace(text) { m ->
            val k = (m.groups[1]?.value ?: m.groups[2]?.value ?: "").lowercase()
            if (k == "char" || k == "bot") charName else userName
        }
    }
}
