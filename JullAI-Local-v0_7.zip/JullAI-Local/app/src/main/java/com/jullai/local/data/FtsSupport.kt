package com.jullai.local.data

import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Búsqueda de texto completo de recuerdos.
 *
 * EVALUACIÓN (v0.4): Room solo genera tablas FTS3/FTS4 (@Fts4); NO tiene soporte para FTS5. FTS5 en Android depende de cómo
 * compiló SQLite cada fabricante/versión y no está garantizado desde la versión mínima del proyecto (Android 8, API 26).
 * FTS4 sí está disponible en todas las versiones de Android. Por eso se usa **FTS4** (y esta app NUNCA dice usar FTS5).
 *
 * La tabla virtual NO es una entidad de Room (Room solo valida sus propias tablas): se crea con SQL, con disparadores que la
 * mantienen sincronizada con `memories`. Si el sistema no pudiera crearla, [available] queda en falso y la recuperación usa un
 * respaldo (comparación de palabras en Kotlin + LIKE en SQL), sin perder funciones.
 */
object FtsSupport {
    const val TABLE = "memories_fts"

    /** Último resultado de [ensure]. */
    @Volatile var available: Boolean = false
        private set

    private val TRIGGERS = listOf(
        "memories_fts_bu" to "CREATE TRIGGER IF NOT EXISTS memories_fts_bu BEFORE UPDATE ON memories BEGIN DELETE FROM $TABLE WHERE docid = old.rowid; END",
        "memories_fts_bd" to "CREATE TRIGGER IF NOT EXISTS memories_fts_bd BEFORE DELETE ON memories BEGIN DELETE FROM $TABLE WHERE docid = old.rowid; END",
        "memories_fts_au" to "CREATE TRIGGER IF NOT EXISTS memories_fts_au AFTER UPDATE ON memories BEGIN " +
            "INSERT INTO $TABLE(docid, content, relatedNames) VALUES (new.rowid, new.content, new.relatedNames); END",
        "memories_fts_ai" to "CREATE TRIGGER IF NOT EXISTS memories_fts_ai AFTER INSERT ON memories BEGIN " +
            "INSERT INTO $TABLE(docid, content, relatedNames) VALUES (new.rowid, new.content, new.relatedNames); END",
    )

    const val CREATE_SQL = "CREATE VIRTUAL TABLE IF NOT EXISTS $TABLE USING fts4(content=\"memories\", content, relatedNames, tokenize=unicode61)"

    /** Crea (si hace falta) la tabla y los disparadores. Nunca lanza: devuelve si la búsqueda de texto completo quedó disponible. */
    fun ensure(db: SupportSQLiteDatabase): Boolean {
        val existed = tableExists(db)
        var ok = false
        try {
            db.execSQL(CREATE_SQL)
            for ((_, sql) in TRIGGERS) db.execSQL(sql)
            if (!existed) db.execSQL("INSERT INTO $TABLE($TABLE) VALUES('rebuild')")   // indexa lo que ya hubiera
            ok = true
        } catch (e: Exception) {
            // Sin FTS4 en este sistema: se quitan restos para que escribir recuerdos nunca falle.
            runCatching { for ((name, _) in TRIGGERS) db.execSQL("DROP TRIGGER IF EXISTS $name") }
        }
        available = ok
        return ok
    }

    private fun tableExists(db: SupportSQLiteDatabase): Boolean =
        runCatching { db.query("SELECT name FROM sqlite_master WHERE type = 'table' AND name = '$TABLE'").use { it.moveToFirst() } }.getOrDefault(false)

    /** Expresión MATCH segura: solo palabras alfanuméricas con prefijo, unidas por OR. Null si no hay nada que buscar. */
    fun matchExpression(tokens: Collection<String>): String? {
        val safe = tokens.map { t -> t.filter { it.isLetterOrDigit() && it.code < 128 } }.filter { it.length >= 3 }.distinct().take(24)
        if (safe.isEmpty()) return null
        return safe.joinToString(" OR ") { "$it*" }
    }
}
