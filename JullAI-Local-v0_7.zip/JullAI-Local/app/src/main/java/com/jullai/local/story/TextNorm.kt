package com.jullai.local.story

import java.text.Normalizer
import java.util.Locale

/** Normalización y comparación de texto en español para la búsqueda de recuerdos (sin dependencias). */
object TextNorm {
    private val STOP = setOf(
        "el", "la", "los", "las", "un", "una", "unos", "unas", "de", "del", "al", "a", "y", "o", "u", "e", "ni", "que", "qué",
        "en", "con", "por", "para", "sin", "sobre", "entre", "hasta", "desde", "hacia", "como", "cómo", "pero", "aunque", "si", "sí",
        "no", "ya", "muy", "mas", "más", "menos", "se", "me", "te", "le", "les", "lo", "nos", "os", "mi", "tu", "su", "mis", "tus",
        "sus", "es", "son", "era", "eran", "fue", "fueron", "ser", "estar", "esta", "este", "esto", "estos", "estas", "ese", "esa",
        "eso", "esos", "esas", "hay", "han", "has", "he", "ha", "había", "tiene", "tienen", "tener", "puede", "pueden", "poder",
        "cuando", "donde", "dónde", "quien", "quién", "cual", "cuál", "todo", "toda", "todos", "todas", "otro", "otra", "otros",
        "otras", "algo", "alguien", "nada", "nadie", "aquí", "ahí", "allí", "así", "tan", "tanto", "también", "solo", "sólo",
        "hacer", "hace", "hizo", "dice", "dijo", "dijeron", "voy", "vas", "va", "van", "vamos", "ir", "ver", "veo", "vez", "cosa", "cosas",
    )

    /** Minúsculas y sin tildes ni marcas (la «ñ» pasa a «n»): «Árbol» y «arbol» comparan igual. */
    fun fold(s: String): String {
        val d = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        val sb = StringBuilder(d.length)
        for (c in d) if (Character.getType(c) != Character.NON_SPACING_MARK.toInt()) sb.append(c)
        return sb.toString()
    }

    /**
     * Formas con las que una palabra puede coincidir con otra: ella misma y sin plural («robles» → «roble», «papeles» → «papel»,
     * «reyes» → «rey»). El español no permite decidir solo por la terminación cuál es la correcta, así que se prueban ambas.
     */
    fun keys(w: String): Set<String> {
        val out = LinkedHashSet<String>()
        out.add(w)
        if (w.length > 3 && w.endsWith("s")) out.add(w.dropLast(1))
        if (w.length > 4 && w.endsWith("es")) out.add(w.dropLast(2))
        return out
    }

    /** Conjunto de claves de coincidencia de varias palabras. */
    fun keySet(words: Collection<String>): Set<String> {
        val out = HashSet<String>()
        for (w in words) out.addAll(keys(w))
        return out
    }

    private fun canon(w: String) = if (w.length > 3 && w.endsWith("s")) w.dropLast(1) else w

    /** Palabras significativas, ya sin tildes (sin palabras vacías, de 3+ letras, sin duplicados, en orden de aparición). */
    fun tokens(s: String): List<String> {
        if (s.isBlank()) return emptyList()
        val out = LinkedHashSet<String>()
        val sb = StringBuilder()
        fun flush() {
            if (sb.isEmpty()) return
            val w = sb.toString()
            sb.setLength(0)
            if (w.length >= 3 && foldedStop(w).not()) out.add(w)
        }
        for (c in fold(s)) {
            if (c.isLetterOrDigit()) sb.append(c) else flush()
        }
        flush()
        return out.toList()
    }

    private val STOP_FOLDED: Set<String> by lazy { STOP.map { fold(it) }.toSet() }
    private fun foldedStop(w: String) = w in STOP_FOLDED

    /** Parecido entre dos textos (0..1): proporción de palabras significativas compartidas. */
    fun similarity(a: String, b: String): Double {
        val ta = tokens(a).map { canon(it) }.toSet()
        val tb = tokens(b).map { canon(it) }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return if (fold(a).trim() == fold(b).trim()) 1.0 else 0.0
        val inter = ta.count { it in tb }
        val union = ta.size + tb.size - inter
        return inter.toDouble() / union
    }

    /** Divide una lista guardada «una por línea». */
    fun lines(s: String): List<String> = s.split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    /** Quita caracteres de control (salvo salto de línea y tabulación) y recorta. Para texto que viene del modelo o de archivos. */
    fun clean(s: String, max: Int): String {
        val sb = StringBuilder(minOf(s.length, max))
        for (c in s) {
            if (sb.length >= max) break
            if (c == '\n' || c == '\t' || c >= ' ' && c != '\u007f') sb.append(c)
        }
        return sb.toString().trim()
    }
}
