package com.jullai.local.discovery

import com.jullai.local.story.TextNorm

/** Tipo de imagen reconocido por sus primeros bytes (no por la extensión ni por lo que diga el servidor). */
object ImageSniff {
    const val PNG = "image/png"
    const val JPEG = "image/jpeg"
    const val WEBP = "image/webp"

    fun typeOf(b: ByteArray): String? = when {
        b.size >= 8 && b[0] == 0x89.toByte() && b[1] == 0x50.toByte() && b[2] == 0x4E.toByte() && b[3] == 0x47.toByte() -> PNG
        b.size >= 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte() -> JPEG
        b.size >= 12 && b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte() && b[2] == 'F'.code.toByte() && b[3] == 'F'.code.toByte() &&
            b[8] == 'W'.code.toByte() && b[9] == 'E'.code.toByte() && b[10] == 'B'.code.toByte() && b[11] == 'P'.code.toByte() -> WEBP
        else -> null
    }
}

/** Una imagen canónica encontrada para una página de personaje. Aún no está descargada. */
data class CanonImageRef(
    val pageApi: String,
    val pageTitle: String,
    val imageUrl: String,
    val fileName: String,
    val license: String,
    val attribution: String,
    val nonFree: Boolean,
)

/**
 * Reglas para las imágenes de personajes canónicos. Se guardan SOLO en la caché privada de la app, con su origen y su licencia, como referencia visual
 * personal; no se exportan en .worldpack/.jullai y se pueden borrar. Si la licencia no se conoce se dice «desconocida»: nunca se presume libre.
 */
object CanonImagePolicy {
    const val MAX_BYTES = 3_000_000
    const val MIN_BYTES = 1_500

    /** Motivo de rechazo de una imagen descargada, o null si es aceptable. */
    fun reject(url: String, bytes: ByteArray): String? {
        if (!WikiHosts.isTrustedImageUrl(url)) return "La imagen está en un servidor que la app no usa para cachear retratos."
        if (bytes.size < MIN_BYTES) return "La imagen descargada es demasiado pequeña."
        if (bytes.size > MAX_BYTES) return "La imagen es demasiado grande."
        if (ImageSniff.typeOf(bytes) == null) return "El archivo descargado no es una imagen PNG, JPEG ni WEBP."
        return null
    }

    /** Texto de derechos para mostrar y guardar: combina la licencia del archivo y la de la wiki. */
    fun rightsNote(fileLicense: String, nonFree: Boolean, siteRights: String): String {
        val parts = ArrayList<String>()
        if (fileLicense.isNotBlank()) parts.add(fileLicense)
        if (nonFree) parts.add("imagen no libre (uso privado como referencia)")
        if (parts.isEmpty()) parts.add(if (siteRights.isNotBlank()) "licencia del archivo desconocida; el texto de la wiki es $siteRights" else "licencia desconocida")
        return parts.joinToString(" · ").take(300)
    }

    /** ¿Parece la imagen de un personaje y no un icono, un mapa o un logotipo? Descarta por el nombre del archivo. */
    fun looksLikeCharacterImage(fileName: String): Boolean {
        val f = TextNorm.fold(fileName)
        if (f.isBlank()) return false
        val bad = listOf("logo", "icon", "icono", "map", "mapa", "flag", "bandera", "symbol", "simbolo", "banner", "poster", "cover", "portada", "title card", "wordmark", "site-logo", "favicon", "placeholder", "noimage", "no image")
        return bad.none { f.contains(it) } && (f.endsWith(".png") || f.endsWith(".jpg") || f.endsWith(".jpeg") || f.endsWith(".webp"))
    }
}

/** Busca la imagen principal de una página de personaje. No descarga la imagen: devuelve la referencia con su licencia. */
class CanonImageFinder(private val client: WikiClient) {

    /** Una consulta por lote de hasta 20 páginas. Páginas sin imagen o con imágenes que no parecen de personaje quedan fuera. */
    suspend fun find(api: String, titles: List<String>): Map<String, CanonImageRef> {
        val out = LinkedHashMap<String, CanonImageRef>()
        if (!WikiHosts.isTrustedApi(api) || titles.isEmpty()) return out
        for (chunk in titles.chunked(20)) {
            val refs = try {
                val json = client.api(api, WikiQuery.pageImages(chunk))
                if (WikiParsers.apiError(json) != null) emptyList() else WikiParsers.pageImages(json)
            } catch (e: WikiFetchException) { if (e.retryable) throw e else emptyList() }
            val unresolved = ArrayList<String>()
            for (t in chunk) {
                val r = refs.firstOrNull { sameTitle(it.title, t) }
                if (r == null || !CanonImagePolicy.looksLikeCharacterImage(r.fileName) || !WikiHosts.isTrustedImageUrl(r.thumbUrl)) { unresolved.add(t); continue }
                val info = fileInfo(api, r.fileName)
                out[t] = CanonImageRef(api, t, r.thumbUrl, r.fileName, info?.license.orEmpty(), info?.artist.orEmpty(), info?.nonFree ?: false)
            }
            // Alternativa solo para Fandom: la API v1 devuelve una miniatura aunque la wiki no tenga PageImages.
            if (unresolved.isNotEmpty() && WikiHosts.isFandom(api)) {
                val thumbs = try { WikiParsers.fandomThumbs(client.fandomUrl(WikiQuery.fandomArticleDetails(api, unresolved))) } catch (e: WikiFetchException) { if (e.retryable) throw e else emptyMap() }
                for (t in unresolved) {
                    val u = thumbs.entries.firstOrNull { sameTitle(it.key, t) }?.value ?: continue
                    if (!WikiHosts.isTrustedImageUrl(u)) continue
                    val file = fandomFileName(u)
                    if (!CanonImagePolicy.looksLikeCharacterImage(file)) continue
                    out[t] = CanonImageRef(api, t, u, file, "", "", false)
                }
            }
        }
        return out
    }

    private suspend fun fileInfo(api: String, fileName: String): FileInfo? = try {
        val json = client.api(api, WikiQuery.fileInfo("File:$fileName"))
        if (WikiParsers.apiError(json) != null) null else WikiParsers.fileInfo(json)
    } catch (e: WikiFetchException) { null }

    /** Nombre del archivo dentro de una dirección de la CDN de Fandom («…/images/a/ab/Rick_Grimes.png/revision/latest/…»). Vacío si no se reconoce. */
    fun fandomFileName(url: String): String = Regex("/images/[0-9a-f]/[0-9a-f]{2}/([^/?]+)").find(url)?.groupValues?.get(1).orEmpty()

    private fun sameTitle(a: String, b: String) = TextNorm.fold(a).replace('_', ' ').trim() == TextNorm.fold(b).replace('_', ' ').trim()
}
