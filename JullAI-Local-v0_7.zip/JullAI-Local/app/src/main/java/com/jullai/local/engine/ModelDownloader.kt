package com.jullai.local.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

/** Qué descargar. [expectedSize] y [sha256] solo se exigen si se conocen DE VERDAD (nunca se inventan). */
class DownloadSpec(val url: String, val fileName: String, val expectedSize: Long = -1, val sha256: String = "")

class DownloadException(message: String, val retryable: Boolean = false) : IOException(message)

/** Respuesta HTTP mínima; [close] libera la conexión. */
class HttpReply(val code: Int, private val headers: Map<String, String>, val body: InputStream?, private val closer: () -> Unit) : AutoCloseable {
    fun header(name: String): String? = headers[name.lowercase()]
    override fun close() = closer()
}

fun interface HttpOpener {
    /** GET [url]; si [rangeStart] > 0 pide «Range: bytes=rangeStart-». No sigue redirecciones (lo hace el descargador, validándolas). */
    fun open(url: String, rangeStart: Long): HttpReply
}

/** Transporte real: HttpURLConnection, sin redirecciones automáticas. */
class UrlConnectionOpener(private val userAgent: String = "JullAI-Local/0.7 (descarga de modelo iniciada por el usuario)") : HttpOpener {
    override fun open(url: String, rangeStart: Long): HttpReply {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 20_000; c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", userAgent)
        c.setRequestProperty("Accept-Encoding", "identity")
        if (rangeStart > 0) c.setRequestProperty("Range", "bytes=$rangeStart-")
        val code = c.responseCode
        val h = HashMap<String, String>()
        for ((k, v) in c.headerFields) if (k != null && v != null && v.isNotEmpty()) h[k.lowercase()] = v.last()
        val stream = if (code in 200..299) c.inputStream else null
        return HttpReply(code, h, stream) { runCatching { stream?.close() }; c.disconnect() }
    }
}

/**
 * Descarga de un modelo GGUF grande, pensada para móvil: streaming a disco (nunca en memoria), progreso, cancelación, REANUDACIÓN con Range,
 * comprobación de espacio, de tamaño declarado, SHA-256 opcional, cabecera GGUF y renombrado atómico al final. El archivo definitivo solo
 * aparece cuando está completo y validado; mientras tanto vive como «.dl.part» (se conserva al cancelar o fallar la red para reanudar).
 * No usa Android: se prueba con un servidor HTTP local.
 */
class ModelDownloader(
    private val dir: File,
    private val freeBytes: () -> Long,
    private val opener: HttpOpener = UrlConnectionOpener(),
    private val hostAllowed: (String) -> Boolean = ::isTrustedModelHost,
    private val safetyMargin: Long = 64L * 1024 * 1024,
) {
    companion object {
        private const val BUF = 1 shl 18
        private const val MAX_REDIRECTS = 6

        /** Hugging Face y sus CDN. Es una lista cerrada: la descarga automática no acepta otros servidores. */
        fun isTrustedModelHost(url: String): Boolean {
            val u = try { URI(url) } catch (e: Exception) { return false }
            if (u.scheme != "https" || u.userInfo != null || u.port != -1) return false
            val h = u.host?.lowercase() ?: return false
            return h == "huggingface.co" || h.endsWith(".huggingface.co") || h == "hf.co" || h.endsWith(".hf.co")
        }

        fun partFile(dir: File, safeName: String) = File(dir, "$safeName.dl.part")
        private fun metaFile(dir: File, safeName: String) = File(dir, "$safeName.dl.meta")

        /** Tamaño ya descargado de una descarga interrumpida (0 si no hay). */
        fun resumableBytes(dir: File, fileName: String) = partFile(dir, ModelFileNames.sanitize(fileName)).takeIf { it.isFile }?.length() ?: 0L

        /** Borra los restos de una descarga (el usuario descarta o empieza de cero). */
        fun discard(dir: File, fileName: String) { val n = ModelFileNames.sanitize(fileName); partFile(dir, n).delete(); metaFile(dir, n).delete() }

        fun parseContentRange(v: String?): Triple<Long, Long, Long>? {
            val m = Regex("^bytes (\\d+)-(\\d+)/(\\d+|\\*)$").find(v?.trim().orEmpty()) ?: return null
            val total = m.groupValues[3].toLongOrNull() ?: -1L
            return Triple(m.groupValues[1].toLong(), m.groupValues[2].toLong(), total)
        }
    }

    class Result(val file: File, val sha256: String, val size: Long, val resumedFrom: Long)

    /** Abre [url] siguiendo redirecciones de forma manual: cada salto debe ser https y de un host permitido. */
    private fun openFollowing(url: String, start: Long): HttpReply {
        var current = url
        repeat(MAX_REDIRECTS + 1) {
            if (!hostAllowed(current)) throw DownloadException("Dirección no permitida para descargas automáticas.")
            val r = try { opener.open(current, start) } catch (e: IOException) { throw DownloadException("Error de red: ${e.message}", true) }
            if (r.code in 301..308 && r.code != 304) {
                val loc = r.header("location"); r.close()
                if (loc.isNullOrBlank()) throw DownloadException("Redirección sin destino.")
                current = try { URI(current).resolve(loc).toString() } catch (e: Exception) { throw DownloadException("Redirección no válida.") }
                return@repeat
            }
            return r
        }
        throw DownloadException("Demasiadas redirecciones.")
    }

    /** Pregunta el tamaño real (sin descargar): pide el primer byte y lee «Content-Range». Devuelve -1 si el servidor no lo dice. */
    suspend fun probeSize(url: String): Long = withContext(Dispatchers.IO) {
        try {
            openFollowing(url, 0).use { r ->
                if (r.code == 206) return@withContext parseContentRange(r.header("content-range"))?.third ?: -1L
                if (r.code == 200) return@withContext r.header("content-length")?.toLongOrNull() ?: -1L
                -1L
            }
        } catch (e: DownloadException) { -1L }
    }

    suspend fun download(spec: DownloadSpec, onProgress: (done: Long, total: Long) -> Unit): Result = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val safe = ModelFileNames.sanitize(spec.fileName)
        val part = partFile(dir, safe)
        val meta = metaFile(dir, safe)
        var start = if (part.isFile) part.length() else 0L
        val savedTotal = meta.takeIf { it.isFile }?.readText()?.trim()?.toLongOrNull() ?: -1L
        // Si el tamaño declarado cambió respecto a la descarga anterior, el parcial no sirve.
        if (start > 0 && spec.expectedSize > 0 && savedTotal > 0 && savedTotal != spec.expectedSize) { part.delete(); start = 0 }

        var reply = openFollowing(spec.url, start)
        var resumedFrom = start
        try {
            var total = -1L
            when (reply.code) {
                206 -> {
                    val cr = parseContentRange(reply.header("content-range"))
                    if (cr == null || cr.first != start) { reply.close(); part.delete(); throw DownloadException("El servidor respondió a la reanudación de forma inesperada; se empezará de cero.", true) }
                    total = cr.third
                }
                200 -> { if (start > 0) { part.delete(); start = 0; resumedFrom = 0 }; total = reply.header("content-length")?.toLongOrNull() ?: -1L }
                416 -> {
                    // «Rango no satisfacible»: o ya estaba completo o el parcial es basura.
                    reply.close()
                    val cr = reply.header("content-range")?.substringAfter("*/")?.toLongOrNull() ?: -1L
                    if (cr > 0 && cr == part.length()) return@withContext finalize(spec, safe, part, meta, cr, resumedFrom)
                    part.delete(); meta.delete()
                    throw DownloadException("La descarga parcial no era válida y se descartó. Vuelve a intentarlo.", true)
                }
                404 -> { reply.close(); throw DownloadException("El archivo no existe en el servidor (404).") }
                401, 403 -> { reply.close(); throw DownloadException("El servidor no permite descargar este archivo (${reply.code}).") }
                429, 503 -> { reply.close(); throw DownloadException("El servidor está saturado (${reply.code}). Inténtalo más tarde.", true) }
                else -> { reply.close(); throw DownloadException("Respuesta inesperada del servidor (${reply.code}).", reply.code >= 500) }
            }
            if (total > 0 && spec.expectedSize > 0 && total != spec.expectedSize) {
                reply.close(); throw DownloadException("El tamaño del servidor ($total bytes) no coincide con el esperado (${spec.expectedSize}). No se descarga.")
            }
            if (total > 0) {
                val need = total - start + safetyMargin
                if (need > freeBytes()) { reply.close(); throw DownloadException("No hay espacio: hacen falta ${need / (1024 * 1024)} MB y quedan ${freeBytes() / (1024 * 1024)} MB.") }
                meta.writeText(total.toString())
            }
            val body = reply.body ?: throw DownloadException("Respuesta sin contenido.", true)
            java.io.FileOutputStream(part, start > 0).use { out ->
                val buf = ByteArray(BUF)
                var done = start
                var last = 0L
                try {
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = body.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done - last >= 4L * 1024 * 1024) { onProgress(done, total); last = done }
                    }
                } catch (e: IOException) {
                    out.flush()
                    throw DownloadException("Se cortó la conexión tras ${done / (1024 * 1024)} MB. Puedes reanudar.", true)
                }
                out.flush()
                onProgress(done, if (total > 0) total else done)
            }
            val size = part.length()
            if (total > 0 && size != total) throw DownloadException("La descarga quedó incompleta ($size de $total bytes). Puedes reanudar.", true)
            finalize(spec, safe, part, meta, size, resumedFrom)
        } finally {
            reply.close()
        }
    }

    private fun finalize(spec: DownloadSpec, safe: String, part: File, meta: File, size: Long, resumedFrom: Long): Result {
        part.inputStream().use { s ->
            when (val c = GgufHeader.check(s)) { is GgufCheck.Invalid -> { part.delete(); meta.delete(); throw DownloadException("Lo descargado no es un modelo GGUF válido: ${c.reason}") }; is GgufCheck.Ok -> Unit }
        }
        val digest = MessageDigest.getInstance("SHA-256")
        part.inputStream().buffered(BUF).use { s -> val b = ByteArray(BUF); while (true) { val n = s.read(b); if (n < 0) break; digest.update(b, 0, n) } }
        val sha = digest.digest().joinToString("") { "%02x".format(it) }
        if (spec.sha256.isNotBlank() && !spec.sha256.equals(sha, ignoreCase = true)) {
            part.delete(); meta.delete()
            throw DownloadException("La huella SHA-256 no coincide: el archivo está dañado o no es el esperado. Se descartó.")
        }
        // Nunca se pisa un modelo existente: si el nombre está ocupado, se elige otro.
        var name = safe; var n = 1
        while (File(dir, name).exists()) name = safe.removeSuffix(".gguf") + "-" + (++n) + ".gguf"
        val dest = File(dir, name)
        try { Files.move(part.toPath(), dest.toPath(), StandardCopyOption.ATOMIC_MOVE) }
        catch (e: AtomicMoveNotSupportedException) { if (!part.renameTo(dest)) throw DownloadException("No se pudo guardar el modelo.") }
        meta.delete()
        return Result(dest, sha, size, resumedFrom)
    }
}

/** Nombre seguro: sin rutas, sin caracteres raros, siempre termina en .gguf. */
object ModelFileNames {
    fun sanitize(raw: String): String {
        val base = raw.substringAfterLast('/').substringAfterLast('\\')
        var clean = base.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().trimStart('.')
        clean = clean.removeSuffix(".gguf").removeSuffix(".GGUF").trim()
        if (clean.isEmpty()) clean = "modelo"
        return clean.take(100) + ".gguf"
    }
}
