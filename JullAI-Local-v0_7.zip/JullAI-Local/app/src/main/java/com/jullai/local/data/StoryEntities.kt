package com.jullai.local.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/*
 * Memoria narrativa (v0.4). Todo cuelga de la partida (role_sessions) y se borra en cascada con ella.
 * Los valores de texto como «ACTIVO» o «CONFIRMADO_POR_USUARIO» están definidos en story/StoryModels.kt.
 * Ninguna referencia a mensajes es clave foránea a propósito: editar o borrar mensajes nunca debe borrar recuerdos.
 */

/** Recuerdo permanente. Solo los «ACTIVO» llegan al modelo. relatedNames: un nombre por línea. */
@Entity(
    tableName = "memories",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId"]), Index(value = ["sessionId", "state"])],
)
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val content: String,
    val importance: Int = 3,
    val narrativeDate: String = "",
    val origin: String,
    val verification: String,
    val state: String = "ACTIVO",
    val pinned: Boolean = false,
    val relatedNames: String = "",
    val sourceMessageId: Long? = null,
    val sourceNote: String = "",
    val createdAt: Long,
    val updatedAt: Long,
)

/** Versión de resumen de la partida. Inmutable: restaurar crea una versión nueva. role_sessions.summary = texto de la última versión. */
@Entity(
    tableName = "summaries",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "version"], unique = true)],
)
data class SummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val version: Int,
    val text: String,
    val source: String,
    val coversUpToOrder: Int = -1,
    val note: String = "",
    val createdAt: Long,
)

/** Acontecimiento de la cronología. orderKey ordena en el tiempo narrativo; narrativeDate es la etiqueta que ve el usuario. */
@Entity(
    tableName = "timeline_events",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "orderKey"])],
)
data class TimelineEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val text: String,
    val narrativeDate: String = "",
    val orderKey: Int,
    val characterNames: String = "",
    val origin: String,
    val state: String = "ACTIVO",
    val sourceMessageId: Long? = null,
    val createdAt: Long,
)

/** Relación dirigida «A hacia B» dentro de UNA partida. Cuatro dimensiones independientes de 1 a 100. */
@Entity(
    tableName = "relationships",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId"]), Index(value = ["sessionId", "aName", "bName"], unique = true)],
)
data class RelationshipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val aName: String,
    val bName: String,
    val trust: Int,
    val affection: Int,
    val respect: Int,
    val romantic: Int,
    val status: String = "",
    val note: String = "",
    val createdAt: Long,
    val updatedAt: Long,
)

/** Historial de cambios de una relación (y propuestas pendientes del modelo). Los «after» solo existen si el cambio se aplicó. */
@Entity(
    tableName = "relationship_events",
    foreignKeys = [
        ForeignKey(entity = RelationshipEntity::class, parentColumns = ["id"], childColumns = ["relationshipId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index(value = ["relationshipId"]), Index(value = ["sessionId"])],
)
data class RelationshipEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relationshipId: Long,
    val sessionId: Long,
    val state: String,
    val origin: String,
    val reason: String,
    val dTrust: Int = 0,
    val dAffection: Int = 0,
    val dRespect: Int = 0,
    val dRomantic: Int = 0,
    val trustAfter: Int? = null,
    val affectionAfter: Int? = null,
    val respectAfter: Int? = null,
    val romanticAfter: Int? = null,
    val sourceMessageId: Long? = null,
    val createdAt: Long,
)

@Entity(
    tableName = "volumes",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId", "number"], unique = true)],
)
data class VolumeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val number: Int,
    val title: String = "",
    val state: String = "ABIERTO",
    val continuitySummary: String = "",
    val createdAt: Long,
    val closedAt: Long? = null,
)

/**
 * Capítulo: un tramo [startOrder, endOrder] del registro ORIGINAL de mensajes (que nunca se modifica).
 * novelText es una versión novelada, editable aparte.
 */
@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = VolumeEntity::class, parentColumns = ["id"], childColumns = ["volumeId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index(value = ["volumeId"]), Index(value = ["sessionId", "number"], unique = true)],
)
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val volumeId: Long,
    val number: Int,
    val title: String = "",
    val state: String = "ABIERTO",
    val startOrder: Int,
    val endOrder: Int? = null,
    val summary: String = "",
    val novelText: String = "",
    val novelState: String = "NINGUNA",
    val createdAt: Long,
    val closedAt: Long? = null,
)

/** Hasta qué mensaje de la partida ya analizó el mantenimiento de memoria (para no repetir ni dejar huecos). */
@Entity(
    tableName = "memory_progress",
    foreignKeys = [ForeignKey(entity = RoleSessionEntity::class, parentColumns = ["id"], childColumns = ["sessionId"], onDelete = ForeignKey.CASCADE)],
)
data class MemoryProgressEntity(
    @PrimaryKey val sessionId: Long,
    val coveredOrder: Int,
    val updatedAt: Long,
)
