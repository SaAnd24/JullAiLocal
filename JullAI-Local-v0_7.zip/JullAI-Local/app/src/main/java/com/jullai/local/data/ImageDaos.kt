package com.jullai.local.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ImageModelDao {
    @Insert
    suspend fun insert(m: ImageModelEntity): Long

    @Update
    suspend fun update(m: ImageModelEntity)

    @Query("DELETE FROM image_models WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM image_models WHERE id = :id")
    suspend fun get(id: Long): ImageModelEntity?

    @Query("SELECT * FROM image_models WHERE fileName = :fileName")
    suspend fun byFileName(fileName: String): ImageModelEntity?

    @Query("SELECT * FROM image_models ORDER BY kind ASC, importedAt DESC")
    fun observeAll(): Flow<List<ImageModelEntity>>

    @Query("SELECT * FROM image_models ORDER BY kind ASC, importedAt DESC")
    suspend fun listAll(): List<ImageModelEntity>

    @Query("SELECT * FROM image_models WHERE kind = :kind AND isDefault = 1 LIMIT 1")
    suspend fun defaultOf(kind: String): ImageModelEntity?

    @Query("UPDATE image_models SET isDefault = 0 WHERE kind = :kind")
    suspend fun clearDefault(kind: String)

    @Query("UPDATE image_models SET isDefault = 1 WHERE id = :id")
    suspend fun setDefault(id: Long)
}

@Dao
interface ImageMetaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(m: ImageMetaEntity)

    @Query("SELECT * FROM image_meta WHERE assetId = :assetId")
    suspend fun get(assetId: Long): ImageMetaEntity?

    @Query("SELECT * FROM image_meta")
    fun observeAll(): Flow<List<ImageMetaEntity>>

    @Query("SELECT * FROM image_meta WHERE durationMs > 0 ORDER BY assetId DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<ImageMetaEntity>

    @Query("SELECT * FROM image_meta WHERE sessionId = :sessionId ORDER BY assetId ASC")
    suspend fun forSession(sessionId: Long): List<ImageMetaEntity>

    @Query("SELECT * FROM image_meta WHERE sessionId = :sessionId AND messageId = :messageId ORDER BY assetId DESC")
    suspend fun forMessage(sessionId: Long, messageId: Long): List<ImageMetaEntity>
}

@Dao
interface ImageTaskDao {
    @Insert
    suspend fun insert(t: ImageTaskEntity): Long

    @Update
    suspend fun update(t: ImageTaskEntity)

    @Query("SELECT * FROM image_tasks WHERE id = :id")
    suspend fun get(id: Long): ImageTaskEntity?

    @Query("SELECT * FROM image_tasks ORDER BY CASE status WHEN 'EN_CURSO' THEN 0 WHEN 'PENDIENTE' THEN 1 WHEN 'APLAZADA' THEN 2 ELSE 3 END, priority ASC, id ASC")
    fun observeAll(): Flow<List<ImageTaskEntity>>

    @Query("SELECT * FROM image_tasks WHERE status = 'PENDIENTE' ORDER BY priority ASC, id ASC")
    suspend fun pending(): List<ImageTaskEntity>

    @Query("SELECT COUNT(*) FROM image_tasks WHERE status IN ('PENDIENTE', 'EN_CURSO', 'APLAZADA')")
    suspend fun openCount(): Int

    /** Tras un cierre inesperado: lo que estaba EN_CURSO vuelve a PENDIENTE (se reintenta desde el principio de esa tarea). */
    @Query("UPDATE image_tasks SET status = 'PENDIENTE', note = :note, updatedAt = :now WHERE status = 'EN_CURSO'")
    suspend fun resetRunning(note: String, now: Long): Int

    @Query("UPDATE image_tasks SET status = 'PENDIENTE', updatedAt = :now WHERE status = 'APLAZADA'")
    suspend fun wakeDeferred(now: Long): Int

    @Query("UPDATE image_tasks SET status = 'CANCELADA', note = :note, updatedAt = :now, finishedAt = :now WHERE status IN ('PENDIENTE', 'APLAZADA')")
    suspend fun cancelAllOpen(note: String, now: Long): Int

    @Query("DELETE FROM image_tasks WHERE status IN ('LISTA', 'CANCELADA')")
    suspend fun clearFinished(): Int

    @Query("DELETE FROM image_tasks WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface VisualProfileDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(p: VisualProfileEntity): Long

    @Query("SELECT * FROM visual_profiles WHERE characterId = :characterId")
    suspend fun forCharacter(characterId: Long): VisualProfileEntity?

    @Query("SELECT * FROM visual_profiles WHERE characterId = :characterId")
    fun observeFor(characterId: Long): Flow<VisualProfileEntity?>

    @Query("DELETE FROM visual_profiles WHERE characterId = :characterId")
    suspend fun deleteFor(characterId: Long)
}
