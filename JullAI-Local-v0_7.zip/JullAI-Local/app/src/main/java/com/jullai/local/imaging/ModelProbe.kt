package com.jullai.local.imaging

import com.jullai.local.roleplay.JArr
import com.jullai.local.roleplay.JNum
import com.jullai.local.roleplay.JObj
import com.jullai.local.roleplay.MiniJson
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream

enum class ModelFormat { SAFETENSORS, GGUF, PICKLE, UNKNOWN }
enum class ImageModelKind { CHECKPOINT, LORA, UNKNOWN }

data class TensorMeta(val dtype: String, val shape: List<Long>)

/**
 * Resultado de leer el CONTENIDO del archivo (cabecera y nombres de tensores), no solo la extensión.
 * [supported] = la estructura es la que este motor puede intentar cargar (SD 1.x en un solo archivo). NO garantiza que el motor
 * lo cargue: eso solo lo confirma una carga real ([ImageEngine.loadModel]).
 */
data class ProbeResult(
    val format: ModelFormat,
    val kind: ImageModelKind,
    val architecture: String,
    val supported: Boolean,
    val reasons: List<String>,
    val warnings: List<String>,
    val sizeBytes: Long,
    val tensorCount: Int,
    val dtype: String,
    val hasVae: Boolean,
) {
    fun summary(): String = buildString {
        append(format.name.lowercase()).append(" · ").append(architecture).append(" · ").append(dtype.ifBlank { "?" })
    }
}

object ModelProbe {
    private const val MAX_HEADER = 16L * 1024 * 1024
    private const val MAX_TENSORS = 200_000
    private const val UNET_FIRST = "model.diffusion_model.input_blocks.0.0.weight"
    private const val CROSS_K = "model.diffusion_model.input_blocks.1.1.transformer_blocks.0.attn2.to_k.weight"

    fun probe(file: File): ProbeResult {
        val size = file.length()
        if (!file.isFile || size < 16) return unknown(size, "El archivo está vacío o es demasiado pequeño.")
        return try {
            file.inputStream().use { raw ->
                val input = BufferedInputStream(raw, 1 shl 16)
                input.mark(16)
                val magic = ByteArray(8)
                val n = readFully(input, magic)
                input.reset()
                when {
                    n >= 4 && magic[0] == 'G'.code.toByte() && magic[1] == 'G'.code.toByte() && magic[2] == 'U'.code.toByte() && magic[3] == 'F'.code.toByte() ->
                        classify(ModelFormat.GGUF, readGguf(input), size)
                    n >= 4 && magic[0] == 'P'.code.toByte() && magic[1] == 'K'.code.toByte() ->
                        pickle(size, "Es un archivo ZIP/PyTorch (.ckpt/.pt).")
                    n >= 2 && magic[0] == 0x80.toByte() ->
                        pickle(size, "Es un archivo pickle (.ckpt).")
                    n >= 8 -> classify(ModelFormat.SAFETENSORS, readSafetensors(input, size), size)
                    else -> unknown(size, "No se reconoce el formato.")
                }
            }
        } catch (e: ProbeException) {
            unknown(size, e.message ?: "Archivo no válido.")
        } catch (e: IOException) {
            unknown(size, "No se pudo leer el archivo: ${e.message}")
        } catch (e: RuntimeException) {
            unknown(size, "Archivo dañado o con formato inesperado.")
        }
    }

    private class ProbeException(msg: String) : Exception(msg)

    private fun unknown(size: Long, why: String) = ProbeResult(
        ModelFormat.UNKNOWN, ImageModelKind.UNKNOWN, "Desconocida", false,
        listOf(why + " Solo se admiten .safetensors y .gguf de Stable Diffusion 1.x."), emptyList(), size, 0, "", false,
    )

    private fun pickle(size: Long, why: String) = ProbeResult(
        ModelFormat.PICKLE, ImageModelKind.UNKNOWN, "Desconocida", false,
        listOf("$why Los .ckpt pueden ejecutar código al abrirse, por eso NO se admiten. Conviértelo a .safetensors con una herramienta externa y vuelve a importarlo."),
        emptyList(), size, 0, "", false,
    )

    private fun readFully(input: InputStream, buf: ByteArray, off: Int = 0, len: Int = buf.size - off): Int {
        var read = 0
        while (read < len) {
            val n = input.read(buf, off + read, len - read)
            if (n < 0) break
            read += n
        }
        return read
    }

    private fun le64(b: ByteArray, off: Int): Long {
        var v = 0L
        for (i in 7 downTo 0) v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        return v
    }

    // ---------------- safetensors ----------------

    private fun readSafetensors(input: InputStream, fileSize: Long): Map<String, TensorMeta> {
        val lenBytes = ByteArray(8)
        if (readFully(input, lenBytes) < 8) throw ProbeException("Cabecera safetensors incompleta.")
        val headerLen = le64(lenBytes, 0)
        if (headerLen < 2 || headerLen > MAX_HEADER || headerLen + 8 > fileSize) throw ProbeException("No es un archivo safetensors (la longitud de la cabecera es imposible).")
        val json = ByteArray(headerLen.toInt())
        if (readFully(input, json) < json.size) throw ProbeException("Cabecera safetensors incompleta.")
        if (json[0] != '{'.code.toByte()) throw ProbeException("No es un archivo safetensors (la cabecera no es JSON).")
        val root = try { MiniJson.parse(String(json, Charsets.UTF_8)) } catch (e: Exception) { throw ProbeException("La cabecera safetensors está dañada.") }
        val obj = root as? JObj ?: throw ProbeException("La cabecera safetensors no es un objeto.")
        val dataLen = fileSize - 8 - headerLen
        val out = LinkedHashMap<String, TensorMeta>()
        for ((name, v) in obj.fields) {
            if (name == "__metadata__") continue
            val t = v as? JObj ?: throw ProbeException("Tensor mal formado: $name")
            val dtype = (t.fields["dtype"] as? com.jullai.local.roleplay.JStr)?.v ?: throw ProbeException("Tensor sin tipo: $name")
            val shape = (t.fields["shape"] as? JArr)?.items?.map { ((it as? JNum)?.v ?: throw ProbeException("Forma no válida en $name")).toLong() } ?: throw ProbeException("Tensor sin forma: $name")
            val off = (t.fields["data_offsets"] as? JArr)?.items?.map { ((it as? JNum)?.v ?: -1.0).toLong() }
            if (off == null || off.size != 2 || off[0] < 0 || off[1] < off[0] || off[1] > dataLen) throw ProbeException("El archivo está truncado o dañado (el tensor $name apunta fuera del archivo).")
            out[name] = TensorMeta(dtype, shape)
            if (out.size > MAX_TENSORS) throw ProbeException("Demasiados tensores.")
        }
        if (out.isEmpty()) throw ProbeException("El archivo no contiene tensores.")
        return out
    }

    // ---------------- GGUF ----------------

    private val GGML_TYPES = mapOf(
        0 to "F32", 1 to "F16", 2 to "Q4_0", 3 to "Q4_1", 6 to "Q5_0", 7 to "Q5_1", 8 to "Q8_0", 9 to "Q8_1",
        10 to "Q2_K", 11 to "Q3_K", 12 to "Q4_K", 13 to "Q5_K", 14 to "Q6_K", 15 to "Q8_K", 30 to "BF16",
    )

    private fun readGguf(input: InputStream): Map<String, TensorMeta> {
        val head = ByteArray(24)
        if (readFully(input, head) < 24) throw ProbeException("Cabecera GGUF incompleta.")
        val version = (head[4].toInt() and 0xFF) or ((head[5].toInt() and 0xFF) shl 8) or ((head[6].toInt() and 0xFF) shl 16) or ((head[7].toInt() and 0xFF) shl 24)
        if (version < 2 || version > 3) throw ProbeException("Versión de GGUF no soportada: $version.")
        val tensors = le64(head, 8)
        val kvs = le64(head, 16)
        if (tensors <= 0 || tensors > MAX_TENSORS || kvs < 0 || kvs > 100_000) throw ProbeException("La cabecera GGUF tiene valores imposibles.")
        val r = LeReader(input)
        repeat(kvs.toInt()) {
            r.skipString()
            skipValue(r, r.u32(), 0)
        }
        val out = LinkedHashMap<String, TensorMeta>()
        repeat(tensors.toInt()) {
            val name = r.string(512)
            val nd = r.u32()
            if (nd < 1 || nd > 8) throw ProbeException("Tensor GGUF con dimensiones imposibles.")
            val dims = ArrayList<Long>()
            repeat(nd.toInt()) { dims.add(r.u64()) }
            val type = r.u32().toInt()
            r.u64()
            // GGUF guarda las dimensiones en orden ggml (inverso al de PyTorch/safetensors): se normaliza.
            out[name] = TensorMeta(GGML_TYPES[type] ?: "T$type", dims.reversed())
        }
        return out
    }

    private fun skipValue(r: LeReader, type: Long, depth: Int) {
        if (depth > 2) throw ProbeException("Metadatos GGUF anidados en exceso.")
        when (type.toInt()) {
            0, 1, 7 -> r.skip(1)
            2, 3 -> r.skip(2)
            4, 5, 6 -> r.skip(4)
            10, 11, 12 -> r.skip(8)
            8 -> r.skipString()
            9 -> {
                val et = r.u32()
                val count = r.u64()
                if (count < 0 || count > 2_000_000) throw ProbeException("Matriz de metadatos GGUF demasiado grande.")
                for (i in 0 until count) skipValue(r, et, depth + 1)
            }
            else -> throw ProbeException("Tipo de metadato GGUF desconocido: $type.")
        }
    }

    private class LeReader(val input: InputStream) {
        private val b8 = ByteArray(8)
        fun u32(): Long { need(4); return (b8[0].toLong() and 0xFF) or ((b8[1].toLong() and 0xFF) shl 8) or ((b8[2].toLong() and 0xFF) shl 16) or ((b8[3].toLong() and 0xFF) shl 24) }
        fun u64(): Long { need(8); return le64(b8, 0) }
        private fun need(n: Int) { if (readFully(input, b8, 0, n) < n) throw ProbeException("El archivo GGUF está truncado.") }
        fun skip(n: Long) {
            var left = n
            val tmp = ByteArray(4096)
            while (left > 0) {
                val got = input.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
                if (got < 0) throw ProbeException("El archivo GGUF está truncado.")
                left -= got
            }
        }
        fun skipString() { val n = u64(); if (n < 0 || n > 64L * 1024 * 1024) throw ProbeException("Cadena GGUF imposible."); skip(n) }
        fun string(max: Int): String {
            val n = u64()
            if (n < 0 || n > max) throw ProbeException("Nombre de tensor GGUF imposible.")
            val bytes = ByteArray(n.toInt())
            if (readFully(input, bytes) < bytes.size) throw ProbeException("El archivo GGUF está truncado.")
            return String(bytes, Charsets.UTF_8)
        }
    }

    // ---------------- clasificación (pura: se prueba con mapas de tensores) ----------------

    /** Clasifica un conjunto de tensores. Pública para poder probarla sin archivos grandes. */
    fun classify(format: ModelFormat, tensors: Map<String, TensorMeta>, size: Long): ProbeResult {
        val names = tensors.keys
        val reasons = ArrayList<String>()
        val warnings = ArrayList<String>()
        val isLora = names.any { it.contains(".lora_down.") || it.contains(".lora_up.") || it.startsWith("lora_unet_") || it.contains(".lora_A.") || it.contains(".lora_B.") }
        val hasUnet = UNET_FIRST in tensors
        val sdxl = names.any { it.startsWith("conditioner.embedders") } || names.any { it.startsWith("lora_te2_") }

        if (isLora && !hasUnet) {
            val dtype = names.firstOrNull { it.contains("lora_down") || it.contains("lora_A") }?.let { tensors[it]?.dtype }.orEmpty()
            if (sdxl) reasons.add("Es una LoRA de SDXL; esta versión solo trabaja con Stable Diffusion 1.x.")
            warnings.add("No se puede comprobar aquí que la LoRA encaje con tu checkpoint: se sabrá al aplicarla. Una LoRA LCM debe ser de SD 1.5.")
            return ProbeResult(format, ImageModelKind.LORA, if (sdxl) "LoRA SDXL" else "LoRA (SD 1.x esperado)", !sdxl, reasons, warnings, size, tensors.size, dtype, false)
        }

        if (sdxl) {
            reasons.add("Es un checkpoint SDXL. Esta versión no incluye SDXL (necesita muchísima más memoria que un Helio G100 con 8 GB).")
            return ProbeResult(format, ImageModelKind.CHECKPOINT, "SDXL", false, reasons, warnings, size, tensors.size, "", false)
        }
        if (!hasUnet) {
            reasons.add("No se encuentra la red de difusión en el formato de un solo archivo de Stable Diffusion (por ejemplo, un modelo en formato diffusers no se admite).")
            return ProbeResult(format, ImageModelKind.UNKNOWN, "Desconocida", false, reasons, warnings, size, tensors.size, "", false)
        }
        val first = tensors[UNET_FIRST]!!
        val inCh = first.shape.getOrNull(1)
        val ctx = tensors[CROSS_K]?.shape?.getOrNull(1)
        val hasVae = names.any { it.startsWith("first_stage_model.") }
        val hasClip = names.any { it.startsWith("cond_stage_model.") }
        val dtype = first.dtype.let { if (format == ModelFormat.GGUF) it else normalizeSt(it) }

        val arch: String
        when {
            ctx == 1024L -> { arch = "SD 2.x"; reasons.add("Es Stable Diffusion 2.x. Esta versión solo ofrece SD 1.x (1.5).") }
            ctx != 768L -> { arch = "Desconocida"; reasons.add("No se pudo identificar la arquitectura (dimensión de atención cruzada: ${ctx ?: "ausente"}).") }
            inCh == 9L -> { arch = "SD 1.x inpainting"; reasons.add("Es una variante de inpainting; no está soportada en esta versión.") }
            inCh != 4L -> { arch = "SD 1.x (variante)"; reasons.add("Canales de entrada inesperados ($inCh); no es un SD 1.x estándar.") }
            else -> arch = "SD 1.x"
        }
        if (reasons.isEmpty()) {
            if (!hasClip) reasons.add("Falta el codificador de texto dentro del archivo.")
            if (!hasVae) warnings.add("El archivo no incluye VAE: las imágenes podrían salir distorsionadas. Usa un checkpoint con VAE integrado.")
        }
        if (dtype == "F32") warnings.add("Está en F32 (≈ ${size / (1024 * 1024)} MB): con 8 GB de RAM compartida con Android es arriesgado. Prefiere una versión F16 o cuantizada (Q8_0/Q4_0).")
        if (dtype == "BF16") warnings.add("BF16 es lento en CPU Arm sin soporte nativo. Prefiere F16 o cuantizado.")
        return ProbeResult(format, ImageModelKind.CHECKPOINT, arch, reasons.isEmpty(), reasons, warnings, size, tensors.size, dtype, hasVae)
    }

    private fun normalizeSt(d: String) = when (d.uppercase()) { "F16" -> "F16"; "F32" -> "F32"; "BF16" -> "BF16"; else -> d.uppercase() }
}
