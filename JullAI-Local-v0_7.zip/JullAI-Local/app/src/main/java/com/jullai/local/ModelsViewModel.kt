package com.jullai.local

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jullai.local.engine.EngineState
import com.jullai.local.engine.ImportException
import com.jullai.local.engine.LoadedModel
import com.jullai.local.engine.MemoryEstimator
import com.jullai.local.engine.ModelInfo
import com.jullai.local.engine.StoredModel
import com.jullai.local.engine.CatalogModel
import com.jullai.local.engine.DownloadException
import com.jullai.local.engine.DownloadSpec
import com.jullai.local.engine.ModelCatalog
import com.jullai.local.engine.ModelDownloader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ModelsUiState(
    val models: List<StoredModel> = emptyList(),
    val selected: StoredModel? = null,
    val selectedInfo: ModelInfo? = null,
    val engineState: EngineState = EngineState.IDLE,
    val loaded: LoadedModel? = null,
    val busyMessage: String? = null,
    val importing: Boolean = false,
    val importProgress: Float = 0f,
    val error: String? = null,
    val notice: String? = null,
    val contextLength: Int = 2048,
    val threads: Int = 4,
    val memoryEstimate: String = "",
    val systemInfo: String = "",
    val nativeLog: String = "",
    val freeStorageMb: Long = 0,
    val downloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val downloadText: String = "",
    val partialMb: Long = 0,
    val remoteSizeMb: Long = -1,
)

/** Local state of the Models screen that is not derived from other flows. */
private data class Local(
    val selectedFileName: String? = null,
    val info: Pair<String, ModelInfo>? = null,
    val importing: Boolean = false,
    val importProgress: Float = 0f,
    val error: String? = null,
    val notice: String? = null,
    val contextLength: Int = 2048,
    val threads: Int = 4,
    val systemInfo: String = "",
    val nativeLog: String = "",
    val freeStorageMb: Long = 0,
    val downloading: Boolean = false,
    val downloadProgress: Float = 0f,
    val downloadText: String = "",
    val partialMb: Long = 0,
    val remoteSizeMb: Long = -1,
)

/** Pantalla Modelos: importar, validar, elegir, cargar y liberar. (Es la antigua pantalla de prueba del Hito 1.) */
class ModelsViewModel(private val c: AppContainer) : ViewModel() {
    private val engine = c.engine
    private val controller = c.controller
    private val store = c.store

    private val local = MutableStateFlow(
        Local(
            contextLength = c.settingsRepository.settings.value.defaultContext,
            threads = c.settingsRepository.settings.value.threads,
        ),
    )
    private var importJob: Job? = null

    val ui: StateFlow<ModelsUiState> = combine(
        local, c.registry.observe(), controller.loaded, controller.busy, controller.state,
    ) { l, models, loaded, busy, st ->
        val selected = models.firstOrNull { it.fileName == l.selectedFileName }
            ?: models.firstOrNull { it.isDefault } ?: models.firstOrNull()
        val info = l.info?.takeIf { it.first == selected?.fileName }?.second
        ModelsUiState(
            models = models, selected = selected, selectedInfo = info, engineState = st, loaded = loaded,
            busyMessage = busy, importing = l.importing, importProgress = l.importProgress,
            error = l.error, notice = l.notice, contextLength = l.contextLength, threads = l.threads,
            memoryEstimate = estimate(selected, info, l.contextLength),
            systemInfo = l.systemInfo, nativeLog = l.nativeLog, freeStorageMb = l.freeStorageMb,
            downloading = l.downloading, downloadProgress = l.downloadProgress, downloadText = l.downloadText, partialMb = l.partialMb, remoteSizeMb = l.remoteSizeMb,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ModelsUiState())

    init {
        refreshStorage()
        viewModelScope.launch {
            runCatching { engine.systemInfo() }
                .onSuccess { info -> local.update { it.copy(systemInfo = info.trim()) } }
                .onFailure { e -> local.update { it.copy(error = "No se pudo iniciar el motor nativo: ${e.message}") } }
        }
        // Cada vez que cambia el modelo seleccionado se valida con el motor (solo vocabulario + hiperparámetros).
        viewModelScope.launch {
            ui.map { it.selected }.distinctUntilChanged { a, b -> a?.fileName == b?.fileName }.collect { sel ->
                if (sel != null) inspect(sel)
            }
        }
    }

    private fun refreshStorage() {
        local.update { it.copy(freeStorageMb = store.freeBytes() / (1024 * 1024), partialMb = ModelDownloader.resumableBytes(store.directory, ModelCatalog.DEFAULT.fileName) / (1024 * 1024)) }
    }

    private var downloadJob: Job? = null

    /** Pregunta al servidor el tamaño real (sin descargar). Si no hay red, lo dice; no se muestra ninguna cifra inventada. */
    fun probeDownloadSize() {
        viewModelScope.launch {
            val size = runCatching { store.downloader().probeSize(ModelCatalog.DEFAULT.url) }.getOrDefault(-1L)
            local.update { it.copy(remoteSizeMb = if (size > 0) size / (1024 * 1024) else -1, notice = if (size > 0) it.notice else "No se pudo consultar el tamaño (¿sin conexión?).") }
        }
    }

    /** Descarga (o reanuda) un modelo del catálogo. Solo ocurre cuando el usuario pulsa el botón. */
    fun downloadModel(m: CatalogModel = ModelCatalog.DEFAULT) {
        if (downloadJob?.isActive == true) return
        downloadJob = viewModelScope.launch {
            local.update { it.copy(downloading = true, downloadProgress = 0f, downloadText = "Conectando…", error = null, notice = null) }
            try {
                val r = store.downloader().download(DownloadSpec(m.url, m.fileName, sha256 = m.sha256)) { done, total ->
                    local.update { it.copy(downloadProgress = if (total > 0) done.toFloat() / total else 0f, downloadText = "${done / (1024 * 1024)} MB" + if (total > 0) " de ${total / (1024 * 1024)} MB" else "") }
                }
                local.update { it.copy(downloadText = "Validando con el motor…") }
                val stored = store.registerDownloaded(r.file, r.sha256) { f -> engine.inspect(f.absolutePath) }
                local.update { it.copy(selectedFileName = stored.fileName, notice = "Modelo descargado y validado: ${stored.displayName}") }
            } catch (e: CancellationException) {
                local.update { it.copy(notice = "Descarga en pausa. Lo descargado se conserva y se puede reanudar.") }
                throw e
            } catch (e: ImportException) {
                local.update { it.copy(error = e.message) }
            } catch (e: DownloadException) {
                local.update { it.copy(error = e.message + if (e.retryable) " Lo descargado se conserva para reanudar." else "") }
            } catch (e: Exception) {
                local.update { it.copy(error = "No se pudo descargar: ${e.message}") }
            } finally {
                local.update { it.copy(downloading = false) }
                refreshStorage()
            }
        }
    }

    fun pauseDownload() { downloadJob?.cancel() }
    fun discardPartialDownload() { ModelDownloader.discard(store.directory, ModelCatalog.DEFAULT.fileName); refreshStorage() }

    private suspend fun inspect(model: StoredModel) {
        try {
            val info = engine.inspect(store.file(model).absolutePath)
            local.update { it.copy(info = model.fileName to info) }
        } catch (e: Exception) {
            local.update { it.copy(info = null, error = "Diagnóstico de \"${model.displayName}\": ${e.message}") }
        }
    }

    private fun estimate(model: StoredModel?, info: ModelInfo?, ctx: Int): String {
        if (model == null || info == null) return ""
        val total = MemoryEstimator.totalBytes(model.sizeBytes, info, ctx)
        val am = c.app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val risky = MemoryEstimator.isRisky(total, mi.availMem)
        return "Memoria estimada (aprox.): ${total / (1024 * 1024)} MB · RAM libre ahora: ${mi.availMem / (1024 * 1024)} MB" +
            if (risky) " · ⚠ puede ser demasiado: reduce el contexto o usa un modelo menor." else ""
    }

    fun select(model: StoredModel) = local.update { it.copy(selectedFileName = model.fileName) }
    fun setContextLength(value: Int) = local.update { it.copy(contextLength = value) }
    fun setThreads(value: Int) = local.update { it.copy(threads = value) }
    fun dismissError() = local.update { it.copy(error = null) }
    fun dismissNotice() = local.update { it.copy(notice = null) }

    fun importModel(uri: Uri) {
        if (importJob?.isActive == true) return
        importJob = viewModelScope.launch {
            local.update { it.copy(importing = true, importProgress = 0f, error = null, notice = null) }
            try {
                val imported = store.importFrom(
                    uri = uri,
                    validate = { file -> engine.inspect(file.absolutePath) },
                    onProgress = { copied, total ->
                        local.update { it.copy(importProgress = if (total > 0) copied.toFloat() / total else 0f) }
                    },
                )
                local.update { it.copy(selectedFileName = imported.fileName, notice = "Modelo importado: ${imported.displayName}") }
            } catch (e: CancellationException) {
                local.update { it.copy(error = "Importación cancelada. No se guardó nada.") }
                throw e
            } catch (e: ImportException) {
                local.update { it.copy(error = e.message) }
            } catch (e: Exception) {
                local.update { it.copy(error = "No se pudo importar: ${e.message}") }
            } finally {
                local.update { it.copy(importing = false) }
                refreshStorage()
            }
        }
    }

    fun cancelImport() { importJob?.cancel() }

    fun setDefault(model: StoredModel) { viewModelScope.launch { store.setDefault(model) } }

    fun deleteModel(model: StoredModel) {
        viewModelScope.launch {
            try {
                if (controller.loaded.value?.model?.fileName == model.fileName) controller.unload()
                store.delete(model)
                local.update { it.copy(notice = "Modelo eliminado. Tus conversaciones se conservan.") }
            } catch (e: Exception) {
                local.update { it.copy(error = "No se pudo eliminar: ${e.message}") }
            } finally {
                refreshStorage()
            }
        }
    }

    fun loadSelected() {
        val st = ui.value
        val model = st.selected ?: return
        viewModelScope.launch {
            local.update { it.copy(error = null) }
            try {
                controller.ensureLoaded(model, local.value.contextLength, local.value.threads)
            } catch (e: Exception) {
                local.update { it.copy(error = e.message ?: "No se pudo cargar el modelo.") }
            } finally {
                refreshLog()
            }
        }
    }

    fun unload() { viewModelScope.launch { controller.unload() } }

    fun refreshLog() {
        viewModelScope.launch {
            runCatching { engine.nativeLog() }.onSuccess { log -> local.update { it.copy(nativeLog = log.takeLast(4000)) } }
        }
    }
}
