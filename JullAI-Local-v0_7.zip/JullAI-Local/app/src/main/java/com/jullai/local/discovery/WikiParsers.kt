package com.jullai.local.discovery

import com.jullai.local.roleplay.J
import com.jullai.local.roleplay.JArr
import com.jullai.local.roleplay.JNum
import com.jullai.local.roleplay.JObj
import com.jullai.local.roleplay.JsonException
import com.jullai.local.roleplay.MiniJson
import com.jullai.local.roleplay.arr
import com.jullai.local.roleplay.asObj
import com.jullai.local.roleplay.bool
import com.jullai.local.roleplay.int
import com.jullai.local.roleplay.obj
import com.jullai.local.roleplay.str
import com.jullai.local.world.UntrustedText

/** Una obra candidata devuelta por la búsqueda (Wikipedia). */
data class WorkCandidate(
    val title: String,
    val api: String,
    val lang: String,
    val qid: String,
    val shortDescription: String,
    val intro: String,
    val kind: String,
    val rank: Int,
)

/** Una sección de una página, en orden de aparición. [level] es el nivel de encabezado de HTML (2 = «==», 3 = «===»). */
data class SectionRef(val title: String, val level: Int, val index: Int)

data class PageImageRef(val title: String, val thumbUrl: String, val fileName: String, val width: Int, val height: Int)

data class FileInfo(val url: String, val mime: String, val size: Long, val license: String, val artist: String, val nonFree: Boolean)

/** Lectura tolerante de las respuestas JSON (formatversion=2). Si el formato no es el esperado devuelven listas vacías o null: nunca lanzan. */
object WikiParsers {
    private fun root(json: String): JObj? = try { MiniJson.parse(json).asObj() } catch (e: JsonException) { null }
    private fun pages(json: String): List<JObj> = root(json)?.obj("query")?.arr("pages")?.items?.mapNotNull { it.asObj() }.orEmpty()
    private fun clean(s: String?, max: Int) = UntrustedText.oneLine(s.orEmpty(), max)

    /** Respuesta de generator=search con pageprops y extractos. Ordenadas por relevancia. Se omiten páginas de desambiguación y listas. */
    fun workCandidates(json: String, api: String, lang: String): List<WorkCandidate> =
        pages(json).mapNotNull { p ->
            val title = clean(p.str("title"), 200)
            if (title.isBlank()) return@mapNotNull null
            val props = p.obj("pageprops")
            if (props != null && props.fields.containsKey("disambiguation")) return@mapNotNull null
            val shortDesc = clean(props?.str("wikibase-shortdesc"), 200)
            val intro = clean(p.str("extract"), 320)
            WorkCandidate(
                title = title, api = api, lang = lang, qid = clean(props?.str("wikibase_item"), 20).takeIf { Regex("^Q[0-9]{1,12}$").matches(it) }.orEmpty(),
                shortDescription = shortDesc, intro = intro, kind = WorkKind.classify(title, shortDesc, intro), rank = p.int("index") ?: Int.MAX_VALUE,
            )
        }.sortedBy { it.rank }

    fun searchTitles(json: String): List<String> =
        root(json)?.obj("query")?.arr("search")?.items?.mapNotNull { it.asObj()?.str("title") }?.map { clean(it, 200) }?.filter { it.isNotBlank() }.orEmpty()

    fun categoryMembers(json: String): List<String> =
        root(json)?.obj("query")?.arr("categorymembers")?.items?.mapNotNull { it.asObj()?.str("title") }?.map { clean(it, 200) }?.filter { it.isNotBlank() }.orEmpty()

    /** Secciones de action=parse&prop=sections. El «line» puede traer marcas HTML: se quitan. */
    fun sections(json: String): List<SectionRef> {
        val list = root(json)?.obj("parse")?.arr("sections")?.items ?: return emptyList()
        return list.mapIndexedNotNull { i, s ->
            val o = s.asObj() ?: return@mapIndexedNotNull null
            val line = clean(com.jullai.local.world.SourceText.decodeEntities(o.str("line").orEmpty().replace(Regex("<[^>]{0,200}>"), "")), 120)
            val level = o.str("level")?.toIntOrNull() ?: o.int("level") ?: (o.int("toclevel")?.plus(1)) ?: 2
            if (line.isBlank()) null else SectionRef(line, level.coerceIn(1, 6), o.str("index")?.toIntOrNull() ?: (i + 1))
        }
    }

    /** Títulos que existen (no «missing») y que no son desambiguaciones, ya con su nombre tras redirecciones. Mapa «título pedido» → «título real». */
    fun existingTitles(json: String): Map<String, String> {
        val r = root(json) ?: return emptyMap()
        val q = r.obj("query") ?: return emptyMap()
        val redirectsFrom = LinkedHashMap<String, String>()
        for (x in listOf("normalized", "redirects")) q.arr(x)?.items?.forEach { it.asObj()?.let { o ->
            val f = o.str("from"); val t = o.str("to")
            if (f != null && t != null) redirectsFrom[f] = t
        } }
        val ok = HashSet<String>()
        for (p in q.arr("pages")?.items?.mapNotNull { it.asObj() }.orEmpty()) {
            if (p.bool("missing") == true || p.bool("invalid") == true) continue
            if (p.obj("pageprops")?.fields?.containsKey("disambiguation") == true) continue
            p.str("title")?.let { ok.add(it) }
        }
        val out = LinkedHashMap<String, String>()
        for (t in ok) out[t] = t
        for ((from, to) in redirectsFrom) {
            var cur = to
            var guard = 0
            while (redirectsFrom.containsKey(cur) && guard++ < 4) cur = redirectsFrom.getValue(cur)
            if (cur in ok) out[from] = cur
        }
        return out
    }

    fun pageImages(json: String): List<PageImageRef> =
        pages(json).mapNotNull { p ->
            val th = p.obj("thumbnail") ?: return@mapNotNull null
            val url = th.str("source") ?: return@mapNotNull null
            PageImageRef(clean(p.str("title"), 200), url.take(600), clean(p.str("pageimage"), 200), th.int("width") ?: 0, th.int("height") ?: 0)
        }

    /** imageinfo con extmetadata: licencia, autor y si es una imagen no libre. */
    fun fileInfo(json: String): FileInfo? {
        val p = pages(json).firstOrNull() ?: return null
        val ii = p.arr("imageinfo")?.items?.firstOrNull()?.asObj() ?: return null
        val meta = ii.obj("extmetadata")
        fun m(k: String) = meta?.obj(k)?.str("value").orEmpty()
        val nonFree = m("NonFree").equals("true", true) || m("NonFree") == "1"
        val license = clean(com.jullai.local.world.SourceText.htmlToText(m("LicenseShortName").ifBlank { m("UsageTerms") }), 120)
        val artist = clean(com.jullai.local.world.SourceText.htmlToText(m("Artist").ifBlank { m("Credit") }), 160)
        return FileInfo(
            url = ii.str("url").orEmpty().take(600), mime = clean(ii.str("mime"), 40), size = (ii.fields["size"] as? JNum)?.v?.toLong() ?: 0L,
            license = license, artist = artist, nonFree = nonFree,
        )
    }

    /** Fandom API v1 /Articles/Details → título → miniatura. (Los «items» son un objeto indexado por id de página.) */
    fun fandomThumbs(json: String): Map<String, String> {
        val items = root(json)?.obj("items") ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        for ((_, v) in items.fields) {
            val o = v.asObj() ?: continue
            val t = o.str("title") ?: continue
            val th = o.str("thumbnail") ?: continue
            out[clean(t, 200)] = th.take(600)
        }
        return out
    }

    // ---- Wikidata ----

    /** Identificadores (Q…) de las afirmaciones de una propiedad (p. ej. P674 «personajes»). */
    fun claimEntityIds(json: String, entityId: String, property: String): List<String> {
        val claims = root(json)?.obj("entities")?.obj(entityId)?.obj("claims")?.arr(property)?.items ?: return emptyList()
        return claims.mapNotNull { c ->
            c.asObj()?.obj("mainsnak")?.obj("datavalue")?.obj("value")?.str("id")?.takeIf { Regex("^Q[0-9]{1,12}$").matches(it) }
        }.distinct()
    }

    /** Valor de texto de una propiedad (p. ej. P6262, identificador del artículo en Fandom: «walkingdead:The Walking Dead»). */
    fun claimString(json: String, entityId: String, property: String): String? {
        val c = root(json)?.obj("entities")?.obj(entityId)?.obj("claims")?.arr(property)?.items?.firstOrNull()?.asObj()
        return c?.obj("mainsnak")?.obj("datavalue")?.str("value")?.let { clean(it, 200) }?.takeIf { it.isNotBlank() }
    }

    /** Etiqueta de cada entidad (preferencia es, luego en). */
    fun labels(json: String): Map<String, String> {
        val ents = root(json)?.obj("entities") ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        for ((id, v) in ents.fields) {
            val l = v.asObj()?.obj("labels") ?: continue
            val label = l.obj("es")?.str("value") ?: l.obj("en")?.str("value") ?: continue
            clean(label, 120).takeIf { it.isNotBlank() }?.let { out[id] = it }
        }
        return out
    }

    /** Enlaces a Wikipedia de una entidad: código de idioma → título. */
    fun sitelinks(json: String, entityId: String): Map<String, String> {
        val sl = root(json)?.obj("entities")?.obj(entityId)?.obj("sitelinks") ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        for ((k, v) in sl.fields) {
            if (!k.endsWith("wiki") || k.length < 5) continue
            val lang = k.removeSuffix("wiki")
            if (!Regex("^[a-z]{2,3}$").matches(lang)) continue
            v.asObj()?.str("title")?.let { out[lang] = clean(it, 200) }
        }
        return out
    }

    /** Dominio y título de la propiedad P6262 «walkingdead:The Walking Dead» → (walkingdead, The Walking Dead). */
    fun splitFandomId(id: String): Pair<String, String>? {
        val i = id.indexOf(':')
        if (i <= 0 || i >= id.length - 1) return null
        val sub = id.substring(0, i).trim().lowercase()
        if (!Regex("^[a-z0-9][a-z0-9-]{0,60}$").matches(sub)) return null
        return sub to id.substring(i + 1).trim()
    }

    fun apiError(json: String): String? {
        val o = root(json) ?: return "La respuesta no es JSON válido."
        val e = o.obj("error") ?: return null
        return clean(e.str("info") ?: e.str("code"), 200).ifBlank { "error de la API" }
    }

    fun isJson(json: String): Boolean = root(json) != null
}

/** Tipos de obra. Se deducen de la descripción corta y la introducción (en español e inglés); no se fía de un identificador de Wikidata no verificado. */
object WorkKind {
    const val SERIE = "SERIE"
    const val ANIME = "ANIME"
    const val MANGA = "MANGA"
    const val COMIC = "COMIC"
    const val PELICULA = "PELICULA"
    const val LIBRO = "LIBRO"
    const val VIDEOJUEGO = "VIDEOJUEGO"
    const val FRANQUICIA = "FRANQUICIA"
    const val OTRA_OBRA = "OTRA_OBRA"
    const val NO_ES_OBRA = "NO_ES_OBRA"   // personaje, episodio, lista, persona, lugar…
    val WORKS = setOf(SERIE, ANIME, MANGA, COMIC, PELICULA, LIBRO, VIDEOJUEGO, FRANQUICIA, OTRA_OBRA)

    fun label(k: String) = when (k) {
        SERIE -> "Serie de televisión"; ANIME -> "Anime"; MANGA -> "Manga"; COMIC -> "Cómic"; PELICULA -> "Película"
        LIBRO -> "Libro o saga literaria"; VIDEOJUEGO -> "Videojuego"; FRANQUICIA -> "Franquicia"; OTRA_OBRA -> "Obra"; else -> "Otro"
    }

    private fun has(f: String, vararg words: String) = words.any { f.contains(it) }

    fun classify(title: String, shortDesc: String, intro: String): String {
        val t = com.jullai.local.story.TextNorm.fold(title)
        val head = com.jullai.local.story.TextNorm.fold(shortDesc.ifBlank { intro.take(160) })
        val long = com.jullai.local.story.TextNorm.fold(intro.take(240))
        if (t.startsWith("list of") || t.startsWith("lista de") || t.startsWith("anexo:") || t.startsWith("category:") || t.startsWith("categoria:")) return WorkKind.NO_ES_OBRA
        if (has(head, "episode", "episodio", "season of", "temporada de", "fictional character", "personaje ficticio", "personaje de", "character in", "character from", "film character", "television character", "soundtrack", "banda sonora", "album", "song", "cancion", "actor", "actress", "actriz", "singer", "cantante", "footballer", "futbolista", "politician", "politico", "village", "municipality", "municipio", "company", "empresa")) return WorkKind.NO_ES_OBRA
        return when {
            has(head, "anime") -> WorkKind.ANIME
            has(head, "manga", "light novel") -> WorkKind.MANGA
            has(head, "comic book series", "comic series", "comic strip", "graphic novel", "serie de comics", "serie de historietas", "historieta", "comic", "cómic", "webcomic") -> WorkKind.COMIC
            has(head, "television series", "tv series", "television show", "serie de television", "serie televisiva", "miniseries", "miniserie", "sitcom", "telenovela", "web series", "serie web", "animated series", "serie animada", "drama series", "serie de drama") -> WorkKind.SERIE
            has(head, "video game", "videojuego", "game series", "serie de videojuegos", "role-playing game", "juego de rol") -> WorkKind.VIDEOJUEGO
            has(head, "film series", "saga cinematografica", "franchise", "franquicia", "media franchise") -> WorkKind.FRANQUICIA
            has(head, "film", "movie", "pelicula", "filme", "cortometraje") -> WorkKind.PELICULA
            has(head, "novel", "novela", "book series", "series of", "saga de", "saga literaria", "fantasy novels", "serie de novelas", "libro", "book", "short story", "cuento") -> WorkKind.LIBRO
            // Sin descripción corta útil: se intenta con la introducción.
            has(long, "television series", "tv series", "serie de television", "american television", "serie estadounidense") -> WorkKind.SERIE
            has(long, "comic book", "comics", "historieta") -> WorkKind.COMIC
            has(long, "video game", "videojuego") -> WorkKind.VIDEOJUEGO
            has(long, "feature film", "is a film", "es una pelicula", "pelicula de") -> WorkKind.PELICULA
            has(long, "novel", "novela") -> WorkKind.LIBRO
            has(long, "franchise", "franquicia") -> WorkKind.FRANQUICIA
            else -> WorkKind.NO_ES_OBRA
        }
    }
}
