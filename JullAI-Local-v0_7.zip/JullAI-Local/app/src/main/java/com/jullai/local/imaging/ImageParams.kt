package com.jullai.local.imaging

/** Resolución validada. [tier] indica el coste relativo: 0 = bajo consumo, 1 = medio, 2 = calidad. */
data class ImageSize(val width: Int, val height: Int, val tier: Int, val label: String) {
    val pixels: Int get() = width * height
}

/**
 * Valores de resolución permitidos (múltiplos de 64; SD 1.5 se entrenó a 512 px, por eso no se ofrece nada mayor).
 * No hay un campo libre: una resolución arbitraria puede agotar la memoria del teléfono.
 */
object ImageSizes {
    val PORTRAIT_LOW = ImageSize(256, 384, 0, "256×384 retrato (bajo consumo)")
    val LANDSCAPE_LOW = ImageSize(384, 256, 0, "384×256 fondo (bajo consumo)")
    val SQUARE_LOW = ImageSize(256, 256, 0, "256×256 cuadrada")
    val PORTRAIT_MID = ImageSize(384, 576, 1, "384×576 retrato (medio)")
    val LANDSCAPE_MID = ImageSize(576, 384, 1, "576×384 fondo (medio)")
    val SQUARE_MID = ImageSize(384, 384, 1, "384×384 cuadrada (medio)")
    val PORTRAIT_HIGH = ImageSize(512, 768, 2, "512×768 retrato (calidad, lento)")
    val LANDSCAPE_HIGH = ImageSize(768, 512, 2, "768×512 fondo (calidad, lento)")
    val SQUARE_HIGH = ImageSize(512, 512, 2, "512×512 cuadrada (calidad, lento)")

    val ALL = listOf(PORTRAIT_LOW, LANDSCAPE_LOW, SQUARE_LOW, PORTRAIT_MID, LANDSCAPE_MID, SQUARE_MID, PORTRAIT_HIGH, LANDSCAPE_HIGH, SQUARE_HIGH)

    fun find(w: Int, h: Int): ImageSize? = ALL.firstOrNull { it.width == w && it.height == h }
    fun isValid(w: Int, h: Int) = find(w, h) != null

    /** Tamaño recomendado para un tipo de recurso en un nivel de calidad (0..2). */
    fun forKind(kind: String, tier: Int): ImageSize {
        val t = tier.coerceIn(0, 2)
        val landscape = kind == "FONDO" || kind == "ILUSTRACION"
        return when (t) {
            0 -> if (landscape) LANDSCAPE_LOW else PORTRAIT_LOW
            1 -> if (landscape) LANDSCAPE_MID else PORTRAIT_MID
            else -> if (landscape) LANDSCAPE_HIGH else PORTRAIT_HIGH
        }
    }
}

object Samplers {
    const val EULER_A = "euler_a"
    const val EULER = "euler"
    const val DPMPP_2M = "dpm++2m"
    const val LCM = "lcm"
    val ALL = listOf(EULER_A, EULER, DPMPP_2M, LCM)

    fun label(s: String) = when (s) {
        EULER_A -> "Euler a"; EULER -> "Euler"; DPMPP_2M -> "DPM++ 2M"; LCM -> "LCM"; else -> s
    }
}

/** Preajustes de calidad. Valores iniciales razonables, NO medidos en el dispositivo; la app registra los tiempos reales. */
enum class QualityPreset(val id: String, val label: String, val tier: Int, val steps: Int, val cfg: Float, val sampler: String, val tiling: Boolean) {
    LOW_POWER("BAJO_CONSUMO", "Bajo consumo", 0, 20, 7f, Samplers.EULER_A, true),
    LOW_POWER_LCM("BAJO_CONSUMO_LCM", "Bajo consumo + LCM (4–8 pasos)", 0, 6, 1.5f, Samplers.LCM, true),
    BALANCED("EQUILIBRADO", "Equilibrado", 1, 20, 7f, Samplers.EULER_A, true),
    QUALITY("CALIDAD", "Calidad (lento, más RAM)", 2, 25, 7f, Samplers.DPMPP_2M, true);

    /** Solo tiene sentido con una LoRA LCM aplicable al checkpoint (el usuario la importa y la selecciona). */
    val needsLcmLora: Boolean get() = sampler == Samplers.LCM

    companion object {
        fun byId(id: String?): QualityPreset = entries.firstOrNull { it.id == id } ?: LOW_POWER
    }
}

/** Coste relativo de una configuración frente a la de bajo consumo por defecto (pasos × píxeles). Aritmética, no un tiempo medido. */
object CostEstimate {
    private const val BASE_STEPS = 20.0
    private const val BASE_PIXELS = 256.0 * 384.0

    fun relative(steps: Int, w: Int, h: Int, cfg: Float): Double {
        val passes = if (cfg > 1.0001f) 2.0 else 1.0   // con CFG > 1 cada paso evalúa el modelo dos veces
        val base = BASE_STEPS * BASE_PIXELS * 2.0
        return steps * (w.toDouble() * h) * passes / base
    }

    /** Segundos estimados a partir de generaciones PREVIAS reales (segundos por unidad de coste). null si no hay historial. */
    fun secondsFromHistory(rel: Double, history: List<Pair<Double, Long>>): Long? {
        val valid = history.filter { it.first > 0.0 && it.second > 0L }
        if (valid.isEmpty()) return null
        val perUnit = valid.sumOf { it.second.toDouble() } / valid.sumOf { it.first }
        return (rel * perUnit / 1000.0).toLong().coerceAtLeast(1L)
    }
}

object Seeds {
    fun resolve(requested: Long, random: java.util.Random = java.util.Random()): Long =
        if (requested >= 0) requested.coerceAtMost(Int.MAX_VALUE.toLong() * 2) else (random.nextInt(Int.MAX_VALUE)).toLong()
}

/** Valida una petición ANTES de llegar al motor. Devuelve el motivo en español, o null si es válida. */
object RequestValidator {
    fun validate(r: GenerationRequest, caps: EngineCapabilities): String? {
        if (r.prompt.isBlank()) return "El prompt está vacío."
        if (!ImageSizes.isValid(r.width, r.height)) return "Resolución no permitida: ${r.width}×${r.height}. Elige una de la lista."
        if (r.steps !in 1..50) return "Los pasos deben estar entre 1 y 50."
        if (r.cfgScale !in 1f..20f) return "La guía (CFG) debe estar entre 1 y 20."
        if (r.sampler !in Samplers.ALL) return "Sampler no válido: ${r.sampler}."
        if (caps.samplers.isNotEmpty() && r.sampler !in caps.samplers) return "El motor compilado no admite el sampler ${Samplers.label(r.sampler)}."
        if (r.loraPath != null && !caps.lora) return "El motor compilado no admite LoRA."
        if (r.initRgb != null) {
            if (!caps.imageToImage) return "El motor compilado no admite imagen de referencia (image-to-image)."
            if (r.initRgb.size != r.width * r.height * 3) return "La imagen de referencia no coincide con la resolución elegida."
        }
        if (r.threads !in 1..8) return "Hilos no válidos."
        return null
    }
}
