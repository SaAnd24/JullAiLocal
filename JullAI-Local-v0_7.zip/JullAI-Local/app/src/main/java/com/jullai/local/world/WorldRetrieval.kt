package com.jullai.local.world

import com.jullai.local.roleplay.PromptSection
import com.jullai.local.story.TextNorm
import kotlin.math.ln
import kotlin.math.max

/** Entrada de la enciclopedia tal y como la ve el recuperador. */
class WorldItem(
    val id: Long,
    val type: String,
    val name: String,
    val aliases: List<String>,
    val summary: String,
    val details: String,
    val confidence: String,
    val sourceRef: String,
    val related: List<String>,
    val spoilerLevel: Int,
    val eraTag: String,
    val updatedAt: Long,
)

/** Qué datos hay disponibles. La implementación con Room (FTS4 + LIKE) vive en WorldRepository. */
interface WorldSource {
    suspend fun candidates(worldId: Long, queryTokens: List<String>): WorldCandidates
}

class WorldCandidates(val items: List<WorldItem>, val ftsIds: Set<Long>?, val backend: String)

class WorldRequest(
    val worldId: Long,
    val worldHeader: String,
    val recent: List<String>,
    val participants: List<String>,
    val spoilerLevel: String,
    val continuity: String,
    val currentEra: String,
    val budgetTokens: Int,
)

data class PickedWorld(val item: WorldItem, val why: String, val text: String, val tokens: Int)

class WorldRetrieval(
    val picked: List<PickedWorld>,
    val rules: String,
    val rulesTokens: Int,
    val notFitting: List<String>,
    val hiddenBySpoiler: Int,
    val backend: String,
    val budget: Int,
    val candidates: Int,
) {
    val usedTokens: Int get() = picked.sumOf { it.tokens } + rulesTokens
    fun isEmpty() = picked.isEmpty() && rules.isBlank()

    /** Secciones para el constructor de contexto: primero reglas y continuidad, después los datos por orden de relevancia. */
    fun toSections(): List<PromptSection> = buildList {
        if (rules.isNotBlank()) add(PromptSection("world_rules", "Reglas del mundo", rules, header = "# MUNDO Y CONTINUIDAD"))
        if (picked.isNotEmpty()) add(
            PromptSection("world_facts", "Datos del mundo", "", picked.map { it.text }, header = UntrustedText.DATA_HEADER),
        )
    }

    fun describe(): String = buildString {
        append("Mundo · búsqueda: $backend · $candidates entradas revisadas · $usedTokens de $budget tokens\n")
        if (isEmpty()) append("No se recuperó nada del mundo (sin entradas pertinentes).\n")
        picked.forEach { append("• [${Confidence.label(it.item.confidence)}] ${it.item.name} (${EntryType.label(it.item.type)}) — ${it.why} (${it.tokens} tok)\n") }
        if (hiddenBySpoiler > 0) append("Ocultas por el nivel de spoilers: $hiddenBySpoiler\n")
        if (notFitting.isNotEmpty()) append("Relevantes que no cupieron: ${notFitting.size}\n")
    }.trimEnd()
}

/**
 * Recuperador de conocimiento del mundo (v0.5). Lógica pura. Selecciona SOLO lo pertinente para la escena dentro de un presupuesto:
 * nunca envía el mundo completo. Respeta el nivel de spoilers y conserva la procedencia y la confianza de cada dato.
 * Es independiente de los recuerdos de la partida (0.4): no los lee ni los mezcla.
 */
class WorldRetriever(private val source: WorldSource) {
    companion object {
        const val MAX_PICKS = 12
        const val RULES_SHARE = 0.30
    }

    suspend fun retrieve(req: WorldRequest, count: suspend (String) -> Int): WorldRetrieval {
        val budget = max(0, req.budgetTokens)
        val participantTokens = req.participants.flatMap { TextNorm.tokens(it) }.toSet()
        val weights = LinkedHashMap<String, Double>()
        req.recent.forEachIndexed { i, text ->
            val w = if (i == req.recent.lastIndex) 2.0 else 1.0
            for (t in TextNorm.tokens(text)) if (t !in participantTokens) weights[t] = max(weights[t] ?: 0.0, w)
        }
        val queryFold = TextNorm.fold(req.recent.joinToString("\n"))
        val cands = source.candidates(req.worldId, weights.keys.toList())

        // Reglas del mundo y continuidad: siempre, pero con tope.
        val rulesText = buildRules(req)
        val rulesCap = (budget * RULES_SHARE).toInt()
        var rules = rulesText
        var rulesTokens = if (rules.isBlank()) 0 else count(rules)
        if (rulesTokens > rulesCap) { rules = trimToTokens(rules, rulesCap, count); rulesTokens = if (rules.isBlank()) 0 else count(rules) }

        val maxSpoiler = SpoilerLevel.maxEntryLevel(req.spoilerLevel)
        val visible = cands.items.filter { it.spoilerLevel <= maxSpoiler }
        val hidden = cands.items.size - visible.size

        val n = max(1, visible.size)
        val keysOf = visible.associate { it.id to TextNorm.keySet(TextNorm.tokens(it.name + " " + it.aliases.joinToString(" ") + " " + it.summary + " " + it.details) + it.related.flatMap { r -> TextNorm.tokens(r) }) }
        val df = HashMap<String, Int>()
        for (q in weights.keys) { val qk = TextNorm.keys(q); df[q] = keysOf.values.count { set -> qk.any { it in set } } }

        class Scored(val item: WorldItem, val score: Double, val relevant: Boolean, val why: String)
        val scored = visible.map { it0 ->
            val set = keysOf[it0.id].orEmpty()
            var kw = 0.0
            val hits = ArrayList<String>()
            for ((q, w) in weights) if (TextNorm.keys(q).any { it in set }) { kw += w * ln(1.0 + n.toDouble() / (1 + (df[q] ?: 0))); hits.add(q) }
            // Un nombre o alias que aparece en la escena pesa mucho más que una palabra suelta.
            val nameHit = (listOf(it0.name) + it0.aliases).any { a -> val f = TextNorm.fold(a).trim(); f.length >= 3 && containsWord(queryFold, f) }
            val fts = cands.ftsIds?.contains(it0.id) == true
            val eraOk = req.currentEra.isBlank() || it0.eraTag.isBlank() || TextNorm.fold(it0.eraTag) == TextNorm.fold(req.currentEra)
            val conf = when (it0.confidence) { Confidence.CONFIRMADO -> 0.4; Confidence.LIMITADA, Confidence.CONTRADICCION -> 0.0; else -> -0.2 }
            val typeBoost = if (it0.type == EntryType.REGLA) 0.6 else 0.0
            val total = kw + (if (nameHit) 4.0 else 0.0) + (if (fts) 0.8 else 0.0) + conf + typeBoost - (if (eraOk) 0.0 else 2.0)
            val why = buildString {
                if (nameHit) append("nombre en la escena")
                if (hits.isNotEmpty()) { if (isNotEmpty()) append("; "); append("palabras: " + hits.take(4).joinToString(", ")) }
                if (fts) { if (isNotEmpty()) append("; "); append("texto completo") }
                if (isEmpty()) append("regla del mundo")
            }
            Scored(it0, total, kw > 0 || nameHit || fts || it0.type == EntryType.REGLA, why)
        }.filter { it.relevant }.sortedByDescending { it.score }

        val picked = ArrayList<PickedWorld>()
        val notFitting = ArrayList<String>()
        var used = rulesTokens
        for (s in scored) {
            if (picked.size >= MAX_PICKS) { notFitting.add(s.item.name); continue }
            val text = render(s.item)
            val c = count(text) + 1
            if (used + c > budget) { notFitting.add(s.item.name); continue }
            used += c
            picked.add(PickedWorld(s.item, s.why, text, c))
        }
        return WorldRetrieval(picked, rules, rulesTokens, notFitting, hidden, cands.backend, budget, visible.size)
    }

    private fun containsWord(haystackFold: String, needleFold: String): Boolean {
        var from = 0
        while (true) {
            val i = haystackFold.indexOf(needleFold, from)
            if (i < 0) return false
            val before = if (i == 0) ' ' else haystackFold[i - 1]
            val after = if (i + needleFold.length >= haystackFold.length) ' ' else haystackFold[i + needleFold.length]
            if (!before.isLetterOrDigit() && !after.isLetterOrDigit()) return true
            from = i + 1
        }
    }

    private fun buildRules(req: WorldRequest): String = buildString {
        if (req.worldHeader.isNotBlank()) appendLine(req.worldHeader.trim())
        val c = Continuity.rule(req.continuity)
        if (c.isNotBlank()) appendLine(c)
        if (req.currentEra.isNotBlank()) appendLine("Época o momento de la historia: ${req.currentEra.trim()}.")
        when (req.spoilerLevel) {
            SpoilerLevel.SIN -> appendLine("No reveles secretos ni sucesos futuros del universo original: solo lo que los personajes ya sepan en la escena.")
            SpoilerLevel.MODERADO -> appendLine("Evita revelar de golpe los secretos centrales del universo original.")
        }
    }.trim()

    /** Una entrada, con su confianza visible para que el modelo no trate una interpretación como un hecho. */
    fun render(i: WorldItem): String {
        val tag = Confidence.promptTag(i.confidence)
        val al = if (i.aliases.isNotEmpty()) " (también: ${i.aliases.take(4).joinToString(", ")})" else ""
        val body = i.summary.trim().replace('\n', ' ')
        return "- [$tag] ${i.name}$al — ${EntryType.label(i.type).lowercase()}: $body"
    }

    private suspend fun trimToTokens(s: String, max: Int, count: suspend (String) -> Int): String {
        if (max <= 0) return ""
        val lines = s.lines().toMutableList()
        while (lines.isNotEmpty() && count(lines.joinToString("\n")) > max) lines.removeAt(lines.lastIndex)
        return lines.joinToString("\n")
    }
}
