package com.jullai.local.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/*
 * Imágenes generadas en el dispositivo (v0.6). Todo es ADITIVO respecto a la 0.5: ninguna tabla anterior cambia.
 * Los recursos siguen viviendo en `visual_assets` (retratos, fondos, expresiones, poses, ilustraciones). Aquí solo se añade:
 *  - image_models: checkpoints y LoRA importados (el archivo vive en almacenamiento privado, NUNCA en el APK).
 *  - image_meta: cómo se generó un recurso (prompt, modelo, semilla, parámetros, tiempos). Sin imágenes en base64.
 *  - image_tasks: cola persistente de generaciones (una cada vez).
 *  - visual_profiles: perfil visual estable por personaje.
 */

/** Checkpoint o LoRA importado por el usuario. [compat]: OK = el motor lo cargó; UNVERIFIED = estructura plausible sin carga; REJECTED = no usable. */
@Entity(
    tableName = "image_models",
    indices = [Index(value = ["fileName"], unique = true)],
)
data class ImageModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val fileName: String,
    val displayName: String,
    val format: String,
    val sizeBytes: Long,
    val architecture: String,
    val compat: String,
    val note: String = "",
    val engineValidated: Boolean = false,
    val isDefault: Boolean = false,
    val licenseNote: String = "",
    val importedAt: Long,
)

/** Parámetros con los que se generó un recurso. */
@Entity(
    tableName = "image_meta",
    foreignKeys = [ForeignKey(entity = VisualAssetEntity::class, parentColumns = ["id"], childColumns = ["assetId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["sessionId"])],
)
data class ImageMetaEntity(
    @PrimaryKey val assetId: Long,
    val prompt: String,
    val negativePrompt: String = "",
    val modelName: String = "",
    val loraName: String = "",
    val sampler: String = "",
    val seed: Long = 0,
    val steps: Int = 0,
    val cfg: Float = 0f,
    val width: Int = 0,
    val height: Int = 0,
    val vaeTiling: Boolean = false,
    val preset: String = "",
    val durationMs: Long = 0,
    val engineId: String = "",
    val engineVersion: String = "",
    val sessionId: Long? = null,
    val messageId: Long? = null,
    val slot: String = "",
    val createdAt: Long,
)

/** Tarea de generación persistente. Una tarea interrumpida vuelve a PENDIENTE y se reintenta desde cero (no se reanuda a mitad de una inferencia). */
@Entity(
    tableName = "image_tasks",
    indices = [Index(value = ["status"]), Index(value = ["sessionId"])],
)
data class ImageTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val priority: Int,
    val status: String,
    val worldId: Long? = null,
    val sessionId: Long? = null,
    val messageId: Long? = null,
    val characterId: Long? = null,
    val label: String = "",
    val locationRef: String = "",
    val emotion: String = "",
    val pose: String = "",
    val prompt: String,
    val negativePrompt: String = "",
    val width: Int,
    val height: Int,
    val steps: Int,
    val seed: Long = -1,
    val preset: String = "BAJO_CONSUMO",
    val attempts: Int = 0,
    val error: String = "",
    val resultAssetId: Long? = null,
    val note: String = "",
    val createdAt: Long,
    val updatedAt: Long,
    val startedAt: Long? = null,
    val finishedAt: Long? = null,
)

/** Perfil visual estable de un personaje (descripción física, estilo, ropa por etapa, referencia principal). */
@Entity(
    tableName = "visual_profiles",
    foreignKeys = [ForeignKey(entity = CharacterEntity::class, parentColumns = ["id"], childColumns = ["characterId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["characterId"], unique = true)],
)
data class VisualProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val characterId: Long,
    val physicalDescription: String = "",
    val styleDescription: String = "",
    val outfits: String = "",
    val negativeDefaults: String = "",
    val referenceAssetId: Long? = null,
    val updatedAt: Long,
)
