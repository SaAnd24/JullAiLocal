package com.jullai.local.imaging

import com.jullai.local.story.TextNorm
import com.jullai.local.world.Emotion
import com.jullai.local.world.SceneDraft

/** Metadatos opcionales que un modelo (o una ficha) haya podido escribir al final de un turno. TODO es opcional y se valida. */
data class TurnMeta(
    val speaker: String? = null,
    val emotion: String? = null,
    val pose: String? = null,
    val location: String? = null,
    val event: String? = null,
    val important: Boolean? = null,
)

/**
 * Lector TOLERANTE de metadatos de turno. No se exige JSON perfecto a un modelo pequeño: se acepta una línea
 * `[[escena: hablante=Aria; emocion=ALEGRIA; lugar=Taberna; importante=si]]` (o un JSON suelto entre llaves) y, si algo no se
 * entiende, se IGNORA conservando el texto. Los metadatos nunca se muestran en el diálogo, pero el texto guardado en la base de datos no se modifica.
 */
object TurnMetaParser {
    private val BLOCK = Regex("\\[\\[\\s*escena\\s*:(.*?)]]", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val JSON_TAIL = Regex("\\n\\s*\\{[^{}]{0,400}\"(?:speakerId|hablante|emotion|emocion)\"[^{}]{0,400}}\\s*$", RegexOption.IGNORE_CASE)
    private val KEY = mapOf(
        "hablante" to "speaker", "speaker" to "speaker", "speakerid" to "speaker",
        "emocion" to "emotion", "emotion" to "emotion", "pose" to "pose", "postura" to "pose",
        "lugar" to "location", "localizacion" to "location", "locationid" to "location", "location" to "location",
        "evento" to "event", "visualevent" to "event", "importante" to "important", "isimportantscene" to "important",
    )

    class Parsed(val displayText: String, val meta: TurnMeta?)

    /** Separa el texto visible de los metadatos. Nunca lanza; sin bloque devuelve el texto tal cual. */
    fun parse(text: String): Parsed {
        return try {
            val m = BLOCK.find(text)
            if (m != null) {
                Parsed((text.removeRange(m.range)).trim(), fromPairs(m.groupValues[1].split(';', '\n').mapNotNull { splitPair(it) }))
            } else {
                val j = JSON_TAIL.find(text)
                if (j != null) Parsed(text.removeRange(j.range).trim(), fromPairs(jsonPairs(j.value))) else Parsed(text, null)
            }
        } catch (e: RuntimeException) {
            Parsed(text, null)
        }
    }

    private fun splitPair(s: String): Pair<String, String>? {
        val i = s.indexOf('=').takeIf { it > 0 } ?: s.indexOf(':').takeIf { it > 0 } ?: return null
        val k = s.substring(0, i).trim().lowercase().replace("_", "")
        val v = s.substring(i + 1).trim().trim('"', '\'')
        return if (k.isNotEmpty() && v.isNotEmpty()) k to v else null
    }

    private fun jsonPairs(s: String): List<Pair<String, String>> =
        Regex("\"([A-Za-z_]+)\"\\s*:\\s*(\"[^\"]*\"|true|false|[A-Za-z0-9_.-]+)").findAll(s).map { it.groupValues[1].lowercase().replace("_", "") to it.groupValues[2].trim('"') }.toList()

    private fun fromPairs(pairs: List<Pair<String, String>>): TurnMeta? {
        val map = HashMap<String, String>()
        for ((k, v) in pairs) KEY[k]?.let { map.putIfAbsent(it, v.take(80)) }
        if (map.isEmpty()) return null
        return TurnMeta(
            speaker = map["speaker"], emotion = map["emotion"]?.uppercase(), pose = map["pose"], location = map["location"], event = map["event"],
            important = map["important"]?.lowercase()?.let { it in listOf("si", "sí", "true", "1", "yes") },
        )
    }

    /**
     * Combina lo que dice el modelo con lo deducido por reglas (SceneDirector). Un valor del modelo solo se acepta si se puede VALIDAR
     * contra personajes y lugares reales y emociones conocidas; si no, se conserva la deducción segura.
     */
    fun merge(base: SceneDraft, meta: TurnMeta?, knownCharacters: List<String>, knownLocations: List<String>): SceneDraft {
        if (meta == null) return base
        fun matchOf(v: String?, known: List<String>) = v?.let { x -> known.firstOrNull { TextNorm.fold(it).trim() == TextNorm.fold(x).trim() } }
        val speaker = matchOf(meta.speaker, knownCharacters) ?: base.speaker
        val location = matchOf(meta.location, knownLocations) ?: base.location
        val emotion = meta.emotion?.takeIf { it in Emotion.ALL } ?: base.emotion
        val pose = meta.pose?.takeIf { it.length in 2..40 && it.all { c -> c.isLetter() || c == '_' } }?.uppercase() ?: base.pose
        val important = meta.important ?: base.important
        return base.copy(speaker = speaker, location = location, emotion = emotion, pose = pose, important = important || base.important)
    }
}
