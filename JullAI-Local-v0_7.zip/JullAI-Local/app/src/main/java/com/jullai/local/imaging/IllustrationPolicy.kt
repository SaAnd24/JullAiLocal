package com.jullai.local.imaging

/** Datos reales de una escena para decidir si merece una ilustración completa. */
data class IllustrationContext(
    val important: Boolean,
    val alreadyHasIllustration: Boolean,
    val alreadyQueued: Boolean,
    /** Turnos de respuesta transcurridos desde la última ilustración de esta partida (null = nunca hubo una). */
    val turnsSinceLast: Int?,
    val modelAvailable: Boolean,
)

object IllustrationPolicy {
    enum class Decision { NONE, SUGGEST, ENQUEUE }

    /**
     * - Una respuesta normal NUNCA genera imagen.
     * - Sin modelo importado no se propone nada (la narrativa sigue operativa).
     * - OFF: nada. MANUAL: nada automático (el botón «Ilustrar» siempre está disponible). IMPORTANTES: se sugiere en escenas importantes.
     *   EQUILIBRADA: se encola sola en escenas importantes respetando una pausa mínima de turnos.
     */
    fun decide(mode: String, minGap: Int, c: IllustrationContext): Decision {
        if (!c.important || c.alreadyHasIllustration || c.alreadyQueued || !c.modelAvailable) return Decision.NONE
        return when (mode) {
            IllustrationMode.IMPORTANT -> Decision.SUGGEST
            IllustrationMode.BALANCED -> if (c.turnsSinceLast == null || c.turnsSinceLast >= minGap) Decision.ENQUEUE else Decision.SUGGEST
            else -> Decision.NONE
        }
    }
}
