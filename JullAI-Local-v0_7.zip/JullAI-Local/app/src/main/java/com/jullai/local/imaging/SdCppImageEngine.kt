package com.jullai.local.imaging

import com.jullai.local.imaging.nativebridge.SdBridge
import com.jullai.local.imaging.nativebridge.SdProgress
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/** Superficie nativa mínima. Existe para poder sustituirla por un falso en las pruebas. */
interface SdNative {
    val isLoaded: Boolean
    val loadError: String?
    fun init()
    fun version(): String
    fun capabilities(): String
    fun log(): String
    fun lastError(): String
    fun lastInfo(): String
    fun load(path: String, threads: Int, img2img: Boolean): Long
    fun generate(handle: Long, params: String, prompt: String, negative: String, initRgb: ByteArray?, callback: SdProgress?): ByteArray?
    fun cancel(): Boolean
    fun free(handle: Long)
}

object RealSdNative : SdNative {
    override val isLoaded: Boolean get() = SdBridge.isLoaded
    override val loadError: String? get() = SdBridge.loadError
    override fun init() = SdBridge.nativeInit()
    override fun version() = SdBridge.nativeVersion()
    override fun capabilities() = SdBridge.nativeCapabilities()
    override fun log() = SdBridge.nativeGetLog()
    override fun lastError() = SdBridge.nativeLastError()
    override fun lastInfo() = SdBridge.nativeLastInfo()
    override fun load(path: String, threads: Int, img2img: Boolean) = SdBridge.nativeLoad(path, threads, img2img)
    override fun generate(handle: Long, params: String, prompt: String, negative: String, initRgb: ByteArray?, callback: SdProgress?) =
        SdBridge.nativeGenerate(handle, params, prompt, negative, initRgb, callback)
    override fun cancel() = SdBridge.nativeCancel()
    override fun free(handle: Long) = SdBridge.nativeFree(handle)
}

/**
 * Motor de imágenes basado en stable-diffusion.cpp (MIT), solo CPU. Un único hilo de trabajo ejecuta las llamadas pesadas.
 * Las capacidades se leen del código nativo REALMENTE compilado: si el commit fijado no expone cancelar, LoRA o image-to-image,
 * aquí aparecen como no disponibles y la interfaz no las ofrece.
 */
class SdCppImageEngine(
    private val native: SdNative = RealSdNative,
    private val abi: String = "arm64-v8a",
    private val dispatcher: CoroutineDispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "jullai-sd").also { it.isDaemon = true } }.asCoroutineDispatcher(),
) : ImageEngine {
    override val id = "sdcpp"
    private val _state = MutableStateFlow(if (native.isLoaded) ImageEngineState.IDLE else ImageEngineState.UNAVAILABLE)
    override val state: StateFlow<ImageEngineState> = _state.asStateFlow()

    @Volatile private var handle = 0L
    @Volatile private var loadedPath: String? = null
    @Volatile private var capsCache: EngineCapabilities? = null
    @Volatile private var initDone = false

    private fun ensureInit() { if (!initDone && native.isLoaded) { native.init(); initDone = true } }

    override fun capabilities(): EngineCapabilities {
        capsCache?.let { return it }
        if (!native.isLoaded) return EngineCapabilities.NONE
        val kv = native.capabilities().split(';').filter { it.contains('=') }.associate { it.substringBefore('=') to it.substringAfter('=') }
        val c = EngineCapabilities(
            cancel = kv["cancel"] == "1", progress = kv["progress"] == "1", vaeTiling = kv["vae_tiling"] == "1", lora = kv["lora"] == "1",
            imageToImage = kv["img2img"] == "1", negativePrompt = kv["negative"] == "1",
            samplers = kv["samplers"].orEmpty().split(',').filter { it.isNotBlank() },
        )
        capsCache = c
        return c
    }

    override suspend fun diagnose(): EngineDiagnostics = withContext(dispatcher) {
        if (!native.isLoaded) return@withContext EngineDiagnostics(id, "—", false, abi, emptyList(), native.loadError ?: "Biblioteca nativa de imágenes no disponible.")
        ensureInit()
        val c = capabilities()
        fun yn(b: Boolean) = if (b) "sí" else "no"
        EngineDiagnostics(
            id, native.version(), true, abi,
            listOf(
                "Motor: stable-diffusion.cpp (MIT), solo CPU", "Commit: ${native.version()}",
                "Cancelar: ${yn(c.cancel)} · Progreso: ${yn(c.progress)} · VAE por mosaicos: ${yn(c.vaeTiling)}",
                "LoRA: ${yn(c.lora)} · Imagen de referencia: ${yn(c.imageToImage)} · Prompt negativo: ${yn(c.negativePrompt)}",
                "Samplers: ${c.samplers.joinToString(", ") { Samplers.label(it) }.ifBlank { "ninguno" }}",
            ),
            problem = if (abi != "arm64-v8a") "El motor solo se compila para arm64-v8a." else null,
        )
    }

    override suspend fun loadModel(path: String, threads: Int): LoadedImageModel = withContext(dispatcher) {
        if (!native.isLoaded) throw ImageEngineException(ImageEngineException.Code.NOT_AVAILABLE, native.loadError ?: "Biblioteca nativa de imágenes no disponible.")
        ensureInit()
        if (handle != 0L && loadedPath == path) return@withContext LoadedImageModel(path, 0, java.io.File(path).length())
        freeLocked()
        _state.value = ImageEngineState.LOADING
        val t0 = System.currentTimeMillis()
        val h = try { native.load(path, threads, capabilities().imageToImage) } catch (e: RuntimeException) { 0L }
        if (h == 0L) {
            _state.value = ImageEngineState.ERROR
            val msg = native.lastError().ifBlank { "El motor no pudo cargar el modelo." }
            throw ImageEngineException(if (isOom(msg)) ImageEngineException.Code.OUT_OF_MEMORY else ImageEngineException.Code.INVALID_MODEL, msg)
        }
        handle = h; loadedPath = path
        _state.value = ImageEngineState.READY
        LoadedImageModel(path, System.currentTimeMillis() - t0, java.io.File(path).length())
    }

    override suspend fun generate(request: GenerationRequest, onProgress: (GenProgress) -> Unit): GenerationResult = withContext(dispatcher) {
        val h = handle
        if (h == 0L) throw ImageEngineException(ImageEngineException.Code.FAILED, "No hay un modelo de imagen cargado.")
        _state.value = ImageEngineState.GENERATING
        val params = buildString {
            append("width=").append(request.width).append('\n').append("height=").append(request.height).append('\n')
            append("steps=").append(request.steps).append('\n').append("cfg=").append(request.cfgScale).append('\n')
            append("seed=").append(request.seed).append('\n').append("sampler=").append(request.sampler).append('\n')
            append("tiling=").append(if (request.vaeTiling) 1 else 0).append('\n').append("threads=").append(request.threads).append('\n')
            request.loraPath?.let { append("lora_path=").append(it).append('\n').append("lora_strength=").append(request.loraStrength).append('\n') }
            append("init_strength=").append(request.initStrength).append('\n')
        }
        val report = onProgress   // (dentro del objeto, «onProgress» sería el propio método: se captura antes)
        val cb = if (capabilities().progress) object : SdProgress {
            override fun onProgress(step: Int, steps: Int, seconds: Float) { report(GenProgress(step, steps, seconds)) }
        } else null
        val t0 = System.currentTimeMillis()
        val rgb = try {
            native.generate(h, params, request.prompt, request.negativePrompt, request.initRgb, cb)
        } catch (e: RuntimeException) {
            _state.value = ImageEngineState.ERROR
            throw ImageEngineException(ImageEngineException.Code.FAILED, "Fallo inesperado del motor: ${e.message}", e)
        }
        val info = parseInfo(native.lastInfo())
        if (rgb == null) {
            val err = native.lastError()
            _state.value = ImageEngineState.READY
            when {
                info["cancelled"] == "1" -> throw ImageEngineException(ImageEngineException.Code.CANCELLED, "Generación cancelada.")
                isOom(err) -> { release(); throw ImageEngineException(ImageEngineException.Code.OUT_OF_MEMORY, "Memoria agotada generando la imagen. Baja la resolución o los pasos, o cierra otras apps.") }
                else -> throw ImageEngineException(ImageEngineException.Code.FAILED, err.ifBlank { "El motor no devolvió una imagen." })
            }
        }
        val w = info["width"]?.toIntOrNull() ?: request.width
        val hgt = info["height"]?.toIntOrNull() ?: request.height
        if (rgb.size != w * hgt * 3) {
            _state.value = ImageEngineState.READY
            throw ImageEngineException(ImageEngineException.Code.FAILED, "El motor devolvió datos de imagen incoherentes.")
        }
        _state.value = ImageEngineState.READY
        GenerationResult(
            rgb = rgb, width = w, height = hgt, seed = request.seed,
            totalMillis = info["millis"]?.toLongOrNull() ?: (System.currentTimeMillis() - t0),
            applied = infoList(native.lastInfo(), "applied"), ignored = infoList(native.lastInfo(), "ignored"),
            engineId = id, engineVersion = native.version(),
        )
    }

    override fun cancel(): Boolean = if (native.isLoaded && capabilities().cancel && _state.value == ImageEngineState.GENERATING) native.cancel() else false

    override suspend fun release() = withContext(dispatcher) { freeLocked() }

    private fun freeLocked() {
        val h = handle
        if (h != 0L) { native.free(h); handle = 0L; loadedPath = null }
        if (native.isLoaded) _state.value = ImageEngineState.IDLE
    }

    private fun isOom(msg: String) = msg.contains("memoria", ignoreCase = true) || msg.contains("alloc", ignoreCase = true)
    private fun parseInfo(s: String): Map<String, String> = s.lines().filter { '=' in it && !it.startsWith("applied=") && !it.startsWith("ignored=") }.associate { it.substringBefore('=') to it.substringAfter('=') }
    private fun infoList(s: String, key: String): List<String> = s.lines().filter { it.startsWith("$key=") }.map { it.substringAfter('=') }
}
