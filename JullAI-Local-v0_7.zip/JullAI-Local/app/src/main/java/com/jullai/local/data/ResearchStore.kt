package com.jullai.local.data

class AddResult(val created: Int, val skipped: Int)

/**
 * Lo que necesita el motor de investigación de la base de datos. Es una interfaz a propósito: el motor es lógica pura que se prueba con un
 * almacén en memoria, y WorldRepository la implementa sobre Room.
 */
interface ResearchStore {
    suspend fun task(id: Long): ResearchTaskEntity?
    suspend fun saveTask(t: ResearchTaskEntity)
    suspend fun world(id: Long): WorldEntity?
    /** Añade nombres a los personajes y lugares prioritarios del mundo SIN quitar ni reordenar lo que escribió el usuario. */
    suspend fun mergePriorities(worldId: Long, characters: List<String>, places: List<String>)
    suspend fun sourcesOf(worldId: Long): List<SourceEntity>
    fun sourceText(s: SourceEntity): String?
    suspend fun addSource(worldId: Long, kind: String, uri: String, title: String, status: String, error: String): Long
    suspend fun markSourceProcessed(id: Long, title: String, text: String, license: String, provenance: String, taskId: Long?)
    suspend fun markSourceFailed(id: Long, status: String, error: String, taskId: Long?)
    suspend fun addDrafts(worldId: Long, drafts: List<com.jullai.local.world.DraftEntry>): AddResult
    suspend fun detectContradictions(worldId: Long): Int
    suspend fun entryCount(worldId: Long): Int
    suspend fun identity(worldId: Long): WorldIdentityEntity?
    suspend fun saveIdentity(e: WorldIdentityEntity)
    suspend fun savePlan(worldId: Long, planJson: String, notes: String)
    suspend fun canonImage(worldId: Long, name: String): CanonImageEntity?
    suspend fun saveCanonImage(e: CanonImageEntity)
}
