package com.jullai.local.imaging

import com.jullai.local.world.Emotion

/** Perfil visual de un personaje (copia de VisualProfileEntity sin dependencias de Room, para poder probarlo). */
data class VisualProfile(
    val physical: String = "",
    val style: String = "",
    /** Una línea por etapa: «etapa|ropa» (la etapa puede ir vacía). */
    val outfits: String = "",
    val negative: String = "",
)

/**
 * Construye prompts de generación a partir de la ficha. Todo es editable por el usuario antes de generar.
 * SD 1.5 usa CLIP con un máximo de 77 tokens: los prompts se mantienen compactos y lo importante va primero.
 * IMPORTANTE: no se depende del NOMBRE de un personaje conocido; la descripción física del perfil es lo que describe a la persona.
 */
object PromptBuilder {
    const val MAX_PROMPT_CHARS = 380
    const val DEFAULT_NEGATIVE = "lowres, bad anatomy, bad hands, extra fingers, missing fingers, cropped, worst quality, low quality, jpeg artifacts, text, watermark, signature, blurry"

    private val EMOTION_TEXT = mapOf(
        Emotion.ALEGRIA to "smiling, happy expression",
        Emotion.TRISTEZA to "sad expression, teary eyes",
        Emotion.ENFADO to "angry expression, furrowed brow",
        Emotion.MIEDO to "frightened expression, wide eyes",
        Emotion.SORPRESA to "surprised expression, open mouth",
        Emotion.VERGUENZA to "embarrassed, blushing",
        Emotion.SERIO to "serious expression",
    )

    private val POSE_TEXT = mapOf(
        "BRAZOS_CRUZADOS" to "arms crossed",
        "SENTADO" to "sitting",
        "DE_PIE" to "standing",
        "CAMINANDO" to "walking",
        "SALUDANDO" to "waving",
    )

    fun emotionText(emotion: String): String = EMOTION_TEXT[emotion].orEmpty()
    fun poseText(pose: String): String = POSE_TEXT[pose] ?: pose.replace('_', ' ').lowercase()

    /** Ropa que corresponde a una etapa (busca coincidencia exacta; si no, la línea sin etapa). */
    fun outfitFor(profile: VisualProfile, stage: String): String {
        val rows = profile.outfits.lines().map { it.trim() }.filter { it.isNotEmpty() }.map {
            val i = it.indexOf('|')
            if (i < 0) "" to it else it.substring(0, i).trim() to it.substring(i + 1).trim()
        }
        val wanted = stage.trim().lowercase()
        return rows.firstOrNull { wanted.isNotEmpty() && it.first.lowercase() == wanted }?.second
            ?: rows.firstOrNull { it.first.isEmpty() }?.second
            ?: ""
    }

    private fun join(vararg parts: String): String = parts.map { it.trim().trim(',') }.filter { it.isNotEmpty() }.joinToString(", ")

    /** Retrato / expresión / pose de un personaje. */
    fun character(profile: VisualProfile, appearanceFallback: String, emotion: String = "", pose: String = "", stage: String = ""): String {
        val body = profile.physical.ifBlank { appearanceFallback }
        val text = join(
            profile.style.ifBlank { "anime style illustration" },
            "portrait of a character",
            body, outfitFor(profile, stage), emotionText(emotion), if (pose.isBlank()) "" else poseText(pose),
            "detailed face, simple background",
        )
        return cap(text)
    }

    fun background(style: String, locationName: String, locationDescription: String): String =
        cap(join(style.ifBlank { "anime style background art" }, locationDescription.ifBlank { locationName }, "no people, scenery, detailed, wide shot"))

    /** Ilustración de una escena importante: las personas aparecen por su descripción física, no por su nombre. */
    fun scene(style: String, sceneSummary: String, people: List<String>, location: String): String =
        cap(join(style.ifBlank { "anime style illustration" }, sceneSummary, people.joinToString(" and "), location, "dramatic lighting, detailed"))

    fun negative(profile: VisualProfile): String = if (profile.negative.isBlank()) DEFAULT_NEGATIVE else join(profile.negative, DEFAULT_NEGATIVE)

    private fun cap(s: String): String {
        val one = s.replace(Regex("\\s+"), " ").trim()
        if (one.length <= MAX_PROMPT_CHARS) return one
        val cut = one.take(MAX_PROMPT_CHARS)
        val comma = cut.lastIndexOf(',')
        return if (comma > MAX_PROMPT_CHARS / 2) cut.take(comma) else cut
    }

    /** Resumen breve de una escena a partir del texto narrativo (sin modelo): primera frase útil, sin asteriscos ni diálogos largos. */
    fun summarizeScene(text: String, maxChars: Int = 160): String {
        val clean = text.replace('*', ' ').replace(Regex("[\\u201C\\u201D\"«»]"), " ").replace(Regex("\\s+"), " ").trim()
        val sentence = Regex("[^.!?…]{12,}[.!?…]").find(clean)?.value?.trim() ?: clean
        return if (sentence.length <= maxChars) sentence else sentence.take(maxChars).trimEnd() + "…"
    }
}
