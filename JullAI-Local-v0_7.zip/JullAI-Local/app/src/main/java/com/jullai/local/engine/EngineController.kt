package com.jullai.local.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Modelo actualmente cargado en el motor y con qué configuración. */
data class LoadedModel(
    val model: StoredModel,
    val info: ModelInfo,
    val contextLength: Int,
    val threads: Int,
)

/**
 * Punto único para cargar/descargar el modelo de texto. Lo usan el chat (carga automática al enviar un mensaje)
 * y la pantalla Modelos (carga manual). El modelo se mantiene cargado al cambiar de pantalla.
 */
class EngineController(
    val engine: LlamaEngine,
    private val store: ModelStore,
) {
    private val mutex = Mutex()
    private val _loaded = MutableStateFlow<LoadedModel?>(null)
    val loaded: StateFlow<LoadedModel?> = _loaded.asStateFlow()

    private val _busy = MutableStateFlow<String?>(null)
    val busy: StateFlow<String?> = _busy.asStateFlow()

    val state: StateFlow<EngineState> get() = engine.state

    /**
     * v0.6: gancho que se ejecuta ANTES de cargar/usar el modelo de texto. El coordinador de recursos lo usa para detener el motor de
     * imágenes y liberar su memoria (el texto tiene prioridad). Si lanza, el mensaje (en español) llega a quien pidió la carga.
     */
    @Volatile var beforeLoad: (suspend () -> Unit)? = null

    /**
     * Garantiza que [model] esté cargado con ese contexto e hilos; si ya lo está no hace nada (la caché KV se conserva).
     * Lanza una excepción con mensaje en español si no se puede cargar.
     */
    suspend fun ensureLoaded(model: StoredModel, contextLength: Int, threads: Int): LoadedModel {
        beforeLoad?.invoke()
        return ensureLoadedLocked(model, contextLength, threads)
    }

    private suspend fun ensureLoadedLocked(model: StoredModel, contextLength: Int, threads: Int): LoadedModel = mutex.withLock {
        val cur = _loaded.value
        val st = engine.state.value
        val active = st == EngineState.READY || st == EngineState.GENERATING
        if (cur != null && active && cur.model.fileName == model.fileName &&
            cur.contextLength == contextLength && cur.threads == threads
        ) {
            return@withLock cur
        }
        check(st != EngineState.GENERATING) { "Hay una generación en curso; espera o detenla antes de cambiar el modelo." }
        _busy.value = "Cargando ${model.displayName}…"
        try {
            val file = store.file(model)
            check(file.exists()) { "El archivo del modelo ya no existe. Impórtalo de nuevo." }
            val info = engine.load(file.absolutePath, EngineConfig(contextLength = contextLength, threads = threads))
            val result = LoadedModel(model, info, contextLength, threads)
            _loaded.value = result
            result
        } catch (e: Throwable) {
            _loaded.value = null
            throw e
        } finally {
            _busy.value = null
        }
    }

    /** Libera modelo y contexto nativos (cancela antes cualquier generación). */
    suspend fun unload() = mutex.withLock {
        engine.unload()
        _loaded.value = null
    }

    /** Libera solo si no hay una generación en curso. Devuelve true si liberó. */
    suspend fun unloadIfIdle(): Boolean {
        if (engine.state.value == EngineState.GENERATING || engine.state.value == EngineState.LOADING) return false
        unload()
        return true
    }
}
