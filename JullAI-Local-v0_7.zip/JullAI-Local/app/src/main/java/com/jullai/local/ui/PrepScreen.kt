package com.jullai.local.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jullai.local.roleplay.RoleplayViewModel
import com.jullai.local.roleplay.WorldViewModel
import com.jullai.local.world.CastMode
import com.jullai.local.world.Continuity
import com.jullai.local.world.PrepStatus
import com.jullai.local.world.SpoilerLevel

/**
 * Preparación progresiva de una partida con mundo. Cinco tareas con estado REAL (listo, pendiente, fallido): no hay porcentajes inventados.
 * No hace falta completarlo todo: se puede empezar en cuanto el mundo, el reparto y la primera escena están listos.
 * La preparación narrativa NO genera imágenes. La preparación visual (v0.6) es aparte, opcional y no bloquea el inicio: se añade a la cola de imágenes.
 */
@Composable
fun PrepScreen(world: WorldViewModel, rp: RoleplayViewModel, imaging: com.jullai.local.imaging.ImagingViewModel, sessionId: Long, onBack: () -> Unit, onPlay: () -> Unit, onOpenWorld: (Long) -> Unit, onStudio: () -> Unit) {
    val imgTasks by imaging.tasks.collectAsState()
    val imgNotice by imaging.notice.collectAsState()
    val worlds by world.worlds.collectAsState()
    val link by world.sessionWorld(sessionId).collectAsState(initial = null)
    val report by world.prep.collectAsState()
    val steps by world.prepSteps(sessionId).collectAsState(initial = emptyList())
    val notice by world.notice.collectAsState()
    var cast by rememberSaveable { mutableStateOf(CastMode.MIXTO) }
    var cont by rememberSaveable { mutableStateOf(Continuity.FLEXIBLE) }
    var spoil by rememberSaveable { mutableStateOf(SpoilerLevel.SIN) }
    var era by rememberSaveable { mutableStateOf("") }
    var pickedWorld by rememberSaveable { mutableStateOf(0L) }
    LaunchedEffect(sessionId) { rp.open(sessionId) }
    LaunchedEffect(link?.sessionId, link?.worldId) { if (link != null) world.runPreparation(sessionId) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Mundo de la partida", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                val l = link
                if (l == null) {
                    BasicText("Esta partida no tiene mundo. Puedes jugar sin él o vincular uno: la enciclopedia aporta datos, reglas y continuidad. Lo que ocurra en la partida NO modifica el mundo.", style = Type.Cuerpo)
                    SectionTitle("Elegir mundo")
                    if (worlds.isEmpty()) BasicText("Aún no tienes mundos. Crea uno en Biblioteca → Mundos.", style = Type.Nota)
                    ChipFlow(worlds.map { it.id.toString() }, { it == pickedWorld.toString() }, { id -> worlds.firstOrNull { it.id.toString() == id }?.name ?: id }, { pickedWorld = it.toLong() }, perRow = 2)
                    BasicText("Continuidad (independiente del reparto)", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                    ChipFlow(Continuity.ALL, { it == cont }, { Continuity.label(it).substringBefore(" (") }, { cont = it })
                    BasicText(Continuity.rule(cont), style = Type.Nota)
                    BasicText("Reparto", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                    ChipFlow(CastMode.ALL, { it == cast }, { CastMode.label(it).replace("Personajes ", "") }, { cast = it })
                    BasicText("Spoilers", style = Type.Nota.copy(color = Ink.Oro), modifier = Modifier.padding(top = 10.dp))
                    ChipFlow(SpoilerLevel.ALL, { it == spoil }, { SpoilerLevel.label(it) }, { spoil = it })
                    LabeledField("Época o momento de inicio", era, { era = it })
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InkButton("Vincular y preparar", { worlds.firstOrNull { it.id == pickedWorld }?.let { world.bindSession(sessionId, it, cast, cont, spoil, era) } }, enabled = worlds.any { it.id == pickedWorld })
                        InkButton("Jugar sin mundo", onPlay, primary = false)
                    }
                } else {
                    BasicText("«${l.worldName}» · ${Continuity.label(l.continuityMode)} · ${CastMode.label(l.castMode)} · ${SpoilerLevel.label(l.spoilerLevel)}", style = Type.Seccion.copy(fontSize = 16.sp))
                    BasicText("El avance, las relaciones y los recuerdos de esta partida son independientes de otras partidas que usen el mismo mundo.", style = Type.Nota)
                    SectionTitle("Preparación")
                    BasicText(report?.summary() ?: "Calculando…", style = Type.Nota.copy(color = Ink.Oro))
                }
            }
            if (link != null) {
                items(steps, key = { it.id }) { st ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        BasicText("${st.step}. ${st.title} — ${labelOf(st.status)}", style = Type.Cuerpo.copy(color = if (st.status == PrepStatus.FALLIDO) Ink.Granate else if (st.status == PrepStatus.LISTO) Ink.Marfil else Ink.Oro))
                        if (st.detail.isNotBlank()) BasicText(st.detail, style = Type.Nota)
                    }
                }
                item {
                    val r = report
                    Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InkButton("Empezar a jugar", onPlay, enabled = r?.canStart == true)
                        InkButton("Reintentar", { world.runPreparation(sessionId) }, primary = false)
                    }
                    if (r != null && !r.canStart) BasicText("Para empezar hacen falta: mundo leído, personaje con ficha y primera escena. Lo demás puede completarse después.", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
                    SectionTitle("Recursos visuales (opcional)")
                    val open = imgTasks.filter { it.sessionId == sessionId && it.status in listOf("PENDIENTE", "EN_CURSO", "APLAZADA") }
                    val done = imgTasks.count { it.sessionId == sessionId && it.status == "LISTA" }
                    val failed = imgTasks.count { it.sessionId == sessionId && it.status == "FALLIDA" }
                    BasicText("Cola de esta partida: $done lista(s) · ${open.size} pendiente(s) · $failed fallida(s). Orden: personaje principal, fondo de la primera localización, expresiones y fondos siguientes. Puedes jugar sin esperar.", style = Type.Nota)
                    imgNotice?.let { BasicText(it, style = Type.Nota.copy(color = Ink.Oro)) }
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InkButton("Preparar recursos", { imaging.planForSession(sessionId) }, primary = false)
                        InkButton("Abrir cola", onStudio, primary = false)
                    }
                    link?.worldId?.let { id -> InkLink("Abrir el mundo para añadir entradas o investigar", { onOpenWorld(id) }) }
                    InkLink("Desvincular el mundo", { world.unbindSession(sessionId) }, danger = true)
                }
            }
        }
    }
    notice?.let { n -> InkDialog("Aviso", { world.dismissNotice() }) { BasicText(n, style = Type.Cuerpo); Row(Modifier.padding(top = 12.dp)) { InkButton("Entendido", { world.dismissNotice() }) } } }
}

private fun labelOf(s: String) = when (s) {
    PrepStatus.LISTO -> "listo"; PrepStatus.EN_CURSO -> "en curso"; PrepStatus.FALLIDO -> "fallido"; PrepStatus.OMITIDO -> "omitido"; else -> "pendiente"
}
