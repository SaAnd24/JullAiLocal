package com.jullai.local.imaging

import com.jullai.local.data.ImageMetaEntity
import com.jullai.local.data.ImageTaskEntity
import com.jullai.local.world.AssetKind
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * Cola persistente de generaciones. UNA tarea cada vez (el dispositivo objetivo no admite más). Las tareas y sus estados viven en Room:
 * al cerrar y abrir la app las pendientes siguen ahí; las que estaban en curso vuelven a «pendiente» y se reintentan DESDE EL PRINCIPIO
 * de esa tarea (el motor no puede guardar una inferencia a medias). No se muestran porcentajes inventados: solo el paso real del motor.
 */
class ImageQueue(
    private val repo: ImageRepository,
    private val coordinator: ResourceCoordinator,
    private val engineInfo: () -> Pair<String, String>,
    private val capabilities: () -> EngineCapabilities,
    private val settings: () -> ImageSettings,
    private val modelFile: (String) -> File,
    private val saveImage: (GenerationResult) -> String,
    private val readReference: (String, Int, Int) -> ByteArray?,
    private val assetFile: suspend (Long) -> String?,
    private val scope: CoroutineScope,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()
    private val _currentTask = MutableStateFlow<Long?>(null)
    val currentTask: StateFlow<Long?> = _currentTask.asStateFlow()
    private val _progress = MutableStateFlow<GenProgress?>(null)
    val progress: StateFlow<GenProgress?> = _progress.asStateFlow()
    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private var loop: Job? = null

    /** Al arrancar la app: lo que estaba EN_CURSO vuelve a pendiente. No se lanza nada solo (salvo que el ajuste «ejecutar automáticamente» esté activo). */
    suspend fun onAppStart() {
        val n = repo.resetRunning("Interrumpida al cerrarse la app: se reintenta desde el principio.")
        if (n > 0) _message.value = "$n tarea(s) interrumpida(s) volvieron a pendiente."
    }

    /** Pone en marcha la cola si no está corriendo. [wake] = el usuario lo pidió: las aplazadas vuelven a pendiente. */
    fun kick(wake: Boolean = false) {
        if (loop?.isActive == true) return
        loop = scope.launch {
            if (wake) repo.wakeDeferred()
            runUntilIdle()
        }
    }

    suspend fun enqueue(spec: TaskSpec): Long {
        val id = repo.enqueue(spec)
        if (settings().autoRun) kick()
        return id
    }

    /** Cancela una tarea: si es la que corre, pide cancelar al motor; si no, la marca cancelada. */
    suspend fun cancel(id: Long) {
        if (_currentTask.value == id) { coordinator.requestCancel("Cancelada por el usuario.", byUser = true); return }
        val t = repo.task(id) ?: return
        if (t.status == TaskStatus.PENDIENTE || t.status == TaskStatus.APLAZADA) repo.updateTask(t.copy(status = TaskStatus.CANCELADA, note = "Cancelada por el usuario.", finishedAt = clock()))
    }

    /** Cancela lo que corre y todo lo pendiente. */
    suspend fun cancelAll() {
        repo.cancelAllOpen("Cancelada por el usuario.")
        coordinator.requestCancel("Cancelada por el usuario.", byUser = true)
    }

    suspend fun retry(id: Long) {
        val t = repo.task(id) ?: return
        if (t.status == TaskStatus.FALLIDA || t.status == TaskStatus.CANCELADA || t.status == TaskStatus.APLAZADA) {
            repo.updateTask(t.copy(status = TaskStatus.PENDIENTE, error = "", note = "Reintento manual.", finishedAt = null))
            kick(wake = false)
        }
    }

    /** Ejecuta tareas pendientes, una a una, hasta que no quede ninguna o haya que parar. Pública para poder probarla de forma determinista. */
    suspend fun runUntilIdle() {
        _running.value = true
        try {
            while (true) {
                val t = repo.pendingTasks().firstOrNull() ?: break
                if (coordinator.textHasPriority()) { _message.value = "En pausa: el texto tiene prioridad."; break }
                if (!runTask(t)) break
            }
        } finally {
            _running.value = false
            _currentTask.value = null
            _progress.value = null
            // Fin de la cola: se libera el motor visual (el de texto se recargará solo al enviar la próxima acción).
            runCatching { coordinator.releaseIfIdle() }
            if (_message.value.isBlank() || _message.value.startsWith("Generando")) _message.value = ""
        }
    }

    /** Devuelve false si la cola debe parar (aplazada, cancelada por el sistema, error del motor ausente). */
    private suspend fun runTask(t0: ImageTaskEntity): Boolean {
        val now = clock()
        var t = t0.copy(status = TaskStatus.EN_CURSO, attempts = t0.attempts + 1, startedAt = now, error = "", note = "")
        repo.updateTask(t)
        _currentTask.value = t.id
        _progress.value = null
        _message.value = "Generando: ${t.label.ifBlank { AssetKind.label(t.kind) }}"

        val ck = repo.defaultModel(ImageModelKinds.CHECKPOINT)
        if (ck == null) { fail(t, "No hay un modelo de imagen. Importa un checkpoint SD 1.x en «Estudio de imágenes → Modelos».", stop = true); return false }
        val ckFile = modelFile(ck.fileName)
        if (!ckFile.exists()) { fail(t, "El archivo del modelo «${ck.displayName}» ya no existe. Impórtalo de nuevo.", stop = true); return false }

        val s = settings()
        val preset = QualityPreset.byId(t.preset)
        val lora = repo.defaultModel(ImageModelKinds.LORA)?.takeIf { modelFile(it.fileName).exists() }
        // La LoRA seleccionada es una LoRA LCM: solo se aplica con los preajustes LCM (con 20 pasos y CFG 7 estropearía la imagen).
        val useLora = lora != null && capabilities().lora && lora.compat != ModelCompat.REJECTED && preset.needsLcmLora
        var effPreset = preset
        if (preset.needsLcmLora && !useLora) effPreset = QualityPreset.LOW_POWER

        // Referencia de identidad: solo si el motor lo expone, el ajuste lo permite y existe una imagen de referencia del personaje.
        var init: ByteArray? = null
        if (s.useReference && capabilities().imageToImage && t.characterId != null && (t.kind == AssetKind.EXPRESION || t.kind == AssetKind.POSE)) {
            val refId = repo.profile(t.characterId)?.referenceAssetId
            val refFile = refId?.let { assetFile(it) }
            init = refFile?.let { readReference(it, t.width, t.height) }
        }
        val seed = Seeds.resolve(t.seed)
        val req = GenerationRequest(
            prompt = t.prompt, negativePrompt = t.negativePrompt, width = t.width, height = t.height,
            steps = if (effPreset !== preset) QualityPreset.LOW_POWER.steps.coerceAtLeast(t.steps.coerceAtMost(30)) else t.steps,
            cfgScale = effPreset.cfg, seed = seed, sampler = effPreset.sampler, vaeTiling = s.vaeTiling && capabilities().vaeTiling,
            threads = s.threads, loraPath = if (useLora) modelFile(lora!!.fileName).absolutePath else null, loraStrength = s.loraStrength,
            initRgb = init, initStrength = 0.55f,
        )
        val outcome = try {
            coordinator.run(ImageJob(req, ckFile.absolutePath, ck.sizeBytes) { p -> _progress.value = p })
        } catch (e: CancellationException) {
            repo.updateTask(t.copy(status = TaskStatus.PENDIENTE, note = "Interrumpida: se reintenta."))
            throw e
        }
        when (outcome) {
            is JobOutcome.Done -> {
                val r = outcome.result
                try {
                    val file = saveImage(r)
                    val (engId, engVer) = engineInfo()
                    val meta = ImageMetaEntity(
                        assetId = 0, prompt = t.prompt, negativePrompt = t.negativePrompt, modelName = ck.displayName, loraName = if (useLora) lora!!.displayName else "",
                        sampler = effPreset.sampler, seed = r.seed, steps = req.steps, cfg = req.cfgScale, width = r.width, height = r.height,
                        vaeTiling = req.vaeTiling, preset = effPreset.id, durationMs = r.totalMillis, engineId = engId, engineVersion = engVer,
                        sessionId = t.sessionId, messageId = t.messageId, slot = t.kind, createdAt = clock(),
                    )
                    val label = t.label.ifBlank { AssetKind.label(t.kind) }
                    val assetId = repo.saveGenerated(t.kind, file, label, t.characterId, t.worldId, t.locationRef, t.emotion, meta)
                    t = t.copy(status = TaskStatus.LISTA, resultAssetId = assetId, finishedAt = clock(), note = r.ignored.joinToString("; ").take(200))
                    repo.updateTask(t)
                    _lastError.value = null
                    return true
                } catch (e: Exception) {
                    fail(t, "La imagen se generó pero no se pudo guardar: ${e.message}", stop = false)
                    return true
                }
            }
            is JobOutcome.Deferred -> {
                repo.updateTask(t.copy(status = TaskStatus.APLAZADA, note = outcome.reason.take(300), startedAt = null))
                _message.value = outcome.reason
                return false
            }
            is JobOutcome.Cancelled -> {
                if (outcome.byUser) repo.updateTask(t.copy(status = TaskStatus.CANCELADA, note = outcome.reason, finishedAt = clock()))
                else { repo.updateTask(t.copy(status = TaskStatus.APLAZADA, note = outcome.reason, startedAt = null)); _message.value = outcome.reason }
                return outcome.byUser && repo.pendingTasks().isNotEmpty()
            }
            is JobOutcome.Failed -> {
                val stop = outcome.code == ImageEngineException.Code.NOT_AVAILABLE || outcome.code == ImageEngineException.Code.INVALID_MODEL || outcome.code == ImageEngineException.Code.OUT_OF_MEMORY
                fail(t, outcome.message, stop)
                return !stop
            }
        }
    }

    private suspend fun fail(t: ImageTaskEntity, msg: String, stop: Boolean) {
        repo.updateTask(t.copy(status = TaskStatus.FALLIDA, error = msg.take(400), finishedAt = clock()))
        _lastError.value = msg
        if (stop) _message.value = msg
    }
}
