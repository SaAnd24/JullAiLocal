package com.jullai.local.roleplay

/**
 * Lector de personajes: tarjetas Character Card V1/V2 (y lectura básica de V3) de SillyTavern, en JSON,
 * y el JSON propio de JullAI (exportación). Todo el contenido son DATOS: se limpian, se limitan y nunca se ejecutan.
 * Las claves de lorebook que parecen regex se tratan como texto literal (evita ataques de regex catastrófica).
 */
object CardParser {
    const val OWN_FORMAT = "jullai-character"

    fun parseBytes(bytes: ByteArray): ParsedCard {
        if (bytes.size > CardLimits.MAX_JSON_BYTES) throw CardException("El archivo JSON es demasiado grande (más de ${CardLimits.MAX_JSON_BYTES / 1_000_000} MB).")
        return parseJson(String(bytes, Charsets.UTF_8))
    }

    fun parseJson(text: String): ParsedCard {
        if (text.length > CardLimits.MAX_JSON_BYTES) throw CardException("El JSON es demasiado grande.")
        val root = try {
            MiniJson.parse(text)
        } catch (e: JsonException) {
            throw CardException("El archivo no es un JSON válido. ${e.message}")
        }
        val o = root as? JObj ?: throw CardException("El JSON no es una tarjeta: se esperaba un objeto.")
        val warnings = ArrayList<String>()

        if (o.str("format") == OWN_FORMAT) return parseOwn(o, warnings)

        val spec = o.str("spec")
        return when {
            spec == "chara_card_v2" || spec == "chara_card_v3" -> {
                val data = o.obj("data") ?: throw CardException("La tarjeta ($spec) no tiene el bloque «data».")
                val v3 = spec == "chara_card_v3"
                fromCardData(data, if (v3) "V3" else "V2", warnings, nickname = v3)
            }
            spec != null -> throw CardException("Versión de tarjeta no soportada: «${Sanitize.oneLine(spec, 40)}». Se admiten V1, V2 y (lectura básica) V3.")
            o.obj("data")?.str("name") != null -> {
                warnings.add("La tarjeta no indica su versión; se leyó como V2.")
                fromCardData(o.obj("data")!!, "V2", warnings, nickname = false)
            }
            o.str("name") != null || o.str("first_mes") != null || o.str("char_name") != null ->
                fromCardData(o, "V1", warnings, nickname = false)
            else -> throw CardException("El JSON no parece una tarjeta de personaje (no tiene «spec» ni «name»).")
        }
    }

    private fun fromCardData(d: JObj, format: String, warnings: MutableList<String>, nickname: Boolean): ParsedCard {
        var name = Sanitize.oneLine(d.str("name") ?: d.str("char_name"), CardLimits.MAX_NAME_CHARS)
        val description = Sanitize.text(d.str("description") ?: d.str("char_persona"), label = "descripción", warnings = warnings)
        val firstMes = Sanitize.text(d.str("first_mes") ?: d.str("char_greeting"), label = "mensaje de bienvenida", warnings = warnings)
        if (name.isEmpty()) {
            if (description.isEmpty() && firstMes.isEmpty()) throw CardException("La tarjeta no tiene nombre ni contenido.")
            name = "Personaje sin nombre"
            warnings.add("La tarjeta no tenía nombre; se le puso «Personaje sin nombre».")
        }

        var behavior = Sanitize.text(d.str("system_prompt"), label = "system_prompt", warnings = warnings)
        val post = Sanitize.text(d.str("post_history_instructions"), label = "post_history_instructions", warnings = warnings)
        if (post.isNotEmpty()) {
            behavior = if (behavior.isEmpty()) post else behavior + "\n\n" + post
            warnings.add("«post_history_instructions» se añadió a las instrucciones de comportamiento (esta versión no las coloca después del historial).")
        }
        if (behavior.isNotEmpty()) warnings.add("La tarjeta trae instrucciones propias («system_prompt»). Se tratan como parte de la ficha, no como órdenes de la app: revísalas.")

        val greetings = ArrayList<String>()
        d.arr("alternate_greetings")?.items?.forEach { g ->
            if (greetings.size >= CardLimits.MAX_GREETINGS) return@forEach
            val t = Sanitize.text((g as? JStr)?.v, CardLimits.MAX_GREETING_CHARS)
            if (t.isNotEmpty()) greetings.add(t)
        }
        if ((d.arr("alternate_greetings")?.items?.size ?: 0) > CardLimits.MAX_GREETINGS) warnings.add("Solo se importaron los primeros ${CardLimits.MAX_GREETINGS} saludos alternativos.")

        val aliases = ArrayList<String>()
        if (nickname) Sanitize.oneLine(d.str("nickname"), CardLimits.MAX_NAME_CHARS).takeIf { it.isNotEmpty() && it != name }?.let { aliases.add(it) }

        val tags = d.arr("tags")?.items?.mapNotNull { (it as? JStr)?.v?.let { t -> Sanitize.oneLine(t, 40).takeIf { s -> s.isNotEmpty() } } }
            ?.take(CardLimits.MAX_TAGS) ?: emptyList()

        val character = ParsedCharacter(
            name = name,
            aliases = aliases,
            appearance = description,
            personality = Sanitize.text(d.str("personality") ?: d.str("char_persona_traits"), label = "personalidad", warnings = warnings),
            behaviorInstructions = behavior,
            scenario = Sanitize.text(d.str("scenario") ?: d.str("world_scenario"), label = "escenario", warnings = warnings),
            firstMessage = firstMes,
            alternateGreetings = greetings,
            dialogueExamples = Sanitize.text(d.str("mes_example") ?: d.str("example_dialogue"), label = "ejemplos de diálogo", warnings = warnings),
            privateNotes = Sanitize.text(d.str("creator_notes"), label = "notas del creador", warnings = warnings),
            tags = tags,
            creator = Sanitize.oneLine(d.str("creator"), 80),
        )
        val book = d.obj("character_book")?.let { parseBook(it, name, warnings) }
        return ParsedCard(character, book, format, warnings)
    }

    internal fun parseBook(b: JObj, charName: String, warnings: MutableList<String>): ParsedLorebook {
        val rawEntries: List<J> = when (val e = b.get("entries")) {
            is JArr -> e.items
            is JObj -> e.fields.values.toList()
            else -> emptyList()
        }
        if (rawEntries.size > CardLimits.MAX_LORE_ENTRIES) warnings.add("El lorebook tiene ${rawEntries.size} entradas; solo se importaron las primeras ${CardLimits.MAX_LORE_ENTRIES}.")
        var regexKeys = 0
        var skipped = 0
        val entries = ArrayList<ParsedLoreEntry>()
        for (re in rawEntries.take(CardLimits.MAX_LORE_ENTRIES)) {
            val e = re as? JObj
            if (e == null) { skipped++; continue }
            fun keyList(vararg names: String): List<String> {
                for (n in names) {
                    val a = e.get(n)
                    val raw: List<String> = when (a) {
                        is JArr -> a.items.mapNotNull { (it as? JStr)?.v }
                        is JStr -> a.v.split(',')
                        else -> continue
                    }
                    return raw.map { Sanitize.oneLine(it, CardLimits.MAX_KEY_CHARS) }.filter { it.isNotEmpty() }.take(CardLimits.MAX_KEYS_PER_ENTRY)
                }
                return emptyList()
            }
            val keys = keyList("keys", "key")
            val secondary = keyList("secondary_keys", "keysecondary")
            regexKeys += (keys + secondary).count { it.length > 2 && it.startsWith("/") && it.lastIndexOf('/') > 0 }
            val content = Sanitize.text(e.str("content"), CardLimits.MAX_LORE_CONTENT_CHARS)
            val constant = e.bool("constant") ?: false
            if (content.isEmpty() || (keys.isEmpty() && !constant)) { skipped++; continue }
            val disabled = e.bool("disable") ?: false
            entries.add(
                ParsedLoreEntry(
                    name = Sanitize.oneLine(e.str("name") ?: e.str("comment"), CardLimits.MAX_NAME_CHARS),
                    keys = keys,
                    secondaryKeys = secondary,
                    content = content,
                    enabled = (e.bool("enabled") ?: true) && !disabled,
                    constant = constant,
                    selective = e.bool("selective") ?: false,
                    caseSensitive = e.bool("case_sensitive") ?: false,
                    priority = (e.int("priority") ?: 10).coerceIn(-1000, 1000),
                    insertionOrder = (e.int("insertion_order") ?: e.int("order") ?: 100).coerceIn(-100000, 100000),
                ),
            )
        }
        if (skipped > 0) warnings.add("$skipped entradas del lorebook se omitieron (vacías, sin claves o con formato no válido).")
        if (regexKeys > 0) warnings.add("$regexKeys claves del lorebook parecen expresiones regulares; esta app las usa como texto literal.")
        return ParsedLorebook(
            name = Sanitize.oneLine(b.str("name"), CardLimits.MAX_NAME_CHARS).ifEmpty { "Lorebook de $charName" },
            description = Sanitize.text(b.str("description"), 2000),
            scanDepth = (b.int("scan_depth") ?: 4).coerceIn(1, 50),
            entries = entries,
        )
    }

    // ------------- JSON propio de JullAI (exportar / importar) -------------

    fun toOwnJson(c: ParsedCharacter, book: ParsedLorebook?): String {
        val charObj = obj(
            "name" to jstr(c.name), "aliases" to jstrList(c.aliases), "appearance" to jstr(c.appearance),
            "personality" to jstr(c.personality), "speechStyle" to jstr(c.speechStyle), "history" to jstr(c.history),
            "motivations" to jstr(c.motivations), "likesDislikes" to jstr(c.likesDislikes),
            "behaviorInstructions" to jstr(c.behaviorInstructions), "initialRelationship" to jstr(c.initialRelationship),
            "scenario" to jstr(c.scenario), "firstMessage" to jstr(c.firstMessage),
            "alternateGreetings" to jstrList(c.alternateGreetings), "dialogueExamples" to jstr(c.dialogueExamples),
            "privateNotes" to jstr(c.privateNotes), "tags" to jstrList(c.tags), "creator" to jstr(c.creator),
        )
        val fields = linkedMapOf<String, J>("format" to jstr(OWN_FORMAT), "version" to jnum(1), "character" to charObj)
        if (book != null) {
            fields["lorebook"] = obj(
                "name" to jstr(book.name), "description" to jstr(book.description), "scanDepth" to jnum(book.scanDepth),
                "entries" to JArr(book.entries.map { e ->
                    obj(
                        "name" to jstr(e.name), "keys" to jstrList(e.keys), "secondaryKeys" to jstrList(e.secondaryKeys),
                        "content" to jstr(e.content), "enabled" to jbool(e.enabled), "constant" to jbool(e.constant),
                        "selective" to jbool(e.selective), "caseSensitive" to jbool(e.caseSensitive),
                        "priority" to jnum(e.priority), "insertionOrder" to jnum(e.insertionOrder),
                    )
                }),
            )
        }
        return MiniJson.write(JObj(fields), pretty = true)
    }

    private fun parseOwn(o: JObj, warnings: MutableList<String>): ParsedCard {
        val ver = o.int("version") ?: 1
        if (ver > 1) throw CardException("Este archivo es de una versión más nueva de JullAI (formato $ver). Actualiza la app.")
        val c = o.obj("character") ?: throw CardException("Falta el bloque «character».")
        fun s(k: String, max: Int = CardLimits.MAX_FIELD_CHARS) = Sanitize.text(c.str(k), max, k, warnings)
        fun list(a: JArr?, max: Int, cap: Int) = a?.items?.mapNotNull { (it as? JStr)?.v?.let { t -> Sanitize.text(t, max).takeIf { x -> x.isNotEmpty() } } }?.take(cap) ?: emptyList()
        val name = Sanitize.oneLine(c.str("name"), CardLimits.MAX_NAME_CHARS)
        if (name.isEmpty()) throw CardException("El personaje no tiene nombre.")
        val ch = ParsedCharacter(
            name = name, aliases = list(c.arr("aliases"), CardLimits.MAX_NAME_CHARS, 20),
            appearance = s("appearance"), personality = s("personality"), speechStyle = s("speechStyle"), history = s("history"),
            motivations = s("motivations"), likesDislikes = s("likesDislikes"), behaviorInstructions = s("behaviorInstructions"),
            initialRelationship = s("initialRelationship"), scenario = s("scenario"), firstMessage = s("firstMessage"),
            alternateGreetings = list(c.arr("alternateGreetings"), CardLimits.MAX_GREETING_CHARS, CardLimits.MAX_GREETINGS),
            dialogueExamples = s("dialogueExamples"), privateNotes = s("privateNotes"),
            tags = list(c.arr("tags"), 40, CardLimits.MAX_TAGS), creator = Sanitize.oneLine(c.str("creator"), 80),
        )
        val book = o.obj("lorebook")?.let { b ->
            val entries = (b.arr("entries")?.items ?: emptyList()).take(CardLimits.MAX_LORE_ENTRIES).mapNotNull { re ->
                val e = re as? JObj ?: return@mapNotNull null
                fun keys(k: String) = list(e.arr(k), CardLimits.MAX_KEY_CHARS, CardLimits.MAX_KEYS_PER_ENTRY)
                val content = Sanitize.text(e.str("content"), CardLimits.MAX_LORE_CONTENT_CHARS)
                if (content.isEmpty()) return@mapNotNull null
                ParsedLoreEntry(
                    name = Sanitize.oneLine(e.str("name"), CardLimits.MAX_NAME_CHARS), keys = keys("keys"), secondaryKeys = keys("secondaryKeys"),
                    content = content, enabled = e.bool("enabled") ?: true, constant = e.bool("constant") ?: false,
                    selective = e.bool("selective") ?: false, caseSensitive = e.bool("caseSensitive") ?: false,
                    priority = (e.int("priority") ?: 10).coerceIn(-1000, 1000), insertionOrder = (e.int("insertionOrder") ?: 100).coerceIn(-100000, 100000),
                )
            }
            ParsedLorebook(Sanitize.oneLine(b.str("name"), CardLimits.MAX_NAME_CHARS).ifEmpty { "Lorebook de $name" },
                Sanitize.text(b.str("description"), 2000), (b.int("scanDepth") ?: 4).coerceIn(1, 50), entries)
        }
        return ParsedCard(ch, book, "JullAI", warnings)
    }
}
