package com.jullai.local.roleplay

/**
 * JSON mínimo, propio y sin dependencias. Existe a propósito: las tarjetas de personaje son datos NO confiables,
 * así que el lector tiene límite de profundidad (no se desborda la pila con corchetes anidados) y de tamaño.
 * Solo lee y escribe JSON; nunca ejecuta nada.
 */
sealed interface J
object JNull : J
data class JBool(val v: Boolean) : J
data class JNum(val v: Double) : J
data class JStr(val v: String) : J
data class JArr(val items: List<J>) : J
data class JObj(val fields: Map<String, J>) : J

class JsonException(message: String) : Exception(message)

object MiniJson {
    const val MAX_DEPTH = 48

    fun parse(input: String): J {
        val text = input.removePrefix("﻿")
        val p = Parser(text)
        p.skipWs()
        val v = p.value(0)
        p.skipWs()
        if (!p.atEnd()) p.fail("hay texto después del final del JSON")
        return v
    }

    private class Parser(val s: String) {
        var i = 0
        fun atEnd() = i >= s.length
        fun fail(msg: String): Nothing = throw JsonException("JSON no válido (posición $i): $msg")

        fun skipWs() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun value(depth: Int): J {
            if (depth > MAX_DEPTH) fail("anidamiento demasiado profundo")
            if (atEnd()) fail("se esperaba un valor")
            return when (val c = s[i]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> JStr(str())
                't' -> lit("true", JBool(true))
                'f' -> lit("false", JBool(false))
                'n' -> lit("null", JNull)
                else -> if (c == '-' || c in '0'..'9') num() else fail("carácter inesperado '$c'")
            }
        }

        fun lit(word: String, v: J): J {
            if (!s.startsWith(word, i)) fail("se esperaba $word")
            i += word.length
            return v
        }

        fun num(): J {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i] in '0'..'9' || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            val d = s.substring(st, i).toDoubleOrNull() ?: fail("número no válido")
            return JNum(d)
        }

        fun str(): String {
            i++ // comilla inicial
            val sb = StringBuilder()
            while (true) {
                if (atEnd()) fail("cadena sin cerrar")
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (atEnd()) fail("escape incompleto")
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) fail("escape \\u incompleto")
                                val code = s.substring(i, i + 4).toIntOrNull(16) ?: fail("escape \\u no válido")
                                sb.append(code.toChar())
                                i += 4
                            }
                            else -> fail("escape no válido \\$e")
                        }
                    }
                    else -> sb.append(c) // se toleran saltos de línea sin escapar dentro de cadenas
                }
            }
        }

        fun arr(depth: Int): J {
            i++
            val items = ArrayList<J>()
            skipWs()
            if (!atEnd() && s[i] == ']') { i++; return JArr(items) }
            while (true) {
                skipWs()
                items.add(value(depth + 1))
                skipWs()
                if (atEnd()) fail("lista sin cerrar")
                when (s[i++]) {
                    ',' -> continue
                    ']' -> return JArr(items)
                    else -> fail("se esperaba ',' o ']'")
                }
            }
        }

        fun obj(depth: Int): J {
            i++
            val map = LinkedHashMap<String, J>()
            skipWs()
            if (!atEnd() && s[i] == '}') { i++; return JObj(map) }
            while (true) {
                skipWs()
                if (atEnd() || s[i] != '"') fail("se esperaba un nombre de campo")
                val k = str()
                skipWs()
                if (atEnd() || s[i] != ':') fail("se esperaba ':'")
                i++
                skipWs()
                map[k] = value(depth + 1)
                skipWs()
                if (atEnd()) fail("objeto sin cerrar")
                when (s[i++]) {
                    ',' -> continue
                    '}' -> return JObj(map)
                    else -> fail("se esperaba ',' o '}'")
                }
            }
        }
    }

    fun write(v: J, pretty: Boolean = false): String {
        val sb = StringBuilder()
        w(v, sb, pretty, 0)
        return sb.toString()
    }

    private fun w(v: J, sb: StringBuilder, pretty: Boolean, ind: Int) {
        when (v) {
            JNull -> sb.append("null")
            is JBool -> sb.append(v.v)
            is JNum -> if (v.v == Math.floor(v.v) && Math.abs(v.v) < 1e15) sb.append(v.v.toLong()) else sb.append(v.v)
            is JStr -> quote(v.v, sb)
            is JArr -> {
                if (v.items.isEmpty()) { sb.append("[]"); return }
                sb.append('[')
                v.items.forEachIndexed { n, it ->
                    if (n > 0) sb.append(',')
                    if (pretty) nl(sb, ind + 1)
                    w(it, sb, pretty, ind + 1)
                }
                if (pretty) nl(sb, ind)
                sb.append(']')
            }
            is JObj -> {
                if (v.fields.isEmpty()) { sb.append("{}"); return }
                sb.append('{')
                var n = 0
                for ((k, x) in v.fields) {
                    if (n++ > 0) sb.append(',')
                    if (pretty) nl(sb, ind + 1)
                    quote(k, sb)
                    sb.append(if (pretty) ": " else ":")
                    w(x, sb, pretty, ind + 1)
                }
                if (pretty) nl(sb, ind)
                sb.append('}')
            }
        }
    }

    private fun nl(sb: StringBuilder, ind: Int) {
        sb.append('\n')
        repeat(ind) { sb.append("  ") }
    }

    private fun quote(s: String, sb: StringBuilder) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append("\\u%04x".format(c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }
}

// ---- Ayudas de lectura tolerantes (devuelven valores por defecto si el campo falta o es de otro tipo) ----

fun J?.asObj(): JObj? = this as? JObj
fun J?.asArr(): JArr? = this as? JArr
fun JObj.get(key: String): J? = fields[key]
fun JObj.str(key: String): String? = when (val v = fields[key]) {
    is JStr -> v.v
    is JNum -> MiniJson.write(v)
    else -> null
}
fun JObj.bool(key: String): Boolean? = (fields[key] as? JBool)?.v
fun JObj.int(key: String): Int? = (fields[key] as? JNum)?.v?.let { if (it.isNaN() || it.isInfinite()) null else it.coerceIn(-1e9, 1e9).toInt() }
fun JObj.arr(key: String): JArr? = fields[key] as? JArr
fun JObj.obj(key: String): JObj? = fields[key] as? JObj

fun obj(vararg pairs: Pair<String, J>): JObj = JObj(linkedMapOf(*pairs))
fun jstr(s: String): J = JStr(s)
fun jnum(n: Int): J = JNum(n.toDouble())
fun jbool(b: Boolean): J = JBool(b)
fun jstrList(l: List<String>): J = JArr(l.map { JStr(it) })
