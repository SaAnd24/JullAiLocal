package com.jullai.local.research

import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI
import java.net.URL

/** Respuesta HTTP ya acotada (el cuerpo nunca supera el límite pedido). */
class HttpResponse(val code: Int, val headers: Map<String, String>, val body: ByteArray, val finalUrl: String, val truncated: Boolean)

class HttpFailure(message: String, val retryable: Boolean) : Exception(message)

/** Transporte HTTP sustituible (en pruebas se usa uno falso). */
interface HttpTransport {
    suspend fun get(url: String, headers: Map<String, String>, maxBytes: Int): HttpResponse
}

/** Reglas puras sobre qué direcciones puede pedir la app. Protege la red local del usuario (SSRF). */
object UrlPolicy {
    const val USER_AGENT = "JullAI-Local/0.7 (app Android personal de rol; investigación iniciada por el usuario; solo lectura)"

    /** Devuelve un motivo de rechazo, o null si la dirección es aceptable. */
    fun reject(url: String): String? {
        val uri = try { URI(url.trim()) } catch (e: Exception) { return "La dirección no es válida." }
        val scheme = uri.scheme?.lowercase()
        if (scheme != "https" && scheme != "http") return "Solo se admiten direcciones http o https."
        val host = uri.host?.lowercase() ?: return "La dirección no tiene servidor."
        if (uri.userInfo != null) return "No se admiten direcciones con usuario y contraseña."
        val port = uri.port
        if (port != -1 && port != 80 && port != 443 && port != 8080 && port != 8443) return "Puerto no permitido."
        if (isPrivateHost(host)) return "No se permite consultar servidores de la red local o internos."
        return null
    }

    fun isPrivateHost(host: String): Boolean {
        val h = host.trim('[', ']').lowercase()
        if (h == "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".lan") || h.endsWith(".home.arpa")) return true
        if (!h.contains('.') && !h.contains(':')) return true   // nombres sin punto (intranet)
        val v4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$").find(h)
        if (v4 != null) {
            val o = v4.groupValues.drop(1).map { it.toInt() }
            if (o.any { it > 255 }) return true
            return o[0] == 0 || o[0] == 10 || o[0] == 127 || (o[0] == 169 && o[1] == 254) || (o[0] == 172 && o[1] in 16..31) ||
                (o[0] == 192 && o[1] == 168) || (o[0] == 100 && o[1] in 64..127) || o[0] >= 224
        }
        if (h.contains(':')) return h == "::1" || h == "::" || h.startsWith("fc") || h.startsWith("fd") || h.startsWith("fe80") || h.startsWith("::ffff:")
        return false
    }

    fun isPrivateAddress(a: InetAddress) = a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress || a.isSiteLocalAddress || a.isMulticastAddress
}

/** Lector de robots.txt (formato estándar). Lógica pura. */
object Robots {
    /** ¿Puede [agentToken] pedir [path]? Gana la regla más larga; a igualdad, Allow. Sin reglas aplicables: se permite. */
    fun allowed(robotsTxt: String, agentToken: String, path: String): Boolean {
        val agent = agentToken.lowercase()
        class Group(val agents: MutableList<String> = ArrayList(), val rules: MutableList<Pair<Boolean, String>> = ArrayList())
        val groups = ArrayList<Group>()
        var cur: Group? = null
        var lastWasAgent = false
        for (raw in robotsTxt.lines()) {
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val i = line.indexOf(':')
            if (i < 0) continue
            val key = line.substring(0, i).trim().lowercase()
            val value = line.substring(i + 1).trim()
            when (key) {
                "user-agent" -> {
                    val g = if (lastWasAgent && cur != null) cur else Group().also { groups.add(it) }
                    g.agents.add(value.lowercase()); cur = g; lastWasAgent = true
                }
                "allow", "disallow" -> { cur?.rules?.add((key == "allow") to value); lastWasAgent = false }
                else -> lastWasAgent = false
            }
        }
        val specific = groups.filter { g -> g.agents.any { it != "*" && agent.contains(it) } }
        val applicable = if (specific.isNotEmpty()) specific else groups.filter { "*" in it.agents }
        var best: Pair<Boolean, String>? = null
        for (g in applicable) for (r in g.rules) {
            if (r.second.isEmpty()) continue   // «Disallow:» vacío = permitir todo
            if (matches(r.second, path)) {
                val b = best
                if (b == null || r.second.length > b.second.length || (r.second.length == b.second.length && r.first)) best = r
            }
        }
        return best?.first ?: true
    }

    private fun matches(pattern: String, path: String): Boolean {
        val anchored = pattern.endsWith("$")
        val p = if (anchored) pattern.dropLast(1) else pattern
        val regex = Regex("^" + p.split("*").joinToString(".*") { Regex.escape(it) } + (if (anchored) "$" else ""))
        return regex.containsMatchIn(path)
    }
}

/**
 * HTTP «educado»: valida cada dirección (también tras redirecciones), limita el ritmo por servidor, respeta Retry-After y
 * identifica a la app con User-Agent. No evita controles de acceso: ante 401/403/429 se detiene e informa.
 */
class PoliteHttp(
    private val transport: HttpTransport,
    private val minIntervalMs: Long = 1100,
    private val now: () -> Long = { System.currentTimeMillis() },
    private val sleep: suspend (Long) -> Unit = { delay(it) },
) {
    private val lastByHost = HashMap<String, Long>()
    private val robotsCache = HashMap<String, String?>()

    suspend fun get(url: String, maxBytes: Int = 2_000_000, accept: String = "text/html,text/plain,application/json;q=0.9,*/*;q=0.1"): HttpResponse {
        var current = url
        repeat(4) { hop ->
            UrlPolicy.reject(current)?.let { throw HttpFailure(it, false) }
            throttle(hostOf(current))
            val r = transport.get(current, mapOf("User-Agent" to UrlPolicy.USER_AGENT, "Accept" to accept, "Accept-Language" to "es,en;q=0.7"), maxBytes)
            when (r.code) {
                in 200..299 -> return r
                301, 302, 303, 307, 308 -> {
                    val loc = r.headers["location"] ?: throw HttpFailure("Redirección sin destino.", false)
                    current = try { URI(current).resolve(loc).toString() } catch (e: Exception) { throw HttpFailure("Redirección no válida.", false) }
                }
                401, 403 -> throw HttpFailure("El sitio no permite el acceso automático (código ${r.code}). Se respeta; importa el contenido a mano si quieres usarlo.", false)
                404, 410 -> throw HttpFailure("La página no existe (código ${r.code}). Puedes cambiar la dirección.", false)
                429, 503 -> {
                    val wait = (r.headers["retry-after"]?.trim()?.toLongOrNull() ?: 0L).coerceIn(0, 3600)
                    if (hop == 0 && wait in 1..8) { sleep(wait * 1000); return@repeat }
                    throw HttpFailure("El sitio pide esperar o está saturado (código ${r.code}${if (wait > 0) ", reintentar en ${wait}s" else ""}).", true)
                }
                else -> throw HttpFailure("Respuesta inesperada del servidor (código ${r.code}).", r.code >= 500)
            }
        }
        throw HttpFailure("Demasiadas redirecciones.", false)
    }

    /** ¿robots.txt permite esta dirección a la app? Si no se puede leer robots.txt, se permite (norma habitual). */
    suspend fun robotsAllows(url: String): Boolean {
        val uri = try { URI(url) } catch (e: Exception) { return false }
        val origin = "${uri.scheme}://${uri.authority}"
        val txt = robotsCache.getOrPut(origin) {
            try {
                val r = get("$origin/robots.txt", 200_000, "text/plain,*/*;q=0.1")
                String(r.body, Charsets.UTF_8)
            } catch (e: HttpFailure) { null }
        } ?: return true
        val path = (uri.rawPath ?: "/").ifEmpty { "/" } + (uri.rawQuery?.let { "?$it" } ?: "")
        return Robots.allowed(txt, "jullai-local", path)
    }

    private fun hostOf(url: String) = try { URI(url).host?.lowercase().orEmpty() } catch (e: Exception) { "" }

    private suspend fun throttle(host: String) {
        val last = lastByHost[host]
        if (last != null) { val wait = minIntervalMs - (now() - last); if (wait > 0) sleep(wait) }
        lastByHost[host] = now()
    }
}

/** Transporte real con HttpURLConnection. Comprueba la IP resuelta (red local) y acota el tamaño leído. */
class UrlConnectionTransport : HttpTransport {
    override suspend fun get(url: String, headers: Map<String, String>, maxBytes: Int): HttpResponse =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val u = URL(url)
            try {
                val addrs = InetAddress.getAllByName(u.host)
                if (addrs.any { UrlPolicy.isPrivateAddress(it) }) throw HttpFailure("Ese servidor resuelve a una dirección de red local: no se consulta.", false)
            } catch (e: java.net.UnknownHostException) {
                throw HttpFailure("No se encontró el servidor (¿sin conexión?).", true)
            }
            val c = u.openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 15_000
                c.readTimeout = 20_000
                c.requestMethod = "GET"
                for ((k, v) in headers) c.setRequestProperty(k, v)
                val code = c.responseCode
                val hs = HashMap<String, String>()
                for ((k, v) in c.headerFields) if (k != null && v.isNotEmpty()) hs[k.lowercase()] = v.last()
                val stream = (if (code in 200..299) c.inputStream else c.errorStream) ?: return@withContext HttpResponse(code, hs, ByteArray(0), url, false)
                val out = ByteArrayOutputStream()
                var truncated = false
                stream.use { s ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = s.read(buf)
                        if (n < 0) break
                        if (out.size() + n > maxBytes) { out.write(buf, 0, maxBytes - out.size()); truncated = true; break }
                        out.write(buf, 0, n)
                    }
                }
                HttpResponse(code, hs, out.toByteArray(), url, truncated)
            } catch (e: HttpFailure) {
                throw e
            } catch (e: java.net.SocketTimeoutException) {
                throw HttpFailure("El servidor tardó demasiado en responder.", true)
            } catch (e: java.io.IOException) {
                throw HttpFailure("Error de red: ${e.message ?: "sin detalle"}", true)
            } finally {
                c.disconnect()
            }
        }
}
