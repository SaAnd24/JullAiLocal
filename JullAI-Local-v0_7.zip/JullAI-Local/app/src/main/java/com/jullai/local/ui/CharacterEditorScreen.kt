package com.jullai.local.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.roleplay.CharactersViewModel
import com.jullai.local.roleplay.Swipes

/** Editor de la ficha de personaje. Lo escrito vive en el ViewModel: sobrevive a ir al lorebook y volver. */
@Composable
fun CharacterEditorScreen(
    vm: CharactersViewModel,
    characterId: Long,
    onBack: () -> Unit,
    onOpenLorebook: (Long) -> Unit,
) {
    LaunchedEffect(characterId) { vm.openEditor(characterId) }
    val draft by vm.draft.collectAsState()
    val lorebooks by vm.lorebooks.collectAsState()
    val message by vm.message.collectAsState()
    var pickingBook by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.pickPortrait(uri) }

    val d = draft
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = if (characterId == 0L) "Personaje nuevo" else "Editar personaje",
            onBack = { vm.discardDraft(); onBack() },
            trailing = { InkLink("Guardar", { vm.saveDraft { onBack() } }, enabled = d != null) },
        )
        if (d == null) {
            BasicText("Cargando…", style = Type.Nota, modifier = Modifier.padding(20.dp))
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
                Row(Modifier.padding(top = 8.dp)) {
                    PortraitImage(vm.portraitStore, d.portraitFile, d.name.ifBlank { "?" }, Modifier.width(110.dp).height(150.dp), maxSide = 512)
                    Column(Modifier.padding(start = 14.dp)) {
                        BasicText("Retrato", style = Type.Nota.copy(color = Ink.Oro))
                        BasicText("Se guarda reducido en este teléfono.", style = Type.Nota)
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            InkButton("Elegir imagen", { imagePicker.launch(arrayOf("image/*")) }, primary = false)
                        }
                        if (d.portraitFile != null) InkLink("Quitar retrato", { vm.removePortrait() }, danger = true)
                    }
                }
                LabeledField("Nombre", d.name, { v -> vm.edit { it.copy(name = v) } }, placeholder = "Nombre del personaje")
                LabeledField("Alias", d.aliases, { v -> vm.edit { it.copy(aliases = v) } }, hint = "Uno por línea.", minHeight = 24)
                LabeledField("Descripción física / general", d.appearance, { v -> vm.edit { it.copy(appearance = v) } }, minHeight = 60)
                LabeledField("Personalidad", d.personality, { v -> vm.edit { it.copy(personality = v) } }, minHeight = 60)
                LabeledField("Forma de hablar", d.speechStyle, { v -> vm.edit { it.copy(speechStyle = v) } }, minHeight = 44)
                LabeledField("Historia personal", d.history, { v -> vm.edit { it.copy(history = v) } }, minHeight = 60)
                LabeledField("Motivaciones", d.motivations, { v -> vm.edit { it.copy(motivations = v) } })
                LabeledField("Gustos y aversiones", d.likesDislikes, { v -> vm.edit { it.copy(likesDislikes = v) } })
                LabeledField("Instrucciones de comportamiento", d.behaviorInstructions, { v -> vm.edit { it.copy(behaviorInstructions = v) } },
                    hint = "Cómo debe actuar el modelo con este personaje.")
                LabeledField("Relación inicial con el usuario", d.initialRelationship, { v -> vm.edit { it.copy(initialRelationship = v) } })
                LabeledField("Escenario", d.scenario, { v -> vm.edit { it.copy(scenario = v) } }, minHeight = 60,
                    hint = "Puedes usar {{char}} y {{user}}.")
                LabeledField("Mensaje de bienvenida", d.firstMessage, { v -> vm.edit { it.copy(firstMessage = v) } }, minHeight = 80, maxHeight = 300)

                // Saludos alternativos
                val greetings = remember(d.alternateGreetings) { Swipes.parse(d.alternateGreetings) }
                SectionTitle("Saludos alternativos")
                greetings.forEachIndexed { i, g ->
                    LabeledField("Saludo ${i + 2}", g, { v ->
                        vm.edit { it.copy(alternateGreetings = Swipes.toJson(greetings.toMutableList().also { l -> l[i] = v })) }
                    }, minHeight = 44)
                    InkLink("Quitar este saludo", { vm.edit { it.copy(alternateGreetings = Swipes.toJson(greetings.filterIndexed { j, _ -> j != i })) } }, danger = true)
                }
                Box(Modifier.padding(top = 8.dp)) {
                    InkButton("Añadir saludo", { vm.edit { it.copy(alternateGreetings = Swipes.toJson(greetings + "")) } }, primary = false, enabled = greetings.size < 40)
                }

                LabeledField("Ejemplos de diálogo", d.dialogueExamples, { v -> vm.edit { it.copy(dialogueExamples = v) } }, minHeight = 60, maxHeight = 300,
                    hint = "Opcional. Es lo primero que se recorta si falta espacio en el contexto.")

                SectionTitle("Mundo y lorebook")
                BasicText("Mundo asociado: ninguno (la biblioteca de mundos llega en la v0.5).", style = Type.Nota)
                val book = lorebooks.firstOrNull { it.id == d.lorebookId }
                if (book == null) {
                    BasicText("Sin lorebook. Un lorebook añade datos del mundo solo cuando la escena menciona sus palabras clave.", style = Type.Nota, modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InkButton("Crear lorebook", { vm.createLorebookForDraft() }, primary = false)
                        if (lorebooks.isNotEmpty()) InkButton("Usar uno existente", { pickingBook = true }, primary = false)
                    }
                } else {
                    BasicText("Lorebook: ${book.name}", style = Type.Cuerpo.copy(color = Ink.Oro), modifier = Modifier.padding(top = 6.dp))
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        InkButton("Editar entradas", { onOpenLorebook(book.id) })
                        InkButton("Cambiar", { pickingBook = true }, primary = false)
                    }
                    InkLink("Quitar de este personaje", { vm.detachLorebook() }, danger = true)
                }

                LabeledField("Notas privadas del creador", d.privateNotes, { v -> vm.edit { it.copy(privateNotes = v) } }, minHeight = 44,
                    hint = "NUNCA se envían al modelo. Solo son para ti.")
                LabeledField("Etiquetas", d.tags, { v -> vm.edit { it.copy(tags = v) } }, hint = "Separadas por comas.", minHeight = 24)
                LabeledField("Creador", d.creator, { v -> vm.edit { it.copy(creator = v) } }, minHeight = 24)

                Row(Modifier.padding(top = 20.dp, bottom = 40.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    InkButton("Guardar personaje", { vm.saveDraft { onBack() } })
                    InkButton("Cancelar", { vm.discardDraft(); onBack() }, primary = false)
                }
            }
        }
    }

    if (pickingBook) {
        InkDialog("Elegir lorebook", { pickingBook = false }) {
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                lorebooks.forEach { b ->
                    Box(
                        Modifier.padding(top = 6.dp).fillMaxWidth().background(Ink.Pizarra, RoundedCornerShape(6.dp))
                            .clickable { vm.useLorebook(b.id); pickingBook = false }.padding(12.dp),
                    ) { BasicText(b.name, style = Type.Cuerpo) }
                }
            }
            Box(Modifier.padding(top = 12.dp)) { InkButton("Cancelar", { pickingBook = false }, primary = false) }
        }
    }
    message?.let { m ->
        InkDialog("Aviso", { vm.dismissMessage() }) {
            BasicText(m, style = Type.Cuerpo)
            Box(Modifier.padding(top = 14.dp)) { InkButton("Aceptar", { vm.dismissMessage() }) }
        }
    }
}
