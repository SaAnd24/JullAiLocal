package com.jullai.local.engine

/**
 * Catálogo integrado de modelos de TEXTO descargables. Solo contiene lo verificable por el propio enlace:
 * NO se inventan tamaños ni huellas SHA-256. El tamaño real se pregunta al servidor antes de descargar (ModelDownloader.probeSize)
 * y, si en el futuro se confirma una huella oficial, se añade en [sha256].
 */
data class CatalogModel(
    val id: String,
    val name: String,
    val description: String,
    val url: String,
    val fileName: String,
    val license: String,
    /** Orientación para elegir; es una guía, no una medición. */
    val recommendedFor: String,
    val sha256: String = "",
)

object ModelCatalog {
    val QWEN_3B = CatalogModel(
        id = "qwen2.5-3b-instruct-q4_k_m",
        name = "Qwen2.5-3B-Instruct (Q4_K_M)",
        description = "Modelo pequeño y equilibrado para rol y narración en español e inglés. Es el recomendado para empezar en un móvil de 8 GB.",
        url = "https://huggingface.co/QuantFactory/Qwen2.5-3B-Instruct-GGUF/resolve/main/Qwen2.5-3B-Instruct.Q4_K_M.gguf",
        fileName = "Qwen2.5-3B-Instruct.Q4_K_M.gguf",
        license = "Consulta la licencia del modelo en su página de Hugging Face antes de usarlo.",
        recommendedFor = "Primer modelo; móviles con 6–8 GB de RAM.",
    )
    val ALL = listOf(QWEN_3B)
    val DEFAULT = QWEN_3B
}
