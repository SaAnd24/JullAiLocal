package com.jullai.local.engine

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

enum class EngineState { IDLE, LOADING, READY, GENERATING, ERROR }

enum class FinishReason { END, MAX_TOKENS, CANCELLED, CONTEXT_FULL }

data class GenerationParams(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val maxTokens: Int = 256,
    val seed: Long = -1L,
    /** Reutiliza la caché KV si el prefijo del prompt coincide con el turno anterior (v0.2). */
    val reuseCache: Boolean = true,
)

data class EngineConfig(
    val contextLength: Int = 2048,
    val batchSize: Int = 256,
    val threads: Int = 4,
    val useMmap: Boolean = true,
)

data class ChatMessage(val role: String, val content: String)

sealed interface GenEvent {
    data class Text(val text: String) : GenEvent
    data class Finished(val reason: FinishReason, val tokens: Int, val millis: Long) : GenEvent
}

/**
 * Controla el ciclo de vida del modelo y del contexto nativos.
 * Todas las llamadas JNI se serializan en UN hilo de trabajo, nunca en el hilo principal.
 * cancel() solo activa un indicador atómico en el motor, por lo que puede llamarse desde cualquier hilo.
 */
class LlamaEngine {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "jullai-engine").apply { isDaemon = true } }
    private val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    private val _state = MutableStateFlow(EngineState.IDLE)
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    @Volatile private var modelHandle: Long = 0
    @Volatile private var ctxHandle: Long = 0
    @Volatile var loadedPath: String? = null
        private set
    @Volatile var loadedInfo: ModelInfo? = null
        private set

    private val initialized = AtomicBoolean(false)

    private fun ensureInit() {
        if (initialized.compareAndSet(false, true)) LlamaBridge.nativeInit()
    }

    suspend fun systemInfo(): String = withContext(dispatcher) { ensureInit(); LlamaBridge.nativeSystemInfo() }

    suspend fun nativeLog(): String = withContext(dispatcher) { ensureInit(); LlamaBridge.nativeGetLog() }

    /** Valida un GGUF con el propio motor (solo vocabulario + hiperparámetros). Lanza si es incompatible. */
    suspend fun inspect(path: String): ModelInfo = withContext(dispatcher) {
        ensureInit()
        ModelInfo.parse(LlamaBridge.nativeInspectModel(path))
    }

    suspend fun load(path: String, config: EngineConfig): ModelInfo = withContext(dispatcher) {
        ensureInit()
        releaseInternal()
        _state.value = EngineState.LOADING
        _lastError.value = null
        try {
            val model = LlamaBridge.nativeLoadModel(path, config.useMmap)
            modelHandle = model
            val info = ModelInfo.parse(LlamaBridge.nativeModelInfo(model))
            ctxHandle = LlamaBridge.nativeCreateContext(model, config.contextLength, config.batchSize, config.threads)
            loadedPath = path
            loadedInfo = info
            _state.value = EngineState.READY
            info
        } catch (e: Throwable) {
            releaseInternal()
            _lastError.value = e.message ?: "Error desconocido al cargar el modelo."
            _state.value = EngineState.ERROR
            throw e
        }
    }

    /** Aplica la plantilla conversacional del modelo a la lista de mensajes. */
    suspend fun applyTemplate(messages: List<ChatMessage>): String = withContext(dispatcher) {
        check(modelHandle != 0L) { "No hay ningún modelo cargado." }
        LlamaBridge.nativeApplyTemplate(
            modelHandle,
            messages.map { it.role }.toTypedArray(),
            messages.map { it.content }.toTypedArray(),
            true,
        )
    }

    suspend fun countTokens(text: String): Int = withContext(dispatcher) {
        check(modelHandle != 0L) { "No hay ningún modelo cargado." }
        LlamaBridge.nativeCountTokens(modelHandle, text)
    }

    /** Genera texto de forma progresiva. El flujo termina siempre con GenEvent.Finished (o con una excepción). */
    fun generate(prompt: String, params: GenerationParams): Flow<GenEvent> = callbackFlow {
        val job = launch(dispatcher) {
            try {
                runGeneration(prompt, params) { event -> trySend(event) }
                close()
            } catch (e: Throwable) {
                close(e)
            }
        }
        awaitClose {
            // Si el colector cancela el flujo, pedimos al motor que pare.
            this@LlamaEngine.cancel()
            job.cancel()
        }
    }.buffer(Channel.UNLIMITED)

    private fun runGeneration(prompt: String, params: GenerationParams, emit: (GenEvent) -> Unit) {
        val ctx = ctxHandle
        check(ctx != 0L && _state.value == EngineState.READY) { "El motor no está listo para generar." }
        _state.value = EngineState.GENERATING
        val start = System.nanoTime()
        var tokens = 0
        try {
            val code = LlamaBridge.nativeGenerate(
                ctx, prompt, params.maxTokens, params.temperature, params.topP, params.topK, params.seed,
                params.reuseCache,
                TokenCallback { bytes ->
                    tokens++
                    emit(GenEvent.Text(String(bytes, Charsets.UTF_8)))
                    true
                },
            )
            val reason = when (code) {
                0 -> FinishReason.END
                1 -> FinishReason.MAX_TOKENS
                3 -> FinishReason.CONTEXT_FULL
                else -> FinishReason.CANCELLED
            }
            emit(GenEvent.Finished(reason, tokens, (System.nanoTime() - start) / 1_000_000))
        } finally {
            if (_state.value == EngineState.GENERATING) _state.value = EngineState.READY
        }
    }

    /** Tokens del prompt que se reutilizaron de la caché KV en la última generación (diagnóstico). */
    suspend fun lastReusedTokens(): Int = withContext(dispatcher) {
        if (ctxHandle == 0L) 0 else LlamaBridge.nativeLastReused(ctxHandle)
    }

    /** Vacía la caché KV (el siguiente turno procesará el prompt completo). */
    suspend fun resetCache() = withContext(dispatcher) {
        if (ctxHandle != 0L) LlamaBridge.nativeResetCache(ctxHandle)
    }

    /** Pide detener la generación en curso. Seguro desde cualquier hilo. */
    fun cancel() {
        val ctx = ctxHandle
        if (ctx != 0L) LlamaBridge.nativeCancel(ctx)
    }

    /** Libera contexto y modelo nativos. Si había una generación, se cancela primero. */
    suspend fun unload() {
        cancel()
        withContext(dispatcher) {
            releaseInternal()
            _state.value = EngineState.IDLE
        }
    }

    private fun releaseInternal() {
        val c = ctxHandle
        val m = modelHandle
        ctxHandle = 0
        modelHandle = 0
        loadedPath = null
        loadedInfo = null
        if (c != 0L) LlamaBridge.nativeFreeContext(c)
        if (m != 0L) LlamaBridge.nativeFreeModel(m)
    }

    /** Para el cierre de la app: libera recursos y detiene el hilo de trabajo. */
    fun shutdown() {
        cancel()
        executor.execute {
            releaseInternal()
        }
        executor.shutdown()
    }
}
