package com.jullai.local.engine

/** Recibe los trozos de texto (bytes UTF-8 completos). Devuelve false para detener la generación. */
fun interface TokenCallback {
    fun onToken(bytes: ByteArray): Boolean
}

/**
 * Puente JNI hacia llama.cpp (ver app/src/main/cpp/jullai_engine.cpp).
 * Todas las funciones pesadas deben llamarse desde un hilo de trabajo; LlamaEngine se encarga de ello.
 * Los errores llegan como IllegalStateException con un mensaje en español.
 */
object LlamaBridge {
    init {
        System.loadLibrary("jullai_engine")
    }

    @JvmStatic external fun nativeInit()
    @JvmStatic external fun nativeSystemInfo(): String
    @JvmStatic external fun nativeGetLog(): String
    @JvmStatic external fun nativeInspectModel(path: String): String
    @JvmStatic external fun nativeLoadModel(path: String, useMmap: Boolean): Long
    @JvmStatic external fun nativeModelInfo(model: Long): String
    @JvmStatic external fun nativeFreeModel(model: Long)
    @JvmStatic external fun nativeCreateContext(model: Long, nCtx: Int, nBatch: Int, nThreads: Int): Long
    @JvmStatic external fun nativeFreeContext(ctx: Long)
    @JvmStatic external fun nativeCancel(ctx: Long)
    @JvmStatic external fun nativeLastReused(ctx: Long): Int
    @JvmStatic external fun nativeResetCache(ctx: Long)
    @JvmStatic external fun nativeCountTokens(model: Long, text: String): Int
    @JvmStatic external fun nativeApplyTemplate(
        model: Long,
        roles: Array<String>,
        contents: Array<String>,
        addAssistant: Boolean,
    ): String

    @JvmStatic external fun nativeGenerate(
        ctx: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        seed: Long,
        reuseCache: Boolean,
        callback: TokenCallback,
    ): Int
}
