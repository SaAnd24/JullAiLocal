package com.jullai.local.roleplay

import com.jullai.local.AppContainer
import com.jullai.local.data.RoleSessionEntity
import com.jullai.local.data.MessageRole
import com.jullai.local.data.MessageState
import com.jullai.local.engine.ChatMessage
import com.jullai.local.engine.FinishReason
import com.jullai.local.engine.GenEvent
import com.jullai.local.engine.GenerationParams
import com.jullai.local.engine.StoredModel
import com.jullai.local.story.ContinuityDraft
import com.jullai.local.story.MaintenanceParser
import com.jullai.local.story.MaintenancePrompts
import com.jullai.local.story.NovelLine
import com.jullai.local.story.NovelPlanner
import com.jullai.local.story.Origin
import com.jullai.local.story.StoryLimits
import com.jullai.local.story.StoryLine
import kotlinx.coroutines.CancellationException
import com.jullai.local.engine.EngineState
import com.jullai.local.story.MaintenancePolicy
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MaintenanceOutcome(
    /** Borrador de resumen (editable). Null si el modelo no devolvió un resumen. */
    val summary: String?,
    /** false = el modelo no siguió el formato y [summary] es su texto en bruto, para que lo corrijas a mano. */
    val formatOk: Boolean,
    val coversUpTo: Int,
    val addedMemories: Int,
    val addedEvents: Int,
    val addedRelations: Int,
    val linesPending: Int,
    val note: String,
)

/**
 * Trabajos de memoria que usan el modelo local: mantenimiento (resumen + propuestas), novela de capítulos, resúmenes y
 * continuidad de volúmenes. Usan el MISMO motor de un solo hilo que la generación normal: quien los llama debe haber
 * comprobado que el motor no está ocupado. Nada de lo que devuelven se guarda como verdad sin que el usuario lo acepte.
 */
class JobStatus(val kind: String = "", val running: Boolean = false, val progress: String = "", val message: String = "", val error: String? = null, val sessionId: Long = 0)

/** Borrador de resumen pendiente de que lo revises. No se guarda hasta que lo aceptas. */
class SummaryDraft(val sessionId: Long, val text: String, val formatOk: Boolean, val coversUpTo: Int, val note: String)

class ContinuityState(val sessionId: Long, val text: String)

class StoryJobs(private val c: AppContainer) {
    private val role = c.roleplayRepository
    private val story = c.storyRepository

    private val _status = MutableStateFlow(JobStatus())
    val status: StateFlow<JobStatus> = _status.asRef()
    private val _summaryDraft = MutableStateFlow<SummaryDraft?>(null)
    val summaryDraft: StateFlow<SummaryDraft?> = _summaryDraft.asStateFlow()
    private val _continuity = MutableStateFlow<ContinuityState?>(null)
    val continuity: StateFlow<ContinuityState?> = _continuity.asStateFlow()

    private fun <T> MutableStateFlow<T>.asRef(): StateFlow<T> = this.asStateFlow()

    fun clearSummaryDraft() { _summaryDraft.value = null }
    fun clearContinuity() { _continuity.value = null }
    fun dismissMessage() { _status.value = JobStatus() }

    fun engineFree(): Boolean {
        val st = c.engine.state.value
        return c.storyJob?.isActive != true && st != EngineState.GENERATING && st != EngineState.LOADING && c.controller.busy.value == null
    }

    /** Detiene el trabajo en curso. No se guarda nada a medias. */
    fun cancel() { c.storyJob?.let { it.cancel(); c.engine.cancel() } }

    private fun launch(kind: String, sessionId: Long, block: suspend () -> String): Boolean {
        if (!engineFree()) {
            _status.value = JobStatus(kind, false, error = "El motor está ocupado. Espera a que termine la respuesta o deténla.", sessionId = sessionId)
            return false
        }
        _status.value = JobStatus(kind, true, "Preparando…", sessionId = sessionId)
        c.storyJob = c.scope.launch {
            try {
                val msg = block()
                _status.value = JobStatus(kind, false, message = msg, sessionId = sessionId)
            } catch (e: CancellationException) {
                withContext(NonCancellable) { _status.value = JobStatus(kind, false, message = "Detenido. No se guardó nada de este trabajo.", sessionId = sessionId) }
            } catch (e: Exception) {
                _status.value = JobStatus(kind, false, error = e.message ?: "Error desconocido.", sessionId = sessionId)
            }
        }
        return true
    }

    /** Mantenimiento pedido por el usuario o disparado por la política automática. */
    fun startMaintenance(sessionId: Long): Boolean = launch("mantenimiento", sessionId) {
        _status.value = JobStatus("mantenimiento", true, "Leyendo la historia con el modelo…", sessionId = sessionId)
        val r = maintenance(sessionId)
        if (r.summary != null) _summaryDraft.value = SummaryDraft(sessionId, r.summary, r.formatOk, r.coversUpTo, r.note)
        if (r.addedMemories + r.addedEvents + r.addedRelations > 0 || r.summary != null || r.formatOk) story.setCovered(sessionId, r.coversUpTo)
        buildString {
            append("Listo: ${r.addedMemories} recuerdos, ${r.addedEvents} sucesos y ${r.addedRelations} cambios de relación propuestos")
            if (r.summary != null) append("; hay un borrador de resumen para revisar")
            append('.')
            if (r.linesPending > 0) append(" Quedan ${r.linesPending} mensajes por analizar: vuelve a pulsar el botón.")
            if (r.note.isNotBlank()) append(' ').append(r.note)
        }
    }

    /** Tras una respuesta completa: ¿toca mantenimiento automático? Nunca interrumpe nada y nunca guarda sin que lo aceptes. */
    fun autoCheck(sessionId: Long, chapterJustClosed: Boolean = false) {
        c.scope.launch {
            kotlinx.coroutines.delay(800)   // deja que el motor termine de soltar la generación
            val st = c.settingsRepository.settings.value
            if (!st.memEnabled || st.memAutoMode == "MANUAL") return@launch
            val since = runCatching { story.userTurnsSince(sessionId) }.getOrDefault(0)
            if (MaintenancePolicy.isDue(st.memAutoMode, st.memEveryTurns, since, chapterJustClosed) && engineFree()) startMaintenance(sessionId)
        }
    }

    fun startNovel(sessionId: Long, chapterId: Long): Boolean = launch("novela", sessionId) {
        val text = novelize(sessionId, chapterId) { i, n -> _status.value = JobStatus("novela", true, "Novelizando parte $i de $n…", sessionId = sessionId) }
        story.saveNovelGenerated(chapterId, text)
        "Texto novelado generado. Puedes editarlo; el registro original no se tocó."
    }

    fun startChapterSummary(sessionId: Long, chapterId: Long): Boolean = launch("resumen de capítulo", sessionId) {
        val text = summarizeChapter(sessionId, chapterId) { i, n -> _status.value = JobStatus("resumen de capítulo", true, "Resumiendo parte $i de $n…", sessionId = sessionId) }
        story.saveChapterSummary(chapterId, text)
        "Resumen del capítulo guardado (puedes editarlo)."
    }

    fun startContinuity(sessionId: Long, useModel: Boolean): Boolean = launch("continuidad", sessionId) {
        _continuity.value = ContinuityState(sessionId, continuityDraft(sessionId, useModel))
        "Borrador de continuidad listo: revísalo y confirma el cierre del volumen."
    }

    fun continuityManual(sessionId: Long) {
        c.scope.launch {
            try { _continuity.value = ContinuityState(sessionId, continuityDraft(sessionId, false)) }
            catch (e: Exception) { _status.value = JobStatus("continuidad", false, error = e.message, sessionId = sessionId) }
        }
    }

    private suspend fun resolveModel(s: RoleSessionEntity): StoredModel? {
        val all = c.registry.list()
        return s.modelFileName?.let { f -> all.firstOrNull { it.fileName == f } } ?: all.firstOrNull { it.isDefault } ?: all.firstOrNull()
    }

    private suspend fun prepare(s: RoleSessionEntity) {
        val model = resolveModel(s) ?: throw IllegalStateException("No hay ningún modelo importado. Ve a Modelos e importa un archivo .gguf.")
        c.controller.ensureLoaded(model, s.contextLength, c.settingsRepository.settings.value.threads)
    }

    /** Una inferencia completa. Si se detiene, lanza CancellationException y NO devuelve texto parcial. */
    private suspend fun complete(s: RoleSessionEntity, messages: List<ChatMessage>, maxTokens: Int, temperature: Float): String {
        val prompt = c.engine.applyTemplate(messages)
        val tokens = c.engine.countTokens(prompt)
        if (tokens > s.contextLength - maxTokens - 16)
            throw IllegalStateException("El texto a procesar ($tokens tokens) no cabe en el contexto de ${s.contextLength}. Sube el contexto de la partida en «Motor».")
        val sb = StringBuilder()
        var cancelled = false
        c.engine.generate(prompt, GenerationParams(temperature = temperature, topP = 0.9f, maxTokens = maxTokens, reuseCache = false)).collect { ev ->
            when (ev) {
                is GenEvent.Text -> sb.append(ev.text)
                is GenEvent.Finished -> if (ev.reason == FinishReason.CANCELLED) cancelled = true
            }
        }
        if (cancelled) throw CancellationException("Detenido por el usuario")
        return sb.toString().trim()
    }

    // ---------------- mantenimiento: resumen + propuestas ----------------

    suspend fun maintenance(sessionId: Long): MaintenanceOutcome {
        val s = role.getSession(sessionId) ?: throw IllegalStateException("La partida ya no existe.")
        val ch = role.character(s.characterId) ?: throw IllegalStateException("El personaje de esta partida ya no existe.")
        story.ensureDefaultRelationship(sessionId, ch.name, s.userName)
        val covered = story.coveredOrder(sessionId)
        val rows = story.linesAfter(sessionId, covered).filter { !(it.role == MessageRole.ASSISTANT && it.state == MessageState.GENERATING) }
        if (rows.isEmpty()) return MaintenanceOutcome(null, true, covered, 0, 0, 0, 0, "No hay mensajes nuevos que analizar.")
        prepare(s)
        val lines = rows.map { StoryLine(it.orderIndex, if (it.role == MessageRole.USER) s.userName else ch.name, Macros.apply(it.content, ch.name, s.userName)) }
        val prompt = MaintenancePrompts.build(
            participants = "${ch.name} (personaje), ${s.userName} (usuario)", previousSummary = s.summary,
            knownMemories = story.knownMemoryTexts(sessionId, 12), lines = lines, contextLength = s.contextLength,
            count = { c.engine.countTokens(it) }, applyTemplate = { c.engine.applyTemplate(it) },
        ) ?: throw IllegalStateException("El contexto de la partida es demasiado pequeño para analizar la historia. Súbelo en «Motor».")
        val raw = complete(s, prompt.messages, MaintenancePrompts.OUTPUT_TOKENS.coerceAtMost(s.contextLength / 3), 0.3f)
        val parsed = MaintenanceParser.parse(raw)
        val srcMsg = rows.firstOrNull { it.orderIndex == prompt.coversUpTo }?.id
        val note = "Análisis automático de los mensajes ${rows.first().orderIndex + 1} a ${prompt.coversUpTo + 1}"
        val m = story.proposeMemories(sessionId, parsed.memories, srcMsg, note)
        val e = story.proposeEvents(sessionId, parsed.events, srcMsg)
        val r = story.proposeRelationChanges(sessionId, parsed.relations, srcMsg)
        val summary = parsed.summary ?: if (parsed.isEmpty() && raw.isNotBlank()) TextNormClean.raw(raw) else null
        val formatOk = parsed.summary != null || !parsed.isEmpty()
        return MaintenanceOutcome(summary, formatOk, prompt.coversUpTo, m, e, r, prompt.linesPending,
            if (raw.isBlank()) "El modelo no devolvió nada." else if (!formatOk) "El modelo no siguió el formato: revisa su texto y corrígelo a mano." else "")
    }

    // ---------------- capítulos ----------------

    private suspend fun chapterLines(chapterId: Long, s: RoleSessionEntity, charName: String): Pair<com.jullai.local.data.ChapterEntity, List<NovelLine>> {
        val chapter = story.chapter(chapterId) ?: throw IllegalStateException("Ese capítulo ya no existe.")
        val lines = story.chapterMessages(chapter).filter { it.state != MessageState.GENERATING }
            .map { NovelLine(if (it.role == MessageRole.USER) s.userName else charName, Macros.apply(it.content, charName, s.userName), it.role == MessageRole.USER) }
        if (lines.isEmpty()) throw IllegalStateException("El capítulo no tiene mensajes.")
        return chapter to lines
    }

    /** Novela del capítulo por partes. [onProgress] recibe (parte, total). No toca el registro original ni los datos de la historia. */
    suspend fun novelize(sessionId: Long, chapterId: Long, onProgress: (Int, Int) -> Unit): String {
        val s = role.getSession(sessionId) ?: throw IllegalStateException("La partida ya no existe.")
        val ch = role.character(s.characterId) ?: throw IllegalStateException("El personaje ya no existe.")
        val (chapter, lines) = chapterLines(chapterId, s, ch.name)
        prepare(s)
        val sysCost = c.engine.countTokens(NovelPlanner.SYSTEM) + 120
        val out = NovelPlanner.OUTPUT_TOKENS.coerceAtMost(s.contextLength / 3)
        val budget = (s.contextLength - out - sysCost - 700 - 32).coerceAtLeast(200)
        val chunks = NovelPlanner.chunks(lines, budget) { c.engine.countTokens(it) }
        val parts = ArrayList<String>()
        chunks.forEachIndexed { i, chunk ->
            onProgress(i + 1, chunks.size)
            val msgs = NovelPlanner.prompt(chapter.title.ifBlank { "Capítulo ${chapter.number}" }, NovelPlanner.tail(parts.lastOrNull().orEmpty()), chunk, i + 1, chunks.size)
            parts.add(complete(s, msgs, out, 0.7f))
        }
        return NovelPlanner.join(parts)
    }

    suspend fun summarizeChapter(sessionId: Long, chapterId: Long, onProgress: (Int, Int) -> Unit): String {
        val s = role.getSession(sessionId) ?: throw IllegalStateException("La partida ya no existe.")
        val ch = role.character(s.characterId) ?: throw IllegalStateException("El personaje ya no existe.")
        val (chapter, lines) = chapterLines(chapterId, s, ch.name)
        prepare(s)
        val sys = "Eres un archivista. Resumes capítulos de una historia de rol en 3 a 6 frases, en tercera persona y pasado, usando solo lo que aparece en el texto. Devuelve únicamente el resumen."
        val out = 400.coerceAtMost(s.contextLength / 3)
        val budget = (s.contextLength - out - c.engine.countTokens(sys) - 500 - 32).coerceAtLeast(200)
        val chunks = NovelPlanner.chunks(lines, budget) { c.engine.countTokens(it) }
        var running = ""
        chunks.forEachIndexed { i, chunk ->
            onProgress(i + 1, chunks.size)
            val body = buildString {
                append("CAPÍTULO: ").append(chapter.title.ifBlank { "Capítulo ${chapter.number}" }).append('\n')
                if (running.isNotBlank()) append("\nRESUMEN HASTA AHORA:\n").append(running).append('\n')
                append("\nFRAGMENTO:\n"); chunk.forEach { append(it.speaker).append(": ").append(it.text.trim()).append('\n') }
                append("\nEscribe el resumen actualizado del capítulo.")
            }
            running = complete(s, listOf(ChatMessage("system", sys), ChatMessage("user", body)), out, 0.3f)
        }
        return running
    }

    // ---------------- cierre de volumen ----------------

    /** Borrador del resumen de continuidad. Con modelo: lo escribe el modelo (las relaciones las pone la app). Sin modelo: borrador manual. */
    suspend fun continuityDraft(sessionId: Long, useModel: Boolean): String {
        val s = role.getSession(sessionId) ?: throw IllegalStateException("La partida ya no existe.")
        val vol = story.openVolume(sessionId) ?: throw IllegalStateException("No hay ningún volumen abierto.")
        val chapterSummaries = story.chaptersOfVolume(vol.id).filter { it.summary.isNotBlank() }.map { "Capítulo ${it.number}: ${it.summary}" }
        val events = story.recentEventTexts(sessionId, 6)
        val relations = story.relationItems(sessionId)
        val sections = if (useModel && resolveModel(s) != null) {
            prepare(s)
            val key = story.knownMemoryTexts(sessionId, 10)
            val raw = complete(s, ContinuityDraft.prompt("Volumen ${vol.number}", s.summary, chapterSummaries, key, events), 600.coerceAtMost(s.contextLength / 3), 0.3f)
            ContinuityDraft.parseSections(raw)
        } else ContinuityDraft.fallbackSections(s.summary, chapterSummaries, events)
        return ContinuityDraft.compose(sections, relations)
    }
}

internal object TextNormClean {
    fun raw(s: String) = com.jullai.local.story.TextNorm.clean(s, StoryLimits.SUMMARY_CHARS)
}
