package com.jullai.local.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jullai.local.SettingsViewModel
import com.jullai.local.story.AutoMode

/** Ajustes avanzados. Solo afectan a conversaciones NUEVAS (salvo hilos y caché KV, que son globales). */
@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    var profileName by remember(s.playerProfileName) { mutableStateOf(s.playerProfileName) }
    var profilePersona by remember(s.playerProfilePersona) { mutableStateOf(s.playerProfilePersona) }
    var systemDraft by remember(s.defaultSystemPrompt) { mutableStateOf(s.defaultSystemPrompt) }
    var rpSystemDraft by remember(s.rpSystemPrompt) { mutableStateOf(s.rpSystemPrompt) }
    var rpRulesDraft by remember(s.rpNarrativeRules) { mutableStateOf(s.rpNarrativeRules) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Ajustes avanzados", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp)) {
            SectionTitle("Rendimiento (global)")
            Stepper(
                "Hilos de CPU", "${s.threads}",
                { vm.update { it.copy(threads = (it.threads - 1).coerceAtLeast(1)) } },
                { vm.update { it.copy(threads = (it.threads + 1).coerceAtMost(8)) } },
            )
            BasicText("Cambiar los hilos recarga el modelo en el siguiente mensaje. En un Helio G100, 4 suele ser un buen punto de partida.", style = Type.Nota)
            InkToggleRow("Reutilizar la caché de contexto entre turnos", s.reuseKvCache, { v -> vm.update { it.copy(reuseKvCache = v) } })
            BasicText(
                "Acelera mucho las respuestas porque no reprocesa todo el historial en cada turno. " +
                    "Si notaras respuestas raras o fallos, desactívala: el resultado es el mismo pero más lento.",
                style = Type.Nota,
            )

            SectionTitle("Valores para conversaciones nuevas")
            Stepper(
                "Contexto (tokens)", "${s.defaultContext}",
                { vm.update { it.copy(defaultContext = (it.defaultContext - 512).coerceAtLeast(512)) } },
                { vm.update { it.copy(defaultContext = (it.defaultContext + 512).coerceAtMost(8192)) } },
            )
            Stepper(
                "Temperatura", "%.1f".format(s.defaultTemperature),
                { vm.update { it.copy(defaultTemperature = (Math.round(it.defaultTemperature * 10) - 1).coerceAtLeast(0) / 10f) } },
                { vm.update { it.copy(defaultTemperature = (Math.round(it.defaultTemperature * 10) + 1).coerceAtMost(20) / 10f) } },
            )
            Stepper(
                "Top-p", "%.2f".format(s.defaultTopP),
                { vm.update { it.copy(defaultTopP = (Math.round(it.defaultTopP * 20) - 1).coerceAtLeast(2) / 20f) } },
                { vm.update { it.copy(defaultTopP = (Math.round(it.defaultTopP * 20) + 1).coerceAtMost(20) / 20f) } },
            )
            Stepper(
                "Máx. tokens de respuesta", "${s.defaultMaxTokens}",
                { vm.update { it.copy(defaultMaxTokens = (it.defaultMaxTokens - 64).coerceAtLeast(16)) } },
                { vm.update { it.copy(defaultMaxTokens = (it.defaultMaxTokens + 64).coerceAtMost(2048)) } },
            )
            BasicText("Instrucciones del sistema por defecto", style = Type.Cuerpo, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            InkField(systemDraft, { systemDraft = it }, "Instrucciones del sistema", Modifier.fillMaxWidth(), minHeight = 88)
            Box(Modifier.padding(top = 10.dp)) {
                InkButton(
                    "Guardar instrucciones",
                    { vm.update { it.copy(defaultSystemPrompt = systemDraft) } },
                    enabled = systemDraft != s.defaultSystemPrompt,
                )
            }

            SectionTitle("Valores para partidas de roleplay nuevas")
            Stepper(
                "Contexto (tokens)", "${s.rpContext}",
                { vm.update { it.copy(rpContext = (it.rpContext - 512).coerceAtLeast(512)) } },
                { vm.update { it.copy(rpContext = (it.rpContext + 512).coerceAtMost(8192)) } },
            )
            Stepper(
                "Temperatura", "%.1f".format(s.rpTemperature),
                { vm.update { it.copy(rpTemperature = (Math.round(it.rpTemperature * 10) - 1).coerceAtLeast(0) / 10f) } },
                { vm.update { it.copy(rpTemperature = (Math.round(it.rpTemperature * 10) + 1).coerceAtMost(20) / 10f) } },
            )
            Stepper(
                "Máx. tokens de respuesta", "${s.rpMaxTokens}",
                { vm.update { it.copy(rpMaxTokens = (it.rpMaxTokens - 64).coerceAtLeast(16)) } },
                { vm.update { it.copy(rpMaxTokens = (it.rpMaxTokens + 64).coerceAtMost(2048)) } },
            )
            InkToggleRow("Cortar si el modelo empieza a escribir por ti", s.rpStopOnUserTurn, { v -> vm.update { it.copy(rpStopOnUserTurn = v) } })
            BasicText(
                "Si la respuesta contiene un salto de línea seguido de «TuNombre:», se corta ahí. Los valores solo afectan a partidas NUEVAS.",
                style = Type.Nota,
            )
            BasicText("Instrucciones del sistema para roleplay", style = Type.Cuerpo, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            InkField(rpSystemDraft, { rpSystemDraft = it }, "Instrucciones del sistema", Modifier.fillMaxWidth(), minHeight = 88)
            BasicText("Reglas narrativas por defecto (cada partida tiene su copia editable)", style = Type.Cuerpo, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            InkField(rpRulesDraft, { rpRulesDraft = it }, "Reglas narrativas", Modifier.fillMaxWidth(), minHeight = 88)
            Box(Modifier.padding(top = 10.dp)) {
                InkButton(
                    "Guardar textos de roleplay",
                    { vm.update { it.copy(rpSystemPrompt = rpSystemDraft, rpNarrativeRules = rpRulesDraft) } },
                    enabled = rpSystemDraft != s.rpSystemPrompt || rpRulesDraft != s.rpNarrativeRules,
                )
            }

            SectionTitle("Memoria narrativa")
            InkToggleRow("Usar la memoria al generar respuestas", s.memEnabled, { v -> vm.update { it.copy(memEnabled = v) } })
            BasicText(
                "Recuerdos, relaciones y cronología se añaden al contexto según lo que se habla. Si la apagas, solo se usan los textos de la 0.3 (el contenido guardado se conserva).",
                style = Type.Nota,
            )
            BasicText("Análisis de la historia con el modelo", style = Type.Cuerpo, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            AutoMode.ALL.forEach { m ->
                Box(Modifier.padding(bottom = 6.dp)) { InkChip(AutoMode.label(m), s.memAutoMode == m, { vm.update { it.copy(memAutoMode = m) } }) }
            }
            if (s.memAutoMode == AutoMode.CADA_N) {
                Stepper(
                    "Cada cuántos turnos tuyos", "${s.memEveryTurns}",
                    { vm.update { it.copy(memEveryTurns = (it.memEveryTurns - 3).coerceAtLeast(3)) } },
                    { vm.update { it.copy(memEveryTurns = (it.memEveryTurns + 3).coerceAtMost(60)) } },
                )
            }
            BasicText(
                "Por defecto es manual: analizar la historia es una inferencia pesada y consume batería. El modelo solo propone; tú decides. Si empiezas a escribir mientras analiza, se detiene.",
                style = Type.Nota,
            )

            SectionTitle("Perfil global del jugador")
            BasicText("Tu nombre y tu personaje reutilizables. Al empezar una partida puedes copiarlos, adaptarlos o ignorarlos; cada partida guarda su propia copia.", style = Type.Nota)
            InkField(profileName, { profileName = it }, "Nombre", Modifier.fillMaxWidth().padding(top = 8.dp), minHeight = 24)
            InkField(profilePersona, { profilePersona = it }, "Descripción de tu personaje", Modifier.fillMaxWidth().padding(top = 8.dp), minHeight = 60, maxHeight = 200)
            Box(Modifier.padding(top = 10.dp)) {
                InkButton(
                    "Guardar perfil",
                    { vm.update { it.copy(playerProfileName = profileName.trim(), playerProfilePersona = profilePersona) } },
                    enabled = profileName != s.playerProfileName || profilePersona != s.playerProfilePersona,
                )
            }

            SectionTitle("Acerca de")
            BasicText(
                "JullAI Local 0.5.0 · todo se ejecuta en este teléfono. Sin cuentas, sin anuncios y sin analítica. " +
                    "Único permiso: INTERNET, usado SOLO por la investigación online opcional de mundos (APIs de MediaWiki y las URLs que tú indiques). " +
                    "Chat, roleplay, memoria, mundos, archivos locales, .worldpack y novela visual funcionan sin conexión.",
                style = Type.Nota,
            )
            Box(Modifier.height(32.dp))
        }
    }
}
