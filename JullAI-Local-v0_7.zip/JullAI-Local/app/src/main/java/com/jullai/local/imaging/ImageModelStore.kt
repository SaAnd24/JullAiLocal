package com.jullai.local.imaging

import android.content.Context
import android.net.Uri
import android.os.StatFs
import com.jullai.local.data.ImageModelEntity
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

/** Resultado de importar un archivo de modelo de imagen. */
sealed interface ImportOutcome {
    class Imported(val entity: ImageModelEntity, val probe: ProbeResult) : ImportOutcome
    /** El archivo se rechazó ANTES de guardarse (formato, arquitectura, daño). No queda nada copiado. */
    class Rejected(val probe: ProbeResult?, val reason: String) : ImportOutcome
}

/**
 * Almacén privado de checkpoints y LoRA de imagen. Los pesos NO van en el APK ni se redistribuyen: el usuario los importa con el selector
 * del sistema (SAF) y se copian a `filesDir/image_models`. La licencia del modelo es asunto del usuario y es DISTINTA de la del motor.
 */
class ImageModelStore(private val context: Context) {
    val directory: File get() = File(context.filesDir, "image_models").also { it.mkdirs() }

    fun file(m: ImageModelEntity): File = file(m.fileName)

    fun file(fileName: String): File {
        require(fileName.isNotEmpty() && !fileName.contains('/') && !fileName.contains('\\') && !fileName.contains("..")) { "Nombre de modelo no válido." }
        return File(directory, fileName)
    }

    fun freeBytes(): Long = StatFs(directory.absolutePath).availableBytes

    /**
     * Copia a un archivo temporal, calcula SHA-256, lee el CONTENIDO ([ModelProbe]) y solo si es utilizable lo renombra definitivamente.
     * Comprueba antes el espacio libre. Nunca deja medio archivo si algo falla.
     */
    fun import(uri: Uri, displayName: String, declaredSize: Long, kindHint: String?, onProgress: (Long) -> Unit = {}): ImportOutcome {
        if (declaredSize > 0 && freeBytes() < declaredSize + 256L * 1024 * 1024) {
            return ImportOutcome.Rejected(null, "No hay espacio suficiente: el archivo ocupa ${declaredSize / (1024 * 1024)} MB y quedan ${freeBytes() / (1024 * 1024)} MB libres.")
        }
        val tmp = File(directory, "import_" + UUID.randomUUID().toString().take(8) + ".tmp")
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            val input = context.contentResolver.openInputStream(uri) ?: return ImportOutcome.Rejected(null, "No se pudo abrir el archivo.")
            input.use { src ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val n = src.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n); digest.update(buf, 0, n); total += n
                        onProgress(total)
                    }
                }
            }
            val probe = ModelProbe.probe(tmp)
            if (!probe.supported) { tmp.delete(); return ImportOutcome.Rejected(probe, probe.reasons.joinToString(" ")) }
            val kind = if (probe.kind == ImageModelKind.LORA) ImageModelKinds.LORA else ImageModelKinds.CHECKPOINT
            if (kindHint != null && kindHint != kind) {
                tmp.delete()
                return ImportOutcome.Rejected(probe, if (kind == ImageModelKinds.LORA) "El archivo es una LoRA, no un checkpoint." else "El archivo es un checkpoint, no una LoRA.")
            }
            val sha = digest.digest().joinToString("") { "%02x".format(it) }
            val ext = if (probe.format == ModelFormat.GGUF) "gguf" else "safetensors"
            val finalName = "m_${sha.take(16)}.$ext"
            val dest = file(finalName)
            if (dest.exists()) { tmp.delete(); return ImportOutcome.Rejected(probe, "Este archivo ya está importado.") }
            if (!tmp.renameTo(dest)) { tmp.delete(); throw IOException("No se pudo guardar el archivo.") }
            val entity = ImageModelEntity(
                kind = kind, fileName = finalName, displayName = displayName.take(120).ifBlank { finalName }, format = probe.format.name,
                sizeBytes = total, architecture = probe.architecture, compat = ModelCompat.UNVERIFIED,
                note = probe.warnings.joinToString(" ").take(400), importedAt = System.currentTimeMillis(),
            )
            return ImportOutcome.Imported(entity, probe)
        } catch (e: IOException) {
            tmp.delete()
            return ImportOutcome.Rejected(null, "Error al copiar el archivo: ${e.message}")
        } catch (e: RuntimeException) {
            tmp.delete()
            return ImportOutcome.Rejected(null, "No se pudo importar: ${e.message}")
        }
    }

    fun delete(fileName: String?) { if (fileName != null) runCatching { file(fileName).delete() } }
}
