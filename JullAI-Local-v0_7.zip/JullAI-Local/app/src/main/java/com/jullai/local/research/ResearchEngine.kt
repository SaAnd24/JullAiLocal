package com.jullai.local.research

import com.jullai.local.data.CanonImageEntity
import com.jullai.local.data.ResearchStore
import com.jullai.local.data.ResearchTaskEntity
import com.jullai.local.data.SourceEntity
import com.jullai.local.data.WorldEntity
import com.jullai.local.data.WorldIdentityEntity
import com.jullai.local.discovery.CanonImageFinder
import com.jullai.local.discovery.CanonImagePolicy
import com.jullai.local.discovery.CharacterSheet
import com.jullai.local.discovery.DiscoveryPlan
import com.jullai.local.discovery.PageRef
import com.jullai.local.discovery.PageRole
import com.jullai.local.discovery.PlanCodec
import com.jullai.local.discovery.Resolution
import com.jullai.local.discovery.SavedPlan
import com.jullai.local.discovery.SourcePlanner
import com.jullai.local.discovery.UniverseResolver
import com.jullai.local.discovery.WikiClient
import com.jullai.local.discovery.WikiFetchException
import com.jullai.local.discovery.WikiHosts
import com.jullai.local.discovery.WorkCandidate
import com.jullai.local.discovery.WorkIdentity
import com.jullai.local.story.TextNorm
import com.jullai.local.world.DraftEntry
import com.jullai.local.world.EntryState
import com.jullai.local.world.ResearchDepth
import com.jullai.local.world.ResearchPhase
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceStatus
import com.jullai.local.world.TaskStatus
import com.jullai.local.world.WikiExtractor
import kotlinx.coroutines.CancellationException
import java.security.MessageDigest

/** Resultado de ejecutar una tarea. [retry] pide al planificador volver a intentarlo más tarde (reintentos limitados). */
class EngineOutcome(val status: String, val retry: Boolean, val message: String)

/** Piezas del descubrimiento automático. Si es null, el motor se comporta como en la 0.5 (solo fuentes que el usuario añadió). */
class AutoDiscovery(
    val client: WikiClient,
    /** Guarda los bytes de una imagen ya validada en el almacén de retratos y devuelve el nombre del archivo. Lanza IllegalArgumentException si no se puede leer. */
    val saveImage: suspend (ByteArray) -> String,
    val imagesEnabled: () -> Boolean = { true },
)

/**
 * Investigación de un mundo en fases REANUDABLES e idempotentes. Cada paso se guarda: si Android mata el proceso, la tarea sigue donde estaba y
 * no repite lo ya hecho (fuentes por dirección única, entradas con deduplicación, imágenes por personaje).
 *
 *  1. IDENTIFICANDO  — busca la obra (Wikipedia) y su continuidad; Wikidata completa los datos. Solo cuenta lo que se comprobó.
 *  2. PLANIFICANDO   — descubre wiki de Fandom, listados, personajes y lugares; guarda el plan.
 *  3. DESCARGANDO    — lee cada página y crea fichas con procedencia (texto recortado, nunca copias masivas).
 *  4. IMAGENES       — guarda en caché privada la imagen de cada personaje canónico, con su origen y licencia.
 *  5. CONTRADICCIONES — las marca; nunca las resuelve sola.
 * Solo es un éxito si hay fuentes procesadas Y entradas válidas.
 */
class ResearchEngine(
    private val repo: ResearchStore,
    private val providers: List<SourceProvider>,
    private val wiki: MediaWikiProvider?,
    private val auto: AutoDiscovery? = null,
) {
    suspend fun run(taskId: Long): EngineOutcome {
        var task = repo.task(taskId) ?: return EngineOutcome(TaskStatus.FALLIDA, false, "La tarea ya no existe.")
        if (TaskStatus.isFinal(task.status)) return EngineOutcome(task.status, false, TaskStatus.label(task.status))
        val world = repo.world(task.worldId)
        if (world == null) { save(task.copy(status = TaskStatus.FALLIDA, phase = ResearchPhase.FIN, lastError = "El mundo ya no existe.", finishedAt = System.currentTimeMillis())); return EngineOutcome(TaskStatus.FALLIDA, false, "El mundo ya no existe.") }
        if (!world.allowOnline) {
            save(task.copy(status = TaskStatus.FALLIDA, phase = ResearchPhase.FIN, lastError = "La investigación online está desactivada para este mundo.", finishedAt = System.currentTimeMillis()))
            return EngineOutcome(TaskStatus.FALLIDA, false, "La investigación online está desactivada para este mundo.")
        }
        task = save(task.copy(status = TaskStatus.EN_CURSO, attempts = task.attempts + 1, note = ""))
        var retryable = false
        val notes = ArrayList<String>()
        try {
            // ---- fases 1 y 2: identificar la obra y descubrir fuentes (solo con descubrimiento automático) ----
            if (auto != null && (task.phase == ResearchPhase.PENDIENTE || task.phase == ResearchPhase.BUSCANDO || task.phase == ResearchPhase.IDENTIFICANDO || task.phase == ResearchPhase.PLANIFICANDO)) {
                val langs = listOf(world.language.lowercase().take(2).ifBlank { "es" }, "en").distinct()
                var identity = repo.identity(world.id)
                if (identity == null) {
                    task = save(task.copy(phase = ResearchPhase.IDENTIFICANDO, note = "Buscando «${world.name}»…"))
                    when (val r = UniverseResolver(auto.client).search(world.name, langs)) {
                        is Resolution.Auto -> identity = identify(auto, world, r.pick, notes)
                        is Resolution.Ask -> identity = identify(auto, world, r.options.first(), notes.also { it.add("Había varias continuidades posibles (${r.options.joinToString { c -> c.title }}); se eligió la primera. Puedes elegir otra al crear el mundo.") })
                        Resolution.NotFound -> notes.add("No se encontró «${world.name}» como obra en Wikipedia. Se usarán solo las fuentes que añadas a mano.")
                        is Resolution.Failed -> { retryable = retryable || r.retryable; notes.add(r.message) }
                    }
                }
                if (cancelled(taskId)) return EngineOutcome(TaskStatus.CANCELADA, false, "Cancelada por el usuario.")
                if (identity != null && PlanCodec.decode(identity.planJson) == null) {
                    task = save(task.copy(phase = ResearchPhase.PLANIFICANDO, note = "Descubriendo fuentes y personajes de «${identity.title}»…"))
                    val plan = SourcePlanner(auto.client).plan(toIdentity(identity), world.researchDepth, langs)
                    retryable = retryable || plan.hadRetryableFailure
                    notes.addAll(plan.notes)
                    // Un plan vacío por un fallo temporal NO se guarda: así se vuelve a planificar en el reintento.
                    if (plan.characters.isNotEmpty() || plan.lorePages.isNotEmpty() && !plan.hadRetryableFailure) {
                        repo.savePlan(world.id, PlanCodec.encode(plan), plan.notes.joinToString("\n"))
                        register(world, plan)
                    }
                }
            }
            // Fuentes wiki añadidas por el usuario (comportamiento de la 0.5): se descubren páginas relacionadas en ELLAS.
            if (task.phase == ResearchPhase.PENDIENTE || task.phase == ResearchPhase.BUSCANDO || task.phase == ResearchPhase.IDENTIFICANDO || task.phase == ResearchPhase.PLANIFICANDO) {
                task = save(task.copy(phase = ResearchPhase.BUSCANDO))
                val apis = wikiApis(world.preferredSources)
                val max = ResearchDepth.maxPages(world.researchDepth)
                if (wiki != null && apis.isNotEmpty()) {
                    val terms = (listOf(world.name) + split(world.priorityCharacters) + split(world.priorityPlaces)).distinct()
                    val known = repo.sourcesOf(world.id).map { it.uri }.toSet()
                    var added = 0
                    for (api in apis) {
                        if (added >= max) break
                        val titles = try { wiki.discover(api, terms, max - added) } catch (e: HttpFailure) { retryable = retryable || e.retryable; emptyList() }
                        for (t in titles) { val uri = MediaWikiProvider.uriOf(api, t); if (uri !in known && added < max) { repo.addSource(world.id, SourceKind.MEDIAWIKI, uri, t, SourceStatus.PENDIENTE, ""); added++ } }
                    }
                }
                task = save(task.copy(phase = ResearchPhase.DESCARGANDO))
            }

            // ---- fase 3: descargar y extraer, fuente por fuente ----
            val saved = repo.identity(world.id)?.let { PlanCodec.decode(it.planJson) }
            val freshWorld = repo.world(world.id) ?: world
            val allSources = repo.sourcesOf(world.id)
            val todo = allSources.filter { it.status == SourceStatus.PENDIENTE || (it.status == SourceStatus.FALLIDA && retryableStatus(it) && it.attempts < task.maxAttempts) }
            task = save(task.copy(progressTotal = task.progressDone + todo.size, phase = ResearchPhase.DESCARGANDO, note = "Leyendo ${todo.size} páginas…"))
            val prio = split(freshWorld.priorityCharacters)
            val places = split(freshWorld.priorityPlaces)
            for (src in todo) {
                if (cancelled(taskId)) return EngineOutcome(TaskStatus.CANCELADA, false, "Cancelada por el usuario.")
                val provider = providers.firstOrNull { it.canHandle(src) }
                if (provider == null) { repo.markSourceFailed(src.id, SourceStatus.NO_COMPATIBLE, "Ningún proveedor entiende esta fuente.", taskId); task = bump(taskId, failed = 1); continue }
                when (val r = provider.fetch(src)) {
                    is FetchResult.Ok -> {
                        repo.markSourceProcessed(src.id, r.title, r.text, r.license, r.provenance, taskId)
                        val state = if (src.kind == SourceKind.MEDIAWIKI) EntryState.ACTIVO else EntryState.PROPUESTO
                        val drafts = draftsFor(src, r, saved, prio, places).map { it.copy(state = state) }
                        val added = repo.addDrafts(world.id, drafts)
                        task = bump(taskId, ok = 1, entries = added.created)
                    }
                    is FetchResult.Failed -> { repo.markSourceFailed(src.id, SourceStatus.FALLIDA, r.message, taskId); retryable = retryable || r.retryable; task = bump(taskId, failed = 1, error = "${src.title.ifBlank { src.uri }}: ${r.message}") }
                    is FetchResult.Unsupported -> { repo.markSourceFailed(src.id, SourceStatus.NO_COMPATIBLE, r.message, taskId); task = bump(taskId, failed = 1) }
                }
            }

            // ---- fase 4: imágenes de personajes canónicos (opcional, nunca bloquea lo demás) ----
            if (auto != null && auto.imagesEnabled() && saved != null) {
                task = save(repo.task(taskId)!!.copy(phase = ResearchPhase.IMAGENES))
                try {
                    if (!fetchImages(auto, world, saved, taskId)) return EngineOutcome(TaskStatus.CANCELADA, false, "Cancelada por el usuario.")
                } catch (e: WikiFetchException) {
                    if (e.retryable) retryable = true
                    notes.add("Imágenes: ${e.message}")
                }
            }

            // ---- fase 5: contradicciones (se muestran, nunca se resuelven solas) ----
            task = save(repo.task(taskId)!!.copy(phase = ResearchPhase.CONTRADICCIONES))
            repo.detectContradictions(world.id)

            // ---- final: éxito solo con fuentes y entradas válidas ----
            val fin = repo.task(taskId)!!
            val sources = repo.sourcesOf(world.id)
            val okSources = sources.count { it.status == SourceStatus.PROCESADA }
            val entries = repo.entryCount(world.id)
            val extra = notes.distinct().take(4).joinToString(" ")
            val (status, msg) = when {
                sources.isEmpty() -> TaskStatus.SIN_RESULTADOS to ("No se encontraron fuentes que consultar. " + extra.ifBlank { "Añade una wiki, una URL o un archivo." })
                okSources == 0 -> TaskStatus.FALLIDA to "Ninguna fuente se pudo procesar. Revisa los errores por fuente. $extra".trim()
                fin.entriesCreated == 0 && entries == 0 -> TaskStatus.SIN_RESULTADOS to "Se leyeron fuentes pero no se obtuvo ninguna entrada válida."
                else -> TaskStatus.COMPLETADA to "Terminada: $okSources fuentes procesadas, ${fin.entriesCreated} entradas nuevas." + (if (extra.isNotBlank()) " $extra" else "")
            }
            // Con algún fallo temporal pendiente se reintenta (aunque otras fuentes ya se procesaran), hasta el límite de intentos.
            val willRetry = retryable && fin.attempts < fin.maxAttempts
            if (willRetry) {
                save(fin.copy(status = TaskStatus.PENDIENTE, phase = ResearchPhase.DESCARGANDO, note = "Falló algo temporal; se reintentará (intento ${fin.attempts} de ${fin.maxAttempts}).", lastError = msg))
                return EngineOutcome(TaskStatus.PENDIENTE, true, "Reintento programado.")
            }
            save(fin.copy(status = status, phase = ResearchPhase.FIN, lastError = if (status == TaskStatus.COMPLETADA) fin.lastError else msg, note = msg, finishedAt = System.currentTimeMillis()))
            return EngineOutcome(status, false, msg)
        } catch (e: CancellationException) {
            // El proceso o el trabajo se interrumpió: la tarea queda PENDIENTE y se reanudará sin repetir lo ya procesado.
            repo.task(taskId)?.let { t -> if (!TaskStatus.isFinal(t.status)) save(t.copy(status = TaskStatus.PENDIENTE, note = "Interrumpida; se reanudará donde se quedó.")) }
            throw e
        } catch (e: Exception) {
            val t = repo.task(taskId)
            if (t != null) save(t.copy(status = TaskStatus.FALLIDA, phase = ResearchPhase.FIN, lastError = e.message ?: "Error inesperado", finishedAt = System.currentTimeMillis()))
            return EngineOutcome(TaskStatus.FALLIDA, false, "Error inesperado: ${e.message}")
        }
    }

    // ------------------------------------------------------------------ identidad y plan

    private suspend fun identify(auto: AutoDiscovery, world: WorldEntity, c: WorkCandidate, notes: MutableList<String>): WorldIdentityEntity {
        val id = UniverseResolver(auto.client).identify(c)
        notes.addAll(id.notes)
        val e = WorldIdentityEntity(
            worldId = world.id, qid = id.qid, title = id.title, kind = id.kind, lang = id.lang, description = id.description,
            wikipedia = id.wikipedia.entries.joinToString("\n") { "${it.key}\t${it.value}" }, fandomSub = id.fandomSub, fandomTitle = id.fandomTitle,
            notes = id.notes.joinToString("\n"), identifiedAt = System.currentTimeMillis(),
        )
        repo.saveIdentity(e)
        return e
    }

    private fun toIdentity(e: WorldIdentityEntity) = WorkIdentity(
        e.qid, e.title, e.kind, e.lang, e.description,
        e.wikipedia.lines().mapNotNull { l -> l.split('\t').takeIf { it.size == 2 && it[0].isNotBlank() && it[1].isNotBlank() }?.let { it[0] to it[1] } }.toMap(),
        e.fandomSub, e.fandomTitle, emptyList(), e.notes.lines().filter { it.isNotBlank() },
    )

    /** Registra como fuentes las páginas del plan (la dirección es única por mundo: repetirlo no duplica) y añade los nombres a los prioritarios. */
    private suspend fun register(world: WorldEntity, plan: DiscoveryPlan) {
        val pages = LinkedHashMap<String, PageRef>()
        for (p in plan.lorePages) pages.putIfAbsent("${p.api}#${p.title}", p)
        for (c in plan.characters) for (p in c.pages) pages.putIfAbsent("${p.api}#${p.title}", p)
        for (p in plan.places) pages.putIfAbsent("${p.api}#${p.title}", p)
        val maxPages = ResearchDepth.maxPages(world.researchDepth) + plan.characters.size + 4
        for (p in pages.values.take(maxPages + 12)) repo.addSource(world.id, SourceKind.MEDIAWIKI, MediaWikiProvider.uriOf(p.api, p.title), p.title, SourceStatus.PENDIENTE, "")
        repo.mergePriorities(world.id, plan.characters.map { it.name }, plan.places.map { it.title })
    }

    // ------------------------------------------------------------------ extracción por tipo de página

    private suspend fun draftsFor(src: SourceEntity, r: FetchResult.Ok, saved: SavedPlan?, prio: List<String>, places: List<String>): List<DraftEntry> {
        val ref = "${r.title} · ${src.uri}".take(300)
        if (saved != null && src.kind == SourceKind.MEDIAWIKI) {
            val key = src.uri.removePrefix(MediaWikiProvider.PREFIX)
            saved.characterByPage()[key]?.let { c -> return CharacterSheet.fromPage(c.name, c.aliases, c.actor, r.text, ref, src.id) }
            if (key in saved.listKeys() || CharacterSheet.isListPage(r.title)) {
                // Un listado de personajes no se guarda como una entrada gigante: solo aporta la ficha de quienes no tienen página propia.
                return saved.characters.filter { it.pages.isEmpty() }.mapNotNull { c ->
                    CharacterSheet.findSection(r.text, c.name, c.aliases)?.let { body -> CharacterSheet.fromListSection(c.name, c.aliases, c.actor, body, ref, src.id) }
                }
            }
        }
        return WikiExtractor.fromPlainPage(r.title, r.text, ref, src.id, prio, places)
    }

    // ------------------------------------------------------------------ imágenes canónicas

    /** @return false si el usuario canceló. Idempotente: un personaje con imagen (o ya comprobado sin imagen) no se vuelve a pedir. */
    private suspend fun fetchImages(auto: AutoDiscovery, world: WorldEntity, plan: SavedPlan, taskId: Long): Boolean {
        val pending = ArrayList<com.jullai.local.discovery.PlannedCharacter>()
        for (c in plan.characters) if (c.pages.isNotEmpty() && repo.canonImage(world.id, c.name)?.state.let { it != "OK" && it != "SIN_IMAGEN" }) pending.add(c)
        if (pending.isEmpty()) return true
        val finder = CanonImageFinder(auto.client)
        val sources = repo.sourcesOf(world.id).associateBy { it.uri }
        val unresolved = pending.toMutableList()
        var level = 0
        var done = 0
        var ok = 0
        while (unresolved.isNotEmpty() && level < 3) {
            val byApi = unresolved.filter { it.pages.size > level }.groupBy { it.pages[level].api }
            if (byApi.isEmpty()) break
            for ((api, chars) in byApi) {
                if (cancelled(taskId)) return false
                val found = finder.find(api, chars.map { it.pages[level].title })
                for (c in chars) {
                    if (cancelled(taskId)) return false
                    val page = c.pages[level]
                    val ref = found[page.title] ?: continue
                    val rights = sources[MediaWikiProvider.uriOf(page.api, page.title)]?.license.orEmpty()
                    val now = System.currentTimeMillis()
                    val bytes = try { auto.client.bytes(ref.imageUrl, CanonImagePolicy.MAX_BYTES) } catch (e: WikiFetchException) {
                        if (e.retryable) throw e
                        repo.saveCanonImage(CanonImageEntity(worldId = world.id, entryName = c.name, pageApi = page.api, pageTitle = page.title, imageUrl = ref.imageUrl, fileName = ref.fileName, state = "FALLIDA", error = e.message.orEmpty().take(200), createdAt = now, updatedAt = now))
                        continue
                    }
                    val reject = CanonImagePolicy.reject(ref.imageUrl, bytes)
                    if (reject != null) { repo.saveCanonImage(CanonImageEntity(worldId = world.id, entryName = c.name, pageApi = page.api, pageTitle = page.title, imageUrl = ref.imageUrl, fileName = ref.fileName, state = "FALLIDA", error = reject, createdAt = now, updatedAt = now)); continue }
                    val file = try { auto.saveImage(bytes) } catch (e: IllegalArgumentException) {
                        repo.saveCanonImage(CanonImageEntity(worldId = world.id, entryName = c.name, pageApi = page.api, pageTitle = page.title, imageUrl = ref.imageUrl, fileName = ref.fileName, state = "FALLIDA", error = e.message.orEmpty().take(200), createdAt = now, updatedAt = now)); continue
                    }
                    repo.saveCanonImage(
                        CanonImageEntity(
                            worldId = world.id, entryName = c.name, pageApi = page.api, pageTitle = page.title, imageUrl = ref.imageUrl, fileName = ref.fileName,
                            license = CanonImagePolicy.rightsNote(ref.license, ref.nonFree, rights), attribution = ref.attribution.take(200), nonFree = ref.nonFree,
                            file = file, sha256 = sha256(bytes), state = "OK", createdAt = now, updatedAt = now,
                        ),
                    )
                    unresolved.remove(c); ok++
                }
                done += chars.size
                repo.task(taskId)?.let { save(it.copy(note = "Imágenes de personajes: $ok guardadas…")) }
            }
            level++
        }
        // Lo que ninguna página pudo aportar queda anotado como «sin imagen» para no volver a pedirlo en cada reintento.
        val now = System.currentTimeMillis()
        for (c in unresolved) if (repo.canonImage(world.id, c.name) == null) {
            val p = c.pages.first()
            repo.saveCanonImage(CanonImageEntity(worldId = world.id, entryName = c.name, pageApi = p.api, pageTitle = p.title, state = "SIN_IMAGEN", createdAt = now, updatedAt = now))
        }
        return true
    }

    private fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    // ------------------------------------------------------------------ utilidades

    private suspend fun save(t: ResearchTaskEntity): ResearchTaskEntity { repo.saveTask(t); return repo.task(t.id) ?: t }

    private suspend fun cancelled(taskId: Long) = repo.task(taskId)?.status == TaskStatus.CANCELADA

    private suspend fun bump(taskId: Long, ok: Int = 0, failed: Int = 0, entries: Int = 0, error: String = ""): ResearchTaskEntity {
        val t = repo.task(taskId)!!
        return save(t.copy(progressDone = t.progressDone + ok + failed, sourcesOk = t.sourcesOk + ok, sourcesFailed = t.sourcesFailed + failed, entriesCreated = t.entriesCreated + entries, lastError = if (error.isNotBlank()) error.take(300) else t.lastError))
    }

    /** Un fallo es reintentable salvo los definitivos (sin acceso, no existe...): se distingue por el texto guardado. */
    private fun retryableStatus(s: SourceEntity) = s.error.contains("saturado") || s.error.contains("Error de red") || s.error.contains("tardó") || s.error.contains("conexión") || s.error.contains("lag")

    private fun split(s: String) = s.lines().flatMap { it.split(',', ';') }.map { it.trim() }.filter { it.isNotEmpty() }

    /** Direcciones de API de «fuentes preferidas»: líneas que empiezan por http(s):// y terminan en api.php (o llevan «wiki:»). */
    private fun wikiApis(preferred: String) = preferred.lines().map { it.trim().removePrefix("wiki:").trim() }.filter { (it.startsWith("https://") || it.startsWith("http://")) && it.contains("api.php") }.distinct().take(3)
}
