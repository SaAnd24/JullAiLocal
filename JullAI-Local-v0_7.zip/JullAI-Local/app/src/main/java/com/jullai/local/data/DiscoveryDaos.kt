package com.jullai.local.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WorldIdentityDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: WorldIdentityEntity)

    @Query("SELECT * FROM world_identity WHERE worldId = :worldId")
    suspend fun get(worldId: Long): WorldIdentityEntity?

    @Query("SELECT * FROM world_identity WHERE worldId = :worldId")
    fun observe(worldId: Long): Flow<WorldIdentityEntity?>

    @Query("UPDATE world_identity SET planJson = :plan, notes = :notes, plannedAt = :now WHERE worldId = :worldId")
    suspend fun savePlan(worldId: Long, plan: String, notes: String, now: Long)
}

@Dao
interface CanonImageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: CanonImageEntity): Long

    @Query("SELECT * FROM canon_images WHERE worldId = :worldId ORDER BY entryName COLLATE NOCASE ASC")
    suspend fun forWorld(worldId: Long): List<CanonImageEntity>

    @Query("SELECT * FROM canon_images WHERE worldId = :worldId ORDER BY entryName COLLATE NOCASE ASC")
    fun observeForWorld(worldId: Long): Flow<List<CanonImageEntity>>

    @Query("SELECT * FROM canon_images WHERE worldId = :worldId AND entryName = :name")
    suspend fun byName(worldId: Long, name: String): CanonImageEntity?

    @Query("SELECT COUNT(*) FROM canon_images WHERE worldId = :worldId AND state = 'OK'")
    suspend fun okCount(worldId: Long): Int

    @Query("SELECT * FROM canon_images WHERE state = 'OK' AND file IS NOT NULL")
    suspend fun allWithFiles(): List<CanonImageEntity>

    @Query("DELETE FROM canon_images WHERE worldId = :worldId")
    suspend fun deleteForWorld(worldId: Long)

    @Query("DELETE FROM canon_images WHERE id = :id")
    suspend fun delete(id: Long)
}
