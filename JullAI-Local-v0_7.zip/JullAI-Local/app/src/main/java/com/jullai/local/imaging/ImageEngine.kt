package com.jullai.local.imaging

import kotlinx.coroutines.flow.StateFlow

/**
 * Interfaz del motor de imágenes, SEPARADA del motor de texto (LlamaEngine). Permite sustituir el motor visual sin tocar
 * la interfaz, las fichas ni el sistema de recursos. Cada operación solo existe si el motor la expone de verdad:
 * lo que no soporte se declara en [EngineCapabilities] (leído del código nativo en ejecución, no supuesto).
 */
interface ImageEngine {
    /** Identificador estable del motor (p. ej. "sdcpp"). Se guarda con cada imagen generada. */
    val id: String
    val state: StateFlow<ImageEngineState>

    /** Comprueba si el motor se puede usar en este dispositivo (biblioteca nativa, ABI, memoria). Nunca lanza. */
    suspend fun diagnose(): EngineDiagnostics

    /** Funciones realmente expuestas por el motor compilado. Vacío si la biblioteca nativa no está disponible. */
    fun capabilities(): EngineCapabilities

    /** Carga el modelo en el motor (validación real: si el motor no lo acepta, lanza [ImageEngineException]). */
    suspend fun loadModel(path: String, threads: Int): LoadedImageModel

    /** Genera UNA imagen. [onProgress] solo se invoca si el motor informa de progreso. Cancelable con [cancel] si el motor lo permite. */
    suspend fun generate(request: GenerationRequest, onProgress: (GenProgress) -> Unit = {}): GenerationResult

    /** Pide cancelar la generación en curso. Devuelve false si el motor no admite cancelar o no hay nada que cancelar. */
    fun cancel(): Boolean

    /** Libera modelo y memoria nativa. Seguro llamarlo varias veces. */
    suspend fun release()
}

enum class ImageEngineState { IDLE, LOADING, READY, GENERATING, ERROR, UNAVAILABLE }

data class EngineDiagnostics(
    val engineId: String,
    val engineVersion: String,
    val available: Boolean,
    val abi: String,
    val details: List<String>,
    /** Motivo en español si no está disponible. */
    val problem: String? = null,
)

/** Funciones que el motor compilado EXPONE. Si algo es false, la interfaz no lo ofrece. */
data class EngineCapabilities(
    val cancel: Boolean = false,
    val progress: Boolean = false,
    val vaeTiling: Boolean = false,
    val lora: Boolean = false,
    val imageToImage: Boolean = false,
    val negativePrompt: Boolean = false,
    val samplers: List<String> = emptyList(),
) {
    companion object { val NONE = EngineCapabilities() }
}

data class LoadedImageModel(val path: String, val loadMillis: Long, val sizeBytes: Long)

data class GenProgress(val step: Int, val steps: Int, val secondsPerStep: Float)

/** Todo lo necesario para una imagen. Las dimensiones deben ser de [ImageSizes] (valores validados). */
data class GenerationRequest(
    val prompt: String,
    val negativePrompt: String = "",
    val width: Int,
    val height: Int,
    val steps: Int,
    val cfgScale: Float,
    val seed: Long,
    val sampler: String,
    val vaeTiling: Boolean,
    val threads: Int,
    val loraPath: String? = null,
    val loraStrength: Float = 1f,
    /** Imagen de referencia (RGB sin comprimir, ancho*alto*3) para image-to-image; null = texto a imagen. */
    val initRgb: ByteArray? = null,
    val initStrength: Float = 0.6f,
) {
    override fun equals(other: Any?): Boolean = this === other
    override fun hashCode(): Int = System.identityHashCode(this)
}

data class GenerationResult(
    val rgb: ByteArray,
    val width: Int,
    val height: Int,
    val seed: Long,
    val totalMillis: Long,
    /** Parámetros que el motor aplicó de verdad y los que ignoró (p. ej. «prompt negativo ignorado con CFG 1»). */
    val applied: List<String>,
    val ignored: List<String>,
    val engineId: String,
    val engineVersion: String,
)

/** Error con mensaje comprensible en español. [code] permite a la interfaz decidir qué ofrecer (reintentar, cambiar ajustes...). */
class ImageEngineException(val code: Code, message: String, cause: Throwable? = null) : Exception(message, cause) {
    enum class Code { NOT_AVAILABLE, INVALID_MODEL, OUT_OF_MEMORY, CANCELLED, BUSY, UNSUPPORTED, FAILED }
}
