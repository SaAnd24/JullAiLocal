package com.jullai.local.discovery

import com.jullai.local.roleplay.J
import com.jullai.local.roleplay.JArr
import com.jullai.local.roleplay.JStr
import com.jullai.local.roleplay.JsonException
import com.jullai.local.roleplay.MiniJson
import com.jullai.local.roleplay.arr
import com.jullai.local.roleplay.asObj
import com.jullai.local.roleplay.int
import com.jullai.local.roleplay.jnum
import com.jullai.local.roleplay.jstr
import com.jullai.local.roleplay.jstrList
import com.jullai.local.roleplay.obj
import com.jullai.local.roleplay.str
import com.jullai.local.world.UntrustedText

/** Lo mínimo del plan que hay que recordar para reanudar una investigación sin volver a descubrir nada. */
class SavedPlan(val fandomApi: String, val lore: List<PageRef>, val characters: List<PlannedCharacter>, val places: List<PageRef>) {
    /** Clave estable de una página: «api#título». Coincide con el URI de las fuentes («mw:» + clave). */
    fun key(p: PageRef) = "${p.api}#${p.title}"
    fun characterByPage(): Map<String, PlannedCharacter> = HashMap<String, PlannedCharacter>().also { m -> for (c in characters) for (p in c.pages) m.putIfAbsent(key(p), c) }
    fun placeKeys(): Set<String> = places.map { key(it) }.toSet()
    fun listKeys(): Set<String> = lore.filter { it.role == PageRole.LISTA }.map { key(it) }.toSet()
}

object PlanCodec {
    private fun page(p: PageRef) = obj("a" to jstr(p.api), "t" to jstr(p.title), "r" to jstr(p.role))

    fun encode(plan: DiscoveryPlan): String = MiniJson.write(
        obj(
            "v" to jnum(1), "fandom" to jstr(plan.fandomApi.orEmpty()),
            "lore" to JArr(plan.lorePages.map { page(it) }), "places" to JArr(plan.places.map { page(it) }),
            "chars" to JArr(plan.characters.map { c ->
                obj("n" to jstr(c.name), "al" to jstrList(c.aliases), "tier" to jnum(c.tier), "actor" to jstr(c.actor), "list" to com.jullai.local.roleplay.jbool(c.fromList), "pages" to JArr(c.pages.map { page(it) }))
            }),
        ),
    )

    /** Lee un plan guardado. Si está dañado o es de otra versión devuelve null (se vuelve a planificar; no se pierde nada). Solo acepta APIs de la lista cerrada. */
    fun decode(json: String): SavedPlan? {
        if (json.isBlank()) return null
        return try {
            val r = MiniJson.parse(json).asObj() ?: return null
            if (r.int("v") != 1) return null
            fun pages(a: JArr?): List<PageRef> = a?.items?.mapNotNull { j ->
                val o = j.asObj() ?: return@mapNotNull null
                val api = o.str("a") ?: return@mapNotNull null
                val t = UntrustedText.oneLine(o.str("t").orEmpty(), 200)
                if (!WikiHosts.isTrustedApi(api) || t.isBlank()) null else PageRef(api, t, o.str("r") ?: PageRole.PRINCIPAL)
            }.orEmpty()
            val chars = r.arr("chars")?.items?.mapNotNull { j ->
                val o = j.asObj() ?: return@mapNotNull null
                val n = UntrustedText.oneLine(o.str("n").orEmpty(), 80)
                if (n.isBlank()) null else PlannedCharacter(
                    n, o.arr("al")?.items?.mapNotNull { (it as? JStr)?.v?.let { s -> UntrustedText.oneLine(s, 60) } }.orEmpty(), o.int("tier") ?: 2, pages(o.arr("pages")),
                    UntrustedText.oneLine(o.str("actor").orEmpty(), 60), (o.fields["list"] as? com.jullai.local.roleplay.JBool)?.v == true,
                )
            }.orEmpty()
            SavedPlan(r.str("fandom").orEmpty(), pages(r.arr("lore")), chars, pages(r.arr("places")))
        } catch (e: JsonException) { null }
    }
}
