package com.jullai.local.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Retratos de personajes: se guardan REDUCIDOS (lado máx. 768 px) en el almacenamiento privado de la app.
 * Nunca se guarda el archivo original del usuario (una tarjeta PNG puede pesar varios MB).
 */
class PortraitStore(private val context: Context) {
    private val dir: File get() = File(context.filesDir, "portraits").also { it.mkdirs() }
    private val cache = object : LruCache<String, Bitmap>(12 * 1024) {   // 12 MB (la unidad es KB)
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun file(name: String): File {
        require(name.isNotEmpty() && !name.contains('/') && !name.contains('\\') && !name.contains("..")) { "Nombre de retrato no válido." }
        return File(dir, name)
    }

    /** Decodifica, reduce y guarda. Devuelve el nombre del archivo. Lanza IllegalArgumentException (mensaje en español) si no es una imagen. */
    fun save(bytes: ByteArray, maxSide: Int = MAX_SIDE): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        require(w > 0 && h > 0 && w <= 30000 && h <= 30000) { "El archivo no es una imagen válida (usa PNG, JPG o WEBP)." }
        var sample = 1
        while (maxOf(w, h) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            ?: throw IllegalArgumentException("No se pudo leer la imagen.")
        val scale = maxSide.toFloat() / maxOf(decoded.width, decoded.height)
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(decoded, (decoded.width * scale).toInt().coerceAtLeast(1), (decoded.height * scale).toInt().coerceAtLeast(1), true) else decoded
        val png = bmp.hasAlpha()
        val name = "p_" + UUID.randomUUID().toString().replace("-", "") + if (png) ".png" else ".jpg"
        FileOutputStream(file(name)).use { out ->
            bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 90, out)
        }
        if (bmp !== decoded) decoded.recycle()
        return name
    }

    /** Guarda una imagen generada (RGB sin comprimir) como PNG, sin reducirla (ya es pequeña). Devuelve el nombre del archivo. */
    fun saveRgb(rgb: ByteArray, w: Int, h: Int): String {
        require(w in 1..2048 && h in 1..2048 && rgb.size == w * h * 3) { "Datos de imagen no válidos." }
        val px = IntArray(w * h)
        var i = 0
        for (k in px.indices) {
            val r = rgb[i].toInt() and 0xFF
            val g = rgb[i + 1].toInt() and 0xFF
            val b = rgb[i + 2].toInt() and 0xFF
            px[k] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            i += 3
        }
        val bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        val name = "g_" + UUID.randomUUID().toString().replace("-", "") + ".png"
        try {
            FileOutputStream(file(name)).use { out -> check(bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) { "No se pudo guardar la imagen." } }
        } catch (e: Exception) {
            runCatching { file(name).delete() }
            throw e
        } finally {
            bmp.recycle()
        }
        return name
    }

    /** Lee un recurso y lo deja como RGB de w×h (para usarlo de referencia en image-to-image). null si no se puede leer. */
    fun loadRgb(name: String, w: Int, h: Int): ByteArray? {
        val f = runCatching { file(name) }.getOrNull()?.takeIf { it.exists() } ?: return null
        val src = BitmapFactory.decodeFile(f.absolutePath) ?: return null
        val scaled = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h * 3)
        var i = 0
        for (c in px) { out[i++] = ((c shr 16) and 0xFF).toByte(); out[i++] = ((c shr 8) and 0xFF).toByte(); out[i++] = (c and 0xFF).toByte() }
        if (scaled !== src) scaled.recycle()
        src.recycle()
        return out
    }

    fun delete(name: String?) {
        if (name == null) return
        runCatching { file(name).delete() }
        cache.evictAll()
    }

    /** Copia el retrato a un archivo nuevo (para duplicar personajes sin compartir el archivo). */
    fun copy(name: String?): String? {
        if (name == null) return null
        return runCatching {
            val src = file(name)
            if (!src.exists()) return null
            val newName = "p_" + UUID.randomUUID().toString().replace("-", "") + "." + src.extension
            src.copyTo(file(newName))
            newName
        }.getOrNull()
    }

    /** Carga un retrato reducido para mostrarlo (con caché). Llamar fuera del hilo principal. */
    fun load(name: String, maxSide: Int): Bitmap? {
        val key = "$name@$maxSide"
        cache.get(key)?.let { return it }
        val f = runCatching { file(name) }.getOrNull() ?: return null
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        cache.put(key, bmp)
        return bmp
    }

    companion object {
        const val MAX_SIDE = 768
    }
}
