package com.jullai.local.data

import androidx.room.withTransaction
import com.jullai.local.roleplay.Swipes
import com.jullai.local.story.BCharacter
import com.jullai.local.story.BChapter
import com.jullai.local.story.BKnowledge
import com.jullai.local.story.BLoreEntry
import com.jullai.local.story.BLorebook
import com.jullai.local.story.BMemory
import com.jullai.local.story.BMessage
import com.jullai.local.story.BRelEvent
import com.jullai.local.story.BRelationship
import com.jullai.local.story.BSession
import com.jullai.local.story.BSummary
import com.jullai.local.story.BTimeline
import com.jullai.local.story.BVolume
import com.jullai.local.story.Bible
import com.jullai.local.story.BibleCodec
import com.jullai.local.story.BibleManifest
import com.jullai.local.story.TextNorm

/**
 * Exportar e importar una partida completa (.jullai). La importación SIEMPRE crea filas nuevas (personaje, lorebook, partida…):
 * nunca sustituye ni borra nada existente, ni siquiera si coincide el nombre. Todo va en una sola transacción: si algo falla,
 * no queda una partida a medias.
 */
class BibleService(private val db: AppDatabase, private val clock: () -> Long = { System.currentTimeMillis() }) {

    /** Reúne todos los datos de la partida. [portraitBytes] lee el archivo del retrato (ya reducido) si existe. */
    suspend fun export(sessionId: Long, portraitBytes: (String) -> ByteArray?): Bible {
        val s = db.roleSessions().get(sessionId) ?: throw StoryException("La partida ya no existe.")
        val c = db.characters().get(s.characterId) ?: throw StoryException("El personaje de la partida ya no existe.")
        val book = c.lorebookId?.let { bid ->
            db.lorebooks().get(bid)?.let { b ->
                BLorebook(
                    b.name, b.description, b.scanDepth,
                    db.loreEntries().list(bid).map {
                        BLoreEntry(it.name, TextNorm.lines(it.keys), TextNorm.lines(it.secondaryKeys), it.content, it.enabled, it.constant, it.selective, it.caseSensitive, it.priority, it.insertionOrder)
                    },
                )
            }
        }
        val msgs = db.roleMessages().list(sessionId)
        val msgIds = msgs.map { it.id }.toSet()
        fun ref(id: Long?) = id?.takeIf { it in msgIds }
        val assets = HashMap<String, ByteArray>()
        var portraitId: String? = null
        c.portraitFile?.let { f -> portraitBytes(f)?.let { assets["portrait1"] = it; portraitId = "portrait1" } }

        return Bible(
            manifest = BibleManifest(appVersion = BibleCodec.APP_VERSION, exportedAt = clock(), title = s.title, counts = emptyMap(), assets = emptyList()),
            character = BCharacter(
                c.name, TextNorm.lines(c.aliases), c.appearance, c.personality, c.speechStyle, c.history, c.motivations, c.likesDislikes, c.behaviorInstructions,
                c.initialRelationship, c.scenario, c.firstMessage, c.alternateGreetingList(), c.dialogueExamples, c.privateNotes,
                c.tags.split(',').map { it.trim() }.filter { it.isNotEmpty() }, c.creator, portraitId,
            ),
            lorebook = book,
            session = BSession(
                s.title, s.scenarioText, s.userName, s.userPersona, s.narrativeRules, s.summary, s.temperature, s.topP, s.maxTokens, s.contextLength,
                s.createdAt, s.updatedAt, db.memoryProgress().get(sessionId)?.coveredOrder ?: -1,
            ),
            messages = msgs.map { BMessage(it.id, it.role, it.content, it.orderIndex, it.createdAt, it.state, Swipes.parse(it.swipes), it.swipeIndex) },
            knowledge = db.knowledge().list(sessionId).map { BKnowledge(it.scope, it.text, it.createdAt) },
            memories = db.memories().listAll(sessionId).map {
                BMemory(it.id, it.content, it.importance, it.narrativeDate, it.origin, it.verification, it.state, it.pinned, TextNorm.lines(it.relatedNames), ref(it.sourceMessageId), it.sourceNote, it.createdAt, it.updatedAt)
            },
            summaries = db.summaries().list(sessionId).sortedBy { it.version }.map { BSummary(it.version, it.text, it.source, it.coversUpToOrder, it.note, it.createdAt) },
            timeline = db.timeline().listAll(sessionId).map { BTimeline(it.id, it.text, it.narrativeDate, it.orderKey, TextNorm.lines(it.characterNames), it.origin, it.state, ref(it.sourceMessageId), it.createdAt) },
            relationships = db.relationships().list(sessionId).map { BRelationship(it.id, it.aName, it.bName, it.trust, it.affection, it.respect, it.romantic, it.status, it.note, it.createdAt, it.updatedAt) },
            relEvents = db.relationshipEvents().list(sessionId).map {
                BRelEvent(it.relationshipId, it.state, it.origin, it.reason, it.dTrust, it.dAffection, it.dRespect, it.dRomantic, it.trustAfter, it.affectionAfter, it.respectAfter, it.romanticAfter, ref(it.sourceMessageId), it.createdAt)
            },
            volumes = db.volumes().list(sessionId).map { BVolume(it.id, it.number, it.title, it.state, it.continuitySummary, it.createdAt, it.closedAt) },
            chapters = db.chapters().list(sessionId).map { BChapter(it.id, it.volumeId, it.number, it.title, it.state, it.startOrder, it.endOrder, it.summary, it.novelText, it.novelState, it.createdAt, it.closedAt) },
            assets = assets,
        )
    }

    /**
     * Crea personaje (+lorebook) y partida con todo su contenido. [portraitFile] es el retrato ya guardado en el almacenamiento
     * de la app (o null); si esta función falla, quien llama debe borrarlo. Devuelve el id de la partida nueva.
     */
    suspend fun import(b: Bible, portraitFile: String?): Long = db.withTransaction {
        val now = clock()
        val bookId = b.lorebook?.let { l ->
            val id = db.lorebooks().insert(LorebookEntity(name = l.name.ifBlank { "Lorebook" }, description = l.description, scanDepth = l.scanDepth, createdAt = now, updatedAt = now))
            db.loreEntries().insertAll(
                l.entries.map {
                    LoreEntryEntity(
                        lorebookId = id, name = it.name, keys = it.keys.joinToString("\n"), secondaryKeys = it.secondaryKeys.joinToString("\n"), content = it.content,
                        enabled = it.enabled, constant = it.constant, selective = it.selective, caseSensitive = it.caseSensitive, priority = it.priority, insertionOrder = it.insertionOrder,
                    )
                },
            )
            id
        }
        val c = b.character
        val charId = db.characters().insert(
            CharacterEntity(
                name = c.name, aliases = c.aliases.joinToString("\n"), portraitFile = portraitFile, appearance = c.appearance, personality = c.personality,
                speechStyle = c.speechStyle, history = c.history, motivations = c.motivations, likesDislikes = c.likesDislikes, behaviorInstructions = c.behaviorInstructions,
                initialRelationship = c.initialRelationship, scenario = c.scenario, firstMessage = c.firstMessage, alternateGreetings = Swipes.toJson(c.alternateGreetings),
                dialogueExamples = c.dialogueExamples, lorebookId = bookId, privateNotes = c.privateNotes, tags = c.tags.joinToString(", "), creator = c.creator,
                createdAt = now, updatedAt = now,
            ),
        )
        val titles = db.sessionLookup().titles().map { it.trim().lowercase() }.toSet()
        var title = b.session.title
        if (title.trim().lowercase() in titles) title = "$title (importada)"
        val s = b.session
        val sid = db.roleSessions().insert(
            RoleSessionEntity(
                characterId = charId, title = title, scenarioText = s.scenarioText, userName = s.userName, userPersona = s.userPersona, narrativeRules = s.narrativeRules,
                summary = s.summary, modelFileName = null, temperature = s.temperature, topP = s.topP, maxTokens = s.maxTokens, contextLength = s.contextLength,
                createdAt = s.createdAt.takeIf { it > 0 } ?: now, updatedAt = now,
            ),
        )
        val msgMap = HashMap<Long, Long>()
        for (m in b.messages) {
            msgMap[m.srcId] = db.roleMessages().insert(
                RoleMessageEntity(
                    sessionId = sid, role = m.role, content = m.content, orderIndex = m.orderIndex, createdAt = m.createdAt, state = m.state,
                    swipes = Swipes.toJson(m.swipes), swipeIndex = m.swipeIndex,
                ),
            )
        }
        fun mref(id: Long?) = id?.let { msgMap[it] }
        b.knowledge.forEach { db.knowledge().insert(KnowledgeItemEntity(sessionId = sid, scope = it.scope, text = it.text, createdAt = it.createdAt)) }
        db.memories().insertAll(
            b.memories.map {
                MemoryEntity(
                    sessionId = sid, content = it.content, importance = it.importance, narrativeDate = it.narrativeDate, origin = it.origin, verification = it.verification,
                    state = it.state, pinned = it.pinned, relatedNames = it.related.joinToString("\n"), sourceMessageId = mref(it.sourceMessageSrcId), sourceNote = it.sourceNote,
                    createdAt = it.createdAt, updatedAt = it.updatedAt,
                )
            },
        )
        b.summaries.sortedBy { it.version }.forEach {
            db.summaries().insert(SummaryEntity(sessionId = sid, version = it.version, text = it.text, source = it.source, coversUpToOrder = it.coversUpToOrder, note = it.note, createdAt = it.createdAt))
        }
        db.timeline().insertAll(
            b.timeline.map {
                TimelineEventEntity(
                    sessionId = sid, text = it.text, narrativeDate = it.narrativeDate, orderKey = it.orderKey, characterNames = it.characters.joinToString("\n"),
                    origin = it.origin, state = it.state, sourceMessageId = mref(it.sourceMessageSrcId), createdAt = it.createdAt,
                )
            },
        )
        val relMap = HashMap<Long, Long>()
        for (r in b.relationships) {
            relMap[r.srcId] = db.relationships().insert(
                RelationshipEntity(sessionId = sid, aName = r.a, bName = r.b, trust = r.trust, affection = r.affection, respect = r.respect, romantic = r.romantic, status = r.status, note = r.note, createdAt = r.createdAt, updatedAt = r.updatedAt),
            )
        }
        db.relationshipEvents().insertAll(
            b.relEvents.map {
                RelationshipEventEntity(
                    relationshipId = relMap.getValue(it.srcRelationshipId), sessionId = sid, state = it.state, origin = it.origin, reason = it.reason,
                    dTrust = it.dTrust, dAffection = it.dAffection, dRespect = it.dRespect, dRomantic = it.dRomantic,
                    trustAfter = it.trustAfter, affectionAfter = it.affectionAfter, respectAfter = it.respectAfter, romanticAfter = it.romanticAfter,
                    sourceMessageId = mref(it.sourceMessageSrcId), createdAt = it.createdAt,
                )
            },
        )
        val volMap = HashMap<Long, Long>()
        for (v in b.volumes) {
            volMap[v.srcId] = db.volumes().insert(VolumeEntity(sessionId = sid, number = v.number, title = v.title, state = v.state, continuitySummary = v.continuitySummary, createdAt = v.createdAt, closedAt = v.closedAt))
        }
        for (ch in b.chapters) {
            db.chapters().insert(
                ChapterEntity(
                    sessionId = sid, volumeId = volMap.getValue(ch.srcVolumeId), number = ch.number, title = ch.title, state = ch.state, startOrder = ch.startOrder, endOrder = ch.endOrder,
                    summary = ch.summary, novelText = ch.novelText, novelState = ch.novelState, createdAt = ch.createdAt, closedAt = ch.closedAt,
                ),
            )
        }
        if (s.coveredOrder >= 0) db.memoryProgress().upsert(MemoryProgressEntity(sid, s.coveredOrder, now))
        sid
    }
}
