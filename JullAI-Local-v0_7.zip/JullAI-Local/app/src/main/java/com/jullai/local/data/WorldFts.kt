package com.jullai.local.data

import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Búsqueda de texto completo de las entradas de un mundo (v0.5). Igual que con los recuerdos de la 0.4: FTS4 (no FTS5),
 * tabla virtual creada con SQL (no es una entidad de Room) y mantenida por disparadores. Si el sistema no la admite,
 * [available] queda en falso y la recuperación usa el respaldo (LIKE + puntuación en Kotlin).
 */
object WorldFts {
    const val TABLE = "world_entries_fts"

    @Volatile var available: Boolean = false
        private set

    private val TRIGGERS = listOf(
        "world_entries_fts_bu" to "CREATE TRIGGER IF NOT EXISTS world_entries_fts_bu BEFORE UPDATE ON world_entries BEGIN DELETE FROM $TABLE WHERE docid = old.rowid; END",
        "world_entries_fts_bd" to "CREATE TRIGGER IF NOT EXISTS world_entries_fts_bd BEFORE DELETE ON world_entries BEGIN DELETE FROM $TABLE WHERE docid = old.rowid; END",
        "world_entries_fts_au" to "CREATE TRIGGER IF NOT EXISTS world_entries_fts_au AFTER UPDATE ON world_entries BEGIN " +
            "INSERT INTO $TABLE(docid, name, aliases, summary, details, relatedNames) VALUES (new.rowid, new.name, new.aliases, new.summary, new.details, new.relatedNames); END",
        "world_entries_fts_ai" to "CREATE TRIGGER IF NOT EXISTS world_entries_fts_ai AFTER INSERT ON world_entries BEGIN " +
            "INSERT INTO $TABLE(docid, name, aliases, summary, details, relatedNames) VALUES (new.rowid, new.name, new.aliases, new.summary, new.details, new.relatedNames); END",
    )

    const val CREATE_SQL = "CREATE VIRTUAL TABLE IF NOT EXISTS $TABLE USING fts4(content=\"world_entries\", name, aliases, summary, details, relatedNames, tokenize=unicode61)"

    /** Crea (si hace falta) la tabla y los disparadores. Nunca lanza. */
    fun ensure(db: SupportSQLiteDatabase): Boolean {
        val existed = tableExists(db)
        var ok = false
        try {
            db.execSQL(CREATE_SQL)
            for ((_, sql) in TRIGGERS) db.execSQL(sql)
            if (!existed) db.execSQL("INSERT INTO $TABLE($TABLE) VALUES('rebuild')")
            ok = true
        } catch (e: Exception) {
            runCatching { for ((name, _) in TRIGGERS) db.execSQL("DROP TRIGGER IF EXISTS $name") }
        }
        available = ok
        return ok
    }

    private fun tableExists(db: SupportSQLiteDatabase): Boolean =
        runCatching { db.query("SELECT name FROM sqlite_master WHERE type = 'table' AND name = '$TABLE'").use { it.moveToFirst() } }.getOrDefault(false)
}
