package com.jullai.local.discovery

import java.net.URI
import java.net.URLEncoder

/**
 * Qué servidores puede consultar SOLA la investigación automática (v0.7), sin que el usuario apruebe cada dirección.
 * Es una lista cerrada y pequeña a propósito: Wikipedia, Wikidata, Wikimedia Commons y wikis de Fandom (que exponen la API estándar de MediaWiki).
 * Cualquier otra dirección solo se consulta si el usuario la añade él mismo (comportamiento de la 0.5, con robots.txt).
 * Todo lo que devuelven estas APIs sigue siendo texto NO confiable (ver UntrustedText).
 */
object WikiHosts {
    private val FANDOM_SUB = Regex("^[a-z0-9][a-z0-9-]{0,60}\\.fandom\\.com$")
    private val LANG = Regex("^[a-z]{2,3}(-[a-z]{2,4})?$")
    private val API_PATH = Regex("^(/w|/[a-z]{2,3}(-[a-z]{2,4})?)?/api\\.php$")

    /** ¿Es una API de MediaWiki de la lista cerrada, por https y sin puertos ni credenciales? */
    fun isTrustedApi(url: String): Boolean {
        val u = parse(url) ?: return false
        if (u.scheme != "https" || u.userInfo != null || u.port != -1 || u.rawQuery != null) return false
        val host = u.host?.lowercase() ?: return false
        if (!API_PATH.matches(u.path ?: return false)) return false
        return host == "www.wikidata.org" || host == "commons.wikimedia.org" ||
            (host.endsWith(".wikipedia.org") && LANG.matches(host.removeSuffix(".wikipedia.org"))) ||
            FANDOM_SUB.matches(host)
    }

    /** ¿Puede la app descargar imágenes de esta dirección? Solo CDN de Wikimedia y de Fandom, por https. */
    fun isTrustedImageUrl(url: String): Boolean {
        val u = parse(url) ?: return false
        if (u.scheme != "https" || u.userInfo != null || u.port != -1) return false
        val host = u.host?.lowercase() ?: return false
        return host == "upload.wikimedia.org" || host == "static.wikia.nocookie.net" || host == "vignette.wikia.nocookie.net" ||
            host == "images.wikia.nocookie.net"
    }

    fun isFandom(api: String): Boolean = parse(api)?.host?.lowercase()?.endsWith(".fandom.com") == true

    fun wikipedia(lang: String): String {
        require(LANG.matches(lang)) { "Idioma no válido." }
        return "https://$lang.wikipedia.org/w/api.php"
    }

    const val WIKIDATA = "https://www.wikidata.org/w/api.php"

    /** API de una wiki de Fandom. [lang] vacío o «en» → raíz; otro idioma → «/es/api.php». */
    fun fandom(sub: String, lang: String = ""): String? {
        val host = "${sub.lowercase()}.fandom.com"
        if (!FANDOM_SUB.matches(host)) return null
        val l = lang.lowercase()
        return if (l.isEmpty() || l == "en") "https://$host/api.php" else if (LANG.matches(l)) "https://$host/$l/api.php" else null
    }

    /** Subdominios de Fandom que se prueban para un título («The Walking Dead» → thewalkingdead, walkingdead). Solo son candidatos: se validan en vivo. */
    fun fandomGuesses(title: String): List<String> {
        val base = com.jullai.local.story.TextNorm.fold(title.substringBefore('(')).replace(Regex("[^a-z0-9 ]"), " ").trim()
        if (base.isEmpty()) return emptyList()
        val words = base.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val noArticle = words.filter { it !in setOf("the", "el", "la", "los", "las", "a", "an", "of", "de") }
        val out = LinkedHashSet<String>()
        for (w in listOf(noArticle, words)) {
            if (w.isEmpty()) continue
            out.add(w.joinToString(""))
            out.add(w.joinToString("-"))
        }
        return out.filter { it.length in 2..60 }.take(4)
    }

    /** Dirección de una página para mostrarla al usuario (no se usa para pedir datos). */
    fun pageUrl(api: String, title: String): String {
        val base = api.substringBefore("/api.php").removeSuffix("/w")
        return base + (if (isFandom(api)) "/wiki/" else "/wiki/") + URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("%2F", "/").replace("%3A", ":")
    }

    private fun parse(url: String): URI? = try { URI(url.trim()) } catch (e: Exception) { null }
}

/** Constructores de consultas a la API de MediaWiki/Wikidata (solo cadenas: no hacen red). Los parámetros del usuario siempre van codificados. */
object WikiQuery {
    private fun e(s: String) = URLEncoder.encode(s, "UTF-8")
    private const val FMT = "format=json&formatversion=2"
    private const val PIPE = "%7C"

    /** Busca páginas por texto y devuelve su descripción corta y su identificador de Wikidata. Sirve para identificar la obra. */
    fun searchWorks(query: String, limit: Int = 8) =
        "action=query&generator=search&gsrsearch=${e(query)}&gsrnamespace=0&gsrlimit=${limit.coerceIn(1, 15)}" +
            "&prop=pageprops${PIPE}extracts&ppprop=wikibase_item${PIPE}wikibase-shortdesc${PIPE}disambiguation&exintro=1&explaintext=1&exlimit=${limit.coerceIn(1, 15)}&exchars=320&redirects=1&$FMT"

    fun searchTitles(term: String, limit: Int = 5) =
        "action=query&list=search&srsearch=${e(term)}&srlimit=${limit.coerceIn(1, 20)}&srnamespace=0&maxlag=5&$FMT"

    /** Secciones (con su nivel) de una página, en el orden en que aparecen. */
    fun sections(page: String) = "action=parse&page=${e(page)}&prop=sections&redirects=1&maxlag=5&$FMT"

    fun categoryMembers(category: String, limit: Int = 50) =
        "action=query&list=categorymembers&cmtitle=${e("Category:$category")}&cmtype=page&cmnamespace=0&cmlimit=${limit.coerceIn(1, 100)}&maxlag=5&$FMT"

    /** ¿Existen estas páginas? (hasta 50 por consulta). Devuelve también si son páginas de desambiguación. */
    fun exists(titles: List<String>) =
        "action=query&prop=info${PIPE}pageprops&ppprop=disambiguation&titles=${e(titles.take(50).joinToString("|"))}&redirects=1&maxlag=5&$FMT"

    /** Imagen principal de cada página. pilicense=any incluye imágenes no libres (carátulas, fotos de personajes) para cachearlas en privado. */
    fun pageImages(titles: List<String>, thumb: Int = 600) =
        "action=query&prop=pageimages&piprop=thumbnail${PIPE}name&pithumbsize=${thumb.coerceIn(100, 1000)}&pilicense=any&titles=${e(titles.take(20).joinToString("|"))}&redirects=1&maxlag=5&$FMT"

    fun fileInfo(fileTitle: String) =
        "action=query&prop=imageinfo&iiprop=url${PIPE}mime${PIPE}size${PIPE}extmetadata&iiextmetadatafilter=LicenseShortName${PIPE}Artist${PIPE}Credit${PIPE}UsageTerms${PIPE}NonFree&titles=${e(fileTitle)}&maxlag=5&$FMT"

    /** Texto plano de una página completa (con «== Sección ==»). Se limita al tamaño máximo de fuente al leerlo. */
    fun articleText(title: String) =
        "action=query&prop=extracts${PIPE}info&explaintext=1&exsectionformat=wiki&inprop=url&redirects=1&titles=${e(title)}&maxlag=5&$FMT"

    fun siteInfo() = "action=query&meta=siteinfo&siprop=general${PIPE}rightsinfo&maxlag=5&$FMT"

    // ---- Wikidata ----
    fun wikidataEntities(ids: List<String>, props: String) =
        "action=wbgetentities&ids=${e(ids.take(50).joinToString("|"))}&props=${e(props)}&languages=es${PIPE}en&languagefallback=1&maxlag=5&$FMT"

    /** Fandom: detalle de artículos (miniatura). Es la API v1 de Fandom, no de MediaWiki: se usa solo como alternativa para imágenes. */
    fun fandomArticleDetails(base: String, titles: List<String>, width: Int = 600): String {
        val root = base.substringBefore("/api.php")
        return "$root/api/v1/Articles/Details?titles=${e(titles.take(20).joinToString(","))}&abstract=0&width=${width.coerceIn(100, 1000)}&height=${(width * 4 / 3).coerceIn(100, 1400)}"
    }
}
