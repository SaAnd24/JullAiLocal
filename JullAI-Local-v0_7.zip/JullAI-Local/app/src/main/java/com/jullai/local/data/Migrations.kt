package com.jullai.local.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Migraciones de la base de datos. NUNCA destructivas: solo se AÑADEN tablas, sin tocar las existentes
 * (conversaciones, mensajes, modelos y ajustes de la v0.2 quedan intactos).
 *
 * El SQL reproduce EXACTAMENTE lo que Room espera para las entidades de RoleplayEntities.kt
 * (nombres de columna, tipos, NOT NULL, claves foráneas e índices); si una entidad cambia hay que cambiar esto
 * y subir la versión con una migración nueva.
 */
object Migrations {
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `lorebooks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, " +
                    "`description` TEXT NOT NULL, `scanDepth` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)",
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `lorebook_entries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `lorebookId` INTEGER NOT NULL, " +
                    "`name` TEXT NOT NULL, `keys` TEXT NOT NULL, `secondaryKeys` TEXT NOT NULL, `content` TEXT NOT NULL, `enabled` INTEGER NOT NULL, " +
                    "`constant` INTEGER NOT NULL, `selective` INTEGER NOT NULL, `caseSensitive` INTEGER NOT NULL, `priority` INTEGER NOT NULL, " +
                    "`insertionOrder` INTEGER NOT NULL, FOREIGN KEY(`lorebookId`) REFERENCES `lorebooks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_lorebook_entries_lorebookId` ON `lorebook_entries` (`lorebookId`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `characters` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `aliases` TEXT NOT NULL, " +
                    "`portraitFile` TEXT, `appearance` TEXT NOT NULL, `personality` TEXT NOT NULL, `speechStyle` TEXT NOT NULL, `history` TEXT NOT NULL, " +
                    "`motivations` TEXT NOT NULL, `likesDislikes` TEXT NOT NULL, `behaviorInstructions` TEXT NOT NULL, `initialRelationship` TEXT NOT NULL, " +
                    "`scenario` TEXT NOT NULL, `firstMessage` TEXT NOT NULL, `alternateGreetings` TEXT NOT NULL, `dialogueExamples` TEXT NOT NULL, " +
                    "`worldId` INTEGER, `lorebookId` INTEGER, `privateNotes` TEXT NOT NULL, `tags` TEXT NOT NULL, `creator` TEXT NOT NULL, " +
                    "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`lorebookId`) REFERENCES `lorebooks`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_characters_lorebookId` ON `characters` (`lorebookId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_characters_name` ON `characters` (`name`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `scenarios` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `characterId` INTEGER NOT NULL, " +
                    "`title` TEXT NOT NULL, `text` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`characterId`) REFERENCES `characters`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_scenarios_characterId` ON `scenarios` (`characterId`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `role_sessions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `characterId` INTEGER NOT NULL, " +
                    "`title` TEXT NOT NULL, `scenarioText` TEXT NOT NULL, `userName` TEXT NOT NULL, `userPersona` TEXT NOT NULL, " +
                    "`narrativeRules` TEXT NOT NULL, `summary` TEXT NOT NULL, `modelFileName` TEXT, `temperature` REAL NOT NULL, `topP` REAL NOT NULL, " +
                    "`maxTokens` INTEGER NOT NULL, `contextLength` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`characterId`) REFERENCES `characters`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_role_sessions_characterId` ON `role_sessions` (`characterId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_role_sessions_updatedAt` ON `role_sessions` (`updatedAt`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `role_messages` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, " +
                    "`role` TEXT NOT NULL, `content` TEXT NOT NULL, `orderIndex` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `state` TEXT NOT NULL, " +
                    "`swipes` TEXT NOT NULL, `swipeIndex` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_role_messages_sessionId_orderIndex` ON `role_messages` (`sessionId`, `orderIndex`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `knowledge_items` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, " +
                    "`scope` TEXT NOT NULL, `text` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_knowledge_items_sessionId` ON `knowledge_items` (`sessionId`)")
        }
    }

    /**
     * v0.4: memoria narrativa, relaciones, capítulos y volúmenes. SOLO añade tablas (no toca nada de la 0.3).
     * Igual que con la 1→2, el SQL reproduce lo que Room espera para StoryEntities.kt; la prueba MigrationTest lo valida.
     */
    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            for (sql in STORY_TABLES_SQL) db.execSQL(sql)
            // Búsqueda de texto completo (FTS4): es opcional. Si el sistema no la admite, la app usa un respaldo.
            FtsSupport.ensure(db)
        }
    }

    /**
     * v0.5: mundos, conocimiento, fuentes, tareas de investigación, vínculo partida-mundo, preparación, recursos visuales y escenas.
     * SOLO añade tablas: no toca ninguna de las de la 0.2-0.4 (la columna characters.worldId ya existía y se reutiliza).
     */
    val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            for (sql in WORLD_TABLES_SQL) db.execSQL(sql)
            WorldFts.ensure(db)   // opcional: si el sistema no admite FTS4, la app usa el respaldo con LIKE
        }
    }

    /** Un único origen de verdad para el esquema v3: lo usan la migración y las pruebas. */
    val STORY_TABLES_SQL: List<String> = listOf(
        "CREATE TABLE IF NOT EXISTS `memories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `content` TEXT NOT NULL, " +
            "`importance` INTEGER NOT NULL, `narrativeDate` TEXT NOT NULL, `origin` TEXT NOT NULL, `verification` TEXT NOT NULL, `state` TEXT NOT NULL, " +
            "`pinned` INTEGER NOT NULL, `relatedNames` TEXT NOT NULL, `sourceMessageId` INTEGER, `sourceNote` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
            "`updatedAt` INTEGER NOT NULL, FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_memories_sessionId` ON `memories` (`sessionId`)",
        "CREATE INDEX IF NOT EXISTS `index_memories_sessionId_state` ON `memories` (`sessionId`, `state`)",
        "CREATE TABLE IF NOT EXISTS `summaries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `version` INTEGER NOT NULL, " +
            "`text` TEXT NOT NULL, `source` TEXT NOT NULL, `coversUpToOrder` INTEGER NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_summaries_sessionId_version` ON `summaries` (`sessionId`, `version`)",
        "CREATE TABLE IF NOT EXISTS `timeline_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `text` TEXT NOT NULL, " +
            "`narrativeDate` TEXT NOT NULL, `orderKey` INTEGER NOT NULL, `characterNames` TEXT NOT NULL, `origin` TEXT NOT NULL, `state` TEXT NOT NULL, " +
            "`sourceMessageId` INTEGER, `createdAt` INTEGER NOT NULL, FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_timeline_events_sessionId_orderKey` ON `timeline_events` (`sessionId`, `orderKey`)",
        "CREATE TABLE IF NOT EXISTS `relationships` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `aName` TEXT NOT NULL, " +
            "`bName` TEXT NOT NULL, `trust` INTEGER NOT NULL, `affection` INTEGER NOT NULL, `respect` INTEGER NOT NULL, `romantic` INTEGER NOT NULL, " +
            "`status` TEXT NOT NULL, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_relationships_sessionId` ON `relationships` (`sessionId`)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_relationships_sessionId_aName_bName` ON `relationships` (`sessionId`, `aName`, `bName`)",
        "CREATE TABLE IF NOT EXISTS `relationship_events` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `relationshipId` INTEGER NOT NULL, `sessionId` INTEGER NOT NULL, " +
            "`state` TEXT NOT NULL, `origin` TEXT NOT NULL, `reason` TEXT NOT NULL, `dTrust` INTEGER NOT NULL, `dAffection` INTEGER NOT NULL, `dRespect` INTEGER NOT NULL, " +
            "`dRomantic` INTEGER NOT NULL, `trustAfter` INTEGER, `affectionAfter` INTEGER, `respectAfter` INTEGER, `romanticAfter` INTEGER, `sourceMessageId` INTEGER, " +
            "`createdAt` INTEGER NOT NULL, FOREIGN KEY(`relationshipId`) REFERENCES `relationships`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_relationship_events_relationshipId` ON `relationship_events` (`relationshipId`)",
        "CREATE INDEX IF NOT EXISTS `index_relationship_events_sessionId` ON `relationship_events` (`sessionId`)",
        "CREATE TABLE IF NOT EXISTS `volumes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `number` INTEGER NOT NULL, `title` TEXT NOT NULL, " +
            "`state` TEXT NOT NULL, `continuitySummary` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `closedAt` INTEGER, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_volumes_sessionId_number` ON `volumes` (`sessionId`, `number`)",
        "CREATE TABLE IF NOT EXISTS `chapters` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `volumeId` INTEGER NOT NULL, `number` INTEGER NOT NULL, " +
            "`title` TEXT NOT NULL, `state` TEXT NOT NULL, `startOrder` INTEGER NOT NULL, `endOrder` INTEGER, `summary` TEXT NOT NULL, `novelText` TEXT NOT NULL, " +
            "`novelState` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `closedAt` INTEGER, " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , " +
            "FOREIGN KEY(`volumeId`) REFERENCES `volumes`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_chapters_volumeId` ON `chapters` (`volumeId`)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_chapters_sessionId_number` ON `chapters` (`sessionId`, `number`)",
        "CREATE TABLE IF NOT EXISTS `memory_progress` (`sessionId` INTEGER NOT NULL, `coveredOrder` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`sessionId`), " +
            "FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
    )

    /** Un único origen de verdad para el esquema v4 (generado a partir de WorldEntities.kt; lo valida tools/verify/check_schema.py). */
    val WORLD_TABLES_SQL: List<String> = listOf(
        "CREATE TABLE IF NOT EXISTS `worlds` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `uuid` TEXT NOT NULL, `name` TEXT NOT NULL, `description` TEXT NOT NULL, `language` TEXT NOT NULL, `setting` TEXT NOT NULL, `era` TEXT NOT NULL, `rules` TEXT NOT NULL, `narrativeLimits` TEXT NOT NULL, `spoilerLevel` TEXT NOT NULL, `castMode` TEXT NOT NULL, `continuityMode` TEXT NOT NULL, `researchDepth` TEXT NOT NULL, `preferredSources` TEXT NOT NULL, `priorityCharacters` TEXT NOT NULL, `priorityPlaces` TEXT NOT NULL, `allowOnline` INTEGER NOT NULL, `origin` TEXT NOT NULL, `revision` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_worlds_uuid` ON `worlds` (`uuid`)",
        "CREATE INDEX IF NOT EXISTS `index_worlds_updatedAt` ON `worlds` (`updatedAt`)",
        "CREATE TABLE IF NOT EXISTS `world_entries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `worldId` INTEGER NOT NULL, `type` TEXT NOT NULL, `name` TEXT NOT NULL, `aliases` TEXT NOT NULL, `summary` TEXT NOT NULL, `details` TEXT NOT NULL, `confidence` TEXT NOT NULL, `origin` TEXT NOT NULL, `sourceId` INTEGER, `sourceRef` TEXT NOT NULL, `evidence` TEXT NOT NULL, `factKey` TEXT NOT NULL, `contradictionGroup` TEXT NOT NULL, `relatedNames` TEXT NOT NULL, `spoilerLevel` INTEGER NOT NULL, `eraTag` TEXT NOT NULL, `state` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`worldId`) REFERENCES `worlds`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_world_entries_worldId` ON `world_entries` (`worldId`)",
        "CREATE INDEX IF NOT EXISTS `index_world_entries_worldId_type` ON `world_entries` (`worldId`, `type`)",
        "CREATE INDEX IF NOT EXISTS `index_world_entries_worldId_state` ON `world_entries` (`worldId`, `state`)",
        "CREATE TABLE IF NOT EXISTS `sources` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `worldId` INTEGER NOT NULL, `kind` TEXT NOT NULL, `uri` TEXT NOT NULL, `title` TEXT NOT NULL, `status` TEXT NOT NULL, `error` TEXT NOT NULL, `attempts` INTEGER NOT NULL, `consultedAt` INTEGER, `license` TEXT NOT NULL, `provenance` TEXT NOT NULL, `contentHash` TEXT NOT NULL, `textFile` TEXT, `charCount` INTEGER NOT NULL, `taskId` INTEGER, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`worldId`) REFERENCES `worlds`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_sources_worldId` ON `sources` (`worldId`)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_sources_worldId_uri` ON `sources` (`worldId`, `uri`)",
        "CREATE TABLE IF NOT EXISTS `research_tasks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `worldId` INTEGER NOT NULL, `phase` TEXT NOT NULL, `status` TEXT NOT NULL, `progressDone` INTEGER NOT NULL, `progressTotal` INTEGER NOT NULL, `sourcesOk` INTEGER NOT NULL, `sourcesFailed` INTEGER NOT NULL, `entriesCreated` INTEGER NOT NULL, `attempts` INTEGER NOT NULL, `maxAttempts` INTEGER NOT NULL, `lastError` TEXT NOT NULL, `note` TEXT NOT NULL, `workId` TEXT, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `finishedAt` INTEGER, FOREIGN KEY(`worldId`) REFERENCES `worlds`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_research_tasks_worldId` ON `research_tasks` (`worldId`)",
        "CREATE INDEX IF NOT EXISTS `index_research_tasks_status` ON `research_tasks` (`status`)",
        "CREATE TABLE IF NOT EXISTS `world_sessions` (`sessionId` INTEGER NOT NULL, `worldId` INTEGER, `worldUuid` TEXT NOT NULL, `worldName` TEXT NOT NULL, `castMode` TEXT NOT NULL, `continuityMode` TEXT NOT NULL, `spoilerLevel` TEXT NOT NULL, `startEra` TEXT NOT NULL, `visual` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`sessionId`), FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(`worldId`) REFERENCES `worlds`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )",
        "CREATE INDEX IF NOT EXISTS `index_world_sessions_worldId` ON `world_sessions` (`worldId`)",
        "CREATE TABLE IF NOT EXISTS `prep_steps` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `step` INTEGER NOT NULL, `title` TEXT NOT NULL, `status` TEXT NOT NULL, `detail` TEXT NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_prep_steps_sessionId_step` ON `prep_steps` (`sessionId`, `step`)",
        "CREATE TABLE IF NOT EXISTS `visual_assets` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `kind` TEXT NOT NULL, `file` TEXT NOT NULL, `label` TEXT NOT NULL, `characterId` INTEGER, `worldId` INTEGER, `locationRef` TEXT NOT NULL, `emotion` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)",
        "CREATE INDEX IF NOT EXISTS `index_visual_assets_kind` ON `visual_assets` (`kind`)",
        "CREATE INDEX IF NOT EXISTS `index_visual_assets_characterId` ON `visual_assets` (`characterId`)",
        "CREATE INDEX IF NOT EXISTS `index_visual_assets_worldId` ON `visual_assets` (`worldId`)",
        "CREATE TABLE IF NOT EXISTS `scene_meta` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sessionId` INTEGER NOT NULL, `messageId` INTEGER NOT NULL, `locationRef` TEXT NOT NULL, `speaker` TEXT NOT NULL, `emotion` TEXT NOT NULL, `pose` TEXT NOT NULL, `eventType` TEXT NOT NULL, `assetRefs` TEXT NOT NULL, `important` INTEGER NOT NULL, `valid` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, FOREIGN KEY(`sessionId`) REFERENCES `role_sessions`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_scene_meta_sessionId_messageId` ON `scene_meta` (`sessionId`, `messageId`)",
    )

    /** v0.6: SOLO añade 4 tablas (image_models, image_meta, image_tasks, visual_profiles). Ninguna tabla anterior cambia. */
    val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
        override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            IMAGE_TABLES_SQL.forEach { db.execSQL(it) }
        }
    }

    /** v0.7: SOLO añade 2 tablas (world_identity, canon_images). Ninguna tabla anterior cambia ni se toca ningún dato. */
    val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
        override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            DISCOVERY_TABLES_SQL.forEach { db.execSQL(it) }
        }
    }

    /** Todas las migraciones, en orden. Un único sitio para AppDatabase y las pruebas. */
    val ALL: Array<androidx.room.migration.Migration> get() = arrayOf(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)

    /** Un único origen de verdad para el esquema v5 (lo valida tools/verify/check_schema.py contra ImageEntities.kt). */
    val IMAGE_TABLES_SQL: List<String> = listOf(
        "CREATE TABLE IF NOT EXISTS `image_models` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `kind` TEXT NOT NULL, `fileName` TEXT NOT NULL, `displayName` TEXT NOT NULL, `format` TEXT NOT NULL, `sizeBytes` INTEGER NOT NULL, `architecture` TEXT NOT NULL, `compat` TEXT NOT NULL, `note` TEXT NOT NULL, `engineValidated` INTEGER NOT NULL, `isDefault` INTEGER NOT NULL, `licenseNote` TEXT NOT NULL, `importedAt` INTEGER NOT NULL)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_image_models_fileName` ON `image_models` (`fileName`)",
        "CREATE TABLE IF NOT EXISTS `image_meta` (`assetId` INTEGER NOT NULL, `prompt` TEXT NOT NULL, `negativePrompt` TEXT NOT NULL, `modelName` TEXT NOT NULL, `loraName` TEXT NOT NULL, `sampler` TEXT NOT NULL, `seed` INTEGER NOT NULL, `steps` INTEGER NOT NULL, `cfg` REAL NOT NULL, `width` INTEGER NOT NULL, `height` INTEGER NOT NULL, `vaeTiling` INTEGER NOT NULL, `preset` TEXT NOT NULL, `durationMs` INTEGER NOT NULL, `engineId` TEXT NOT NULL, `engineVersion` TEXT NOT NULL, `sessionId` INTEGER, `messageId` INTEGER, `slot` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`assetId`), FOREIGN KEY(`assetId`) REFERENCES `visual_assets`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_image_meta_sessionId` ON `image_meta` (`sessionId`)",
        "CREATE TABLE IF NOT EXISTS `image_tasks` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `kind` TEXT NOT NULL, `priority` INTEGER NOT NULL, `status` TEXT NOT NULL, `worldId` INTEGER, `sessionId` INTEGER, `messageId` INTEGER, `characterId` INTEGER, `label` TEXT NOT NULL, `locationRef` TEXT NOT NULL, `emotion` TEXT NOT NULL, `pose` TEXT NOT NULL, `prompt` TEXT NOT NULL, `negativePrompt` TEXT NOT NULL, `width` INTEGER NOT NULL, `height` INTEGER NOT NULL, `steps` INTEGER NOT NULL, `seed` INTEGER NOT NULL, `preset` TEXT NOT NULL, `attempts` INTEGER NOT NULL, `error` TEXT NOT NULL, `resultAssetId` INTEGER, `note` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `startedAt` INTEGER, `finishedAt` INTEGER)",
        "CREATE INDEX IF NOT EXISTS `index_image_tasks_status` ON `image_tasks` (`status`)",
        "CREATE INDEX IF NOT EXISTS `index_image_tasks_sessionId` ON `image_tasks` (`sessionId`)",
        "CREATE TABLE IF NOT EXISTS `visual_profiles` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `characterId` INTEGER NOT NULL, `physicalDescription` TEXT NOT NULL, `styleDescription` TEXT NOT NULL, `outfits` TEXT NOT NULL, `negativeDefaults` TEXT NOT NULL, `referenceAssetId` INTEGER, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`characterId`) REFERENCES `characters`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_visual_profiles_characterId` ON `visual_profiles` (`characterId`)",
    )

    /** Un único origen de verdad para el esquema v6 (lo valida tools/verify/check_schema.py contra DiscoveryEntities.kt). */
    val DISCOVERY_TABLES_SQL: List<String> = listOf(
        "CREATE TABLE IF NOT EXISTS `world_identity` (`worldId` INTEGER NOT NULL, `qid` TEXT NOT NULL, `title` TEXT NOT NULL, `kind` TEXT NOT NULL, `lang` TEXT NOT NULL, `description` TEXT NOT NULL, `wikipedia` TEXT NOT NULL, `fandomSub` TEXT NOT NULL, `fandomTitle` TEXT NOT NULL, `planJson` TEXT NOT NULL, `notes` TEXT NOT NULL, `identifiedAt` INTEGER NOT NULL, `plannedAt` INTEGER, PRIMARY KEY(`worldId`), FOREIGN KEY(`worldId`) REFERENCES `worlds`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE TABLE IF NOT EXISTS `canon_images` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `worldId` INTEGER NOT NULL, `entryName` TEXT NOT NULL, `pageApi` TEXT NOT NULL, `pageTitle` TEXT NOT NULL, `imageUrl` TEXT NOT NULL, `fileName` TEXT NOT NULL, `license` TEXT NOT NULL, `attribution` TEXT NOT NULL, `nonFree` INTEGER NOT NULL, `file` TEXT, `sha256` TEXT NOT NULL, `state` TEXT NOT NULL, `error` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`worldId`) REFERENCES `worlds`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )",
        "CREATE INDEX IF NOT EXISTS `index_canon_images_worldId` ON `canon_images` (`worldId`)",
        "CREATE UNIQUE INDEX IF NOT EXISTS `index_canon_images_worldId_entryName` ON `canon_images` (`worldId`, `entryName`)",
    )
}
