// JullAI Local — puente JNI hacia llama.cpp.
//
// Diseño:
//  - Una API pequeña y sin estado global salvo el registro de log.
//  - Todas las funciones pesadas (cargar, generar) deben llamarse desde un hilo de trabajo;
//    el lado Kotlin las serializa en un único hilo.
//  - nativeCancel() solo activa un indicador atómico: puede llamarse desde cualquier hilo.
//  - Los errores se devuelven como excepciones Java (IllegalStateException) con un mensaje claro.
//  - Los trozos de texto se entregan como bytes UTF-8 completos (nunca se parte un carácter).

#include <jni.h>

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

#ifdef __ANDROID__
#include <android/log.h>
#define JULL_LOG(prio, ...) __android_log_print(prio, "JullAI", __VA_ARGS__)
#else
#define ANDROID_LOG_INFO 0
#define ANDROID_LOG_ERROR 0
#define JULL_LOG(prio, ...) do { std::fprintf(stderr, "[JullAI] "); std::fprintf(stderr, __VA_ARGS__); std::fprintf(stderr, "\n"); } while (0)
#endif

namespace {

// ---------------------------------------------------------------------------
// Registro de log (últimas líneas, para diagnóstico dentro de la app)
// ---------------------------------------------------------------------------
std::mutex g_log_mutex;
std::deque<std::string> g_log_lines;
constexpr size_t kMaxLogLines = 300;
std::string g_log_partial;

void push_log_text(const char * text) {
    std::lock_guard<std::mutex> lock(g_log_mutex);
    g_log_partial += text;
    size_t pos;
    while ((pos = g_log_partial.find('\n')) != std::string::npos) {
        std::string line = g_log_partial.substr(0, pos);
        g_log_partial.erase(0, pos + 1);
        if (line.empty()) continue;
        g_log_lines.push_back(line);
        if (g_log_lines.size() > kMaxLogLines) g_log_lines.pop_front();
    }
}

void llama_log_cb(ggml_log_level level, const char * text, void * /*user*/) {
    if (text == nullptr) return;
    push_log_text(text);
    if (level >= GGML_LOG_LEVEL_WARN) {
        JULL_LOG(ANDROID_LOG_ERROR, "%s", text);
    }
}

// ---------------------------------------------------------------------------
// Estructuras de manejo
// ---------------------------------------------------------------------------
struct ModelHandle {
    llama_model * model = nullptr;
};

struct ContextHandle {
    llama_context * ctx = nullptr;
    ModelHandle * model = nullptr;
    std::atomic<bool> cancel{false};
    // Tokens que realmente están en la caché KV (secuencia 0), en orden. Permite reutilizar el prefijo
    // común entre turnos (v0.2). Se mantiene siempre sincronizada con la memoria del contexto.
    std::vector<llama_token> cached;
    int32_t last_reused = 0;  // tokens del prompt reutilizados en la última generación (diagnóstico)
};

bool abort_callback(void * data) {
    auto * h = static_cast<ContextHandle *>(data);
    return h != nullptr && h->cancel.load(std::memory_order_relaxed);
}

void throw_state(JNIEnv * env, const std::string & msg) {
    jclass cls = env->FindClass("java/lang/IllegalStateException");
    if (cls != nullptr) env->ThrowNew(cls, msg.c_str());
}

std::string jstring_to_std(JNIEnv * env, jstring s) {
    if (s == nullptr) return {};
    const char * chars = env->GetStringUTFChars(s, nullptr);
    if (chars == nullptr) return {};
    std::string out(chars);
    env->ReleaseStringUTFChars(s, chars);
    return out;
}

jstring std_to_jstring(JNIEnv * env, const std::string & s) {
    // NewStringUTF exige UTF-8 modificado válido; construimos mediante byte[] para ser robustos.
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(s.size()));
    if (arr == nullptr) return nullptr;
    env->SetByteArrayRegion(arr, 0, static_cast<jsize>(s.size()), reinterpret_cast<const jbyte *>(s.data()));
    jclass str_cls = env->FindClass("java/lang/String");
    jmethodID ctor = env->GetMethodID(str_cls, "<init>", "([BLjava/lang/String;)V");
    jstring charset = env->NewStringUTF("UTF-8");
    auto result = static_cast<jstring>(env->NewObject(str_cls, ctor, arr, charset));
    env->DeleteLocalRef(arr);
    env->DeleteLocalRef(charset);
    env->DeleteLocalRef(str_cls);
    return result;
}

// Longitud del prefijo de `s` que termina en un límite de carácter UTF-8 completo.
size_t utf8_complete_prefix(const std::string & s) {
    const size_t n = s.size();
    if (n == 0) return 0;
    size_t i = n;
    int back = 0;
    while (i > 0 && back < 4) {
        i--;
        back++;
        const unsigned char c = static_cast<unsigned char>(s[i]);
        if ((c & 0xC0) != 0x80) {  // ASCII o byte inicial
            int need = 1;
            if (c >= 0xF0) need = 4;
            else if (c >= 0xE0) need = 3;
            else if (c >= 0xC0) need = 2;
            return (back >= need) ? n : i;
        }
    }
    return n;  // secuencia inválida: se entrega tal cual
}

std::string meta_str(const llama_model * model, const char * key) {
    char buf[512];
    const int32_t n = llama_model_meta_val_str(model, key, buf, sizeof(buf));
    if (n < 0) return {};
    return std::string(buf);
}

// vocab_only = true: el modelo solo tiene vocabulario e hiperparámetros parciales; algunas funciones
// (n_head, n_head_kv...) abortan el proceso en ese modo, así que se leen de los metadatos GGUF.
std::string describe_model(const llama_model * model, bool vocab_only) {
    char desc[256] = {0};
    llama_model_desc(model, desc, sizeof(desc));
    const std::string arch = meta_str(model, "general.architecture");
    std::string out;
    out += "desc=" + std::string(desc) + "\n";
    out += "architecture=" + arch + "\n";
    out += "name=" + meta_str(model, "general.name") + "\n";
    out += "size_label=" + meta_str(model, "general.size_label") + "\n";
    out += "license=" + meta_str(model, "general.license") + "\n";
    out += "has_chat_template=" + std::string(llama_model_chat_template(model, nullptr) != nullptr ? "true" : "false") + "\n";
    if (vocab_only) {
        out += "n_ctx_train=" + meta_str(model, (arch + ".context_length").c_str()) + "\n";
        out += "n_layer=" + meta_str(model, (arch + ".block_count").c_str()) + "\n";
        out += "n_embd=" + meta_str(model, (arch + ".embedding_length").c_str()) + "\n";
        out += "n_head=" + meta_str(model, (arch + ".attention.head_count").c_str()) + "\n";
        std::string kv = meta_str(model, (arch + ".attention.head_count_kv").c_str());
        out += "n_head_kv=" + kv + "\n";
    } else {
        out += "n_params=" + std::to_string(llama_model_n_params(model)) + "\n";
        out += "n_ctx_train=" + std::to_string(llama_model_n_ctx_train(model)) + "\n";
        out += "n_layer=" + std::to_string(llama_model_n_layer(model)) + "\n";
        out += "n_embd=" + std::to_string(llama_model_n_embd(model)) + "\n";
        out += "n_head=" + std::to_string(llama_model_n_head(model)) + "\n";
        out += "n_head_kv=" + std::to_string(llama_model_n_head_kv(model)) + "\n";
    }
    return out;
}

}  // namespace

// ---------------------------------------------------------------------------
// JNI
// ---------------------------------------------------------------------------
#define JNI_FN(name) Java_com_jullai_local_engine_LlamaBridge_##name

extern "C" {

JNIEXPORT void JNICALL JNI_FN(nativeInit)(JNIEnv *, jclass) {
    static std::once_flag once;
    std::call_once(once, []() {
        llama_log_set(llama_log_cb, nullptr);
        llama_backend_init();
    });
}

JNIEXPORT jstring JNICALL JNI_FN(nativeSystemInfo)(JNIEnv * env, jclass) {
    return std_to_jstring(env, llama_print_system_info());
}

JNIEXPORT jstring JNICALL JNI_FN(nativeGetLog)(JNIEnv * env, jclass) {
    std::string out;
    {
        std::lock_guard<std::mutex> lock(g_log_mutex);
        for (const auto & l : g_log_lines) {
            out += l;
            out += '\n';
        }
    }
    return std_to_jstring(env, out);
}

// Valida un GGUF con el propio motor: carga solo vocabulario + hiperparámetros.
// Si la arquitectura no está soportada o el archivo está corrupto, lanza una excepción.
JNIEXPORT jstring JNICALL JNI_FN(nativeInspectModel)(JNIEnv * env, jclass, jstring jpath) {
    const std::string path = jstring_to_std(env, jpath);
    llama_model_params params = llama_model_default_params();
    params.vocab_only = true;
    params.load_mode = LLAMA_LOAD_MODE_MMAP;
    llama_model * model = llama_model_load_from_file(path.c_str(), params);
    if (model == nullptr) {
        throw_state(env, "El motor no pudo leer el archivo como modelo GGUF compatible (arquitectura no soportada o archivo dañado).");
        return nullptr;
    }
    const std::string info = describe_model(model, true);
    llama_model_free(model);
    return std_to_jstring(env, info);
}

JNIEXPORT jlong JNICALL JNI_FN(nativeLoadModel)(JNIEnv * env, jclass, jstring jpath, jboolean use_mmap) {
    const std::string path = jstring_to_std(env, jpath);
    llama_model_params params = llama_model_default_params();
    params.n_gpu_layers = 0;  // Solo CPU: ruta de compatibilidad inicial.
    params.load_mode = (use_mmap == JNI_TRUE) ? LLAMA_LOAD_MODE_MMAP : LLAMA_LOAD_MODE_NONE;
    llama_model * model = llama_model_load_from_file(path.c_str(), params);
    if (model == nullptr) {
        throw_state(env, "No se pudo cargar el modelo. Puede faltar memoria, o el archivo no es compatible con este motor.");
        return 0;
    }
    auto * h = new ModelHandle();
    h->model = model;
    return reinterpret_cast<jlong>(h);
}

JNIEXPORT jstring JNICALL JNI_FN(nativeModelInfo)(JNIEnv * env, jclass, jlong model_handle) {
    auto * h = reinterpret_cast<ModelHandle *>(model_handle);
    if (h == nullptr || h->model == nullptr) {
        throw_state(env, "Modelo no cargado.");
        return nullptr;
    }
    return std_to_jstring(env, describe_model(h->model, false));
}

JNIEXPORT void JNICALL JNI_FN(nativeFreeModel)(JNIEnv *, jclass, jlong model_handle) {
    auto * h = reinterpret_cast<ModelHandle *>(model_handle);
    if (h == nullptr) return;
    if (h->model != nullptr) llama_model_free(h->model);
    delete h;
}

JNIEXPORT jlong JNICALL JNI_FN(nativeCreateContext)(JNIEnv * env, jclass, jlong model_handle,
                                                    jint n_ctx, jint n_batch, jint n_threads) {
    auto * mh = reinterpret_cast<ModelHandle *>(model_handle);
    if (mh == nullptr || mh->model == nullptr) {
        throw_state(env, "Modelo no cargado.");
        return 0;
    }
    auto * ch = new ContextHandle();
    ch->model = mh;

    llama_context_params params = llama_context_default_params();
    params.n_ctx = static_cast<uint32_t>(n_ctx);
    params.n_batch = static_cast<uint32_t>(n_batch);
    params.n_ubatch = static_cast<uint32_t>(n_batch);
    params.n_threads = n_threads;
    params.n_threads_batch = n_threads;
    params.abort_callback = abort_callback;
    params.abort_callback_data = ch;
    params.no_perf = true;

    ch->ctx = llama_init_from_model(mh->model, params);
    if (ch->ctx == nullptr) {
        delete ch;
        throw_state(env, "No se pudo crear el contexto de inferencia (probablemente falta memoria; reduce la longitud de contexto).");
        return 0;
    }
    return reinterpret_cast<jlong>(ch);
}

JNIEXPORT void JNICALL JNI_FN(nativeFreeContext)(JNIEnv *, jclass, jlong ctx_handle) {
    auto * ch = reinterpret_cast<ContextHandle *>(ctx_handle);
    if (ch == nullptr) return;
    if (ch->ctx != nullptr) llama_free(ch->ctx);
    delete ch;
}

JNIEXPORT void JNICALL JNI_FN(nativeCancel)(JNIEnv *, jclass, jlong ctx_handle) {
    auto * ch = reinterpret_cast<ContextHandle *>(ctx_handle);
    if (ch != nullptr) ch->cancel.store(true);
}

// Tokens del prompt reutilizados de la caché KV en la última generación (0 si no hubo reutilización).
JNIEXPORT jint JNICALL JNI_FN(nativeLastReused)(JNIEnv *, jclass, jlong ctx_handle) {
    auto * ch = reinterpret_cast<ContextHandle *>(ctx_handle);
    return ch == nullptr ? 0 : ch->last_reused;
}

// Vacía la caché KV (p. ej. al cambiar de conversación o tras editar el historial).
JNIEXPORT void JNICALL JNI_FN(nativeResetCache)(JNIEnv *, jclass, jlong ctx_handle) {
    auto * ch = reinterpret_cast<ContextHandle *>(ctx_handle);
    if (ch == nullptr || ch->ctx == nullptr) return;
    llama_memory_clear(llama_get_memory(ch->ctx), true);
    ch->cached.clear();
    ch->last_reused = 0;
}

JNIEXPORT jint JNICALL JNI_FN(nativeCountTokens)(JNIEnv * env, jclass, jlong model_handle, jstring jtext) {
    auto * mh = reinterpret_cast<ModelHandle *>(model_handle);
    if (mh == nullptr || mh->model == nullptr) {
        throw_state(env, "Modelo no cargado.");
        return 0;
    }
    const std::string text = jstring_to_std(env, jtext);
    const llama_vocab * vocab = llama_model_get_vocab(mh->model);
    const int32_t n = -llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()),
                                      nullptr, 0, true, true);
    return n < 0 ? 0 : n;
}

// Aplica la plantilla conversacional del modelo (o ChatML como alternativa documentada).
JNIEXPORT jstring JNICALL JNI_FN(nativeApplyTemplate)(JNIEnv * env, jclass, jlong model_handle,
                                                      jobjectArray roles, jobjectArray contents,
                                                      jboolean add_assistant) {
    auto * mh = reinterpret_cast<ModelHandle *>(model_handle);
    if (mh == nullptr || mh->model == nullptr) {
        throw_state(env, "Modelo no cargado.");
        return nullptr;
    }
    const jsize n = env->GetArrayLength(roles);
    std::vector<std::string> role_store(n), content_store(n);
    std::vector<llama_chat_message> msgs(n);
    size_t total_chars = 0;
    for (jsize i = 0; i < n; i++) {
        auto jr = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        auto jc = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        role_store[i] = jstring_to_std(env, jr);
        content_store[i] = jstring_to_std(env, jc);
        env->DeleteLocalRef(jr);
        env->DeleteLocalRef(jc);
        msgs[i].role = role_store[i].c_str();
        msgs[i].content = content_store[i].c_str();
        total_chars += role_store[i].size() + content_store[i].size();
    }

    const char * model_tmpl = llama_model_chat_template(mh->model, nullptr);
    const char * candidates[2] = {model_tmpl, "chatml"};
    for (const char * tmpl : candidates) {
        if (tmpl == nullptr) continue;
        std::vector<char> buf(total_chars * 2 + 1024);
        int32_t len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), add_assistant == JNI_TRUE,
                                                buf.data(), static_cast<int32_t>(buf.size()));
        if (len > static_cast<int32_t>(buf.size())) {
            buf.resize(static_cast<size_t>(len) + 1);
            len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), add_assistant == JNI_TRUE,
                                            buf.data(), static_cast<int32_t>(buf.size()));
        }
        if (len >= 0) {
            return std_to_jstring(env, std::string(buf.data(), static_cast<size_t>(len)));
        }
    }
    throw_state(env, "No se pudo aplicar ninguna plantilla conversacional a este modelo.");
    return nullptr;
}

// Códigos de finalización: 0 = fin natural, 1 = límite de tokens, 2 = cancelado, 3 = contexto lleno.
JNIEXPORT jint JNICALL JNI_FN(nativeGenerate)(JNIEnv * env, jclass, jlong ctx_handle, jstring jprompt,
                                              jint max_tokens, jfloat temperature, jfloat top_p,
                                              jint top_k, jlong seed, jboolean reuse_cache, jobject callback) {
    auto * ch = reinterpret_cast<ContextHandle *>(ctx_handle);
    if (ch == nullptr || ch->ctx == nullptr) {
        throw_state(env, "Contexto no creado.");
        return -1;
    }
    ch->cancel.store(false);

    jclass cb_cls = env->GetObjectClass(callback);
    jmethodID on_token = env->GetMethodID(cb_cls, "onToken", "([B)Z");
    if (on_token == nullptr) {
        throw_state(env, "Callback de tokens inválido.");
        return -1;
    }

    const llama_model * model = ch->model->model;
    const llama_vocab * vocab = llama_model_get_vocab(model);
    const std::string prompt = jstring_to_std(env, jprompt);

    // Tokenizar (el texto ya trae los tokens especiales de la plantilla → parse_special = true).
    int32_t n_tokens = -llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()),
                                       nullptr, 0, true, true);
    if (n_tokens <= 0) {
        throw_state(env, "El mensaje está vacío o no se pudo tokenizar.");
        return -1;
    }
    std::vector<llama_token> tokens(static_cast<size_t>(n_tokens));
    if (llama_tokenize(vocab, prompt.c_str(), static_cast<int32_t>(prompt.size()), tokens.data(),
                       n_tokens, true, true) < 0) {
        throw_state(env, "Falló la tokenización del mensaje.");
        return -1;
    }

    const int32_t n_ctx = static_cast<int32_t>(llama_n_ctx(ch->ctx));
    if (n_tokens >= n_ctx) {
        throw_state(env, "El mensaje (" + std::to_string(n_tokens) + " tokens) no cabe en el contexto (" +
                         std::to_string(n_ctx) + "). Aumenta el contexto o acorta el texto.");
        return -1;
    }

    // Cadena de muestreo.
    llama_sampler * smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temperature <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        if (top_k > 0) llama_sampler_chain_add(smpl, llama_sampler_init_top_k(top_k));
        if (top_p > 0.0f && top_p < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
        const uint32_t s = seed < 0 ? LLAMA_DEFAULT_SEED : static_cast<uint32_t>(seed);
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(s));
    }

    // --- Caché KV (v0.2) ---
    // Si reuse_cache: se conserva el prefijo de tokens que coincide con lo ya procesado y solo se decodifica
    // el resto. Si el modelo no admite recortar la memoria (p. ej. arquitecturas recurrentes), se limpia todo.
    llama_memory_t mem = llama_get_memory(ch->ctx);
    int32_t reused = 0;
    if (reuse_cache == JNI_TRUE && !ch->cached.empty()) {
        size_t common = 0;
        const size_t lim = std::min(ch->cached.size(), tokens.size());
        while (common < lim && ch->cached[common] == tokens[common]) common++;
        if (common >= tokens.size()) common = tokens.size() - 1;  // siempre decodificar al menos 1 token
        if (common > 0 && llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(common), -1)) {
            ch->cached.resize(common);
            reused = static_cast<int32_t>(common);
        }
    }
    if (reused == 0) {
        llama_memory_clear(mem, true);
        ch->cached.clear();
    }
    ch->last_reused = reused;

    // Tras un fallo o cancelación a medias, elimina de la memoria cualquier posición que no esté en `cached`.
    auto resync = [&]() {
        llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(ch->cached.size()), -1);
    };

    jint result = 0;
    std::string error;
    std::string pending;  // bytes UTF-8 aún incompletos

    // 1) Procesar la parte nueva del prompt por bloques.
    const int32_t n_batch = static_cast<int32_t>(llama_n_batch(ch->ctx));
    for (int32_t i = reused; i < n_tokens && error.empty() && result == 0;) {
        const int32_t chunk = std::min(n_batch, n_tokens - i);
        llama_batch batch = llama_batch_get_one(tokens.data() + i, chunk);
        const int32_t rc = llama_decode(ch->ctx, batch);
        if (rc == 0) {
            ch->cached.insert(ch->cached.end(), tokens.begin() + i, tokens.begin() + i + chunk);
        } else {
            resync();
        }
        if (ch->cancel.load()) {
            result = 2;
        } else if (rc != 0) {
            error = "Error del motor al procesar el mensaje (código " + std::to_string(rc) + ").";
        }
        i += chunk;
    }

    // 2) Generar token a token.
    int32_t n_past = n_tokens;
    int32_t produced = 0;
    while (error.empty() && result == 0) {
        if (ch->cancel.load()) { result = 2; break; }
        if (produced >= max_tokens) { result = 1; break; }
        if (n_past >= n_ctx) { result = 3; break; }

        llama_token tok = llama_sampler_sample(smpl, ch->ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) { result = 0; break; }

        char piece[256];
        const int32_t pn = llama_token_to_piece(vocab, tok, piece, sizeof(piece), 0, false);
        if (pn > 0) pending.append(piece, static_cast<size_t>(pn));

        const size_t ready = utf8_complete_prefix(pending);
        if (ready > 0) {
            jbyteArray arr = env->NewByteArray(static_cast<jsize>(ready));
            env->SetByteArrayRegion(arr, 0, static_cast<jsize>(ready), reinterpret_cast<const jbyte *>(pending.data()));
            const jboolean keep_going = env->CallBooleanMethod(callback, on_token, arr);
            env->DeleteLocalRef(arr);
            pending.erase(0, ready);
            if (env->ExceptionCheck()) { error = "Excepción en el callback de tokens."; break; }
            if (keep_going != JNI_TRUE) { result = 2; break; }
        }
        produced++;

        llama_batch next = llama_batch_get_one(&tok, 1);
        const int32_t rc = llama_decode(ch->ctx, next);
        if (rc == 0) {
            ch->cached.push_back(tok);
            n_past++;
        } else {
            resync();
        }
        if (ch->cancel.load()) { result = 2; break; }
        if (rc != 0) { error = "Error del motor al generar (código " + std::to_string(rc) + ")."; break; }
    }

    // Vaciar bytes pendientes (si los hay) para no perder el final del texto.
    if (error.empty() && !pending.empty() && !env->ExceptionCheck()) {
        jbyteArray arr = env->NewByteArray(static_cast<jsize>(pending.size()));
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(pending.size()), reinterpret_cast<const jbyte *>(pending.data()));
        env->CallBooleanMethod(callback, on_token, arr);
        env->DeleteLocalRef(arr);
    }

    llama_sampler_free(smpl);
    env->DeleteLocalRef(cb_cls);

    if (!error.empty()) {
        if (!env->ExceptionCheck()) throw_state(env, error);
        return -1;
    }
    return result;
}

}  // extern "C"
