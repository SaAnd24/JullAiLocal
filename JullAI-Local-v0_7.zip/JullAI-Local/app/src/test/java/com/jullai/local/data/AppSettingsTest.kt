package com.jullai.local.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppSettingsTest {
    @Test fun roundTripKeepsEveryValue() {
        val s = AppSettings(
            threads = 6, defaultSystemPrompt = "hola", defaultTemperature = 0.3f, defaultTopP = 0.8f,
            defaultMaxTokens = 256, defaultContext = 4096, reuseKvCache = false,
        )
        assertEquals(s, AppSettings.fromMap(s.toMap()))
    }

    @Test fun missingOrInvalidValuesFallBackToDefaults() {
        val d = AppSettings()
        assertEquals(d, AppSettings.fromMap(emptyMap()))
        assertEquals(d.threads, AppSettings.fromMap(mapOf(AppSettings.K_THREADS to "abc")).threads)
        assertEquals(d.reuseKvCache, AppSettings.fromMap(mapOf(AppSettings.K_KV to "quizás")).reuseKvCache)
    }

    @Test fun valuesAreClampedToSafeRanges() {
        val s = AppSettings.fromMap(
            mapOf(AppSettings.K_THREADS to "99", AppSettings.K_CTX to "999999", AppSettings.K_TEMP to "9", AppSettings.K_MAXTOK to "1"),
        )
        assertEquals(8, s.threads)
        assertEquals(8192, s.defaultContext)
        assertEquals(2f, s.defaultTemperature)
        assertEquals(16, s.defaultMaxTokens)
    }

    @Test fun conversationDefaultsCopyTheSettings() {
        val s = AppSettings(defaultContext = 1024, defaultMaxTokens = 128)
        val d = s.conversationDefaults()
        assertEquals(1024, d.contextLength)
        assertEquals(128, d.maxTokens)
        assertTrue(d.systemPrompt.isNotBlank())
    }

    @Test fun memorySettingsDefaultToManualAndRoundTrip() {
        val d = AppSettings()
        assertEquals("MANUAL", d.memAutoMode)               // sin segunda inferencia en cada turno
        assertTrue(d.memEnabled)
        val s = d.copy(memAutoMode = "CADA_N", memEveryTurns = 20, novelOnClose = true, playerProfileName = "Ana", playerProfilePersona = "Viajera")
        assertEquals(s, AppSettings.fromMap(s.toMap()))
    }

    @Test fun memorySettingsAreValidated() {
        val s = AppSettings.fromMap(mapOf(AppSettings.K_MEM_AUTO to "SIEMPRE", AppSettings.K_MEM_EVERY to "1"))
        assertEquals("MANUAL", s.memAutoMode)
        assertEquals(3, s.memEveryTurns)
    }
}
