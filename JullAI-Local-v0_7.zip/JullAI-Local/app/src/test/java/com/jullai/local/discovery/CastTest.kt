package com.jullai.local.discovery

import com.jullai.local.data.WorldEntryEntity
import com.jullai.local.world.Confidence
import com.jullai.local.world.EntryOrigin
import com.jullai.local.world.EntryType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CastTest {
    private val page = "Rick Grimes es un exalguacil que despierta tras el apocalipsis y busca a su familia entre los muertos vivientes.\n\n== Apariencia ==\nPelo castaño rizado y barba, usa sombrero de sheriff.\n\n== Personalidad ==\nLeal, protector y a veces implacable con sus enemigos.\n\n== Historia ==\nDespierta en un hospital vacío y parte hacia Atlanta."
    private fun entry(d: DraftLike) = WorldEntryEntity(id = 1, worldId = 1, type = d.type, name = d.name, aliases = "Rick", summary = d.summary, details = d.details, confidence = Confidence.CONFIRMADO, origin = EntryOrigin.FUENTE, spoilerLevel = d.spoiler, createdAt = 0, updatedAt = 0)
    private class DraftLike(val type: String, val name: String, val summary: String, val details: String, val spoiler: Int)

    @Test fun sheetFromPageBecomesPlayableCharacterWithoutInventingFields() {
        val drafts = CharacterSheet.fromPage("Rick Grimes", listOf("Rick"), "Andrew Lincoln", page, "ref", 1)
        val main = drafts.first { it.type == EntryType.PERSONAJE }
        val hist = drafts.first { it.name.endsWith("— historia") }
        assertEquals(2, hist.spoilerLevel)
        val e = entry(DraftLike(main.type, main.name, main.summary, main.details, 0))
        val h = entry(DraftLike(hist.type, hist.name, hist.summary, hist.details, 2))
        val c = CastBuilder.build(e, h, 7, "The Walking Dead", "p_1.png", "Retrato: x", 5)
        assertTrue(c.appearance.contains("barba")); assertTrue(c.personality.contains("protector"))
        assertTrue(c.history.contains("hospital"))
        assertEquals("", c.speechStyle); assertEquals("", c.firstMessage); assertEquals("", c.scenario)
        assertEquals("p_1.png", c.portraitFile); assertEquals(7L, c.worldId)
        assertTrue(c.privateNotes.contains("Andrew Lincoln"))
    }
    @Test fun onlyNonSpoilerActivePersonajesAreCandidates() {
        val a = entry(DraftLike(EntryType.PERSONAJE, "A", "s", "", 0))
        val b = entry(DraftLike(EntryType.ACONTECIMIENTO, "A — historia", "s", "", 2))
        val c = entry(DraftLike(EntryType.PERSONAJE, "C", "s", "", 2))
        assertEquals(listOf("A"), CastBuilder.candidates(listOf(a, b, c)).map { it.name })
    }

    @Test fun planCodecRoundTripsAndRejectsUntrustedHosts() {
        val id = WorkIdentity("Q1", "T", WorkKind.SERIE, "en", "", emptyMap(), "", "", emptyList(), emptyList())
        val plan = DiscoveryPlan(id, "https://x.fandom.com/api.php", listOf(PageRef("https://en.wikipedia.org/w/api.php", "T", PageRole.PRINCIPAL), PageRef("https://evil.com/api.php", "Bad", PageRole.PRINCIPAL)),
            listOf(PlannedCharacter("Rick", listOf("R"), 0, listOf(PageRef("https://x.fandom.com/api.php", "Rick", PageRole.PERSONAJE)), "Actor", false)), emptyList(), emptyList(), false)
        val back = PlanCodec.decode(PlanCodec.encode(plan))!!
        assertEquals(1, back.lore.size); assertEquals("Rick", back.characters[0].name); assertEquals("Actor", back.characters[0].actor)
        assertTrue(PlanCodec.decode("basura {") == null)
    }
}
