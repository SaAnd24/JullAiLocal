package com.jullai.local.story

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NovelTest {
    private val count: suspend (String) -> Int = { t -> t.split(Regex("\\s+")).count { it.isNotEmpty() } }

    @Test fun chunksRespectBudgetAndKeepOrder() = runBlocking {
        val lines = (1..30).map { NovelLine("Aria", "texto $it " + "x ".repeat(20), false) }
        val ch = NovelPlanner.chunks(lines, 100, count)
        assertTrue(ch.size > 1)
        assertEquals(lines, ch.flatten())
        assertTrue(ch.all { c -> c.size == 1 || c.sumOf { count("${it.speaker}: ${it.text}") + 3 } <= 100 })
    }

    @Test fun oversizedMessageGetsItsOwnChunk() = runBlocking {
        val ch = NovelPlanner.chunks(listOf(NovelLine("A", "a", false), NovelLine("A", "palabra ".repeat(500), false), NovelLine("A", "b", false)), 50, count)
        assertEquals(3, ch.size)
    }

    @Test fun promptForbidsInventing() {
        val m = NovelPlanner.prompt("Cap 1", "", listOf(NovelLine("Aria", "Hola", false)), 1, 2)
        assertTrue(m[0].content.contains("no añadas acontecimientos nuevos"))
        assertTrue(m[1].content.contains("parte 1 de 2"))
    }

    @Test fun tailAndJoin() {
        assertEquals("corto", NovelPlanner.tail("corto"))
        assertTrue(NovelPlanner.tail("a".repeat(2000)).length <= 600)
        assertEquals("uno\n\ndos", NovelPlanner.join(listOf(" uno ", "", "dos")))
    }

    @Test fun continuitySectionsParseAndCompose() {
        val raw = "SITUACIÓN ACTUAL:\n- Están en la torre\nACONTECIMIENTOS: - Cruzaron el río\nCONFLICTOS ABIERTOS:\n- El rey los busca\n"
        val s = ContinuityDraft.parseSections(raw)
        assertEquals("- Están en la torre", s["SITUACIÓN ACTUAL"])
        assertEquals("- Cruzaron el río", s["ACONTECIMIENTOS"])
        val text = ContinuityDraft.compose(s, listOf(RelationItem(1, "Aria", "Ana", 40, 30, 55, 10)))
        for (h in ContinuityDraft.SECTIONS) assertTrue(text.contains("$h:"))
        assertTrue(text.contains("confianza 40"))
        assertTrue(text.contains("TRAMAS PENDIENTES:\n- (sin datos"))
    }

    @Test fun headinglessOutputGoesToSituation() {
        val s = ContinuityDraft.parseSections("Todo sigue igual en el pueblo.")
        assertTrue(s.getValue("SITUACIÓN ACTUAL").contains("pueblo"))
    }
}
