package com.jullai.local.engine

import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File
import java.net.InetSocketAddress
import java.nio.file.Files
import java.security.MessageDigest

class DownloaderTest {
    private fun gguf(size: Int): ByteArray {
        val b = ByteArray(size) { (it * 31).toByte() }
        "GGUF".toByteArray().copyInto(b)
        b[4] = 3; b[5] = 0; b[6] = 0; b[7] = 0
        for (i in 8 until 24) b[i] = 0
        b[8] = 2; b[16] = 1
        return b
    }
    private fun sha(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private class Srv(val data: ByteArray, val honorRange: Boolean = true, val cutAfter: Int = -1) {
        val server: HttpServer = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val ranges = ArrayList<String?>()
        val base get() = "http://127.0.0.1:${server.address.port}"
        init {
            server.createContext("/m.gguf") { ex ->
                val r = ex.requestHeaders.getFirst("Range"); ranges.add(r)
                val start = if (honorRange && r != null) r.removePrefix("bytes=").removeSuffix("-").toInt() else 0
                if (start >= data.size) { ex.responseHeaders.add("Content-Range", "bytes */${data.size}"); ex.sendResponseHeaders(416, -1); ex.close(); return@createContext }
                val body = data.copyOfRange(start, data.size)
                if (start > 0) { ex.responseHeaders.add("Content-Range", "bytes $start-${data.size - 1}/${data.size}"); ex.sendResponseHeaders(206, body.size.toLong()) } else ex.sendResponseHeaders(200, body.size.toLong())
                val out = ex.responseBody
                if (cutAfter in 1 until body.size) { out.write(body, 0, cutAfter); out.flush(); ex.close() } else { out.write(body); out.close() }
            }
            server.createContext("/redir") { ex -> ex.responseHeaders.add("Location", "$base/m.gguf"); ex.sendResponseHeaders(302, -1); ex.close() }
            server.createContext("/evil") { ex -> ex.responseHeaders.add("Location", "http://evil.example/x.gguf"); ex.sendResponseHeaders(302, -1); ex.close() }
            server.createContext("/gone") { ex -> ex.sendResponseHeaders(404, -1); ex.close() }
            server.start()
        }
        fun stop() = server.stop(0)
    }

    private fun dl(dir: File, free: Long = Long.MAX_VALUE, margin: Long = 0) =
        ModelDownloader(dir, { free }, UrlConnectionOpener(), { it.startsWith("http://127.0.0.1") }, margin)
    private fun tmp() = Files.createTempDirectory("dl").toFile()

    @Test fun downloadsVerifiesAndMovesAtomically() = runBlocking {
        val data = gguf(3_000_000); val s = Srv(data); val d = tmp()
        try {
            val r = dl(d).download(DownloadSpec("${s.base}/m.gguf", "Mi Modelo.gguf", data.size.toLong(), sha(data))) { _, _ -> }
            assertEquals(sha(data), r.sha256); assertEquals(data.size.toLong(), r.file.length()); assertTrue(r.file.name.endsWith(".gguf"))
            assertTrue(d.listFiles()!!.none { it.name.contains(".dl.") })
        } finally { s.stop() }
    }

    @Test fun followsRedirectsButRefusesForeignHosts() = runBlocking {
        val data = gguf(200_000); val s = Srv(data); val d = tmp()
        try {
            assertEquals(data.size.toLong(), dl(d).download(DownloadSpec("${s.base}/redir", "a.gguf")) { _, _ -> }.size)
            try { dl(d).download(DownloadSpec("${s.base}/evil", "b.gguf")) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.message!!.contains("no permitida")) }
            assertFalse(File(d, "b.gguf").exists())
        } finally { s.stop() }
    }

    @Test fun resumesAfterConnectionCutWithRange() = runBlocking {
        val data = gguf(2_000_000); val cut = Srv(data, cutAfter = 700_000); val d = tmp()
        val name = "r.gguf"
        try {
            try { dl(d).download(DownloadSpec("${cut.base}/m.gguf", name, data.size.toLong())) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.retryable) }
            assertTrue(ModelDownloader.resumableBytes(d, name) in 1 until data.size)
        } finally { cut.stop() }
        val full = Srv(data)
        try {
            val r = dl(d).download(DownloadSpec("${full.base}/m.gguf", name, data.size.toLong(), sha(data))) { _, _ -> }
            assertTrue(r.resumedFrom > 0); assertEquals(sha(data), r.sha256)
            assertTrue(full.ranges.first()!!.startsWith("bytes="))
        } finally { full.stop() }
    }

    @Test fun serverIgnoringRangeRestartsFromZeroWithoutCorruption() = runBlocking {
        val data = gguf(1_000_000); val d = tmp()
        File(d, "x.gguf.dl.part").writeBytes(ByteArray(1234) { 7 })
        val s = Srv(data, honorRange = false)
        try { assertEquals(sha(data), dl(d).download(DownloadSpec("${s.base}/m.gguf", "x.gguf", -1, sha(data))) { _, _ -> }.sha256) } finally { s.stop() }
    }

    @Test fun badShaMagicSizeSpaceAndMissingAreRejectedAndCleaned() = runBlocking {
        val data = gguf(500_000); val s = Srv(data); val d = tmp()
        try {
            try { dl(d).download(DownloadSpec("${s.base}/m.gguf", "s.gguf", -1, "00".repeat(32))) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.message!!.contains("SHA-256")) }
            assertTrue(d.listFiles()!!.isEmpty())
            try { dl(d).download(DownloadSpec("${s.base}/m.gguf", "s2.gguf", 123)) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.message!!.contains("no coincide")) }
            try { dl(d, free = 1000).download(DownloadSpec("${s.base}/m.gguf", "s3.gguf")) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.message!!.contains("espacio")) }
            try { dl(d).download(DownloadSpec("${s.base}/gone", "s4.gguf")) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.message!!.contains("404")) }
        } finally { s.stop() }
        val j = Srv(ByteArray(100_000) { 1 })
        try { dl(d).download(DownloadSpec("${j.base}/m.gguf", "j.gguf")) { _, _ -> }; fail("debía fallar") } catch (e: DownloadException) { assertTrue(e.message!!.contains("GGUF")) } finally { j.stop() }
        assertFalse(File(d, "j.gguf").exists())
    }

    @Test fun neverOverwritesAnExistingModel() = runBlocking {
        val data = gguf(300_000); val s = Srv(data); val d = tmp()
        File(d, "same.gguf").writeText("previo")
        try {
            val r = dl(d).download(DownloadSpec("${s.base}/m.gguf", "same.gguf")) { _, _ -> }
            assertEquals("same-2.gguf", r.file.name); assertEquals("previo", File(d, "same.gguf").readText())
        } finally { s.stop() }
    }

    @Test fun probeSizeAndTrustedHostList() = runBlocking {
        val s = Srv(gguf(123_456)); val d = tmp()
        try { assertEquals(123_456L, dl(d).probeSize("${s.base}/m.gguf")) } finally { s.stop() }
        assertTrue(ModelDownloader.isTrustedModelHost("https://huggingface.co/a/b/resolve/main/x.gguf"))
        assertTrue(ModelDownloader.isTrustedModelHost("https://cdn-lfs.hf.co/x"))
        assertFalse(ModelDownloader.isTrustedModelHost("http://huggingface.co/x")); assertFalse(ModelDownloader.isTrustedModelHost("https://evilhuggingface.co/x"))
        assertFalse(ModelDownloader.isTrustedModelHost("https://huggingface.co.evil.com/x"))
        assertEquals("passwd.gguf", ModelFileNames.sanitize("../../etc/passwd"))
        assertTrue(ModelDownloader.isTrustedModelHost(ModelCatalog.DEFAULT.url))
        assertTrue(ModelCatalog.DEFAULT.url.endsWith(ModelCatalog.DEFAULT.fileName))
    }

    @Test fun cancellationKeepsPartialForResume() = runBlocking {
        val data = gguf(12_000_000); val s = Srv(data); val d = tmp()
        try {
            lateinit var job: Job
            job = launch(Dispatchers.IO) { dl(d).download(DownloadSpec("${s.base}/m.gguf", "c.gguf")) { _, _ -> job.cancel() } }
            job.join()
            assertTrue(job.isCancelled)
            assertFalse(File(d, "c.gguf").exists())
            assertTrue(ModelDownloader.resumableBytes(d, "c.gguf") > 0)
        } finally { s.stop() }
    }
}
