package com.jullai.local.story

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RelationshipRulesTest {
    private val base = RelValues(50, 50, 50, 20)

    @Test fun dimensionsAreIndependent() {
        val r = RelationshipRules.validateProposal(base, RelDelta(trust = 4), "Le confió un secreto")
        assertTrue(r.ok)
        assertEquals(RelValues(54, 50, 50, 20), r.after)
        assertEquals(RelDelta(trust = 4), r.applied)
    }

    @Test fun reasonIsRequired() {
        assertFalse(RelationshipRules.validateProposal(base, RelDelta(trust = 2), "").ok)
        assertFalse(RelationshipRules.validateProposal(base, RelDelta(trust = 2), "  ").ok)
    }

    @Test fun stepIsClampedPerDimensionAndRomanticIsSlower() {
        val r = RelationshipRules.validateProposal(base, RelDelta(trust = 50, romantic = 40), "Un gran gesto")
        assertTrue(r.ok)
        assertEquals(6, r.applied.trust)
        assertEquals(3, r.applied.romantic)
        assertTrue(r.notes.any { it.contains("recortado") })
    }

    @Test fun cannotTouchAllFourDimensionsAtOnce() {
        val r = RelationshipRules.validateProposal(base, RelDelta(5, 4, 3, 2), "Todo cambió de golpe")
        assertTrue(r.ok)
        val touched = listOf(r.applied.trust, r.applied.affection, r.applied.respect, r.applied.romantic).count { it != 0 }
        assertEquals(RelationshipRules.MAX_DIMENSIONS, touched)
        assertEquals(5, r.applied.trust); assertEquals(4, r.applied.affection)
    }

    @Test fun totalIsCapped() {
        val r = RelationshipRules.validateProposal(RelValues(50, 50, 50, 50), RelDelta(trust = 6, affection = 6), "Mucho")
        assertTrue(r.ok)
        assertTrue(r.applied.sumAbs() <= RelationshipRules.MAX_TOTAL)
    }

    @Test fun valuesStayBetween1And100() {
        val up = RelationshipRules.validateProposal(RelValues(98, 50, 50, 50), RelDelta(trust = 6), "Subida")
        assertTrue(up.ok); assertEquals(100, up.after.trust); assertEquals(2, up.applied.trust)
        val down = RelationshipRules.validateProposal(RelValues(2, 50, 50, 50), RelDelta(trust = -6), "Traición")
        assertTrue(down.ok); assertEquals(1, down.after.trust); assertEquals(-1, down.applied.trust)
    }

    @Test fun noEffectIsRejected() {
        assertFalse(RelationshipRules.validateProposal(RelValues(100, 50, 50, 50), RelDelta(trust = 3), "Ya al máximo").ok)
        assertFalse(RelationshipRules.validateProposal(base, RelDelta(), "Nada cambió").ok)
    }

    @Test fun manualSetHasNoStepLimitButKeepsRange() {
        val (v, d) = RelationshipRules.manualSet(base, RelValues(100, 0, 1, 500))
        assertEquals(RelValues(100, 1, 1, 100), v)
        assertEquals(RelDelta(50, -49, -49, 80), d)
    }

    @Test fun highRespectDoesNotImplyRomance() {
        val r = RelationshipRules.validateProposal(RelValues(10, 10, 10, 1), RelDelta(trust = 6, respect = 6), "Admiración profesional")
        assertEquals(1, r.after.romantic)
    }
}
