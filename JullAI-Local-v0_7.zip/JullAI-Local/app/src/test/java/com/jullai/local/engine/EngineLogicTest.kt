package com.jullai.local.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class EngineLogicTest {

    private fun header(magic: String = "GGUF", version: Int = 3, tensors: Long = 10, kv: Long = 20): ByteArray =
        ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN).apply {
            put(magic.toByteArray(Charsets.US_ASCII))
            putInt(version)
            putLong(tensors)
            putLong(kv)
        }.array()

    @Test fun validHeaderIsAccepted() {
        val r = GgufHeader.parse(header(), 24)
        assertTrue(r is GgufCheck.Ok)
        r as GgufCheck.Ok
        assertEquals(3, r.version)
        assertEquals(10L, r.tensorCount)
        assertEquals(20L, r.kvCount)
    }

    @Test fun wrongMagicIsRejected() {
        assertTrue(GgufHeader.parse(header(magic = "RIFF"), 24) is GgufCheck.Invalid)
    }

    @Test fun truncatedHeaderIsRejected() {
        assertTrue(GgufHeader.parse(header(), 10) is GgufCheck.Invalid)
    }

    @Test fun unsupportedVersionIsRejected() {
        assertTrue(GgufHeader.parse(header(version = 99), 24) is GgufCheck.Invalid)
        assertTrue(GgufHeader.parse(header(version = 1), 24) is GgufCheck.Invalid)
    }

    @Test fun absurdCountsAreRejected() {
        assertTrue(GgufHeader.parse(header(tensors = 5_000_000_000L), 24) is GgufCheck.Invalid)
    }

    @Test fun modelInfoParsesEngineOutput() {
        val raw = "desc=llama 7B\narchitecture=llama\nname=Test\nsize_label=7B\nlicense=mit\n" +
            "has_chat_template=true\nn_ctx_train=4096\nn_layer=32\nn_embd=4096\nn_head=32\nn_head_kv=8\n"
        val i = ModelInfo.parse(raw)
        assertEquals("llama", i.architecture)
        assertTrue(i.hasChatTemplate)
        assertEquals(4096, i.nCtxTrain)
        assertEquals(8, i.nHeadKv)
    }

    @Test fun modelInfoToleratesMissingValues() {
        val i = ModelInfo.parse("architecture=x\nn_layer=abc\n")
        assertEquals(0, i.nLayer)
        assertFalse(i.hasChatTemplate)
    }

    @Test fun kvCacheEstimateMatchesFormula() {
        // 2 (K,V) * 32 capas * 2048 ctx * (4096/32 * 8 = 1024) * 2 bytes = 268_435_456
        val info = ModelInfo("", "llama", "", "", "", true, 4096, 32, 4096, 32, 8)
        assertEquals(268_435_456L, MemoryEstimator.kvCacheBytes(info, 2048))
    }

    @Test fun kvCacheIsZeroWithoutData() {
        val info = ModelInfo("", "", "", "", "", false, 0, 0, 0, 0, 0)
        assertEquals(0L, MemoryEstimator.kvCacheBytes(info, 2048))
    }

    @Test fun riskDetection() {
        assertTrue(MemoryEstimator.isRisky(5_000_000_000L, 6_000_000_000L))
        assertFalse(MemoryEstimator.isRisky(1_000_000_000L, 6_000_000_000L))
        assertFalse(MemoryEstimator.isRisky(5_000_000_000L, 0))
    }

    @Test fun fileNamesAreSanitized() {
        assertEquals("x.gguf", ModelStore.sanitizeFileName("../../x.gguf"))
        assertEquals("modelo.gguf", ModelStore.sanitizeFileName(""))
        assertEquals("a_b.gguf", ModelStore.sanitizeFileName("a*b"))
        assertTrue(ModelStore.sanitizeFileName("C:\\dir\\m.gguf").endsWith("m.gguf"))
        assertTrue(ModelStore.sanitizeFileName("x".repeat(500)).length <= 105)
    }
}
