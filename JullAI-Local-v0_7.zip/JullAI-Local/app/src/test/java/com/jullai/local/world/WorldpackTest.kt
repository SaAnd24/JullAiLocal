package com.jullai.local.world

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class WorldpackTest {
    private fun world(rev: Int = 3) = PackWorld("11111111-2222-3333-4444-555555555555", "Eldoria", "Un reino.", "es", "fantasía", "Era del Hierro", "Sin magia de resurrección.", "Sin violencia gráfica", SpoilerLevel.SIN, CastMode.MIXTO, Continuity.FLEXIBLE, ResearchDepth.BASICA, "https://es.wikipedia.org/w/api.php", "Aria", "Puerto Gris", rev)
    private fun entry(name: String, type: String = EntryType.PERSONAJE, conf: String = Confidence.CONFIRMADO, src: Int? = 0, key: String = "") =
        PackEntry(type, name, listOf("la capitana"), "Resumen de $name.", "", conf, EntryOrigin.FUENTE, src, "Ref", "cita verificada de ejemplo", key, "", listOf("Puerto Gris"), 0, "", EntryState.ACTIVO)
    private fun pack(entries: List<PackEntry> = listOf(entry("Aria"), entry("Puerto Gris", EntryType.LUGAR), entry("Batalla", EntryType.ACONTECIMIENTO), entry("Espada", EntryType.OBJETO))) =
        WorldPack("0.5.0", 1_000L, world(), entries, listOf(PackSource(SourceKind.MEDIAWIKI, "mw:https://es.wikipedia.org/w/api.php#Aria", "Aria", SourceStatus.PROCESADA, "CC BY-SA", "API MediaWiki", 5L)))

    private fun bytes(p: WorldPack = pack()): ByteArray = ByteArrayOutputStream().also { WorldpackCodec.write(p, it) }.toByteArray()
    private fun zip(files: Map<String, ByteArray>, order: List<String> = files.keys.toList()): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z -> for (n in order) { z.putNextEntry(ZipEntry(n)); z.write(files.getValue(n)); z.closeEntry() } }
        return out.toByteArray()
    }
    private fun rejected(data: ByteArray, contains: String) {
        try { WorldpackCodec.read(ByteArrayInputStream(data)); fail("Debía rechazarse: $contains") } catch (e: WorldpackException) { assertTrue("«${e.message}» no menciona «$contains»", e.message!!.contains(contains, ignoreCase = true)) }
    }

    @Test fun roundTripKeepsEverything() {
        val back = WorldpackCodec.read(ByteArrayInputStream(bytes()))
        assertEquals("Eldoria", back.world.name); assertEquals(3, back.world.revision); assertEquals(4, back.entries.size); assertEquals(1, back.sources.size)
        val aria = back.entries.first { it.name == "Aria" }
        assertEquals(Confidence.CONFIRMADO, aria.confidence); assertEquals(0, aria.sourceIndex); assertEquals(listOf("la capitana"), aria.aliases)
        assertEquals("CC BY-SA", back.sources[0].license)
    }

    @Test fun packContainsExpectedFilesAndNoSourceText() {
        val files = WorldpackSafety.read(ByteArrayInputStream(bytes()))
        assertTrue(files.keys.containsAll(listOf("manifest.json", "world.json", "lore.md", "characters.json", "locations.json", "timeline.json", "sources.json")))
        assertFalse(String(files.getValue("sources.json")).contains("textFile"))
    }

    @Test fun contradictionsAndConfidenceSurviveRoundTrip() {
        val p = pack(listOf(entry("Aria", conf = Confidence.CONTRADICCION, key = "Aria|edad"), entry("Rumor", conf = Confidence.AFICIONADOS), entry("Mito", conf = Confidence.INVENCION)))
        val back = WorldpackCodec.read(ByteArrayInputStream(bytes(p)))
        assertEquals(setOf(Confidence.CONTRADICCION, Confidence.AFICIONADOS, Confidence.INVENCION), back.entries.map { it.confidence }.toSet())
    }

    @Test fun zipSlipAndUnexpectedNamesAreRejected() {
        for (n in listOf("../evil.json", "/abs.json", "a/../../b.json", "world.json/../x", "..\\x.json", "extra.json", "dir/world.json"))
            rejected(zip(mapOf(n to "{}".toByteArray())), "")
    }

    @Test fun duplicateZipEntriesAreRejected() {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z -> repeat(2) { z.putNextEntry(ZipEntry("world.json")); z.write("{}".toByteArray()); z.closeEntry() } }
        rejected(out.toByteArray(), "repetido")
    }

    @Test fun missingRequiredFilesAreRejected() {
        val files = WorldpackSafety.read(ByteArrayInputStream(bytes())).toMutableMap()
        files.remove("world.json")
        rejected(zip(files), "world.json")
        val f2 = WorldpackSafety.read(ByteArrayInputStream(bytes())).toMutableMap(); f2.remove("manifest.json")
        rejected(zip(f2), "manifest.json")
    }

    @Test fun declaredFileMissingMeansIncomplete() {
        val files = WorldpackSafety.read(ByteArrayInputStream(bytes())).toMutableMap()
        files.remove("characters.json")
        rejected(zip(files), "incompleto")
    }

    @Test fun tamperedFileFailsChecksum() {
        val files = WorldpackSafety.read(ByteArrayInputStream(bytes())).toMutableMap()
        files["lore.md"] = "# otra cosa".toByteArray()
        rejected(zip(files), "suma de verificación")
    }

    @Test fun duplicateEntriesAreRejected() {
        rejected(bytes(pack(listOf(entry("Aria"), entry("Aria")))), "duplicadas")
    }

    @Test fun sameEntityFromDifferentSourcesIsAllowedSoContradictionsCanBeShown() {
        val p = WorldPack("0.5.0", 1L, world(), listOf(entry("Aria", key = "Aria|edad", src = 0), entry("Aria", key = "Aria|edad", src = 1)),
            listOf(PackSource(SourceKind.URL, "https://a.example/x", "A", SourceStatus.PROCESADA, "", "", null), PackSource(SourceKind.URL, "https://b.example/x", "B", SourceStatus.PROCESADA, "", "", null)))
        assertEquals(2, WorldpackCodec.read(ByteArrayInputStream(bytes(p))).entries.size)
    }

    @Test fun oversizedElementIsRejected() {
        val big = ByteArray(300_000) { 'a'.code.toByte() }
        try { WorldpackSafety.read(ByteArrayInputStream(zip(mapOf("lore.md" to big))), WorldpackSafety.Limits(maxFileBytes = 100_000)); fail() } catch (e: WorldpackException) { assertTrue(e.message!!.contains("demasiado grande")) }
    }

    @Test fun tooManyElementsAreRejected() {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z -> repeat(40) { z.putNextEntry(ZipEntry("x$it")); z.closeEntry() } }
        try { WorldpackSafety.read(ByteArrayInputStream(out.toByteArray())); fail() } catch (e: WorldpackException) { /* demasiados o nombre inesperado */ }
    }

    @Test fun garbageAndEmptyAreRejected() {
        rejected("esto no es un zip".toByteArray(), "")
        rejected(ByteArray(0), "vacío")
    }

    @Test fun newerFormatVersionIsRejectedWithClearMessage() {
        val files = WorldpackSafety.read(ByteArrayInputStream(bytes())).toMutableMap()
        val m = String(files.getValue("manifest.json")).replace("\"formatVersion\": 1", "\"formatVersion\": 9").replace("\"minReaderFormat\": 1", "\"minReaderFormat\": 9")
        files["manifest.json"] = m.toByteArray()
        rejected(zip(files, listOf("manifest.json") + files.keys.filter { it != "manifest.json" }), "más nueva")
    }

    @Test fun maliciousSourceSchemeIsRejected() {
        val p = WorldPack("0.5.0", 1L, world(), emptyList(), listOf(PackSource(SourceKind.URL, "javascript://alert(1)", "x", SourceStatus.PENDIENTE, "", "", null)))
        rejected(bytes(p), "esquema")
    }

    @Test fun invalidEnumValuesAreRejected() {
        val files = WorldpackSafety.read(ByteArrayInputStream(bytes())).toMutableMap()
        files["world.json"] = String(files.getValue("world.json")).replace("\"SIN_SPOILERS\"", "\"TODO_LIBRE\"").toByteArray()
        // el manifiesto ya no coincide: primero falla la suma; se reconstruye el manifiesto para probar la validación del contenido
        val p = pack()
        val broken = WorldPack("0.5.0", 1L, PackWorld(p.world.uuid, "x", "", "es", "", "", "", "", "TODO_LIBRE", CastMode.MIXTO, Continuity.FLEXIBLE, ResearchDepth.BASICA, "", "", "", 1), emptyList(), emptyList())
        rejected(bytes(broken), "no permitido")
    }

    @Test fun snapshotRoundTripKeepsLink() {
        val p = WorldPack("0.5.0", 1L, world(), listOf(entry("Aria")), emptyList(), link = PackLink(CastMode.CANONICO, Continuity.ESTRICTA, SpoilerLevel.COMPLETO, "Era 2"))
        val back = WorldpackCodec.decodeSnapshot(WorldpackCodec.encodeSnapshot(p))
        assertEquals(Continuity.ESTRICTA, back.link!!.continuityMode); assertEquals("Era 2", back.link!!.startEra); assertEquals(1, back.entries.size)
    }

    @Test fun snapshotGarbageIsRejected() {
        try { WorldpackCodec.decodeSnapshot("{\"format\":\"otra\"}".toByteArray()); fail() } catch (e: WorldpackException) { }
        try { WorldpackCodec.decodeSnapshot("no json".toByteArray()); fail() } catch (e: WorldpackException) { }
    }
}
