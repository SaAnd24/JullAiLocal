package com.jullai.local.chat

import com.jullai.local.engine.ChatMessage
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class ContextBuilderTest {
    // "Tokens" de prueba: una palabra = un token. La plantilla falsa añade 3 tokens por mensaje.
    private val count: suspend (String) -> Int = { text -> text.split(Regex("\\s+")).count { it.isNotEmpty() } }
    private val template: suspend (List<ChatMessage>) -> String = { msgs ->
        msgs.joinToString("\n") { "<${it.role}> a b ${it.content}" } + "\n<assistant>"
    }

    private fun words(n: Int, tag: String = "w") = (1..n).joinToString(" ") { "$tag$it" }

    private fun msg(role: String, n: Int, tag: String = "w") = ChatMessage(role, words(n, tag))

    private fun build(system: String, history: List<ChatMessage>, ctx: Int, maxResp: Int) = runBlocking {
        ContextBuilder.build(system, history, ctx, maxResp, count, template)
    }

    @Test fun everythingFitsKeepsAllMessagesInOrder() {
        val h = listOf(msg("user", 5, "a"), msg("assistant", 5, "b"), msg("user", 5, "c"))
        val r = build("Sé breve", h, ctx = 1000, maxResp = 200)
        assertEquals(0, r.droppedMessages)
        assertEquals(listOf("system", "user", "assistant", "user"), r.messages.map { it.role })
        assertTrue(r.prompt.endsWith("<assistant>"))
    }

    @Test fun oldestMessagesAreDroppedFirst() {
        val h = (1..10).flatMap { listOf(msg("user", 40, "u$it"), msg("assistant", 40, "a$it")) }
        val r = build("", h, ctx = 400, maxResp = 100)
        assertTrue("debe descartar mensajes antiguos", r.droppedMessages > 0)
        assertEquals("el último mensaje siempre se conserva", h.last(), r.messages.last())
        assertTrue("cabe en el presupuesto", r.promptTokens <= 400 - 100)
    }

    @Test fun trimmedConversationStartsWithUser() {
        val h = (1..10).flatMap { listOf(msg("user", 30, "u$it"), msg("assistant", 30, "a$it")) } + msg("user", 30, "last")
        val r = build("", h, ctx = 300, maxResp = 80)
        val firstNonSystem = r.messages.first { it.role != "system" }
        assertEquals("user", firstNonSystem.role)
    }

    @Test fun systemPromptIsAlwaysKept() {
        val h = (1..20).map { msg(if (it % 2 == 1) "user" else "assistant", 30, "m$it") } + msg("user", 10, "z")
        val r = build("instrucciones importantes", h, ctx = 300, maxResp = 80)
        assertEquals("system", r.messages.first().role)
        assertEquals("instrucciones importantes", r.messages.first().content)
    }

    @Test fun lastMessageTooLongThrows() {
        val h = listOf(msg("user", 500, "x"))
        try {
            build("", h, ctx = 300, maxResp = 100)
            fail("debía lanzar ContextOverflowException")
        } catch (e: ContextOverflowException) {
            assertTrue(e.message!!.isNotBlank())
        }
    }

    @Test fun responseReserveNeverExceedsHalfTheContext() {
        assertEquals(256, ContextBuilder.responseReserve(512, 2048))
        assertEquals(100, ContextBuilder.responseReserve(2048, 100))
    }

    @Test fun tinyContextThrowsInsteadOfLooping() {
        try {
            build("", listOf(msg("user", 1)), ctx = 40, maxResp = 100)
            fail("debía lanzar")
        } catch (e: ContextOverflowException) {
            // esperado
        }
    }

    @Test fun emptyHistoryIsRejected() {
        try {
            build("", emptyList(), 1000, 100)
            fail("debía lanzar")
        } catch (e: IllegalArgumentException) {
            // esperado
        }
    }
}
