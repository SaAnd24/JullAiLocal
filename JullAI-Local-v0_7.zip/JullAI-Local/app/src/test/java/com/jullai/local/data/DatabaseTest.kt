package com.jullai.local.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.jullai.local.engine.StoredModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class DatabaseTest {
    @get:Rule val tmp = TemporaryFolder()

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var repo: ChatRepository
    private var clock = 1_000L

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = ChatRepository(db) { clock++ }
    }

    @After fun tearDown() { db.close() }

    private fun conv(model: String? = "m.gguf") = runBlocking { repo.createConversation(ConversationDefaults(), model) }

    private fun stored(name: String, sha: String, default: Boolean = false) =
        StoredModel(name, name.removeSuffix(".gguf"), 100L, sha, 1L, default)

    // ---------- conversaciones y mensajes ----------

    @Test fun userMessageIsSavedBeforeGeneratingAndFirstMessageNamesTheConversation() = runBlocking {
        val id = conv()
        val (userId, assistantId) = repo.appendUserTurn(id, "Hola, cuéntame un cuento muy largo sobre un dragón que vive en la luna")
        val msgs = repo.history(id)
        assertEquals(2, msgs.size)
        assertEquals("user", msgs[0].role)
        assertEquals(MessageState.COMPLETE, msgs[0].state)
        assertEquals(MessageState.GENERATING, msgs[1].state)
        assertEquals(userId, msgs[0].id)
        assertEquals(assistantId, msgs[1].id)
        val title = repo.getConversation(id)!!.title
        assertTrue(title.startsWith("Hola, cuéntame un cuento"))
        assertTrue(title.length <= 41)
    }

    @Test fun titleIsNotOverwrittenBySecondMessage() = runBlocking {
        val id = conv()
        repo.appendUserTurn(id, "Primero")
        repo.finish(repo.history(id).last().id, "ok", MessageState.COMPLETE)
        repo.appendUserTurn(id, "Segundo")
        assertEquals("Primero", repo.getConversation(id)!!.title)
    }

    @Test fun partialResponseIsSavedAndSurvivesReopeningMarkedAsInterrupted() = runBlocking {
        val id = conv()
        val (_, a) = repo.appendUserTurn(id, "hola")
        repo.savePartial(a, "Texto parcial")
        // Simula cierre inesperado: la app arranca de nuevo.
        assertEquals(1, repo.markInterruptedOnStart())
        val m = repo.getMessage(a)!!
        assertEquals("Texto parcial", m.content)
        assertEquals(MessageState.INTERRUPTED, m.state)
    }

    @Test fun editingAUserMessageDiscardsLaterMessagesAndCreatesNewReply() = runBlocking {
        val id = conv()
        val (u1, a1) = repo.appendUserTurn(id, "uno")
        repo.finish(a1, "respuesta 1", MessageState.COMPLETE)
        val (_, a2) = repo.appendUserTurn(id, "dos")
        repo.finish(a2, "respuesta 2", MessageState.COMPLETE)
        assertEquals(4, repo.history(id).size)

        val newReply = repo.editUserMessage(u1, "uno editado")
        assertNotNull(newReply)
        val msgs = repo.history(id)
        assertEquals(2, msgs.size)
        assertEquals("uno editado", msgs[0].content)
        assertEquals(newReply, msgs[1].id)
        assertEquals("", msgs[1].content)
        assertEquals(MessageState.GENERATING, msgs[1].state)
        assertNull(repo.getMessage(a1))
        assertNull(repo.getMessage(a2))
    }

    @Test fun editingAnAssistantMessageIsRefused() = runBlocking {
        val id = conv()
        val (_, a) = repo.appendUserTurn(id, "uno")
        assertNull(repo.editUserMessage(a, "x"))
    }

    @Test fun onlyTheLastAssistantReplyCanBeRegenerated() = runBlocking {
        val id = conv()
        val (_, a1) = repo.appendUserTurn(id, "uno")
        repo.finish(a1, "r1", MessageState.COMPLETE)
        val (_, a2) = repo.appendUserTurn(id, "dos")
        repo.finish(a2, "r2", MessageState.COMPLETE)
        assertFalse(repo.resetAssistantForRegeneration(a1))
        assertEquals("r1", repo.getMessage(a1)!!.content)
        assertTrue(repo.resetAssistantForRegeneration(a2))
        val m = repo.getMessage(a2)!!
        assertEquals("", m.content)
        assertEquals(MessageState.GENERATING, m.state)
        assertEquals(4, repo.history(id).size)
    }

    @Test fun deletingConversationCascadesToMessagesOnly() = runBlocking {
        val a = conv(); val b = conv()
        repo.appendUserTurn(a, "a"); repo.appendUserTurn(b, "b")
        repo.delete(a)
        assertNull(repo.getConversation(a))
        assertEquals(0, repo.history(a).size)
        assertEquals(2, repo.history(b).size)
    }

    @Test fun renameTrimsAndFallsBackToDefault() = runBlocking {
        val id = conv()
        repo.rename(id, "  Mi historia  ")
        assertEquals("Mi historia", repo.getConversation(id)!!.title)
        repo.rename(id, "   ")
        assertEquals(ChatRepository.DEFAULT_TITLE, repo.getConversation(id)!!.title)
    }

    @Test fun conversationsAreListedMostRecentFirst() = runBlocking {
        val a = conv(); val b = conv()
        repo.appendUserTurn(a, "toca a")   // a pasa a ser la más reciente
        val list = repo.conversations().first()
        assertEquals(listOf(a, b), list.map { it.id })
    }

    // ---------- modelos ----------

    @Test fun removingAModelKeepsConversationsAndReassignsDefault() = runBlocking {
        val registry = ModelRegistry(db)
        registry.add(stored("a.gguf", "sha-a", default = true))
        registry.add(stored("b.gguf", "sha-b"))
        val id = repo.createConversation(ConversationDefaults(), "a.gguf")
        repo.appendUserTurn(id, "hola")

        registry.remove("a.gguf")

        val c = repo.getConversation(id)
        assertNotNull("la conversación NO se borra con el modelo", c)
        assertNull(c!!.modelFileName)
        assertEquals(2, repo.history(id).size)
        val left = registry.list()
        assertEquals(listOf("b.gguf"), left.map { it.fileName })
        assertTrue("el modelo restante pasa a ser el predeterminado", left.single().isDefault)
    }

    @Test fun duplicateShaIsNotInsertedTwice() = runBlocking {
        val registry = ModelRegistry(db)
        registry.add(stored("a.gguf", "same"))
        registry.add(stored("b.gguf", "same"))
        assertEquals(1, registry.count())
    }

    @Test fun legacyRegistryJsonIsMigratedWithoutLosingModels() = runBlocking {
        val dir = tmp.newFolder("models")
        File(dir, "uno.gguf").writeText("x"); File(dir, "dos.gguf").writeText("y")
        File(dir, "registry.json").writeText(
            """[{"fileName":"uno.gguf","displayName":"uno","sizeBytes":1,"sha256":"s1","importedAt":10,"isDefault":true},
               {"fileName":"dos.gguf","displayName":"dos","sizeBytes":1,"sha256":"s2","importedAt":20,"isDefault":false},
               {"fileName":"fantasma.gguf","displayName":"fantasma","sizeBytes":1,"sha256":"s3","importedAt":30,"isDefault":false}]""",
        )
        val registry = ModelRegistry(db)
        assertEquals(2, registry.migrateLegacyRegistry(dir))   // el archivo que ya no existe se ignora
        val list = registry.list()
        assertEquals(listOf("uno.gguf", "dos.gguf"), list.map { it.fileName })
        assertTrue(list.first { it.fileName == "uno.gguf" }.isDefault)
        assertFalse(File(dir, "registry.json").exists())
        assertTrue(File(dir, "registry.json.migrated").exists())
        assertEquals("segunda ejecución: nada que migrar", 0, registry.migrateLegacyRegistry(dir))
        assertEquals(2, registry.count())
    }

    @Test fun corruptLegacyRegistryIsLeftUntouched() = runBlocking {
        val dir = tmp.newFolder("models2")
        File(dir, "registry.json").writeText("esto no es json")
        val registry = ModelRegistry(db)
        assertEquals(0, registry.migrateLegacyRegistry(dir))
        assertTrue(File(dir, "registry.json").exists())
    }

    // ---------- ajustes ----------

    @Test fun settingsArePersistedInTheDatabase() = runBlocking {
        val s = AppSettings(threads = 3, defaultContext = 1024, reuseKvCache = false)
        db.settings().putAll(s.toMap().map { (k, v) -> SettingEntity(k, v) })
        val back = AppSettings.fromMap(db.settings().all().associate { it.settingKey to it.settingValue })
        assertEquals(s, back)
    }

    // ---------- persistencia al cerrar y reabrir ----------

    @Test fun dataSurvivesClosingAndReopeningTheDatabaseFile() = runBlocking {
        val name = "reopen-test.db"
        var file = Room.databaseBuilder(context, AppDatabase::class.java, name).allowMainThreadQueries().build()
        val r1 = ChatRepository(file)
        val id = r1.createConversation(ConversationDefaults(), "m.gguf")
        val (_, a) = r1.appendUserTurn(id, "persistente")
        r1.finish(a, "respuesta guardada", MessageState.COMPLETE)
        file.close()

        file = Room.databaseBuilder(context, AppDatabase::class.java, name).allowMainThreadQueries().build()
        val r2 = ChatRepository(file)
        val msgs = r2.history(id)
        assertEquals(listOf("persistente", "respuesta guardada"), msgs.map { it.content })
        file.close()
        context.deleteDatabase(name)
        Unit
    }
}
