package com.jullai.local.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.jullai.local.roleplay.CardParser
import com.jullai.local.roleplay.Swipes
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class RoleplayDatabaseTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: RoleplayRepository
    private var clock = 1_000L
    private val settings = AppSettings()

    @Before fun setUp() {
        val context: Context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = RoleplayRepository(db) { clock++ }
    }

    @After fun tearDown() { db.close() }

    private val card = """
      {"spec":"chara_card_v2","spec_version":"2.0","data":{"name":"Aria","description":"Elfa","personality":"Seria",
       "scenario":"Bosque","first_mes":"Hola, {{user}}","alternate_greetings":["Buenas, {{user}}","Salve"],
       "creator_notes":"privado","character_book":{"name":"Bosque","entries":[{"keys":["roble"],"content":"Sagrado"}]}}}"""

    private fun importAria(): Long = runBlocking { repo.importCard(CardParser.parseJson(card), "p_1.png") }

    @Test fun importCreatesCharacterAndLorebookTogether() = runBlocking {
        val id = importAria()
        val c = repo.character(id)!!
        assertEquals("Aria", c.name)
        assertEquals("privado", c.privateNotes)
        assertNotNull(c.lorebookId)
        assertEquals(1, repo.loreEntriesList(c.lorebookId!!).size)
    }

    @Test fun startSessionCreatesGreetingWithSwipes() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "Un bosque de noche", "Ana", "", settings, "m.gguf")
        val msgs = repo.history(sid)
        assertEquals(1, msgs.size)
        assertEquals("Hola, Ana", msgs[0].content)
        assertEquals(listOf("Hola, Ana", "Buenas, Ana", "Salve"), Swipes.parse(msgs[0].swipes))
        assertEquals("Un bosque de noche", repo.getSession(sid)!!.scenarioText)
    }

    @Test fun swipesRegenerateKeepsPreviousAnswer() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "", "Ana", "", settings, null)
        val (_, a) = repo.appendUserTurn(sid, "hola")
        repo.finish(a, "Respuesta 1", MessageState.COMPLETE)
        assertTrue(repo.prepareNewSwipe(a))
        repo.finish(a, "Respuesta 2", MessageState.COMPLETE)
        val m = repo.history(sid).last()
        assertEquals(listOf("Respuesta 1", "Respuesta 2"), Swipes.parse(m.swipes))
        assertEquals(1, m.swipeIndex)
        assertTrue(repo.selectSwipe(a, -1))
        assertEquals("Respuesta 1", repo.history(sid).last().content)
        assertFalse(repo.selectSwipe(a, -1))   // ya está en la primera
    }

    @Test fun onlyLastAssistantCanRegenerateOrContinue() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "", "Ana", "", settings, null)
        val (_, a1) = repo.appendUserTurn(sid, "uno"); repo.finish(a1, "r1", MessageState.COMPLETE)
        val (_, a2) = repo.appendUserTurn(sid, "dos"); repo.finish(a2, "r2", MessageState.COMPLETE)
        assertFalse(repo.prepareNewSwipe(a1))
        assertNull(repo.prepareContinuation(a1))
        assertEquals("r2", repo.prepareContinuation(a2))
        assertEquals(MessageState.GENERATING, repo.history(sid).last().state)
    }

    @Test fun editingUserMessageDiscardsLaterMessages() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "", "Ana", "", settings, null)
        val (u1, a1) = repo.appendUserTurn(sid, "uno"); repo.finish(a1, "r1", MessageState.COMPLETE)
        val (_, a2) = repo.appendUserTurn(sid, "dos"); repo.finish(a2, "r2", MessageState.COMPLETE)
        val newA = repo.editUserMessage(u1, "uno editado")!!
        val list = repo.history(sid)
        assertEquals(listOf("Hola, Ana", "uno editado", ""), list.map { it.content })
        assertEquals(newA, list.last().id)
    }

    @Test fun interruptedGenerationKeepsPartialText() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "", "Ana", "", settings, null)
        val (_, a) = repo.appendUserTurn(sid, "hola")
        repo.savePartial(a, "texto parcial")
        assertEquals(1, repo.markInterruptedOnStart())
        val m = repo.history(sid).last()
        assertEquals("texto parcial", m.content)
        assertEquals(MessageState.INTERRUPTED, m.state)
    }

    @Test fun deleteLastMessageUndoesATurn() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "", "Ana", "", settings, null)
        val (_, a) = repo.appendUserTurn(sid, "hola"); repo.finish(a, "r", MessageState.COMPLETE)
        assertTrue(repo.deleteLastMessage(sid))
        assertEquals(2, repo.history(sid).size)
    }

    @Test fun deletingCharacterDeletesItsSessionsAndOrphanLorebookButNotChats() = runBlocking {
        val chats = ChatRepository(db) { clock++ }
        val conv = chats.createConversation(ConversationDefaults(), null)
        val id = importAria()
        val c = repo.character(id)!!
        val sid = repo.startSession(c, "", "Ana", "", settings, null)
        val bookId = c.lorebookId!!
        assertEquals("p_1.png", repo.deleteCharacter(id))
        assertNull(repo.getSession(sid))
        assertNull(db.lorebooks().get(bookId))
        assertNotNull(chats.getConversation(conv))
    }

    @Test fun sharedLorebookSurvivesDeletingOneCharacter() = runBlocking {
        val a = repo.character(importAria())!!
        val b = repo.character(importAria())!!
        repo.linkLorebook(b.id, a.lorebookId!!)
        repo.deleteCharacter(a.id)
        assertNotNull(db.lorebooks().get(a.lorebookId!!))
    }

    @Test fun duplicateCopiesLorebookIndependently() = runBlocking {
        val a = repo.character(importAria())!!
        val copyId = repo.duplicateCharacter(a.id, null)!!
        val copy = repo.character(copyId)!!
        assertTrue(copy.name.endsWith("(copia)"))
        assertTrue(copy.lorebookId != a.lorebookId)
        assertEquals(1, repo.loreEntriesList(copy.lorebookId!!).size)
    }

    @Test fun exportThenImportRoundTrip() = runBlocking {
        val a = repo.character(importAria())!!
        val json = repo.exportJson(a.id)!!
        val again = repo.character(repo.importCard(CardParser.parseJson(json), null))!!
        assertEquals(a.name, again.name)
        assertEquals(a.privateNotes, again.privateNotes)
        assertEquals(a.alternateGreetings, again.alternateGreetings)
        assertEquals(1, repo.loreEntriesList(again.lorebookId!!).size)
    }

    @Test fun deletingModelKeepsSessionsButClearsModel() = runBlocking {
        val c = repo.character(importAria())!!
        val sid = repo.startSession(c, "", "Ana", "", settings, "m.gguf")
        db.roleSessions().clearModel("m.gguf")
        assertNull(repo.getSession(sid)!!.modelFileName)
    }

    @Test fun knowledgeIsPerSession() = runBlocking {
        val c = repo.character(importAria())!!
        val s1 = repo.startSession(c, "", "Ana", "", settings, null)
        val s2 = repo.startSession(c, "", "Ana", "", settings, null)
        repo.addKnowledge(s1, "SECRETO", "algo")
        assertEquals(1, repo.knowledgeList(s1).size)
        assertEquals(0, repo.knowledgeList(s2).size)
        repo.deleteSession(s1)
        assertEquals(0, db.knowledge().list(s1).size)
    }

    @Test fun sessionListJoinsCharacter() = runBlocking {
        val c = repo.character(importAria())!!
        repo.startSession(c, "", "Ana", "", settings, null)
        val list = repo.sessions().first()
        assertEquals("Aria", list[0].characterName)
        assertEquals("p_1.png", list[0].portraitFile)
    }
}
