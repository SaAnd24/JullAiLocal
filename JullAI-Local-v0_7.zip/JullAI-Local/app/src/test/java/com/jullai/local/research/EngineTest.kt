package com.jullai.local.research

import com.jullai.local.data.AddResult
import com.jullai.local.data.CanonImageEntity
import com.jullai.local.data.ResearchStore
import com.jullai.local.data.ResearchTaskEntity
import com.jullai.local.data.SourceEntity
import com.jullai.local.data.WorldEntity
import com.jullai.local.data.WorldIdentityEntity
import com.jullai.local.discovery.FakeWiki
import com.jullai.local.discovery.WikiFetchException
import com.jullai.local.world.DraftEntry
import com.jullai.local.world.TaskStatus
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Almacén en memoria: prueba el flujo del motor (fases, idempotencia, reintentos), no Room. */
class MemStore(val world: WorldEntity) : ResearchStore {
    val tasks = HashMap<Long, ResearchTaskEntity>()
    val sources = ArrayList<SourceEntity>()
    val drafts = ArrayList<DraftEntry>()
    var identity: WorldIdentityEntity? = null
    val images = HashMap<String, CanonImageEntity>()
    var priorChars = ""
    override suspend fun task(id: Long) = tasks[id]
    override suspend fun saveTask(t: ResearchTaskEntity) { tasks[t.id] = t }
    override suspend fun world(id: Long) = world
    override suspend fun mergePriorities(worldId: Long, characters: List<String>, places: List<String>) { priorChars += characters.joinToString(",") }
    override suspend fun sourcesOf(worldId: Long) = sources.toList()
    override fun sourceText(s: SourceEntity): String? = null
    override suspend fun addSource(worldId: Long, kind: String, uri: String, title: String, status: String, error: String): Long {
        if (sources.none { it.uri == uri }) sources.add(SourceEntity(id = sources.size + 1L, worldId = worldId, kind = kind, uri = uri, title = title, status = status, error = error, createdAt = 0, updatedAt = 0))
        return sources.first { it.uri == uri }.id
    }
    private fun upd(id: Long, f: (SourceEntity) -> SourceEntity) { val i = sources.indexOfFirst { it.id == id }; sources[i] = f(sources[i]) }
    override suspend fun markSourceProcessed(id: Long, title: String, text: String, license: String, provenance: String, taskId: Long?) = upd(id) { it.copy(status = "PROCESADA", title = title, license = license) }
    override suspend fun markSourceFailed(id: Long, status: String, error: String, taskId: Long?) = upd(id) { it.copy(status = status, error = error, attempts = it.attempts + 1) }
    override suspend fun addDrafts(worldId: Long, drafts: List<DraftEntry>): AddResult {
        var c = 0
        for (d in drafts) if (this.drafts.none { it.name == d.name && it.type == d.type }) { this.drafts.add(d); c++ }
        return AddResult(c, drafts.size - c)
    }
    override suspend fun detectContradictions(worldId: Long) = 0
    override suspend fun entryCount(worldId: Long) = drafts.size
    override suspend fun identity(worldId: Long) = identity
    override suspend fun saveIdentity(e: WorldIdentityEntity) { identity = e }
    override suspend fun savePlan(worldId: Long, planJson: String, notes: String) { identity = identity?.copy(planJson = planJson, notes = notes) }
    override suspend fun canonImage(worldId: Long, name: String) = images[name]
    override suspend fun saveCanonImage(e: CanonImageEntity) { images[e.entryName] = e }
}

class EngineTest {
    private val world = WorldEntity(id = 1, uuid = "u", name = "The Walking Dead", language = "en", allowOnline = true, createdAt = 0, updatedAt = 0)
    private val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A) + ByteArray(3000)

    private fun handler(api: String, q: String): String? = when {
        !api.contains("wikipedia.org") -> null
        q.contains("generator=search") -> """{"query":{"pages":[{"pageid":1,"title":"The Walking Dead (TV series)","index":1,"pageprops":{"wikibase-shortdesc":"American post-apocalyptic horror drama television series","wikibase_item":"Q1"},"extract":"x"}]}}"""
        q.contains("list=search") -> """{"query":{"search":[{"title":"List of The Walking Dead (TV series) characters"}]}}"""
        q.contains("action=parse") -> """{"parse":{"title":"x","sections":[{"toclevel":1,"level":"2","line":"Main characters","index":"1"},{"toclevel":2,"level":"3","line":"Rick Grimes","index":"2"}]}}"""
        q.contains("prop=pageimages") -> """{"query":{"pages":[{"pageid":3,"title":"Rick Grimes","thumbnail":{"source":"https://upload.wikimedia.org/wikipedia/en/thumb/a/ab/Rick.png/600px-Rick.png","width":600,"height":800},"pageimage":"Rick.png"}]}}"""
        q.contains("prop=imageinfo") -> """{"query":{"pages":[{"title":"File:Rick.png","imageinfo":[{"url":"https://upload.wikimedia.org/wikipedia/en/a/ab/Rick.png","mime":"image/png","size":12345,"extmetadata":{"LicenseShortName":{"value":"Fair use"},"NonFree":{"value":"true"}}}]}]}}"""
        q.contains("prop=info") -> """{"query":{"pages":[{"pageid":3,"title":"Rick Grimes"}]}}"""
        q.contains("prop=extracts") -> """{"query":{"pages":[{"pageid":5,"title":"The Walking Dead (TV series)","extract":"Intro.\n\n== Cast ==\nAndrew Lincoln as Rick Grimes, sheriff\n"}]}}"""
        else -> null
    }

    private val provider = object : SourceProvider {
        override val id = "fake"
        override fun canHandle(source: SourceEntity) = source.uri.startsWith("mw:")
        override suspend fun fetch(source: SourceEntity): FetchResult {
            val title = source.uri.substringAfter('#')
            return FetchResult.Ok(title, "$title es un personaje o una obra de ficción con una introducción suficientemente larga para ser válida.\n\n== Apariencia ==\nPelo castaño y barba.\n\n== Historia ==\nSe despierta en un hospital.", "CC-BY-SA", "fake")
        }
    }

    private fun setup(wiki: FakeWiki): Pair<MemStore, ResearchEngine> {
        val store = MemStore(world)
        store.tasks[1] = ResearchTaskEntity(id = 1, worldId = 1, createdAt = 0, updatedAt = 0)
        val saved = ArrayList<Int>()
        val auto = AutoDiscovery(wiki, saveImage = { b -> saved.add(b.size); "p_${saved.size}.png" })
        return store to ResearchEngine(store, listOf(provider), null, auto)
    }

    @Test fun fullRunIdentifiesPlansReadsAndCachesImages() = runBlocking {
        val wiki = FakeWiki(::handler).also { it.bytesFor = { png } }
        val (store, engine) = setup(wiki)
        val out = engine.run(1)
        assertEquals(TaskStatus.COMPLETADA, out.status)
        assertEquals("Q1", store.identity!!.qid)
        assertTrue(store.sources.any { it.uri.contains("Rick Grimes") })
        assertTrue(store.drafts.any { it.name == "Rick Grimes" })
        val img = store.images["Rick Grimes"]
        assertNotNull(img); assertEquals("OK", img!!.state); assertTrue(img.nonFree); assertTrue(img.license.contains("no libre"))
        assertTrue(wiki.calls.all { it.startsWith("https://") })
    }

    @Test fun secondRunDoesNotDuplicateAnything() = runBlocking {
        val wiki = FakeWiki(::handler).also { it.bytesFor = { png } }
        val (store, engine) = setup(wiki)
        engine.run(1)
        val s = store.sources.size; val d = store.drafts.size
        store.tasks[1] = store.tasks[1]!!.copy(status = TaskStatus.PENDIENTE, phase = "PENDIENTE")
        val calls = wiki.calls.size
        engine.run(1)
        assertEquals(s, store.sources.size); assertEquals(d, store.drafts.size)
        assertTrue("no repite búsqueda de obra", wiki.calls.drop(calls).none { it.contains("generator=search") })
        assertTrue("no vuelve a pedir imágenes ya guardadas", wiki.calls.drop(calls).none { it.contains("prop=pageimages") })
    }

    @Test fun offlineFailureIsRetriedNotReportedAsSuccess() = runBlocking {
        val wiki = FakeWiki { _, _ -> throw WikiFetchException("Sin conexión", true) }
        val (store, engine) = setup(wiki)
        val out = engine.run(1)
        assertTrue(out.retry); assertEquals(TaskStatus.PENDIENTE, out.status)
        assertEquals(0, store.drafts.size)
    }

    @Test fun unknownWorkEndsWithoutResultsHonestly() = runBlocking {
        val wiki = FakeWiki { _, q -> if (q.contains("generator=search")) """{"query":{"pages":[]}}""" else null }
        val (_, engine) = setup(wiki)
        val out = engine.run(1)
        assertEquals(TaskStatus.SIN_RESULTADOS, out.status)
    }

    @Test fun badImageIsRecordedAsFailedAndDoesNotBreakTheRun() = runBlocking {
        val wiki = FakeWiki(::handler).also { it.bytesFor = { "<html>no</html>".toByteArray() + ByteArray(3000) } }
        val (store, engine) = setup(wiki)
        val out = engine.run(1)
        assertEquals(TaskStatus.COMPLETADA, out.status)
        assertEquals("FALLIDA", store.images["Rick Grimes"]!!.state)
    }

    @Test fun cancelledTaskStops() = runBlocking {
        val (store, engine) = setup(FakeWiki(::handler))
        store.tasks[1] = store.tasks[1]!!.copy(status = TaskStatus.CANCELADA)
        assertEquals(TaskStatus.CANCELADA, engine.run(1).status)
    }
}
