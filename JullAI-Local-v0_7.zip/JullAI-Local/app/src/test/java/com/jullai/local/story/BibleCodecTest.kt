package com.jullai.local.story

import com.jullai.local.roleplay.MiniJson
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BibleCodecTest {
    private val png = byteArrayOf(0x89.toByte(), 'P'.code.toByte(), 'N'.code.toByte(), 'G'.code.toByte(), 13, 10, 26, 10, 1, 2, 3, 4, 5)

    fun sample(): Bible = Bible(
        manifest = BibleManifest(appVersion = "0.4.0", exportedAt = 1_700_000_000_000, title = "Mi partida", counts = emptyMap(), assets = emptyList()),
        character = BCharacter("Aria", listOf("La elfa"), "Alta", "Seria", "Formal", "Historia", "Proteger", "Té", "Nunca rompe el personaje", "Desconocidos",
            "Bosque", "Hola, {{user}}", listOf("Salve"), "ej", "NOTA PRIVADA SECRETA", listOf("elfa", "fantasía"), "yo", "portrait1"),
        lorebook = BLorebook("Bosque", "desc", 4, listOf(BLoreEntry("Roble", listOf("roble"), emptyList(), "Sagrado", true, false, false, false, 10, 100))),
        session = BSession("Partida 1", "Un bosque", "Ana", "Una viajera", "Reglas", "Resumen actual", 0.85f, 0.92f, 384, 4096, 10, 20, 5),
        messages = listOf(
            BMessage(11, "assistant", "Hola, Ana", 0, 1, "COMPLETE", listOf("Hola, Ana", "Salve"), 0),
            BMessage(12, "user", "Hola *sonríe*", 1, 2, "COMPLETE", emptyList(), 0),
            BMessage(13, "assistant", "parcial", 2, 3, "GENERATING", emptyList(), 0),
        ),
        knowledge = listOf(BKnowledge("SECRETO", "Aria es la heredera", 3)),
        memories = listOf(
            BMemory(1, "La llave está bajo el roble", 5, "día 1", Origin.USUARIO, Verification.CONFIRMADO, ItemState.ACTIVO, true, listOf("Gorm"), 12, "nota", 5, 6),
            BMemory(2, "Aria oculta algo", 2, "", Origin.INFERENCIA, Verification.INFERIDO, ItemState.PROPUESTO, false, emptyList(), null, "", 5, 6),
        ),
        summaries = listOf(BSummary(1, "v1", Origin.MODELO, 4, "", 7), BSummary(2, "v2", Origin.USUARIO, 4, "", 8)),
        timeline = listOf(BTimeline(1, "Tormenta", "día 2", 20, listOf("Aria"), Origin.USUARIO, ItemState.ACTIVO, 11, 9)),
        relationships = listOf(BRelationship(1, "Aria", "Ana", 40, 30, 55, 10, "aliadas", "", 1, 2)),
        relEvents = listOf(BRelEvent(1, EventState.APLICADO, Origin.MODELO, "Le ayudó", 2, 0, 1, 0, 42, 30, 56, 10, 12, 3)),
        volumes = listOf(BVolume(1, 1, "Vol 1", VolumeState.ABIERTO, "", 1, null)),
        chapters = listOf(BChapter(1, 1, 1, "Cap 1", ChapterState.ABIERTO, 0, null, "", "", NovelState.NINGUNA, 1, null)),
        assets = mapOf("portrait1" to png),
    )

    private fun bytes(b: Bible): ByteArray = ByteArrayOutputStream().also { BibleCodec.write(b, it) }.toByteArray()
    private fun read(b: ByteArray) = BibleCodec.read(ByteArrayInputStream(b))

    @Test fun roundTripKeepsEverything() {
        val src = sample()
        val back = read(bytes(src))
        assertEquals(src.character, back.character)
        assertEquals(src.lorebook, back.lorebook)
        assertEquals(src.session, back.session)
        assertEquals(src.memories, back.memories)
        assertEquals(src.summaries, back.summaries)
        assertEquals(src.timeline, back.timeline)
        assertEquals(src.relationships, back.relationships)
        assertEquals(src.relEvents, back.relEvents)
        assertEquals(src.volumes, back.volumes)
        assertEquals(src.chapters, back.chapters)
        assertEquals(src.knowledge, back.knowledge)
        assertArrayEquals(png, back.assets["portrait1"])
        // la respuesta que se estaba generando pasa a interrumpida
        assertEquals(listOf("COMPLETE", "COMPLETE", "INTERRUPTED"), back.messages.map { it.state })
        assertEquals(src.messages.map { it.content }, back.messages.map { it.content })
        assertEquals(listOf("Hola, Ana", "Salve"), back.messages[0].swipes)
    }

    @Test fun containerHasExpectedFilesAndNoModels() {
        val files = BibleCodec.encode(sample())
        assertTrue(files.keys.containsAll(listOf("manifest.json", "biblia.md", "data/personaje.json", "data/mensajes.json", "assets/portrait1.png")))
        assertFalse(files.keys.any { it.endsWith(".gguf") })
        val m = MiniJson.parse(String(files.getValue("manifest.json"))) as com.jullai.local.roleplay.JObj
        assertEquals("jullai-biblia", (m.fields["format"] as com.jullai.local.roleplay.JStr).v)
    }

    @Test fun readableBibleExcludesPrivateNotesButDataKeepsThem() {
        val files = BibleCodec.encode(sample())
        val md = String(files.getValue("biblia.md"))
        assertFalse(md.contains("NOTA PRIVADA"))
        assertTrue(md.contains("solo de lectura"))
        assertTrue(md.contains("La llave está bajo el roble"))
        assertTrue(String(files.getValue("data/personaje.json")).contains("NOTA PRIVADA SECRETA"))
    }

    @Test fun editingReadableBibleDoesNotChangeImportedData() {
        val files = BibleCodec.encode(sample())
        val edited = LinkedHashMap(files); edited["biblia.md"] = "# TOTALMENTE DISTINTO".toByteArray()
        assertEquals(sample().memories, BibleCodec.decode(edited).memories)
    }

    @Test fun previewCountsOnlyActiveAndPending() {
        val pv = BiblePreview.of(sample())
        assertEquals(1, pv.memories); assertEquals(1, pv.pendingProposals); assertTrue(pv.hasPortrait)
    }

    private fun mutate(name: String, f: (String) -> String): Map<String, ByteArray> {
        val files = LinkedHashMap(BibleCodec.encode(sample()))
        files[name] = f(String(files.getValue(name))).toByteArray()
        return files
    }

    private fun expectFail(files: Map<String, ByteArray>, contains: String) {
        try { BibleCodec.decode(files); fail("debía rechazarse: $contains") } catch (e: BibleException) { assertTrue(e.message, e.message!!.contains(contains)) }
    }

    @Test fun rejectsWrongFormatAndNewerVersion() {
        expectFail(mutate("manifest.json") { it.replace("jullai-biblia", "otra-cosa") }, "no es una partida")
        expectFail(mutate("manifest.json") { it.replace("\"minReaderFormat\": 1", "\"minReaderFormat\": 9") }, "más nueva")
    }

    @Test fun rejectsCorruptedAsset() {
        val files = LinkedHashMap(BibleCodec.encode(sample())); files["assets/portrait1.png"] = png + byteArrayOf(9)
        expectFail(files, "suma de verificación")
    }

    @Test fun rejectsMissingAssetAndMissingRequiredFile() {
        val a = LinkedHashMap(BibleCodec.encode(sample())); a.remove("assets/portrait1.png"); expectFail(a, "Falta el recurso")
        val b = LinkedHashMap(BibleCodec.encode(sample())); b.remove("data/mensajes.json"); expectFail(b, "Falta data/mensajes.json")
    }

    @Test fun rejectsCountMismatchTruncation() {
        expectFail(mutate("manifest.json") { it.replace("\"mensajes\": 3", "\"mensajes\": 4") }, "no coincide con el manifiesto")
    }

    @Test fun rejectsInvalidValues() {
        expectFail(mutate("data/memoria.json") { it.replace("\"importance\": 5", "\"importance\": 9") }, "fuera de rango")
        expectFail(mutate("data/memoria.json") { it.replace("CONFIRMADO_POR_USUARIO", "SUPER_VERDAD") }, "valor desconocido")
        expectFail(mutate("data/relaciones.json") { it.replace("\"trust\": 40", "\"trust\": 0") }, "fuera de rango")
        expectFail(mutate("data/mensajes.json") { it.replace("\"orderIndex\": 1", "\"orderIndex\": 0") }, "repetida")
        expectFail(mutate("data/mensajes.json") { it.replace("\"role\": \"user\"", "\"role\": \"system\"") }, "valor desconocido")
        expectFail(mutate("data/memoria.json") { it.replace("\"id\": 2,", "\"id\": 1,") }, "repetidos")
        expectFail(mutate("data/relaciones.json") { it.replace("\"relationshipId\": 1", "\"relationshipId\": 77") }, "no existe")
        expectFail(mutate("data/estructura.json") { it.replace("\"volumeId\": 1", "\"volumeId\": 5") }, "no existe")
        expectFail(mutate("data/partida.json") { "[1,2" }, "JSON válido")
    }

    @Test fun danglingMessageReferenceBecomesWarningNotFailure() {
        val b = BibleCodec.decode(mutate("data/memoria.json") { it.replace("\"sourceMessageId\": 12", "\"sourceMessageId\": 999") })
        assertNull(b.memories[0].sourceMessageSrcId)
        assertTrue(b.warnings.any { it.contains("mensaje de origen") })
    }

    @Test fun oldBibleWithoutOptionalFilesStillImports() {
        val files = LinkedHashMap(BibleCodec.encode(sample()))
        for (n in listOf("conocimiento", "memoria", "relaciones", "estructura")) files.remove("data/$n.json")
        files["manifest.json"] = String(files.getValue("manifest.json")).replace(Regex("\"counts\": \\{[^}]*\\}"), "\"counts\": {}").toByteArray()
        val b = BibleCodec.decode(files)
        assertTrue(b.memories.isEmpty() && b.relationships.isEmpty()); assertNotNull(b.character)
    }

    // ---------------- ZIP malicioso ----------------

    /** Escribe un ZIP «a mano» (permite nombres repetidos o raros que ZipOutputStream no deja crear). */
    private fun rawZip(entries: List<Pair<String, ByteArray>>): ByteArray {
        val out = ByteArrayOutputStream()
        fun le(v: Int, n: Int) { for (i in 0 until n) out.write((v shr (8 * i)) and 0xFF) }
        for ((name, data) in entries) {
            val crc = CRC32().also { it.update(data) }.value
            le(0x04034b50, 4); le(20, 2); le(0, 2); le(0, 2); le(0, 2); le(0, 2)
            le(crc.toInt(), 4); le(data.size, 4); le(data.size, 4)
            val nb = name.toByteArray(); le(nb.size, 2); le(0, 2)
            out.write(nb); out.write(data)
        }
        return out.toByteArray()
    }

    private fun rejectsZip(bytes: ByteArray, contains: String) {
        try { BibleCodec.read(ByteArrayInputStream(bytes)); fail("debía rechazarse") } catch (e: BibleException) { assertTrue(e.message, e.message!!.contains(contains)) }
    }

    @Test fun rejectsZipSlipAndAbsolutePaths() {
        rejectsZip(rawZip(listOf("../evil.json" to "{}".toByteArray())), "rutas no permitidas")
        rejectsZip(rawZip(listOf("data/../../evil.json" to "{}".toByteArray())), "rutas no permitidas")
        rejectsZip(rawZip(listOf("/etc/passwd" to "x".toByteArray())), "rutas no permitidas")
        rejectsZip(rawZip(listOf("..\\evil.json" to "{}".toByteArray())), "rutas no permitidas")
        rejectsZip(rawZip(listOf("C:/evil.json" to "{}".toByteArray())), "rutas no permitidas")
        rejectsZip(rawZip(listOf("data//partida.json" to "{}".toByteArray())), "rutas no permitidas")
    }

    @Test fun rejectsDuplicatesEvenWithOtherCase() {
        rejectsZip(rawZip(listOf("manifest.json" to "{}".toByteArray(), "manifest.json" to "{}".toByteArray())), "repetido")
        rejectsZip(rawZip(listOf("manifest.json" to "{}".toByteArray(), "MANIFEST.JSON" to "{}".toByteArray())), "inesperado")
    }

    @Test fun rejectsUnexpectedFilesIncludingModels() {
        rejectsZip(rawZip(listOf("modelo.gguf" to ByteArray(10))), "inesperado")
        rejectsZip(rawZip(listOf("data/otro.json" to "{}".toByteArray())), "inesperado")
        rejectsZip(rawZip(listOf("assets/x.exe" to ByteArray(10))), "inesperado")
        rejectsZip(rawZip(listOf("assets/sub/x.png" to ByteArray(10))), "inesperado")
    }

    @Test fun rejectsCompressionBombWithoutHugeAllocation() {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            z.putNextEntry(ZipEntry("data/mensajes.json"))
            val chunk = ByteArray(1024 * 1024)
            repeat(200) { z.write(chunk) }          // 200 MB de ceros comprimen a unos cientos de KB
            z.closeEntry()
        }
        assertTrue("el ZIP malicioso es pequeño", out.size() < 2_000_000)
        rejectsZip(out.toByteArray(), "demasiado grande")
    }

    @Test fun rejectsTooManyEntriesGarbageAndEmpty() {
        rejectsZip(rawZip((1..70).map { "assets/a$it.png" to ByteArray(3) }), "demasiados")
        rejectsZip("esto no es un zip".toByteArray(), "vacío")
        rejectsZip(ByteArray(0), "vacío")
        val good = bytes(sample())
        try { BibleCodec.read(ByteArrayInputStream(good.copyOf(good.size / 2))); fail("truncado debía fallar") } catch (e: BibleException) { }
    }

    @Test fun smallLimitsAreHonoured() {
        val z = rawZip(listOf("manifest.json" to ByteArray(2000)))
        try { ZipSafety.read(ByteArrayInputStream(z), ZipSafety.Limits(maxJsonBytes = 1000)); fail() } catch (e: BibleException) { assertTrue(e.message!!.contains("demasiado grande")) }
    }
}
