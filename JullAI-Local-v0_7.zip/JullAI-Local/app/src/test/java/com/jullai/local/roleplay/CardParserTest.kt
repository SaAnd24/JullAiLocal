package com.jullai.local.roleplay

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.CRC32
import java.util.zip.Deflater

class CardParserTest {
    private val v2 = """
    {"spec":"chara_card_v2","spec_version":"2.0","data":{
      "name":"Aria","description":"Una arquera elfa.","personality":"Seria y leal.","scenario":"Un bosque de noche.",
      "first_mes":"Hola, {{user}}. Soy {{char}}.","mes_example":"<START>\n{{user}}: Hola\n{{char}}: Salve.",
      "creator_notes":"NOTA SECRETA DEL CREADOR","system_prompt":"Habla poco.","post_history_instructions":"Sé breve.",
      "alternate_greetings":["Otro saludo","Y otro"],"tags":["elfa","fantasia"],"creator":"Yo",
      "character_book":{"name":"Bosque","scan_depth":3,"entries":[
        {"keys":["árbol","roble"],"content":"El roble es sagrado.","enabled":true,"insertion_order":5,"priority":20,"name":"Roble"},
        {"keys":["/reg.*/"],"content":"Clave tipo regex.","enabled":true},
        {"keys":[],"content":"Sin claves","enabled":true},
        {"keys":["x"],"content":"","enabled":true}
      ]}}}"""

    @Test fun parsesV2Fields() {
        val c = CardParser.parseJson(v2)
        assertEquals("V2", c.format)
        assertEquals("Aria", c.character.name)
        assertEquals("Una arquera elfa.", c.character.appearance)
        assertEquals("Seria y leal.", c.character.personality)
        assertEquals(listOf("Otro saludo", "Y otro"), c.character.alternateGreetings)
        assertEquals("NOTA SECRETA DEL CREADOR", c.character.privateNotes)
        assertEquals("Habla poco.\n\nSé breve.", c.character.behaviorInstructions)
        assertEquals(listOf("elfa", "fantasia"), c.character.tags)
    }

    @Test fun parsesEmbeddedLorebookAndWarns() {
        val c = CardParser.parseJson(v2)
        val book = c.lorebook!!
        assertEquals("Bosque", book.name)
        assertEquals(3, book.scanDepth)
        assertEquals(2, book.entries.size)          // se omiten la vacía y la sin claves
        assertEquals(listOf("árbol", "roble"), book.entries[0].keys)
        assertEquals(20, book.entries[0].priority)
        assertTrue(c.warnings.any { it.contains("regulares") })
        assertTrue(c.warnings.any { it.contains("omitieron") })
        assertTrue(c.warnings.any { it.contains("system_prompt") })
    }

    @Test fun parsesV1() {
        val c = CardParser.parseJson("""{"name":"Bob","description":"Tipo","personality":"Alegre","scenario":"Bar","first_mes":"Hola","mes_example":"x"}""")
        assertEquals("V1", c.format)
        assertEquals("Bob", c.character.name)
        assertEquals("Hola", c.character.firstMessage)
    }

    @Test fun parsesV3ReadsNickname() {
        val c = CardParser.parseJson("""{"spec":"chara_card_v3","spec_version":"3.0","data":{"name":"Luz","nickname":"Lu","description":"d"}}""")
        assertEquals("V3", c.format)
        assertEquals(listOf("Lu"), c.character.aliases)
    }

    @Test fun rejectsBrokenAndUnknown() {
        listOf(
            "{esto no es json", "[]", "\"hola\"", """{"foo":1}""",
            """{"spec":"chara_card_v9","data":{"name":"a"}}""", """{"spec":"chara_card_v2"}""", """{"spec":"chara_card_v2","data":{}}""",
            "",
        ).forEach {
            try { CardParser.parseJson(it); fail("debía fallar: $it") } catch (e: CardException) { assertTrue(e.message!!.isNotBlank()) }
        }
    }

    @Test fun deepNestingDoesNotOverflowStack() {
        val bomb = "[".repeat(100_000) + "]".repeat(100_000)
        try { CardParser.parseJson(bomb); fail() } catch (e: CardException) { assertTrue(e.message!!.contains("profundo")) }
    }

    @Test fun hugeFieldIsTruncatedWithWarning() {
        val big = "a".repeat(CardLimits.MAX_FIELD_CHARS + 5000)
        val c = CardParser.parseJson("""{"spec":"chara_card_v2","data":{"name":"N","description":"$big"}}""")
        assertEquals(CardLimits.MAX_FIELD_CHARS, c.character.appearance.length)
        assertTrue(c.warnings.any { it.contains("recortó") })
    }

    @Test fun controlCharactersAreStripped() {
        val c = CardParser.parseJson("{\"name\":\"A\\u0000B\\u0007\",\"description\":\"x\\r\\ny\\u0001\"}")
        assertEquals("AB", c.character.name)
        assertEquals("x\ny", c.character.appearance)
    }

    @Test fun manyGreetingsAreCapped() {
        val gs = (1..100).joinToString(",") { "\"g$it\"" }
        val c = CardParser.parseJson("""{"spec":"chara_card_v2","data":{"name":"N","description":"d","alternate_greetings":[$gs]}}""")
        assertEquals(CardLimits.MAX_GREETINGS, c.character.alternateGreetings.size)
        assertTrue(c.warnings.any { it.contains("saludos") })
    }

    @Test fun ownFormatRoundTrips() {
        val orig = CardParser.parseJson(v2)
        val json = CardParser.toOwnJson(orig.character, orig.lorebook)
        val back = CardParser.parseJson(json)
        assertEquals("JullAI", back.format)
        assertEquals(orig.character, back.character)
        assertEquals(orig.lorebook, back.lorebook)
    }

    @Test fun ownFormatNewerVersionIsRejected() {
        try { CardParser.parseJson("""{"format":"jullai-character","version":5,"character":{"name":"A"}}"""); fail() }
        catch (e: CardException) { assertTrue(e.message!!.contains("más nueva")) }
    }

    // ---------------- PNG ----------------

    private fun chunk(type: String, data: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        fun i32(v: Int) { out.write(v ushr 24); out.write(v ushr 16); out.write(v ushr 8); out.write(v) }
        i32(data.size)
        val td = type.toByteArray(Charsets.ISO_8859_1) + data
        out.write(td)
        val crc = CRC32().apply { update(td) }
        i32(crc.value.toInt())
        return out.toByteArray()
    }

    private fun png(vararg chunks: ByteArray): ByteArray {
        val sig = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        return sig + chunk("IHDR", ByteArray(13)) + chunks.fold(ByteArray(0)) { a, b -> a + b } + chunk("IEND", ByteArray(0))
    }

    private fun tEXt(key: String, text: String) = chunk("tEXt", key.toByteArray() + byteArrayOf(0) + text.toByteArray(Charsets.ISO_8859_1))
    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))

    @Test fun pngWithCharaChunk() {
        val bytes = png(tEXt("chara", b64(v2)))
        val json = PngCard.extractJson(bytes)
        assertEquals("Aria", CardParser.parseJson(json).character.name)
    }

    @Test fun pngPrefersCcv3() {
        val v3 = """{"spec":"chara_card_v3","spec_version":"3.0","data":{"name":"TresPuntoCero","description":"d"}}"""
        val bytes = png(tEXt("chara", b64(v2)), tEXt("ccv3", b64(v3)))
        assertEquals("TresPuntoCero", CardParser.parseJson(PngCard.extractJson(bytes)).character.name)
    }

    @Test fun pngWithoutCardIsRejected() {
        try { PngCard.extractJson(png(tEXt("Software", "otra cosa"))); fail() }
        catch (e: CardException) { assertTrue(e.message!!.contains("no contiene una tarjeta")) }
    }

    @Test fun notAPngIsRejected() {
        try { PngCard.extractJson("esto no es un png".toByteArray()); fail() } catch (e: CardException) { assertTrue(e.message!!.contains("PNG")) }
        assertFalse(PngCard.isPng(ByteArray(3)))
    }

    @Test fun invalidBase64IsRejected() {
        try { PngCard.extractJson(png(tEXt("chara", "@@@@no-base64@@@@"))); fail() } catch (e: CardException) { assertTrue(e.message!!.contains("base64")) }
    }

    @Test fun base64OfNonJsonIsRejected() {
        try { PngCard.extractJson(png(tEXt("chara", b64("hola mundo")))); fail() } catch (e: CardException) { assertTrue(e.message!!.contains("JSON")) }
    }

    @Test fun truncatedPngDoesNotCrash() {
        val full = png(tEXt("chara", b64(v2)))
        val cut = full.copyOf(full.size - 60)  // corta dentro del chunk
        try { PngCard.extractJson(cut); fail() } catch (e: CardException) { /* mensaje claro, sin excepción rara */ }
    }

    @Test fun corruptChunkLengthDoesNotCrash() {
        val sig = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        val bad = sig + byteArrayOf(0x7F, 0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte(), 't'.code.toByte(), 'E'.code.toByte(), 'X'.code.toByte(), 't'.code.toByte(), 1, 2, 3)
        try { PngCard.extractJson(bad); fail() } catch (e: CardException) { }
    }

    @Test fun zTXtCompressedChunk() {
        val raw = b64(v2).toByteArray()
        val def = Deflater(); def.setInput(raw); def.finish()
        val buf = ByteArray(raw.size + 100); val n = def.deflate(buf); def.end()
        val data = "chara".toByteArray() + byteArrayOf(0, 0) + buf.copyOf(n)
        val json = PngCard.extractJson(png(chunk("zTXt", data)))
        assertEquals("Aria", CardParser.parseJson(json).character.name)
    }

    @Test fun compressionBombIsRejected() {
        val raw = ByteArray(20_000_000) { 'A'.code.toByte() }
        val def = Deflater(); def.setInput(raw); def.finish()
        val out = ByteArrayOutputStream(); val buf = ByteArray(65536)
        while (!def.finished()) { val k = def.deflate(buf); out.write(buf, 0, k) }
        def.end()
        val data = "chara".toByteArray() + byteArrayOf(0, 0) + out.toByteArray()
        try { PngCard.extractJson(png(chunk("zTXt", data))); fail() } catch (e: CardException) { assertTrue(e.message!!.contains("demasiado grandes")) }
    }

    @Test fun macrosAreSinglePassAndLimited() {
        assertEquals("Hola, Ana. Soy Aria.", Macros.apply("Hola, {{user}}. Soy {{char}}.", "Aria", "Ana"))
        assertEquals("Aria y Ana", Macros.apply("<BOT> y <USER>", "Aria", "Ana"))
        assertEquals("{{random}} Aria", Macros.apply("{{random}} {{Char}}", "Aria", "Ana"))
        assertEquals("{{char}}", Macros.apply("{{user}}", "Aria", "{{char}}")) // no se vuelve a expandir
    }

    @Test fun jsonWriterEscapes() {
        val s = MiniJson.write(obj("a" to jstr("x\"y\n\u0001")))
        assertEquals("""{"a":"x\"y\n\u0001"}""", s)
        assertNotNull(MiniJson.parse(s))
        assertNull(MiniJson.parse("""{"a":null}""").asObj()?.str("a"))
    }
}
