package com.jullai.local.data

import androidx.sqlite.db.SupportSQLiteDatabase

/** Esquemas antiguos escritos a mano (NO generados por Room) para probar migraciones con datos reales. */
object LegacyDbs {
    /** Esquema exacto de la v0.2 (versión 1 de Room). */
    fun createV1(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `models` (`fileName` TEXT NOT NULL, `displayName` TEXT NOT NULL, `sizeBytes` INTEGER NOT NULL, `sha256` TEXT NOT NULL, `importedAt` INTEGER NOT NULL, `isDefault` INTEGER NOT NULL, PRIMARY KEY(`fileName`))")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_models_sha256` ON `models` (`sha256`)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `conversations` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `modelFileName` TEXT, `systemPrompt` TEXT NOT NULL, `temperature` REAL NOT NULL, `topP` REAL NOT NULL, `maxTokens` INTEGER NOT NULL, `contextLength` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_conversations_updatedAt` ON `conversations` (`updatedAt`)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `messages` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `conversationId` INTEGER NOT NULL, `role` TEXT NOT NULL, `content` TEXT NOT NULL, `orderIndex` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `state` TEXT NOT NULL, FOREIGN KEY(`conversationId`) REFERENCES `conversations`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_messages_conversationId_orderIndex` ON `messages` (`conversationId`, `orderIndex`)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `settings` (`settingKey` TEXT NOT NULL, `settingValue` TEXT NOT NULL, PRIMARY KEY(`settingKey`))")
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'viejo')")
    }

    /** Esquema de la v0.3 (versión 2): la v0.2 + las tablas de roleplay, creadas con la MISMA migración 1→2 que usa la app. */
    fun createV2(db: SupportSQLiteDatabase) {
        createV1(db)
        Migrations.MIGRATION_1_2.migrate(db)
    }

    /** Datos realistas de una instalación 0.3: chat, modelo, ajustes, un personaje con partida, mensajes con swipes, conocimiento y resumen escrito a mano. */
    fun insertV03Data(db: SupportSQLiteDatabase) {
        db.execSQL("INSERT INTO conversations VALUES(1,'Mi chat',NULL,'sys',0.7,0.9,512,2048,1,2)")
        db.execSQL("INSERT INTO messages VALUES(1,1,'user','hola',0,1,'COMPLETE')")
        db.execSQL("INSERT INTO models VALUES('m.gguf','m',100,'abc',1,1)")
        db.execSQL("INSERT INTO settings VALUES('threads','6')")
        db.execSQL("INSERT INTO settings VALUES('rp_last_user','Ana')")
        db.execSQL(
            "INSERT INTO characters (id,name,aliases,portraitFile,appearance,personality,speechStyle,history,motivations,likesDislikes,behaviorInstructions," +
                "initialRelationship,scenario,firstMessage,alternateGreetings,dialogueExamples,worldId,lorebookId,privateNotes,tags,creator,createdAt,updatedAt) " +
                "VALUES(1,'Aria','',NULL,'alta','seria','formal','hist','mot','gustos','instr','rel','esc','Hola, viajera.','','',NULL,NULL,'nota privada','','yo',1,2)",
        )
        db.execSQL(
            "INSERT INTO role_sessions (id,characterId,title,scenarioText,userName,userPersona,narrativeRules,summary,modelFileName,temperature,topP,maxTokens,contextLength,createdAt,updatedAt) " +
                "VALUES(1,1,'Partida de Aria','una taberna','Ana','exploradora','reglas','Ana conoció a Aria en la taberna.','m.gguf',0.8,0.9,256,2048,1,3)",
        )
        db.execSQL("INSERT INTO role_messages VALUES(1,1,'assistant','Hola, viajera.',0,1,'COMPLETE','[\"Hola, viajera.\"]',0)")
        db.execSQL("INSERT INTO role_messages VALUES(2,1,'user','Busco el mapa del tesoro.',1,2,'COMPLETE','[]',0)")
        db.execSQL("INSERT INTO role_messages VALUES(3,1,'assistant','Yo lo guardo en la torre.',2,3,'COMPLETE','[\"Yo lo guardo en la torre.\"]',0)")
        db.execSQL("INSERT INTO knowledge_items VALUES(1,1,'FACT','El mapa está en la torre.',1)")
    }
}
