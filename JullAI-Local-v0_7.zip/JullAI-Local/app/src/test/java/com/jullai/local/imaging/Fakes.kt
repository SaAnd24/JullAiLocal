package com.jullai.local.imaging

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Motor de imágenes falso: permite probar el coordinador y la cola sin código nativo. */
class FakeImageEngine(var caps: EngineCapabilities = EngineCapabilities(cancel = true, progress = true, vaeTiling = true, lora = true, imageToImage = true, negativePrompt = true, samplers = Samplers.ALL)) : ImageEngine {
    override val id = "fake"
    private val _state = MutableStateFlow(ImageEngineState.IDLE)
    override val state: StateFlow<ImageEngineState> = _state
    var loaded: String? = null
    val loads = ArrayList<String>()
    var releases = 0
    var failLoad: ImageEngineException? = null
    var failGenerate: ImageEngineException? = null
    var blockUntil: CompletableDeferred<Unit>? = null   // si no es null, generate espera hasta cancelar/soltar
    @Volatile var cancelled = false
    var lastRequest: GenerationRequest? = null
    val prompts = ArrayList<String>()

    override suspend fun diagnose() = EngineDiagnostics(id, "0", true, "arm64-v8a", emptyList())
    override fun capabilities() = caps
    override suspend fun loadModel(path: String, threads: Int): LoadedImageModel {
        failLoad?.let { throw it }
        loaded = path; loads.add(path)
        return LoadedImageModel(path, 1, 1)
    }
    override suspend fun generate(request: GenerationRequest, onProgress: (GenProgress) -> Unit): GenerationResult {
        lastRequest = request; prompts.add(request.prompt)
        failGenerate?.let { throw it }
        cancelled = false
        onProgress(GenProgress(1, request.steps, 0.1f))
        blockUntil?.await()
        if (cancelled) throw ImageEngineException(ImageEngineException.Code.CANCELLED, "cancelada")
        return GenerationResult(ByteArray(request.width * request.height * 3) { 7 }, request.width, request.height, request.seed, 1234, listOf("ok"), emptyList(), id, "0")
    }
    override fun cancel(): Boolean { if (!caps.cancel) return false; cancelled = true; blockUntil?.complete(Unit); return true }
    override suspend fun release() { releases++; loaded = null }
}

class FakeText(var generating: Boolean = false, var loaded: Boolean = true, var canUnload: Boolean = true) : TextSide {
    var unloads = 0
    override fun isGenerating() = generating
    override fun isLoaded() = loaded
    override suspend fun unloadIfIdle(): Boolean { if (!canUnload) return false; unloads++; loaded = false; return true }
}

class FakeGate(var mem: MemoryStatus = MemoryStatus(6L shl 30, 8L shl 30, false), var heat: ThermalLevel = ThermalLevel.NONE) : DeviceGate {
    override fun memory() = mem
    override fun thermal() = heat
}

fun req(w: Int = 256, h: Int = 384, steps: Int = 4, cfg: Float = 7f, sampler: String = Samplers.EULER_A) =
    GenerationRequest("a cat", "bad", w, h, steps, cfg, 5L, sampler, true, 4)
