package com.jullai.local.roleplay

import com.jullai.local.chat.ContextOverflowException
import com.jullai.local.engine.ChatMessage
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class RoleplayContextTest {
    // "Tokens" de prueba: una palabra = un token.
    private val count: suspend (String) -> Int = { t -> t.split(Regex("\\s+")).count { it.isNotEmpty() } }
    private val template: suspend (List<ChatMessage>) -> String = { msgs -> msgs.joinToString("\n") { "<${it.role}> ${it.content}" } + "\n<assistant>" }
    private fun words(n: Int, tag: String) = (1..n).joinToString(" ") { "$tag$it" }

    private val ch = RpCharacter(
        name = "Aria", appearance = "Elfa alta", personality = "Seria", speechStyle = "Formal", history = words(60, "hist"),
        likesDislikes = "Le gusta el té", motivations = "Proteger el bosque", behaviorInstructions = "Nunca rompe el personaje",
        initialRelationship = "Desconocidos", dialogueExamples = words(80, "ejem"),
    )
    private val scene = RpScene(userName = "Ana", scenario = "Bosque de noche", narrativeRules = "No hables por {{user}}", summary = "Se conocieron ayer")
    private val hist = listOf(ChatMessage("assistant", "Hola, {{user}}"), ChatMessage("user", "Hola Aria, vi un roble enorme"))

    private fun input(
        history: List<ChatMessage> = hist, ctx: Int = 4000, maxResp: Int = 300, lore: List<LoreEntry> = emptyList(),
        knowledge: List<KnowledgeItem> = emptyList(), c: RpCharacter = ch, s: RpScene = scene, cont: String? = null,
    ) = RpInput("Eres narrador de {{char}}", c, s, knowledge, lore, 4, history, ctx, maxResp, continuation = cont)

    private fun build(i: RpInput) = runBlocking { RoleplayContextBuilder.build(i, count, template) }

    @Test fun orderOfSectionsAndSingleSystemMessage() {
        val r = build(input())
        assertEquals(listOf("system", "assistant", "user"), r.messages.map { it.role })
        val sys = r.messages[0].content
        val order = listOf("Eres narrador de Aria", "# FICHA DE Aria", "# ESCENARIO ACTUAL", "# REGLAS NARRATIVAS", "# RESUMEN")
        val pos = order.map { sys.indexOf(it) }
        assertTrue("todas presentes: $pos", pos.all { it >= 0 })
        assertEquals(pos.sorted(), pos)
        assertTrue(sys.contains("No hables por Ana"))      // macros resueltas
        assertEquals(0, r.pressureStep)
    }

    @Test fun privateNotesCanNeverReachThePrompt() {
        // El tipo RpCharacter no tiene campo de notas privadas; comprobamos además que ninguna cadena de notas aparece.
        val r = build(input())
        assertFalse(r.prompt.contains("NOTA SECRETA"))
        assertTrue(RpCharacter::class.java.declaredFields.none { it.name.contains("private", true) || it.name.contains("notes", true) })
    }

    @Test fun loreIsActivatedByKeywordsOnly() {
        val lore = listOf(
            LoreEntry(1, "Roble", listOf("roble"), content = "El roble es sagrado", insertionOrder = 1),
            LoreEntry(2, "Dragón", listOf("dragón"), content = "El dragón duerme", insertionOrder = 2),
            LoreEntry(3, "Siempre", emptyList(), content = "Regla del mundo constante", constant = true, insertionOrder = 3),
            LoreEntry(4, "Apagada", listOf("roble"), content = "Entrada desactivada", enabled = false),
        )
        val r = build(input(lore = lore))
        assertTrue(r.prompt.contains("El roble es sagrado"))
        assertTrue(r.prompt.contains("Regla del mundo constante"))
        assertFalse(r.prompt.contains("El dragón duerme"))
        assertFalse(r.prompt.contains("Entrada desactivada"))
        assertEquals(listOf("Roble", "Siempre"), r.loreUsed)
    }

    @Test fun loreMatchingIgnoresCaseAndAccentsAndSupportsSecondaryKeys() {
        val e = LoreEntry(1, "x", listOf("ÁRBOL"), listOf("noche"), "c", selective = true)
        assertEquals(1, LoreMatcher.activate(listOf(e), "un arbol de NOCHE").size)
        assertEquals(0, LoreMatcher.activate(listOf(e), "un arbol de día").size)
        val cs = LoreEntry(2, "y", listOf("Roble"), content = "c", caseSensitive = true)
        assertEquals(0, LoreMatcher.activate(listOf(cs), "un roble").size)
        assertEquals(1, LoreMatcher.activate(listOf(cs), "un Roble").size)
    }

    @Test fun regexKeysAreLiteral() {
        val e = LoreEntry(1, "x", listOf("a.*b"), content = "c")
        assertEquals(0, LoreMatcher.activate(listOf(e), "axxxb").size)
        assertEquals(1, LoreMatcher.activate(listOf(e), "a.*b").size)
    }

    @Test fun loreBudgetDropsLowPriorityFirst() {
        val big = words(120, "x")
        val lore = listOf(
            LoreEntry(1, "Baja", listOf("roble"), content = "baja $big", priority = 1),
            LoreEntry(2, "Alta", listOf("roble"), content = "alta $big", priority = 50),
        )
        val r = build(input(ctx = 900, maxResp = 100, lore = lore))
        // con tan poco espacio solo cabe una; debe ser la de mayor prioridad
        if (r.loreUsed.isNotEmpty()) assertEquals(listOf("Alta"), r.loreUsed)
        assertTrue(r.loreSkipped >= 1 || r.loreUsed.isEmpty())
    }

    @Test fun knowledgeScopesStaySeparated() {
        val k = listOf(
            KnowledgeItem(KnowledgeScope.SECRET, "Aria es la heredera"),
            KnowledgeItem(KnowledgeScope.PUBLIC, "El rey murió"),
            KnowledgeItem(KnowledgeScope.FACT, "Ana rompió el sello"),
            KnowledgeItem(KnowledgeScope.USER, "Ana sabe del mapa"),
            KnowledgeItem(KnowledgeScope.INVENTION, "La magia usa plata"),
        )
        val sys = build(input(knowledge = k)).messages[0].content
        val iSecret = sys.indexOf("Aria es la heredera")
        val iPublic = sys.indexOf("El rey murió")
        assertTrue(iSecret > 0 && iPublic > 0)
        val secretHeader = sys.lastIndexOf("## Secretos", iSecret)
        assertTrue("el secreto debe quedar bajo su propio encabezado", secretHeader in 0 until iSecret)
        // entre el encabezado de secretos y el secreto no puede haber otra información
        assertFalse(sys.substring(secretHeader, iSecret).contains("El rey murió"))
        assertTrue(sys.contains("no los reveles"))
    }

    @Test fun knowledgeKeepsSecretsAndFactsWhenTight() {
        val k = (1..30).map { KnowledgeItem(KnowledgeScope.PUBLIC, "publico " + words(15, "p$it")) } +
            KnowledgeItem(KnowledgeScope.SECRET, "secreto vital") + KnowledgeItem(KnowledgeScope.FACT, "hecho vital")
        val sys = build(input(ctx = 1500, maxResp = 200, knowledge = k)).messages[0].content
        assertTrue(sys.contains("secreto vital"))
        assertTrue(sys.contains("hecho vital"))
    }

    @Test fun pressureDropsExamplesFirstAndKeepsLastMessage() {
        val longHist = (1..30).flatMap { listOf(ChatMessage("user", words(30, "u$it")), ChatMessage("assistant", words(30, "a$it"))) } +
            ChatMessage("user", "ultimo mensaje importante")
        val r = build(input(history = longHist, ctx = 900, maxResp = 150))
        assertEquals("ultimo mensaje importante", r.messages.last().content)
        val fiche = r.report.first { it.id == "fiche" }.tokens
        assertTrue("la ficha respeta su tope (30% de 750)", fiche <= 750 * 0.30 + 15)
        assertTrue("el historial conserva espacio razonable", r.report.first { it.id == "history" }.tokens >= 250)
        assertTrue(r.promptTokens <= 900 - 150)
        assertTrue(r.droppedMessages > 0)
        assertTrue(r.messages[0].content.contains("Eres narrador de Aria"))   // el sistema nunca se pierde
        assertTrue(r.messages[0].content.contains("REGLAS NARRATIVAS"))
    }

    @Test fun roomyContextKeepsExamplesAndEverything() {
        val r = build(input(ctx = 6000, maxResp = 300))
        assertTrue(r.prompt.contains("ejem1 "))
        assertEquals(0, r.droppedMessages)
    }

    @Test fun greetingAssistantFirstIsKept() {
        val r = build(input())
        assertEquals("assistant", r.messages[1].role)
        assertTrue(r.messages[1].content.contains("Hola, {{user}}"))   // el historial no se reescribe
    }

    @Test fun continuationIsAppendedToPrompt() {
        val r = build(input(cont = "Aria sonríe y"))
        assertTrue(r.prompt.endsWith("<assistant>Aria sonríe y"))
    }

    @Test fun impossibleContextThrows() {
        val huge = listOf(ChatMessage("user", words(800, "x")))
        try { build(input(history = huge, ctx = 600, maxResp = 100)); fail() } catch (e: ContextOverflowException) { }
    }

    @Test fun tinyContextThrows() {
        try { build(input(ctx = 60, maxResp = 40)); fail() } catch (e: ContextOverflowException) { }
    }

    @Test fun extraSectionsGoInAndAreCapped() {
        val i = RpInput("sys", ch, scene, emptyList(), emptyList(), 4, hist, 4000, 300, extra = listOf(PromptSection("mem", "Recuerdos", words(50, "rec"))))
        assertTrue(build(i).messages[0].content.contains("# RECUERDOS"))
    }

    // ---------------- swipes y utilidades ----------------

    @Test fun swipesLifecycle() {
        val (items, idx) = Swipes.effective("texto", Swipes.toJson(listOf("a", "b")), 1)
        assertEquals(listOf("a", "texto"), items); assertEquals(1, idx)
        val (n, ni) = Swipes.withNew(items, idx)
        assertEquals(listOf("a", "texto", ""), n); assertEquals(2, ni)
        assertEquals(listOf("solo") to 0, Swipes.effective("solo", "[]", 0))
        assertEquals(listOf("x") to 0, Swipes.effective("x", "basura", 7))
        val full = (1..Swipes.MAX).map { "s$it" }
        val (capped, ci) = Swipes.withNew(full, Swipes.MAX - 1)
        assertEquals(Swipes.MAX, capped.size); assertEquals(Swipes.MAX - 1, ci); assertEquals("", capped.last())
    }

    @Test fun rpTextItalics() {
        assertEquals(listOf(RpSpan("Hola ", false), RpSpan("sonríe", true), RpSpan(" mucho", false)), RpText.spans("Hola *sonríe* mucho"))
        assertEquals(listOf(RpSpan("a * b", false)), RpText.spans("a * b"))
        assertEquals(listOf(RpSpan("fuerte", false, bold = true), RpSpan(" y ", false), RpSpan("sutil", true)), RpText.spans("**fuerte** y *sutil*"))
        assertEquals(listOf(RpSpan("**abierto", false)), RpText.spans("**abierto"))
    }

    @Test fun userTurnStop() {
        val s = UserTurnStop("Ana")
        assertEquals(-1, s.cutIndex("Aria dice hola. Ana está aquí"))
        assertEquals(15, s.cutIndex("Aria dice hola.\nAna: me voy"))
        assertEquals(-1, UserTurnStop("  ").cutIndex("\n: algo"))
    }
}
