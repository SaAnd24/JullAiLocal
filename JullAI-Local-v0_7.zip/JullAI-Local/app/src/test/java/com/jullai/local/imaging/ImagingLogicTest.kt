package com.jullai.local.imaging

import com.jullai.local.world.AssetKind
import com.jullai.local.world.Emotion
import com.jullai.local.world.SceneDraft
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ImagingLogicTest {
    @get:Rule val tmp = TemporaryFolder()

    // ---------- safetensors / gguf escritos a mano ----------
    private fun safetensors(tensors: Map<String, Pair<String, List<Long>>>): File {
        val sb = StringBuilder("{")
        var off = 0L
        tensors.entries.forEachIndexed { i, (name, v) ->
            val bytes = v.second.fold(1L) { a, b -> a * b } * (if (v.first == "F32") 4 else 2)
            if (i > 0) sb.append(',')
            sb.append("\"$name\":{\"dtype\":\"${v.first}\",\"shape\":[${v.second.joinToString(",")}],\"data_offsets\":[$off,${off + bytes}]}")
            off += bytes
        }
        sb.append('}')
        val header = sb.toString().toByteArray()
        val out = ByteArrayOutputStream()
        out.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(header.size.toLong()).array())
        out.write(header)
        out.write(ByteArray(off.toInt()))
        return tmp.newFile().also { it.writeBytes(out.toByteArray()) }
    }

    private val sd15 = mapOf(
        "model.diffusion_model.input_blocks.0.0.weight" to ("F16" to listOf(4L, 4L, 3L, 3L).let { listOf(4L, 4L, 1L, 1L) }),
        "model.diffusion_model.input_blocks.1.1.transformer_blocks.0.attn2.to_k.weight" to ("F16" to listOf(4L, 768L)),
        "cond_stage_model.transformer.text_model.embeddings.token_embedding.weight" to ("F16" to listOf(2L, 2L)),
        "first_stage_model.decoder.conv_in.weight" to ("F16" to listOf(2L, 2L)),
    )

    @Test fun recognizesSd15Safetensors() {
        val r = ModelProbe.probe(safetensors(sd15))
        assertEquals(ModelFormat.SAFETENSORS, r.format); assertEquals(ImageModelKind.CHECKPOINT, r.kind)
        assertEquals("SD 1.x", r.architecture); assertTrue(r.reasons.toString(), r.supported); assertTrue(r.hasVae); assertEquals("F16", r.dtype)
    }

    @Test fun rejectsSdxlSd2AndInpaintAndForeignFiles() {
        assertFalse(ModelProbe.probe(safetensors(sd15 + ("conditioner.embedders.0.x" to ("F16" to listOf(1L))))).supported)
        val sd2 = sd15.toMutableMap().also { it["model.diffusion_model.input_blocks.1.1.transformer_blocks.0.attn2.to_k.weight"] = "F16" to listOf(4L, 1024L) }
        assertEquals("SD 2.x", ModelProbe.probe(safetensors(sd2)).architecture); assertFalse(ModelProbe.probe(safetensors(sd2)).supported)
        val inpaint = sd15.toMutableMap().also { it["model.diffusion_model.input_blocks.0.0.weight"] = "F16" to listOf(4L, 9L, 1L, 1L) }
        assertFalse(ModelProbe.probe(safetensors(inpaint)).supported)
        assertFalse(ModelProbe.probe(safetensors(mapOf("unet.down_blocks.0.weight" to ("F16" to listOf(2L))))).supported)   // diffusers
        val txt = tmp.newFile().also { it.writeText("esto no es un modelo, solo texto largo largo largo") }
        assertFalse(ModelProbe.probe(txt).supported)
    }

    @Test fun rejectsPickleCkptForSecurity() {
        val zip = tmp.newFile().also { it.writeBytes(byteArrayOf('P'.code.toByte(), 'K'.code.toByte(), 3, 4) + ByteArray(64)) }
        val r = ModelProbe.probe(zip)
        assertEquals(ModelFormat.PICKLE, r.format); assertFalse(r.supported); assertTrue(r.reasons.joinToString().contains("código"))
    }

    @Test fun truncatedOrLyingHeaderIsRejectedNotCrashing() {
        val f = safetensors(sd15)
        val bytes = f.readBytes()
        val cut = tmp.newFile().also { it.writeBytes(bytes.copyOf(bytes.size - 5)) }
        assertFalse(ModelProbe.probe(cut).supported)           // los offsets apuntan fuera del archivo
        val huge = tmp.newFile().also { it.writeBytes(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(1L shl 40).array() + ByteArray(32)) }
        assertFalse(ModelProbe.probe(huge).supported)
    }

    @Test fun recognizesLoraAndWarnsItCannotCheckCompatibility() {
        val lora = safetensors(mapOf("lora_unet_down_blocks_0_attentions_0_proj_in.lora_down.weight" to ("F16" to listOf(4L, 8L)), "lora_unet_down_blocks_0_attentions_0_proj_in.lora_up.weight" to ("F16" to listOf(8L, 4L))))
        val r = ModelProbe.probe(lora)
        assertEquals(ImageModelKind.LORA, r.kind); assertTrue(r.supported); assertTrue(r.warnings.isNotEmpty())
        assertFalse(ModelProbe.probe(safetensors(mapOf("lora_te2_x.lora_down.weight" to ("F16" to listOf(2L, 2L))))).supported)   // SDXL
    }

    private fun le(v: Long, n: Int) = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array().copyOf(n)
    private fun ggufStr(s: String) = le(s.length.toLong(), 8) + s.toByteArray()

    @Test fun readsGgufTensorTableAndNormalizesDimensionOrder() {
        val names = listOf("model.diffusion_model.input_blocks.0.0.weight" to listOf(1L, 1L, 4L, 4L), "model.diffusion_model.input_blocks.1.1.transformer_blocks.0.attn2.to_k.weight" to listOf(768L, 4L),
            "cond_stage_model.transformer.text_model.embeddings.token_embedding.weight" to listOf(2L, 2L), "first_stage_model.decoder.conv_in.weight" to listOf(2L, 2L))
        val out = ByteArrayOutputStream()
        out.write("GGUF".toByteArray()); out.write(le(3, 4)); out.write(le(names.size.toLong(), 8)); out.write(le(1, 8))
        out.write(ggufStr("general.architecture")); out.write(le(8, 4)); out.write(ggufStr("sd"))      // un metadato de texto que se debe saltar bien
        names.forEach { (n, dims) -> out.write(ggufStr(n)); out.write(le(dims.size.toLong(), 4)); dims.forEach { out.write(le(it, 8)) }; out.write(le(1, 4)); out.write(le(0, 8)) }
        val r = ModelProbe.probe(tmp.newFile().also { it.writeBytes(out.toByteArray()) })
        assertEquals(ModelFormat.GGUF, r.format); assertEquals("SD 1.x", r.architecture); assertTrue(r.reasons.toString(), r.supported); assertEquals("F16", r.dtype)
    }

    // ---------- resoluciones, presets, coste, validación ----------
    @Test fun onlyValidatedSizesAreAccepted() {
        assertTrue(ImageSizes.isValid(256, 384)); assertTrue(ImageSizes.isValid(384, 256)); assertFalse(ImageSizes.isValid(1024, 1024)); assertFalse(ImageSizes.isValid(257, 384))
        assertEquals(ImageSizes.PORTRAIT_LOW, ImageSizes.forKind(AssetKind.RETRATO, 0)); assertEquals(ImageSizes.LANDSCAPE_LOW, ImageSizes.forKind(AssetKind.FONDO, 0))
        assertTrue(ImageSizes.ALL.all { it.width % 64 == 0 && it.height % 64 == 0 && it.width <= 768 && it.height <= 768 })
    }

    @Test fun requestValidationExplainsInSpanish() {
        val caps = EngineCapabilities(lora = false, imageToImage = false, samplers = listOf(Samplers.EULER_A))
        assertNull(RequestValidator.validate(req(), caps))
        assertNotNull(RequestValidator.validate(req(w = 1000, h = 1000), caps))
        assertTrue(RequestValidator.validate(req(sampler = Samplers.LCM), caps)!!.contains("sampler"))
        assertTrue(RequestValidator.validate(req().copy(loraPath = "/x"), caps)!!.contains("LoRA"))
        assertTrue(RequestValidator.validate(req().copy(initRgb = ByteArray(3)), caps)!!.contains("referencia"))
        assertNotNull(RequestValidator.validate(req(steps = 0), caps))
    }

    @Test fun costIsRelativeAndHistoryEstimateNeedsRealData() {
        val base = CostEstimate.relative(20, 256, 384, 7f)
        assertEquals(1.0, base, 1e-9)
        assertTrue(CostEstimate.relative(25, 512, 768, 7f) > 7.0)
        assertTrue(CostEstimate.relative(6, 256, 384, 1.5f) < base)
        assertNull(CostEstimate.secondsFromHistory(1.0, emptyList()))
        assertEquals(60L, CostEstimate.secondsFromHistory(1.0, listOf(1.0 to 60_000L)))
        assertEquals(120L, CostEstimate.secondsFromHistory(2.0, listOf(1.0 to 60_000L)))
    }

    @Test fun lcmPresetNeedsLoraAndSeedsResolve() {
        assertTrue(QualityPreset.LOW_POWER_LCM.needsLcmLora); assertFalse(QualityPreset.LOW_POWER.needsLcmLora)
        assertEquals(QualityPreset.LOW_POWER, QualityPreset.byId("???"))
        assertEquals(42L, Seeds.resolve(42)); assertTrue(Seeds.resolve(-1) >= 0)
    }

    // ---------- prompts ----------
    @Test fun promptUsesProfileNotNameAndStaysCompact() {
        val p = VisualProfile(physical = "long silver hair, green eyes, young woman", style = "watercolor", outfits = "niñez|school uniform\n|blue coat")
        val t = PromptBuilder.character(p, "ignored", emotion = Emotion.ALEGRIA, pose = "SENTADO", stage = "niñez")
        assertTrue(t.contains("silver hair")); assertTrue(t.contains("school uniform")); assertTrue(t.contains("smiling")); assertTrue(t.contains("sitting")); assertTrue(t.startsWith("watercolor"))
        assertEquals("blue coat", PromptBuilder.outfitFor(p, "adulto"))
        assertTrue(PromptBuilder.character(VisualProfile(physical = "x ".repeat(500)), "").length <= PromptBuilder.MAX_PROMPT_CHARS)
        assertTrue(PromptBuilder.negative(VisualProfile(negative = "hat")).startsWith("hat"))
        assertTrue(PromptBuilder.summarizeScene("*Aria abre la puerta.* «Hola», dice con calma. Más texto.").startsWith("Aria abre la puerta"))
    }

    // ---------- coordinador ----------
    private fun job(w: Int = 256, h: Int = 384) = ImageJob(req(w, h), "/m.safetensors", 2L shl 30)

    @Test fun coordinatorFreesTextRunsImageAndFlagsReload() = runBlocking {
        val e = FakeImageEngine(); val t = FakeText(); val c = ResourceCoordinator(e, t, FakeGate())
        val out = c.run(job())
        assertTrue(out is JobOutcome.Done); assertEquals(1, t.unloads); assertEquals(listOf("/m.safetensors"), e.loads)
        assertTrue(c.state.value.textReloadPending)
        c.releaseIfIdle(); assertEquals(null, e.loaded)
    }

    @Test fun textGeneratingHasPriorityAndNothingIsTouched() = runBlocking {
        val e = FakeImageEngine(); val t = FakeText(generating = true); val c = ResourceCoordinator(e, t, FakeGate())
        val out = c.run(job())
        assertTrue(out is JobOutcome.Deferred && out.code == DeferCode.TEXT_PRIORITY); assertEquals(0, t.unloads); assertTrue(e.loads.isEmpty())
    }

    @Test fun lowMemoryAndHotPhoneDeferWithoutLoadingModel() = runBlocking {
        val e = FakeImageEngine(); val t = FakeText(); val gate = FakeGate(mem = MemoryStatus(300L shl 20, 8L shl 30, false))
        val c = ResourceCoordinator(e, t, gate)
        val o1 = c.run(job()); assertTrue(o1 is JobOutcome.Deferred && o1.code == DeferCode.LOW_MEMORY); assertTrue(e.loads.isEmpty())
        gate.mem = MemoryStatus(6L shl 30, 8L shl 30, false); gate.heat = ThermalLevel.SEVERE
        val o2 = c.run(job()); assertTrue(o2 is JobOutcome.Deferred && o2.code == DeferCode.THERMAL)
        gate.heat = ThermalLevel.NONE
        assertTrue(c.run(job()) is JobOutcome.Done)   // al bajar la temperatura vuelve a funcionar
    }

    @Test fun textBusyCannotBeUnloadedDefersImage() = runBlocking {
        val c = ResourceCoordinator(FakeImageEngine(), FakeText(canUnload = false), FakeGate())
        val o = c.run(job()); assertTrue(o is JobOutcome.Deferred && o.code == DeferCode.TEXT_BUSY)
    }

    @Test fun invalidRequestIsRejectedBeforeTheEngine() = runBlocking {
        val e = FakeImageEngine(); val c = ResourceCoordinator(e, FakeText(), FakeGate())
        val o = c.run(ImageJob(req(w = 999, h = 999), "/m", 1L shl 30)); assertTrue(o is JobOutcome.Failed); assertTrue(e.loads.isEmpty())
    }

    @Test fun engineErrorsBecomeFailedAndNextRunReloads() = runBlocking {
        val e = FakeImageEngine(); val c = ResourceCoordinator(e, FakeText(), FakeGate())
        e.failGenerate = ImageEngineException(ImageEngineException.Code.OUT_OF_MEMORY, "sin memoria")
        val o = c.run(job()); assertTrue(o is JobOutcome.Failed && o.code == ImageEngineException.Code.OUT_OF_MEMORY)
        e.failGenerate = null
        assertTrue(c.run(job()) is JobOutcome.Done); assertEquals(2, e.loads.size)    // tras OOM se recarga
    }

    @Test fun userActionCancelsRunningImageAndReleasesEngineBeforeText() = runBlocking {
        val e = FakeImageEngine().also { it.blockUntil = CompletableDeferred() }
        val t = FakeText(); val c = ResourceCoordinator(e, t, FakeGate())
        val running = async { c.run(job()) }
        while (!c.isBusy) delay(5)
        assertTrue(c.yieldToText(5_000))
        val o = running.await()
        assertTrue(o is JobOutcome.Cancelled); assertFalse((o as JobOutcome.Cancelled).byUser)
        assertEquals(null, e.loaded); assertTrue(c.textHasPriority())   // la cola no arranca justo después
    }

    @Test fun engineWithoutCancelMakesYieldWaitAndReportFailureOnTimeout() = runBlocking {
        val e = FakeImageEngine(EngineCapabilities(cancel = false, samplers = Samplers.ALL)).also { it.blockUntil = CompletableDeferred() }
        val c = ResourceCoordinator(e, FakeText(), FakeGate())
        val running = async { c.run(job()) }
        while (!c.isBusy) delay(5)
        assertFalse(c.yieldToText(150))                       // no se puede cancelar: se avisa en vez de cargar el texto encima
        assertEquals(CoordPhase.BLOCKED, c.state.value.phase)
        e.blockUntil!!.complete(Unit); running.await()
    }

    @Test fun thermalCriticalAndMemoryPressureCancelRunningJob() = runBlocking {
        val e = FakeImageEngine().also { it.blockUntil = CompletableDeferred() }
        val c = ResourceCoordinator(e, FakeText(), FakeGate())
        val running = async { c.run(job()) }
        while (!c.isBusy) delay(5)
        c.onThermal(ThermalLevel.CRITICAL)
        val o = running.await(); assertTrue(o is JobOutcome.Cancelled)
        val e2 = FakeImageEngine().also { it.blockUntil = CompletableDeferred() }
        val c2 = ResourceCoordinator(e2, FakeText(), FakeGate())
        val r2 = async { c2.run(job()) }
        while (!c2.isBusy) delay(5)
        c2.onMemoryPressure(critical = true)
        assertTrue(r2.await() is JobOutcome.Cancelled)
    }

    @Test fun probeLoadValidatesWithEngineAndReleases() = runBlocking {
        val e = FakeImageEngine(); val c = ResourceCoordinator(e, FakeText(), FakeGate())
        assertNull(c.probeLoad("/m", 1L shl 30, 4)); assertEquals(null, e.loaded)
        e.failLoad = ImageEngineException(ImageEngineException.Code.INVALID_MODEL, "tensor desconocido")
        assertEquals("tensor desconocido", c.probeLoad("/m", 1L shl 30, 4))
    }

    // ---------- política de ilustraciones, planificador, metadatos ----------
    @Test fun normalAnswersNeverIllustrateAndModesBehave() {
        fun ctx(important: Boolean = true, has: Boolean = false, queued: Boolean = false, since: Int? = null, model: Boolean = true) = IllustrationContext(important, has, queued, since, model)
        assertEquals(IllustrationPolicy.Decision.NONE, IllustrationPolicy.decide(IllustrationMode.BALANCED, 8, ctx(important = false)))
        assertEquals(IllustrationPolicy.Decision.NONE, IllustrationPolicy.decide(IllustrationMode.MANUAL, 8, ctx()))
        assertEquals(IllustrationPolicy.Decision.NONE, IllustrationPolicy.decide(IllustrationMode.OFF, 8, ctx()))
        assertEquals(IllustrationPolicy.Decision.NONE, IllustrationPolicy.decide(IllustrationMode.BALANCED, 8, ctx(model = false)))
        assertEquals(IllustrationPolicy.Decision.SUGGEST, IllustrationPolicy.decide(IllustrationMode.IMPORTANT, 8, ctx()))
        assertEquals(IllustrationPolicy.Decision.ENQUEUE, IllustrationPolicy.decide(IllustrationMode.BALANCED, 8, ctx()))
        assertEquals(IllustrationPolicy.Decision.SUGGEST, IllustrationPolicy.decide(IllustrationMode.BALANCED, 8, ctx(since = 3)))
        assertEquals(IllustrationPolicy.Decision.NONE, IllustrationPolicy.decide(IllustrationMode.BALANCED, 8, ctx(has = true)))
        assertEquals(IllustrationPolicy.Decision.NONE, IllustrationPolicy.decide(IllustrationMode.BALANCED, 8, ctx(queued = true)))
    }

    @Test fun plannerFollowsRequiredOrderAndSkipsWhatExists() {
        val main = CharRef(1, "Aria", "pelo plateado")
        val places = listOf(PlaceRef("Taberna"), PlaceRef("Torre"), PlaceRef("Puerto"), PlaceRef("Bosque"))
        val plan = VisualPrepPlanner.plan(PlanInput(1, 2, main, listOf(CharRef(2, "Bo", "alto")), places, emptyList(), QualityPreset.LOW_POWER))
        assertEquals(AssetKind.RETRATO, plan[0].kind); assertEquals(1L, plan[0].characterId)
        assertTrue(plan.indexOfFirst { it.kind == AssetKind.FONDO && it.locationRef == "Taberna" } < plan.indexOfFirst { it.kind == AssetKind.EXPRESION })
        assertTrue(plan.none { it.kind == AssetKind.ILUSTRACION })           // las ilustraciones nunca se planifican solas
        assertEquals(2, plan.count { it.kind == AssetKind.FONDO && it.priority == TaskPriority.VARIANT })   // futuras: máx. 2
        assertTrue(plan.all { ImageSizes.isValid(it.size.width, it.size.height) })
        val existing = listOf(ExistingAsset(AssetKind.RETRATO, 1, "", "", ""), ExistingAsset(AssetKind.FONDO, null, "taberna", "", ""))
        val plan2 = VisualPrepPlanner.plan(PlanInput(1, 2, main, emptyList(), places, existing, QualityPreset.LOW_POWER))
        assertTrue(plan2.none { it.kind == AssetKind.RETRATO }); assertTrue(plan2.none { it.locationRef == "Taberna" })
        val open = setOf(VisualPrepPlanner.key(AssetKind.EXPRESION, 1, "", "ALEGRIA"))
        assertTrue(VisualPrepPlanner.plan(PlanInput(1, 2, main, emptyList(), places, existing, QualityPreset.LOW_POWER, openTaskKeys = open)).none { it.emotion == "ALEGRIA" })
    }

    @Test fun turnMetaIsStrippedAndInvalidMetaKeepsText() {
        val a = TurnMetaParser.parse("Aria sonríe.\n[[escena: hablante=Aria; emocion=ALEGRIA; lugar=Taberna; importante=sí]]")
        assertEquals("Aria sonríe.", a.displayText); assertEquals("Aria", a.meta!!.speaker); assertEquals(true, a.meta!!.important)
        val j = TurnMetaParser.parse("Texto.\n{\"speakerId\":\"Aria\",\"emotion\":\"MIEDO\"}")
        assertEquals("Texto.", j.displayText); assertEquals("MIEDO", j.meta!!.emotion)
        val bad = TurnMetaParser.parse("Texto normal con [[escena: basura sin pares]] fin")
        assertNull(bad.meta); assertFalse(bad.displayText.contains("[["))
        val none = TurnMetaParser.parse("Solo narración."); assertNull(none.meta); assertEquals("Solo narración.", none.displayText)
    }

    @Test fun mergeAcceptsOnlyValidatedValues() {
        val base = SceneDraft(location = "", speaker = "Aria", emotion = Emotion.NEUTRAL, pose = "", eventType = "DIALOGO", important = false, valid = true)
        val m = TurnMetaParser.merge(base, TurnMeta(speaker = "Inventado", emotion = "FELIZ", location = "Taberna", important = true), listOf("Aria", "Bo"), listOf("Taberna"))
        assertEquals("Aria", m.speaker); assertEquals(Emotion.NEUTRAL, m.emotion); assertEquals("Taberna", m.location); assertTrue(m.important)
        assertEquals(base, TurnMetaParser.merge(base, null, emptyList(), emptyList()))
    }

    @Test fun settingsRoundTripAndClamp() {
        val s = ImageSettings(preset = QualityPreset.QUALITY.id, threads = 6, autoRun = true, illustrationMode = IllustrationMode.BALANCED)
        assertEquals(s, ImageSettings.fromMap(s.toMap()))
        val clamp = ImageSettings.fromMap(mapOf(ImageSettings.K_THREADS to "99", ImageSettings.K_PRESET to "x", ImageSettings.K_ILLUS to "?", ImageSettings.K_GAP to "0"))
        assertEquals(8, clamp.threads); assertEquals(QualityPreset.LOW_POWER.id, clamp.preset); assertEquals(IllustrationMode.MANUAL, clamp.illustrationMode); assertEquals(2, clamp.minGapTurns)
        assertFalse(ImageSettings().autoRun)    // nada se lanza solo por defecto
    }

    @Test fun thermalMappingAndPolicy() {
        assertEquals(ThermalLevel.NONE, ThermalLevel.fromAndroid(0)); assertEquals(ThermalLevel.SEVERE, ThermalLevel.fromAndroid(3)); assertEquals(ThermalLevel.CRITICAL, ThermalLevel.fromAndroid(5)); assertEquals(ThermalLevel.UNKNOWN, ThermalLevel.fromAndroid(-1))
        assertEquals(GateAction.DEFER, DevicePolicy.thermal(ThermalLevel.SEVERE, false)); assertEquals(GateAction.ALLOW, DevicePolicy.thermal(ThermalLevel.SEVERE, true))
        assertEquals(GateAction.CANCEL, DevicePolicy.thermal(ThermalLevel.CRITICAL, true)); assertEquals(GateAction.ALLOW, DevicePolicy.thermal(ThermalLevel.UNKNOWN, false))
        assertTrue(DevicePolicy.memoryNeeded(2L shl 30, 512, 768, false) > DevicePolicy.memoryNeeded(2L shl 30, 256, 384, true))
    }
}
