package com.jullai.local.story

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextNormTest {
    @Test fun foldRemovesAccentsAndCase() {
        assertEquals("arbol", TextNorm.fold("Árbol"))
        assertEquals("ano nuevo", TextNorm.fold("AÑO Nuevo"))
    }

    @Test fun tokensDropStopWordsShortWordsAndPlurals() {
        val t = TextNorm.tokens("Los robles de la montaña son muy grandes, y el roble sagrado")
        assertTrue("roble" in t)
        assertTrue("sagrado" in t)
        assertFalse("los" in t); assertFalse("de" in t); assertFalse("muy" in t)
        assertTrue(TextNorm.keys("robles").contains("roble")); assertTrue(TextNorm.keys("papeles").contains("papel")); assertTrue(TextNorm.keys("reyes").contains("rey")); assertTrue(TextNorm.keySet(TextNorm.tokens("robles")).intersect(TextNorm.keys("roble")).isNotEmpty())
    }

    @Test fun tokensKeepOrderWithoutDuplicates() {
        assertEquals(listOf("llave", "puerta"), TextNorm.tokens("llave puerta llave"))
        assertTrue(TextNorm.tokens("   ").isEmpty())
    }

    @Test fun similarityDetectsParaphrasedDuplicates() {
        val a = "Aria guardó la llave de la torre bajo el roble"
        assertTrue(TextNorm.similarity(a, "La llave de la torre fue guardada por Aria bajo el roble") > 0.4)
        assertEquals(1.0, TextNorm.similarity(a, a), 0.0001)
        assertTrue(TextNorm.similarity(a, "El rey viajó al norte con su ejército") < 0.1)
    }

    @Test fun cleanRemovesControlCharsAndCaps() {
        assertEquals("ab", TextNorm.clean("a\u0000b\u0007", 10))
        assertEquals("abc", TextNorm.clean("abcdef", 3))
        assertEquals("x\ny", TextNorm.clean("  x\ny  ", 10))
    }
}
