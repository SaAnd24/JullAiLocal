package com.jullai.local.data

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.jullai.local.research.FetchResult
import com.jullai.local.research.ResearchEngine
import com.jullai.local.research.SourceProvider
import com.jullai.local.world.CastMode
import com.jullai.local.world.Confidence
import com.jullai.local.world.Continuity
import com.jullai.local.world.DraftEntry
import com.jullai.local.world.EntryOrigin
import com.jullai.local.world.EntryState
import com.jullai.local.world.EntryType
import com.jullai.local.world.PackLink
import com.jullai.local.world.ResearchDepth
import com.jullai.local.world.SceneDraft
import com.jullai.local.world.SourceKind
import com.jullai.local.world.SourceStatus
import com.jullai.local.world.SpoilerLevel
import com.jullai.local.world.TaskStatus
import com.jullai.local.world.VisualEvent
import com.jullai.local.world.WorldException
import com.jullai.local.world.WorldItem
import com.jullai.local.world.WorldRequest
import com.jullai.local.world.WorldRetriever
import com.jullai.local.world.WorldpackCodec
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/** Mundos, fuentes, investigación, vínculo con partidas y .worldpack contra una base Room REAL (Robolectric). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class WorldDatabaseTest {
    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var repo: WorldRepository
    private lateinit var role: RoleplayRepository
    private lateinit var story: StoryRepository
    private lateinit var dir: File
    private var clock = 1_000L

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        dir = File(context.cacheDir, "ws-${System.nanoTime()}")
        repo = WorldRepository(db, SourceStore(dir)) { clock++ }
        role = RoleplayRepository(db) { clock++ }
        story = StoryRepository(db) { clock++ }
    }

    @After fun tearDown() { db.close(); dir.deleteRecursively() }

    private fun newWorld(name: String = "Eldoria", online: Boolean = false, prefs: String = "") = runBlocking {
        repo.createWorld(WorldEntity(uuid = "", name = name, description = "Un reino", setting = "fantasía", era = "Era 1", rules = "Sin resurrección", allowOnline = online, preferredSources = prefs, createdAt = 0, updatedAt = 0))
    }

    private fun draft(name: String, type: String = EntryType.PERSONAJE, summary: String = "Resumen de $name con texto suficiente.", conf: String = Confidence.CONFIRMADO, src: Long? = null, key: String = "", state: String = EntryState.ACTIVO) =
        DraftEntry(type, name, emptyList(), summary, "", conf, EntryOrigin.FUENTE, state, evidence = "cita de $name para la prueba", factKey = key, sourceRef = "ref", sourceId = src)

    private fun newSession(name: String = "Aria", user: String = "Ana"): Long = runBlocking {
        val c = CharacterEntity(name = name, personality = "leal", firstMessage = "Hola, viajera.", createdAt = 1, updatedAt = 1)
        val id = role.saveCharacter(c)
        role.startSession(c.copy(id = id), "una taberna", user, "exploradora", AppSettings(), "a.gguf")
    }

    private fun failing(msg: String, retryable: Boolean) = object : SourceProvider {
        var calls = 0
        override val id = "f"; override fun canHandle(source: SourceEntity) = true
        override suspend fun fetch(source: SourceEntity): FetchResult { calls++; return FetchResult.Failed(msg, retryable) }
    }
    private class Good : SourceProvider {
        val fetched = ArrayList<String>()
        override val id = "g"; override fun canHandle(source: SourceEntity) = true
        override suspend fun fetch(source: SourceEntity): FetchResult { fetched.add(source.uri); return FetchResult.Ok("Página ${source.uri.takeLast(2)}", "Esta es la introducción de ${source.uri} con bastante texto de ejemplo para extraer una entrada.\n== Historia ==\nSucedió algo importante en esa historia larga.", "CC BY-SA", "prueba") }
    }

    // ---------------- mundos sin conexión ----------------
    @Test fun createAndEditWorldOffline() = runBlocking {
        val id = newWorld()
        val w = repo.world(id)!!
        assertEquals(1, w.revision); assertTrue(w.uuid.length > 20); assertEquals(SpoilerLevel.SIN, w.spoilerLevel)
        repo.updateWorld(w.copy(name = "Eldoria II", rules = "Magia limitada", continuityMode = Continuity.AU))
        val e = repo.world(id)!!
        assertEquals("Eldoria II", e.name); assertEquals(2, e.revision); assertEquals(w.uuid, e.uuid); assertEquals(Continuity.AU, e.continuityMode)
        try { repo.createWorld(w.copy(name = " ")); fail() } catch (x: WorldException) { }
    }

    @Test fun confirmedRequiresSourceAndEvidence() = runBlocking {
        val id = newWorld()
        fun e(conf: String, ref: String, ev: String) = WorldEntryEntity(worldId = id, type = EntryType.PERSONAJE, name = "Aria", confidence = conf, origin = EntryOrigin.MANUAL, sourceRef = ref, evidence = ev, createdAt = 0, updatedAt = 0)
        try { repo.saveEntry(e(Confidence.CONFIRMADO, "", "")); fail() } catch (x: WorldException) { assertTrue(x.message!!.contains("fuente")) }
        repo.saveEntry(e(Confidence.INVENCION, "", ""))
        assertEquals(1, repo.entryCount(id))
    }

    @Test fun draftsAreDeduplicatedAndNeverOverwrite() = runBlocking {
        val id = newWorld()
        val r1 = repo.addDrafts(id, listOf(draft("Aria"), draft("Aria"), draft("Puerto", EntryType.LUGAR)))
        assertEquals(2, r1.created); assertEquals(1, r1.skipped)
        val before = db.worldEntries().listAll(id).first { it.name == "Aria" }
        repo.addDrafts(id, listOf(draft("Aria", summary = "Resumen de Aria con texto suficiente.")))
        assertEquals(before.summary, db.worldEntries().get(before.id)!!.summary)
    }

    @Test fun contradictionsAreShownNotResolved() = runBlocking {
        val id = newWorld()
        val s1 = repo.addSource(id, SourceKind.URL, "https://a.example/x"); val s2 = repo.addSource(id, SourceKind.URL, "https://b.example/x")
        repo.addDrafts(id, listOf(draft("Aria", summary = "Aria tiene treinta años de edad exactos.", src = s1, key = "Aria|edad"), draft("Aria", summary = "Aria murió siendo una niña pequeña.", src = s2, key = "Aria|edad")))
        assertEquals(1, repo.detectContradictions(id))
        val all = db.worldEntries().listAll(id)
        assertEquals(2, all.size); assertTrue(all.all { it.confidence == Confidence.CONTRADICCION }); assertEquals(1, all.map { it.contradictionGroup }.toSet().size)
    }

    // ---------------- el lore base no se altera por la partida ----------------
    @Test fun gameplayNeverTouchesTheEncyclopedia() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria"), draft("Puerto", EntryType.LUGAR)))
        val sid = newSession(); repo.linkSession(sid, repo.world(wid)!!, CastMode.MIXTO, Continuity.FLEXIBLE, SpoilerLevel.SIN, "")
        val snapshotBefore = db.worldEntries().listAll(wid).map { listOf(it.id, it.name, it.summary, it.confidence, it.updatedAt) }
        val worldBefore = repo.world(wid)!!
        val (_, a) = role.appendUserTurn(sid, "Aria muere y el puerto arde."); role.finish(a, "Aria cae. Todo arde.", MessageState.COMPLETE)
        story.ensureStructure(sid)
        story.addMemory(sid, "Aria murió en el incendio del puerto.", 5, "noche", listOf("Aria"), true)
        story.ensureDefaultRelationship(sid, "Aria", "Ana")
        assertEquals(snapshotBefore, db.worldEntries().listAll(wid).map { listOf(it.id, it.name, it.summary, it.confidence, it.updatedAt) })
        assertEquals(worldBefore.revision, repo.world(wid)!!.revision)
    }

    @Test fun oneWorldTwoSessionsWithIndependentMemories() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria")))
        val a = newSession("Aria", "Ana"); val b = newSession("Aria", "Beto")
        for (s in listOf(a, b)) repo.linkSession(s, repo.world(wid)!!, CastMode.MIXTO, Continuity.FLEXIBLE, SpoilerLevel.SIN, "")
        story.ensureStructure(a); story.ensureStructure(b)
        story.addMemory(a, "Ana prometió volver al puerto.", 4, "d1", listOf("Aria"), false)
        assertEquals(1, db.memories().listAll(a).size); assertEquals(0, db.memories().listAll(b).size)
        assertEquals(wid, repo.sessionWorld(a)!!.worldId); assertEquals(wid, repo.sessionWorld(b)!!.worldId)
        assertEquals(1, repo.entryCount(wid))
    }

    @Test fun deletingTheWorldKeepsTheSession() = runBlocking {
        val wid = newWorld(); val sid = newSession()
        repo.linkSession(sid, repo.world(wid)!!, CastMode.MIXTO, Continuity.FLEXIBLE, SpoilerLevel.SIN, "")
        repo.deleteWorld(wid)
        assertNotNull(db.roleSessions().get(sid)); val link = repo.sessionWorld(sid)!!
        assertNull(link.worldId); assertEquals("Eldoria", link.worldName); assertNull(repo.snapshotFor(sid))
    }

    // ---------------- .worldpack ----------------
    @Test fun exportImportCopyKeepsEverythingAndNeverTouchesOriginal() = runBlocking {
        val wid = newWorld(); val src = repo.addSource(wid, SourceKind.URL, "https://a.example/x")
        repo.addDrafts(wid, listOf(draft("Aria", src = src), draft("Puerto", EntryType.LUGAR, src = src), draft("Propuesta", state = EntryState.PROPUESTO)))
        val pack = repo.buildPack(wid)!!
        assertEquals(2, pack.entries.size)   // solo lo activo viaja
        val round = WorldpackCodec.read(java.io.ByteArrayInputStream(java.io.ByteArrayOutputStream().also { WorldpackCodec.write(pack, it) }.toByteArray()))
        val plan = repo.previewImport(round)
        assertNotNull(plan.existing); assertTrue(plan.sameRevision.not() || plan.newEntriesIfMerged == 0)
        val copyId = repo.importPack(round, WorldImportChoice.COPIA)
        assertNotEquals(wid, copyId); assertEquals(2, repo.entryCount(copyId)); assertNotEquals(repo.world(wid)!!.uuid, repo.world(copyId)!!.uuid)
        assertEquals(1, db.sources().list(copyId).size); assertEquals("IMPORTADO", repo.world(copyId)!!.origin)
        assertEquals(3, db.worldEntries().listAll(wid).size)   // el original conserva hasta la propuesta
        assertFalse(repo.world(copyId)!!.allowOnline)           // un mundo importado nace sin permiso online
    }

    @Test fun mergeAddsOnlyMissingAndNeverOverwrites() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria")))
        val pack = repo.buildPack(wid)!!
        repo.saveEntry(db.worldEntries().listAll(wid).first().let { it.copy(summary = "Texto editado por el usuario después.", confidence = Confidence.INVENCION, sourceRef = "", evidence = "") })
        val bigger = com.jullai.local.world.WorldPack(pack.appVersion, pack.exportedAt, pack.world, pack.entries + com.jullai.local.world.PackEntry(EntryType.LUGAR, "Torre", emptyList(), "Una torre alta y fría.", "", Confidence.LIMITADA, EntryOrigin.IMPORTADO, null, "", "", "", "", emptyList(), 0, "", EntryState.ACTIVO), pack.sources)
        assertEquals(1, repo.previewImport(bigger).newEntriesIfMerged)
        val id = repo.importPack(bigger, WorldImportChoice.COMBINAR)
        assertEquals(wid, id); assertEquals(2, repo.entryCount(wid))
        assertEquals("Texto editado por el usuario después.", db.worldEntries().listAll(wid).first { it.name == "Aria" }.summary)
        assertEquals(wid, repo.importPack(bigger, WorldImportChoice.USAR_EXISTENTE))
    }

    @Test fun duplicateWorldIsIndependent() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria")))
        val dup = repo.duplicateWorld(wid)!!
        repo.deleteEntry(db.worldEntries().listAll(dup).first().id)
        assertEquals(0, repo.entryCount(dup)); assertEquals(1, repo.entryCount(wid)); assertTrue(repo.world(dup)!!.name.endsWith("(copia)"))
    }

    @Test fun sessionSnapshotRestoresWorldWhenMissingAndLinksExplicitly() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria"), draft("Puerto", EntryType.LUGAR)))
        val sid = newSession()
        repo.linkSession(sid, repo.world(wid)!!, CastMode.CANONICO, Continuity.ESTRICTA, SpoilerLevel.MODERADO, "Era 7")
        val snap = repo.snapshotFor(sid)!!
        val pack = WorldpackCodec.decodeSnapshot(snap)
        assertEquals(Continuity.ESTRICTA, pack.link!!.continuityMode)
        // «otro dispositivo»: el mundo no existe
        repo.deleteWorld(wid)
        val newSid = newSession("Aria", "Ana")
        assertNull(repo.previewImport(pack).existing)
        val restored = repo.attachSnapshot(newSid, pack, WorldImportChoice.CREAR)
        val link = repo.sessionWorld(newSid)!!
        assertEquals(restored, link.worldId); assertEquals(Continuity.ESTRICTA, link.continuityMode); assertEquals("Era 7", link.startEra); assertEquals(2, repo.entryCount(restored))
        // con el mundo ya presente y distinto, hay que elegir
        val plan = repo.previewImport(pack)
        assertNotNull(plan.existing)
        val local = repo.importPack(pack, WorldImportChoice.USAR_EXISTENTE)
        assertEquals(restored, local)
    }

    // ---------------- recuperación en modo avión ----------------
    @Test fun retrievalWorksWithNoNetworkAndKeepsProvenance() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria", summary = "Aria es la capitana del puerto."), draft("Zorgon", summary = "Villano de otra tierra lejana."), draft("Teoría", summary = "Dicen que Aria es inmortal.", conf = Confidence.AFICIONADOS, key = "")))
        val r = WorldRetriever(repo).retrieve(WorldRequest(wid, "Mundo: Eldoria.", listOf("Ana habla con Aria sobre el puerto"), listOf("Ana"), SpoilerLevel.COMPLETO, Continuity.FLEXIBLE, "", 500)) { it.length / 4 + 1 }
        val names = r.picked.map { it.item.name }
        assertTrue(names.contains("Aria")); assertFalse(names.contains("Zorgon"))
        assertEquals(Confidence.AFICIONADOS, r.picked.first { it.item.name == "Teoría" }.item.confidence)
        assertTrue(r.usedTokens <= 500)
    }

    @Test fun fullTextSearchPathWorksWhenFts4IsAvailable() = runBlocking {
        val ok = WorldFts.ensure(db.openHelper.writableDatabase)
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Aria", summary = "Capitana del puerto gris y del faro."), draft("Torre", EntryType.LUGAR, summary = "Una torre antigua.")))
        val found = repo.searchEntries(wid, "capitana faro")
        assertEquals(listOf("Aria"), found.map { it.name })
        if (ok) assertTrue(repo.candidates(wid, listOf("capitana")).backend.contains("FTS4"))
    }

    // ---------------- motor de investigación ----------------
    private suspend fun taskFor(wid: Long) = repo.createTask(wid)

    @Test fun researchSucceedsOnlyWithSourcesAndEntries() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno"); repo.addSource(wid, SourceKind.URL, "https://b.example/dos")
        val good = Good(); val tid = taskFor(wid)
        val out = ResearchEngine(repo, listOf(good), null).run(tid)
        assertEquals(TaskStatus.COMPLETADA, out.status)
        val t = repo.task(tid)!!
        assertEquals(2, t.sourcesOk); assertEquals(0, t.sourcesFailed); assertTrue(t.entriesCreated >= 2); assertNotNull(t.finishedAt)
        assertTrue(db.sources().list(wid).all { it.status == SourceStatus.PROCESADA && it.consultedAt != null && it.textFile != null && it.license == "CC BY-SA" })
        assertTrue(db.worldEntries().listAll(wid).all { it.state == EntryState.PROPUESTO })   // fuentes de URL: propuestas para revisar
    }

    @Test fun researchWithOnlyFailuresIsNotASuccess() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno")
        val tid = taskFor(wid)
        val out = ResearchEngine(repo, listOf(failing("El sitio no permite el acceso automático (código 403).", false)), null).run(tid)
        assertEquals(TaskStatus.FALLIDA, out.status); assertFalse(out.retry)
        val s = db.sources().list(wid).single(); assertEquals(SourceStatus.FALLIDA, s.status); assertTrue(s.error.contains("403"))
        assertEquals(0, repo.entryCount(wid))
    }

    @Test fun researchWithNothingToReadIsNotASuccess() = runBlocking {
        val wid = newWorld(); val tid = taskFor(wid)
        assertEquals(TaskStatus.SIN_RESULTADOS, ResearchEngine(repo, listOf(Good()), null).run(tid).status)
    }

    @Test fun unsupportedSourcesAreListedAsSuch() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/libro.pdf"); repo.addSource(wid, SourceKind.URL, "https://b.example/ok")
        val p = object : SourceProvider { override val id = "m"; override fun canHandle(source: SourceEntity) = true
            override suspend fun fetch(source: SourceEntity) = if (source.uri.endsWith(".pdf")) FetchResult.Unsupported("PDF no compatible") else Good().fetch(source) }
        val tid = taskFor(wid); assertEquals(TaskStatus.COMPLETADA, ResearchEngine(repo, listOf(p), null).run(tid).status)
        assertEquals(SourceStatus.NO_COMPATIBLE, db.sources().list(wid).first { it.uri.endsWith(".pdf") }.status)
    }

    @Test fun temporaryFailureSchedulesLimitedRetriesThenResumesWithoutRepeating() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno"); repo.addSource(wid, SourceKind.URL, "https://b.example/dos")
        val tid = taskFor(wid)
        var failB = true
        val fetched = ArrayList<String>()
        val flaky = object : SourceProvider { override val id = "x"; override fun canHandle(source: SourceEntity) = true
            override suspend fun fetch(source: SourceEntity): FetchResult { fetched.add(source.uri)
                return if (source.uri.contains("b.example") && failB) FetchResult.Failed("Error de red: sin conexión", true) else Good().fetch(source) } }
        val engine = ResearchEngine(repo, listOf(flaky), null)
        val first = engine.run(tid)
        assertEquals(TaskStatus.PENDIENTE, first.status); assertTrue(first.retry)           // reintento programado
        assertEquals(SourceStatus.PROCESADA, db.sources().list(wid).first { it.uri.contains("a.example") }.status)
        failB = false
        val second = engine.run(tid)
        assertEquals(TaskStatus.COMPLETADA, second.status)
        assertEquals(1, fetched.count { it.contains("a.example") })   // la fuente ya procesada NO se vuelve a pedir
        assertEquals(2, repo.task(tid)!!.attempts)
    }

    @Test fun retriesAreLimited() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno")
        val tid = taskFor(wid); val p = failing("Error de red: sin conexión", true)
        val engine = ResearchEngine(repo, listOf(p), null)
        var last = engine.run(tid); var guard = 0
        while (last.retry && guard++ < 10) last = engine.run(tid)
        assertTrue(guard < 10); assertEquals(TaskStatus.FALLIDA, last.status); assertTrue(p.calls <= 3)
    }

    @Test fun cancelledTaskStopsAndIsNotResurrected() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno")
        val tid = taskFor(wid); repo.saveTask(repo.task(tid)!!.copy(status = TaskStatus.CANCELADA))
        val good = Good()
        assertEquals(TaskStatus.CANCELADA, ResearchEngine(repo, listOf(good), null).run(tid).status)
        assertTrue(good.fetched.isEmpty())
    }

    @Test fun cancelBetweenSourcesKeepsWhatWasDone() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno"); repo.addSource(wid, SourceKind.URL, "https://b.example/dos")
        val tid = taskFor(wid)
        val p = object : SourceProvider { override val id = "c"; override fun canHandle(source: SourceEntity) = true
            override suspend fun fetch(source: SourceEntity): FetchResult { val r = Good().fetch(source); repo.saveTask(repo.task(tid)!!.copy(status = TaskStatus.CANCELADA)); return r } }
        val out = ResearchEngine(repo, listOf(p), null).run(tid)
        assertEquals(TaskStatus.CANCELADA, out.status)
        assertEquals(1, db.sources().list(wid).count { it.status == SourceStatus.PROCESADA }); assertEquals(1, db.sources().list(wid).count { it.status == SourceStatus.PENDIENTE })
    }

    @Test fun finishedTaskIsNotRunAgain() = runBlocking {
        val wid = newWorld(); repo.addSource(wid, SourceKind.URL, "https://a.example/uno"); val tid = taskFor(wid); val good = Good()
        val e = ResearchEngine(repo, listOf(good), null); e.run(tid); val n = good.fetched.size; e.run(tid)
        assertEquals(n, good.fetched.size)
    }

    @Test fun changingAFailedUrlRequeuesIt() = runBlocking {
        val wid = newWorld(); val sid = repo.addSource(wid, SourceKind.URL, "https://roto.example/x")
        repo.markSourceFailed(sid, SourceStatus.FALLIDA, "La página no existe (código 404).", null)
        repo.changeSourceUri(sid, "https://bien.example/x")
        val s = repo.source(sid)!!; assertEquals(SourceStatus.PENDIENTE, s.status); assertEquals("", s.error); assertEquals("https://bien.example/x", s.uri)
        val other = repo.addSource(wid, SourceKind.URL, "https://otra.example/y")
        try { repo.changeSourceUri(sid, "https://otra.example/y"); fail() } catch (x: WorldException) { }
        assertNotEquals(sid, other)
    }

    // ---------------- preparación y novela visual ----------------
    @Test fun firstSceneIsBuiltOnlyWhenMissingAndNeverTouchesTheWorld() = runBlocking {
        val wid = newWorld(); repo.addDrafts(wid, listOf(draft("Puerto Gris", EntryType.LUGAR)))
        val c = CharacterEntity(name = "Aria", personality = "leal", createdAt = 1, updatedAt = 1)
        val cid = role.saveCharacter(c); val sid = role.startSession(c.copy(id = cid), "", "Ana", "", AppSettings(), "a.gguf")
        repo.linkSession(sid, repo.world(wid)!!, CastMode.MIXTO, Continuity.FLEXIBLE, SpoilerLevel.SIN, "")
        val facts0 = repo.prepFacts(sid, false, false); assertTrue(facts0.worldExists); assertEquals(1, facts0.locationEntries)
        val rev = repo.world(wid)!!.revision
        assertTrue(repo.buildFirstScene(sid))
        val text = db.roleSessions().get(sid)!!.scenarioText
        assertTrue(text.contains("Eldoria") && text.contains("Puerto Gris") && text.contains("Aria"))
        db.roleSessions().update(db.roleSessions().get(sid)!!.copy(scenarioText = "Escena del usuario"))
        repo.buildFirstScene(sid); assertEquals("Escena del usuario", db.roleSessions().get(sid)!!.scenarioText)
        assertEquals(rev, repo.world(wid)!!.revision)
    }

    @Test fun sceneMetadataIsStoredPerTurnAndKeepsTextUntouched() = runBlocking {
        val sid = newSession(); val (_, a) = role.appendUserTurn(sid, "Hola"); role.finish(a, "—Hola —dijo Aria.", MessageState.COMPLETE)
        repo.saveScene(sid, a, SceneDraft("Taberna", "Aria", "ALEGRIA", "", VisualEvent.DIALOGO, false, true), "portrait:1")
        repo.saveScene(sid, a, SceneDraft("Taberna", "Aria", "MIEDO", "", VisualEvent.IMPORTANTE, true, true), "")
        val m = repo.sceneFor(sid, a)!!; assertEquals("MIEDO", m.emotion); assertTrue(m.important)
        assertEquals("—Hola —dijo Aria.", db.roleMessages().list(sid).last().content)   // el texto original no cambia
        assertEquals(1, db.sceneMeta().recent(sid, 10).size)
    }

    @Test fun assetsRegistryAssociatesCharactersAndLocations() = runBlocking {
        val c = CharacterEntity(name = "Aria", createdAt = 1, updatedAt = 1); val cid = role.saveCharacter(c)
        repo.addAsset("RETRATO", "p1.jpg", "Aria", cid, null, "", "ENFADO"); repo.addAsset("FONDO", "f1.jpg", "Puerto", null, null, "Puerto Gris", "")
        val infos = repo.assetInfos()
        assertEquals("aria", infos.first { it.kind == "RETRATO" }.characterKey); assertEquals("Puerto Gris", infos.first { it.kind == "FONDO" }.locationRef)
    }

    // ---------------- migración ----------------
    @Test fun upgradeFromV03AddsWorldTablesWithoutTouchingOldData() = runBlocking {
        val name = "mig-v4.db"; context.deleteDatabase(name)
        val helper = FrameworkSQLiteOpenHelperFactory().create(SupportSQLiteOpenHelper.Configuration.builder(context).name(name).callback(object : SupportSQLiteOpenHelper.Callback(2) {
            override fun onCreate(db: SupportSQLiteDatabase) { LegacyDbs.createV2(db); LegacyDbs.insertV03Data(db) }
            override fun onUpgrade(db: SupportSQLiteDatabase, o: Int, n: Int) {}
        }).build()); helper.writableDatabase.close(); helper.close()
        val old = Room.databaseBuilder(context, AppDatabase::class.java, name).addMigrations(*Migrations.ALL).allowMainThreadQueries().build()
        try {
            assertEquals("Mi chat", old.conversations().get(1)!!.title); assertEquals(3, old.roleMessages().list(1).size)
            val r = WorldRepository(old, SourceStore(dir)) { 5L }
            val wid = r.createWorld(WorldEntity(uuid = "", name = "Nuevo", createdAt = 0, updatedAt = 0))
            r.linkSession(1, r.world(wid)!!, CastMode.MIXTO, Continuity.FLEXIBLE, SpoilerLevel.SIN, "")
            assertEquals(wid, r.sessionWorld(1)!!.worldId)
            old.roleSessions().delete(1); assertNull(r.sessionWorld(1))   // CASCADE
            assertNotNull(r.world(wid))
        } finally { old.close(); context.deleteDatabase(name) }
    }
}
