package com.jullai.local.imaging

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.jullai.local.data.AppDatabase
import com.jullai.local.data.CharacterEntity
import com.jullai.local.data.ImageModelEntity
import com.jullai.local.data.LegacyDbs
import com.jullai.local.data.Migrations
import com.jullai.local.data.VisualAssetEntity
import com.jullai.local.data.VisualProfileEntity
import com.jullai.local.world.AssetKind
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ImagingDatabaseTest {
    @get:Rule val tmp = TemporaryFolder()
    private lateinit var db: AppDatabase
    private lateinit var repo: ImageRepository
    private lateinit var engine: FakeImageEngine
    private lateinit var text: FakeText
    private lateinit var gate: FakeGate
    private lateinit var coord: ResourceCoordinator
    private lateinit var queue: ImageQueue
    private var settings = ImageSettings()
    private var clock = 1_000L
    private val saved = ArrayList<String>()

    @Before fun setUp() {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = ImageRepository(db) { clock++ }
        engine = FakeImageEngine(); text = FakeText(); gate = FakeGate()
        coord = ResourceCoordinator(engine, text, gate)
        val dir = tmp.newFolder()
        queue = ImageQueue(
            repo, coord, { "fake" to "0" }, { engine.capabilities() }, { settings }, { java.io.File(dir, it).also { f -> f.writeBytes(ByteArray(8)) } },
            { r -> "g_${saved.size}.png".also { saved.add(it) } }, { _, _, _ -> null }, { null },
            CoroutineScope(SupervisorJob() + Dispatchers.Default), { clock++ },
        )
    }

    @After fun tearDown() { db.close() }

    private fun addModel(kind: String = ImageModelKinds.CHECKPOINT, name: String = "m1") = runBlocking {
        repo.addModel(ImageModelEntity(kind = kind, fileName = "$name.safetensors", displayName = name, format = "SAFETENSORS", sizeBytes = 2L shl 30, architecture = "SD 1.x", compat = ModelCompat.UNVERIFIED, importedAt = 0))
    }

    private fun spec(kind: String = AssetKind.RETRATO, prio: Int = 2, prompt: String = "p", cid: Long? = null, preset: String = QualityPreset.LOW_POWER.id) =
        TaskSpec(kind, prio, ImageSizes.PORTRAIT_LOW, 4, prompt, "neg", worldId = 1, sessionId = 9, messageId = 5, characterId = cid, label = "L", preset = preset)

    @Test fun successSavesAssetAndMetaTogetherAndFirstCheckpointBecomesDefault() = runBlocking {
        addModel()
        assertNotNull(repo.defaultModel(ImageModelKinds.CHECKPOINT))
        val id = repo.enqueue(spec(prompt = "un gato"))
        queue.runUntilIdle()
        val t = repo.task(id)!!
        assertEquals(TaskStatus.LISTA, t.status); assertNotNull(t.resultAssetId)
        val a = db.visualAssets().get(t.resultAssetId!!)!!
        assertEquals(AssetKind.RETRATO, a.kind); assertEquals("g_0.png", a.file)
        val m = repo.meta(a.id)!!
        assertEquals("un gato", m.prompt); assertEquals(5L, m.seed); assertEquals(256, m.width); assertEquals(1234L, m.durationMs); assertEquals("m1", m.modelName); assertEquals(9L, m.sessionId)
        assertTrue(engine.releases >= 1)   // el motor visual se libera al terminar la cola
        assertNull(engine.loaded)
    }

    @Test fun withoutModelTaskFailsClearlyAndNothingIsCreated() = runBlocking {
        val id = repo.enqueue(spec()); queue.runUntilIdle()
        assertEquals(TaskStatus.FALLIDA, repo.task(id)!!.status); assertTrue(repo.task(id)!!.error.contains("modelo de imagen")); assertEquals(0, db.visualAssets().listAll().size)
    }

    @Test fun engineFailureNeverTouchesExistingAssetsOrAddsOne() = runBlocking {
        addModel()
        val old = db.visualAssets().insert(VisualAssetEntity(kind = AssetKind.RETRATO, file = "old.png", characterId = 1, createdAt = 1))
        engine.failGenerate = ImageEngineException(ImageEngineException.Code.FAILED, "boom")
        val id = repo.enqueue(spec(cid = 1)); queue.runUntilIdle()
        val t = repo.task(id)!!
        assertEquals(TaskStatus.FALLIDA, t.status); assertEquals("boom", t.error)
        assertEquals(listOf(old), db.visualAssets().listAll().map { it.id }); assertEquals("old.png", db.visualAssets().get(old)!!.file)
        engine.failGenerate = null
        queue.retry(id); queue.runUntilIdle()
        assertEquals(TaskStatus.LISTA, repo.task(id)!!.status)       // reintentar funciona
    }

    @Test fun priorityOrderIsRespected() = runBlocking {
        addModel()
        repo.enqueue(spec(prio = TaskPriority.ILLUSTRATION, prompt = "ilustracion"))
        repo.enqueue(spec(prio = TaskPriority.VARIANT, prompt = "variante"))
        repo.enqueue(spec(prio = TaskPriority.FIRST_SCENE, prompt = "primera"))
        repo.enqueue(spec(prio = TaskPriority.NEXT_SCENE, prompt = "siguiente"))
        queue.runUntilIdle()
        assertEquals(listOf("primera", "siguiente", "variante", "ilustracion"), engine.prompts)
    }

    @Test fun textPriorityPausesQueueAndTasksStayPending() = runBlocking {
        addModel(); text.generating = true
        val id = repo.enqueue(spec()); queue.runUntilIdle()
        assertEquals(TaskStatus.PENDIENTE, repo.task(id)!!.status); assertTrue(engine.loads.isEmpty())
        text.generating = false; queue.runUntilIdle()
        assertEquals(TaskStatus.LISTA, repo.task(id)!!.status)
    }

    @Test fun hotPhoneDefersAndWakeResumes() = runBlocking {
        addModel(); gate.heat = ThermalLevel.SEVERE
        val id = repo.enqueue(spec()); queue.runUntilIdle()
        assertEquals(TaskStatus.APLAZADA, repo.task(id)!!.status); assertTrue(repo.task(id)!!.note.contains("caliente"))
        gate.heat = ThermalLevel.NONE
        repo.wakeDeferred(); queue.runUntilIdle()
        assertEquals(TaskStatus.LISTA, repo.task(id)!!.status)
    }

    @Test fun interruptedTaskReturnsToPendingAfterRestart() = runBlocking {
        addModel()
        val id = repo.enqueue(spec())
        repo.updateTask(repo.task(id)!!.copy(status = TaskStatus.EN_CURSO))       // la app murió con la tarea en curso
        queue.onAppStart()
        assertEquals(TaskStatus.PENDIENTE, repo.task(id)!!.status); assertTrue(repo.task(id)!!.note.contains("Interrumpida"))
        assertEquals(1, repo.pendingTasks().size)
    }

    @Test fun userCancelOfRunningTaskMarksItCancelled() = runBlocking {
        addModel(); engine.blockUntil = CompletableDeferred()
        val id = repo.enqueue(spec())
        val run = async(Dispatchers.Default) { queue.runUntilIdle() }
        while (queue.currentTask.value != id || !coord.isBusy) delay(5)
        queue.cancel(id); run.await()
        assertEquals(TaskStatus.CANCELADA, repo.task(id)!!.status); assertEquals(0, db.visualAssets().listAll().size)
    }

    @Test fun lcmPresetWithoutLoraFallsBackToNormalSampler() = runBlocking {
        addModel()
        repo.enqueue(spec(preset = QualityPreset.LOW_POWER_LCM.id)); queue.runUntilIdle()
        assertEquals(Samplers.EULER_A, engine.lastRequest!!.sampler); assertEquals(7f, engine.lastRequest!!.cfgScale)
        val lora = addModel(ImageModelKinds.LORA, "lcm"); repo.setDefault(lora)
        repo.enqueue(spec(preset = QualityPreset.LOW_POWER_LCM.id)); queue.runUntilIdle()
        assertEquals(Samplers.LCM, engine.lastRequest!!.sampler); assertNotNull(engine.lastRequest!!.loraPath)
        assertEquals("lcm", repo.meta(db.visualAssets().listAll().last().id)!!.loraName)
    }

    @Test fun cascadeDeletesKeepDatabaseConsistent() = runBlocking {
        val cid = db.characters().insert(CharacterEntity(name = "Aria", createdAt = 1, updatedAt = 1))
        repo.saveProfile(VisualProfileEntity(characterId = cid, physicalDescription = "pelo plateado", updatedAt = 0))
        repo.saveProfile(VisualProfileEntity(characterId = cid, physicalDescription = "pelo negro", updatedAt = 0))   // actualiza, no duplica
        assertEquals("pelo negro", repo.profile(cid)!!.physicalDescription)
        val aid = repo.saveGenerated(AssetKind.RETRATO, "g.png", "x", cid, null, "", "", com.jullai.local.data.ImageMetaEntity(assetId = 0, prompt = "p", createdAt = 1))
        assertNotNull(repo.meta(aid))
        db.visualAssets().delete(aid); assertNull(repo.meta(aid))
        db.characters().get(cid)?.let { db.openHelper.writableDatabase.execSQL("DELETE FROM characters WHERE id = $cid") }
        assertNull(repo.profile(cid))
    }

    @Test fun illustrationsAreStoredPerSessionForRereading() = runBlocking {
        addModel()
        repo.enqueue(spec(kind = AssetKind.ILUSTRACION, prio = TaskPriority.ILLUSTRATION)); queue.runUntilIdle()
        val ills = repo.illustrationsOf(9)
        assertEquals(1, ills.size); assertEquals(5L, ills[0].messageId); assertEquals(1, repo.forMessage(9, 5).size)
    }

    @Test fun upgradeFromV03CreatesEmptyImageTablesAndKeepsData() = runBlocking {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        val name = "mig-img.db"
        ctx.deleteDatabase(name)
        val helper = androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
            androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(ctx).name(name).callback(object : androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(2) {
                override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) { LegacyDbs.createV2(db); LegacyDbs.insertV03Data(db) }
                override fun onUpgrade(db: androidx.sqlite.db.SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
            }).build(),
        )
        helper.writableDatabase.close(); helper.close()
        val d = Room.databaseBuilder(ctx, AppDatabase::class.java, name).addMigrations(*Migrations.ALL).allowMainThreadQueries().build()
        try {
            assertEquals("Mi chat", d.conversations().get(1)!!.title)
            val r = ImageRepository(d)
            assertEquals(0, r.models().size); assertEquals(0, r.openCount())
            r.enqueue(spec()); assertEquals(1, r.openCount())
        } finally { d.close(); ctx.deleteDatabase(name) }
    }
}
