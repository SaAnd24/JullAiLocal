package com.jullai.local.story

import com.jullai.local.engine.ChatMessage
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MaintenanceTest {
    private val count: suspend (String) -> Int = { t -> t.split(Regex("\\s+")).count { it.isNotEmpty() } }
    private val template: suspend (List<ChatMessage>) -> String = { m -> m.joinToString("\n") { it.content } }

    @Test fun parsesAllLineKinds() {
        val raw = """
            RESUMEN: Aria y Ana llegaron al bosque.
            Encontraron un mapa antiguo.
            RECUERDO[5]: Aria guardó la llave de la torre bajo el roble.
            INFERENCIA[2]: Aria parece ocultar algo sobre su pasado.
            CRONOLOGIA[segundo día, noche]: Una tormenta destruyó el puente norte.
            RELACION[Aria>Ana] confianza=+2 afecto=0 respeto=+1 romantico=0 | Ana la ayudó a cruzar el río
        """.trimIndent()
        val p = MaintenanceParser.parse(raw)
        assertTrue(p.summary!!.contains("mapa antiguo"))
        assertEquals(2, p.memories.size)
        assertEquals(5, p.memories[0].importance); assertFalse(p.memories[0].inferred)
        assertTrue(p.memories[1].inferred)
        assertEquals("segundo día, noche", p.events.single().date)
        val r = p.relations.single()
        assertEquals("Aria", r.a); assertEquals("Ana", r.b)
        assertEquals(RelDelta(trust = 2, respect = 1), r.delta)
        assertTrue(r.reason.contains("río"))
    }

    @Test fun toleratesNoiseAndUnicodeMinus() {
        val p = MaintenanceParser.parse("Claro, aquí tienes:\n- RECUERDO: Un hecho suficientemente largo.\n2) relación[Aria→Ana] confianza=−3 | traición\nbasura")
        assertEquals(1, p.memories.size)
        assertEquals(3, p.memories[0].importance)
        assertEquals(-3, p.relations.single().delta.trust)
        assertEquals(2, p.ignoredLines)
    }

    @Test fun enforcesCountsAndLengths() {
        val raw = (1..20).joinToString("\n") { "RECUERDO[3]: hecho número $it con texto" } + "\n" +
            (1..10).joinToString("\n") { "INFERENCIA[1]: deducción $it con texto" } + "\n" +
            (1..10).joinToString("\n") { "RELACION[A>B] afecto=+1 | motivo $it" } + "\nRECUERDO: " + "x".repeat(5000)
        val p = MaintenanceParser.parse(raw)
        assertEquals(MaintenanceParser.MAX_MEMORIES, p.memories.count { !it.inferred })
        assertEquals(MaintenanceParser.MAX_INFERENCES, p.memories.count { it.inferred })
        assertEquals(MaintenanceParser.MAX_RELATIONS, p.relations.size)
        assertTrue(p.memories.all { it.content.length <= StoryLimits.MEMORY_CHARS })
    }

    @Test fun badRelationLinesAreIgnored() {
        val p = MaintenanceParser.parse("RELACION[Solo]: confianza=+1\nRELACION[A>B]: sin numeros | x")
        assertTrue(p.relations.isEmpty()); assertEquals(2, p.ignoredLines)
    }

    @Test fun garbageYieldsEmpty() {
        assertTrue(MaintenanceParser.parse("no sé qué decir\notra cosa").isEmpty())
        assertTrue(MaintenanceParser.parse("").isEmpty())
    }

    @Test fun dedupSkipsParaphrases() {
        val existing = listOf("La llave de la torre está bajo el roble sagrado")
        val out = Dedup.filterNew(listOf("La llave de la torre esta bajo el roble", "Aria teme al fuego", "Aria teme al fuego intenso"), { it }, existing)
        assertEquals(listOf("Aria teme al fuego"), out)
    }

    @Test fun policy() {
        assertFalse(MaintenancePolicy.isDue(AutoMode.MANUAL, 10, 999, true))
        assertFalse(MaintenancePolicy.isDue(AutoMode.CADA_N, 10, 9, false))
        assertTrue(MaintenancePolicy.isDue(AutoMode.CADA_N, 10, 10, false))
        assertTrue(MaintenancePolicy.isDue(AutoMode.CAPITULO, 10, 0, true))
        assertFalse(MaintenancePolicy.isDue(AutoMode.CAPITULO, 10, 50, false))
    }

    private fun lines(n: Int) = (0 until n).map { StoryLine(it, if (it % 2 == 0) "Aria" else "Ana", "mensaje número $it " + "palabra ".repeat(20)) }

    @Test fun promptTakesOldestUncoveredChunkAndReportsPending() = runBlocking {
        val p = MaintenancePrompts.build("Aria, Ana", "resumen previo", listOf("dato conocido"), lines(100), 1500, count, template)!!
        assertTrue(p.linesIncluded in 1 until 100)
        assertEquals(p.linesIncluded - 1, p.coversUpTo)        // empieza por el primero: sin huecos
        assertEquals(100 - p.linesIncluded, p.linesPending)
        val used = count(p.messages.joinToString("\n") { it.content })
        assertTrue("usado $used", used < 1500 - MaintenancePrompts.OUTPUT_TOKENS.coerceAtMost(500))
        assertTrue(p.messages[1].content.contains("RESUMEN ANTERIOR"))
    }

    @Test fun promptNullWhenNothingNewOrNoRoom() = runBlocking {
        assertNull(MaintenancePrompts.build("a", "", emptyList(), emptyList(), 4096, count, template))
        assertNull(MaintenancePrompts.build("a", "", emptyList(), lines(3), 200, count, template))
    }

    @Test fun hugeSingleMessageIsTruncatedSoItAdvances() = runBlocking {
        val big = listOf(StoryLine(7, "Aria", "palabra ".repeat(5000)))
        val p = MaintenancePrompts.build("a", "", emptyList(), big, 2000, count, template)
        assertNotNull(p); assertEquals(7, p!!.coversUpTo)
    }
}
