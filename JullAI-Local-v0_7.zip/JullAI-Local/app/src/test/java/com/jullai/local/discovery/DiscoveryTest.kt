package com.jullai.local.discovery

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Cliente falso con respuestas con la forma real de la API de MediaWiki (formatversion=2). NO prueba que las wikis reales respondan así:
 * eso solo se comprueba en el teléfono (guía de pruebas manuales). Sí prueba que la lógica es correcta con esas formas y que no se rompe con basura.
 */
class FakeWiki(private val handler: (api: String, query: String) -> String?) : WikiClient {
    val calls = ArrayList<String>()
    var bytesFor: (String) -> ByteArray? = { null }
    override suspend fun api(api: String, query: String): String {
        calls.add("$api?$query")
        return handler(api, query) ?: throw WikiFetchException("La página no existe (código 404).", false)
    }
    override suspend fun fandomUrl(url: String): String { calls.add(url); return handler("fandom-v1", url) ?: throw WikiFetchException("sin respuesta", false) }
    override suspend fun bytes(url: String, maxBytes: Int): ByteArray = bytesFor(url) ?: throw WikiFetchException("sin imagen", false)
}

private fun pageJson(vararg pages: String) = """{"batchcomplete":true,"query":{"pages":[${pages.joinToString(",")}]}}"""
private fun searchPage(title: String, index: Int, desc: String, qid: String, extract: String = "", disamb: Boolean = false) =
    """{"pageid":$index,"ns":0,"title":"$title","index":$index,"pageprops":{"wikibase-shortdesc":"$desc","wikibase_item":"$qid"${if (disamb) ",\"disambiguation\":\"\"" else ""}},"extract":"$extract"}"""

class DiscoveryTest {
    // ---------------- lista cerrada de servidores ----------------
    @Test fun trustedApiAcceptsOnlyWikimediaAndFandomOverHttps() {
        assertTrue(WikiHosts.isTrustedApi("https://es.wikipedia.org/w/api.php"))
        assertTrue(WikiHosts.isTrustedApi("https://www.wikidata.org/w/api.php"))
        assertTrue(WikiHosts.isTrustedApi("https://walkingdead.fandom.com/api.php"))
        assertTrue(WikiHosts.isTrustedApi("https://walkingdead.fandom.com/es/api.php"))
        assertFalse(WikiHosts.isTrustedApi("http://es.wikipedia.org/w/api.php"))
        assertFalse(WikiHosts.isTrustedApi("https://wikipedia.org.evil.com/w/api.php"))
        assertFalse(WikiHosts.isTrustedApi("https://evilfandom.com/api.php"))
        assertFalse(WikiHosts.isTrustedApi("https://fandom.com/api.php"))
        assertFalse(WikiHosts.isTrustedApi("https://es.wikipedia.org@evil.com/w/api.php"))
        assertFalse(WikiHosts.isTrustedApi("https://es.wikipedia.org:8443/w/api.php"))
        assertFalse(WikiHosts.isTrustedApi("https://es.wikipedia.org/w/index.php"))
        assertFalse(WikiHosts.isTrustedApi("https://127.0.0.1/api.php"))
        assertFalse(WikiHosts.isTrustedApi("javascript:alert(1)"))
    }
    @Test fun trustedImageHostsAreClosedList() {
        assertTrue(WikiHosts.isTrustedImageUrl("https://upload.wikimedia.org/wikipedia/en/a/ab/X.png"))
        assertTrue(WikiHosts.isTrustedImageUrl("https://static.wikia.nocookie.net/walkingdead/images/a/ab/Rick.png/revision/latest"))
        assertFalse(WikiHosts.isTrustedImageUrl("http://upload.wikimedia.org/x.png"))
        assertFalse(WikiHosts.isTrustedImageUrl("https://upload.wikimedia.org.evil.com/x.png"))
        assertFalse(WikiHosts.isTrustedImageUrl("https://evil.com/x.png"))
        assertFalse(WikiHosts.isTrustedImageUrl("https://192.168.1.4/x.png"))
    }
    @Test fun fandomGuessesAreReasonableAndSafe() {
        val g = WikiHosts.fandomGuesses("The Walking Dead (TV series)")
        assertTrue(g.contains("walkingdead")); assertTrue(g.contains("thewalkingdead"))
        assertTrue(g.all { WikiHosts.fandom(it) != null })
        assertTrue(WikiHosts.fandomGuesses("***").isEmpty())
        assertNull(WikiHosts.fandom("evil.com/x"))
        assertNull(WikiHosts.fandom("a b"))
    }
    @Test fun queriesEncodeUserText() {
        val q = WikiQuery.searchWorks("a&b=c|d")
        assertTrue(q.contains("gsrsearch=a%26b%3Dc%7Cd"))
        assertFalse(q.contains("a&b=c"))
    }

    // ---------------- clasificación de obras ----------------
    @Test fun workKindClassification() {
        assertEquals(WorkKind.SERIE, WorkKind.classify("The Walking Dead (TV series)", "American post-apocalyptic horror drama television series", ""))
        assertEquals(WorkKind.COMIC, WorkKind.classify("The Walking Dead (comic book)", "American comic book series", ""))
        assertEquals(WorkKind.SERIE, WorkKind.classify("The Walking Dead", "serie de televisión estadounidense", ""))
        assertEquals(WorkKind.VIDEOJUEGO, WorkKind.classify("The Walking Dead (video game)", "2012 video game", ""))
        assertEquals(WorkKind.NO_ES_OBRA, WorkKind.classify("Rick Grimes", "Fictional character in The Walking Dead", ""))
        assertEquals(WorkKind.NO_ES_OBRA, WorkKind.classify("List of The Walking Dead characters", "", ""))
        assertEquals(WorkKind.NO_ES_OBRA, WorkKind.classify("Pilot (The Walking Dead)", "", "\"Days Gone Bye\" is the episode"))
        assertEquals(WorkKind.ANIME, WorkKind.classify("Frieren", "Japanese anime television series", ""))
        assertEquals(WorkKind.LIBRO, WorkKind.classify("Dune", "1965 science fiction novel by Frank Herbert", ""))
        assertEquals(WorkKind.PELICULA, WorkKind.classify("Alien", "1979 film by Ridley Scott", ""))
        assertEquals(WorkKind.NO_ES_OBRA, WorkKind.classify("Alien", "", ""))
    }

    // ---------------- resolución y continuidad ----------------
    private fun cand(title: String, desc: String, rank: Int, qid: String, lang: String = "en") =
        WorkCandidate(title, WikiHosts.wikipedia(lang), lang, qid, desc, "", WorkKind.classify(title, desc, ""), rank)

    @Test fun asksForContinuityOnlyWhenKindsDiffer() {
        val r = UniverseResolver.decide("The Walking Dead", listOf(
            cand("The Walking Dead (TV series)", "American horror drama television series", 1, "Q1"),
            cand("The Walking Dead (comic book)", "American comic book series", 2, "Q2"),
            cand("Rick Grimes", "Fictional character", 3, "Q3"),
        ), listOf("es", "en"))
        assertTrue(r is Resolution.Ask)
        val kinds = (r as Resolution.Ask).options.map { it.kind }.toSet()
        assertTrue(kinds.contains(WorkKind.SERIE) && kinds.contains(WorkKind.COMIC))
        assertFalse(r.options.any { it.title == "Rick Grimes" })
    }
    @Test fun autoPicksWhenOneClearWork() {
        val r = UniverseResolver.decide("Dune", listOf(cand("Dune (novel)", "1965 science fiction novel", 1, "Q10"), cand("Paul Atreides", "Fictional character", 2, "Q11")), listOf("en"))
        assertTrue(r is Resolution.Auto)
        assertEquals("Dune (novel)", (r as Resolution.Auto).pick.title)
    }
    @Test fun sameWorkInTwoLanguagesIsNotAQuestion() {
        val r = UniverseResolver.decide("The Walking Dead", listOf(
            cand("The Walking Dead", "serie de televisión estadounidense", 1, "Q1", "es"),
            cand("The Walking Dead (TV series)", "American horror drama television series", 1, "Q1", "en"),
        ), listOf("es", "en"))
        assertTrue(r is Resolution.Auto)
        assertEquals("es", (r as Resolution.Auto).pick.lang)
    }
    @Test fun nothingIsAWorkMeansNotFound() {
        assertTrue(UniverseResolver.decide("Rick", listOf(cand("Rick Grimes", "Fictional character", 1, "Q3")), listOf("en")) is Resolution.NotFound)
        assertTrue(UniverseResolver.decide("x", emptyList(), listOf("en")) is Resolution.NotFound)
    }

    private val searchJson = pageJson(
        searchPage("The Walking Dead (TV series)", 1, "American post-apocalyptic horror drama television series", "Q1", "The Walking Dead is an American post-apocalyptic horror drama television series."),
        searchPage("The Walking Dead (comic book)", 2, "American comic book series", "Q2"),
        searchPage("The Walking Dead", 3, "", "Q9", "The Walking Dead may refer to:", disamb = true),
    )

    @Test fun searchUsesBothLanguagesAndSkipsDisambiguation() = runBlocking {
        val fake = FakeWiki { api, q -> if (q.contains("generator=search")) searchJson else null }
        val r = UniverseResolver(fake).search("The Walking Dead", listOf("es", "en"))
        assertTrue(r is Resolution.Ask)
        assertEquals(2, fake.calls.size)
        assertTrue((r as Resolution.Ask).options.none { it.title == "The Walking Dead" })
    }
    @Test fun searchReportsNetworkFailureHonestly() = runBlocking {
        val fake = FakeWiki { _, _ -> throw WikiFetchException("No se encontró el servidor (¿sin conexión?).", true) }
        val r = UniverseResolver(fake).search("Dune", listOf("es"))
        assertTrue(r is Resolution.Failed)
        assertTrue((r as Resolution.Failed).retryable)
    }
    @Test fun searchSurvivesGarbageResponses() = runBlocking {
        val fake = FakeWiki { _, _ -> "<html>Not JSON</html>" }
        assertTrue(UniverseResolver(fake).search("Dune", listOf("es", "en")) is Resolution.NotFound)
        val fake2 = FakeWiki { _, _ -> """{"error":{"code":"maxlag","info":"Waiting for host"}}""" }
        assertTrue(UniverseResolver(fake2).search("Dune", listOf("en")) is Resolution.NotFound)
    }

    // ---------------- identidad con Wikidata ----------------
    private val wikidataJson = """{"entities":{"Q1":{"id":"Q1","claims":{
        "P6262":[{"mainsnak":{"datavalue":{"value":"walkingdead:The Walking Dead","type":"string"}}}],
        "P674":[{"mainsnak":{"datavalue":{"value":{"id":"Q100"}}}},{"mainsnak":{"datavalue":{"value":{"id":"Q101"}}}},{"mainsnak":{"datavalue":{"value":{"id":"bad"}}}}]},
        "sitelinks":{"eswiki":{"site":"eswiki","title":"The Walking Dead (serie)"},"enwiki":{"site":"enwiki","title":"The Walking Dead (TV series)"},"commonswiki":{"title":"x"}}}}}"""
    private val labelsJson = """{"entities":{"Q100":{"labels":{"en":{"language":"en","value":"Rick Grimes"}}},"Q101":{"labels":{"es":{"language":"es","value":"Daryl Dixon"}}}}}"""

    @Test fun identifyReadsWikidataAndToleratesItsAbsence() = runBlocking {
        val fake = FakeWiki { api, q -> if (api == WikiHosts.WIKIDATA) (if (q.contains("props=labels")) labelsJson else wikidataJson) else null }
        val id = UniverseResolver(fake).identify(cand("The Walking Dead (TV series)", "American horror drama television series", 1, "Q1"))
        assertEquals("walkingdead", id.fandomSub); assertEquals("The Walking Dead", id.fandomTitle)
        assertEquals("The Walking Dead (serie)", id.wikipedia["es"])
        assertEquals(listOf("Rick Grimes", "Daryl Dixon"), id.wikidataCharacters)
        assertEquals("The Walking Dead", id.title)
        val down = FakeWiki { _, _ -> throw WikiFetchException("saturado", true) }
        val id2 = UniverseResolver(down).identify(cand("Dune (novel)", "novel", 1, "Q5"))
        assertTrue(id2.notes.isNotEmpty()); assertEquals("", id2.fandomSub)
    }

    // ---------------- nombres de personajes ----------------
    @Test fun looksLikeNameRules() {
        assertTrue(CharacterNames.looksLikeName("Rick Grimes"))
        assertTrue(CharacterNames.looksLikeName("Daryl"))
        assertTrue(CharacterNames.looksLikeName("Ludwig van Beethoven"))
        assertTrue(CharacterNames.looksLikeName("Rick Grimes (TV series)"))
        assertFalse(CharacterNames.looksLikeName("Main characters"))
        assertFalse(CharacterNames.looksLikeName("Season 3"))
        assertFalse(CharacterNames.looksLikeName("Production"))
        assertFalse(CharacterNames.looksLikeName("Personajes principales"))
        assertFalse(CharacterNames.looksLikeName("the walking dead"))
        assertFalse(CharacterNames.looksLikeName("A very long heading that is not a name at all"))
        assertFalse(CharacterNames.looksLikeName("Rick <b>"))
    }
    @Test fun sectionsGiveCharactersWithTierFromParentHeading() {
        val secs = listOf(
            SectionRef("Main characters", 2, 1), SectionRef("Rick Grimes", 3, 2), SectionRef("Carl Grimes", 3, 3),
            SectionRef("Recurring characters", 2, 4), SectionRef("Morgan Jones", 3, 5),
            SectionRef("Production", 2, 6), SectionRef("Casting", 3, 7), SectionRef("References", 2, 8),
        )
        val c = CharacterNames.fromSections(secs)
        assertEquals(listOf("Rick Grimes", "Carl Grimes", "Morgan Jones"), c.map { it.name })
        assertEquals(listOf(0, 0, 1), c.map { it.tier })
    }
    @Test fun castTextExtractsRolesNotProse() {
        val text = "Intro text.\n\n== Cast ==\nAndrew Lincoln as Rick Grimes, a former sheriff's deputy\nNorman Reedus como Daryl Dixon: un cazador\nHe works as a doctor in town\nThe show stars Jon Bernthal as Shane Walsh\n\n== Reception ==\nMegan Fox as Someone Else"
        val c = CharacterNames.fromCastText(text)
        assertEquals(listOf("Rick Grimes", "Daryl Dixon"), c.map { it.name })
        assertEquals("Andrew Lincoln", c[0].actor)
    }
    @Test fun mergeFoldsFirstNamesAndKeepsPriority() {
        val a = listOf(CharacterCandidate("Rick", tier = 1, order = 0), CharacterCandidate("Michonne", tier = 0, order = 1))
        val b = listOf(CharacterCandidate("Rick Grimes", tier = 0, order = 0), CharacterCandidate("rick grimes", tier = 2, order = 1))
        val m = CharacterNames.merge(listOf(a, b))
        assertEquals(2, m.size)
        val rick = m.first { it.name == "Rick Grimes" }
        assertTrue(rick.aliases.contains("Rick")); assertEquals(0, rick.tier)
        assertEquals(listOf("Rick Grimes", "Michonne"), m.map { it.name })
    }
    @Test fun differentPeopleWithSameFirstNameAreNotMerged() {
        val m = CharacterNames.merge(listOf(listOf(CharacterCandidate("Carol Peletier", tier = 0, order = 0), CharacterCandidate("Carol Hunter", tier = 2, order = 1))))
        assertEquals(2, m.size)
    }
    @Test fun titlesFilter() {
        val c = CharacterNames.fromTitles(listOf("Rick Grimes", "Season 3", "Rick Grimes/Gallery", "List of deaths", "Category:X", "Negan (TV series)"), 3, source = "t")
        assertEquals(listOf("Rick Grimes", "Negan"), c.map { it.name })
    }

    // ---------------- planificador de fuentes ----------------
    private val identity = WorkIdentity("Q1", "The Walking Dead", WorkKind.SERIE, "en", "serie", mapOf("en" to "The Walking Dead (TV series)", "es" to "The Walking Dead"), "", "", emptyList(), emptyList())

    private fun fandomHandler(api: String, q: String): String? = when {
        api == "https://walkingdead.fandom.com/api.php" && q.contains("meta=siteinfo") -> """{"query":{"general":{"sitename":"Walking Dead Wiki","lang":"en"},"rightsinfo":{"url":"https://creativecommons.org/licenses/by-sa/3.0/","text":"CC-BY-SA"}}}"""
        api == "https://walkingdead.fandom.com/api.php" && q.contains("list=search") -> """{"query":{"search":[{"title":"The Walking Dead (TV Series)"},{"title":"Rick Grimes"}]}}"""
        api == "https://walkingdead.fandom.com/api.php" && q.contains("cmtitle=Category%3AMain+characters") -> """{"query":{"categorymembers":[{"title":"Rick Grimes"},{"title":"Daryl Dixon"},{"title":"Season 3"}]}}"""
        api == "https://walkingdead.fandom.com/api.php" && q.contains("cmtitle=Category%3ACharacters") -> """{"query":{"categorymembers":[{"title":"Zed Minor"},{"title":"Rick Grimes"}]}}"""
        api == "https://walkingdead.fandom.com/api.php" && q.contains("cmtitle=Category%3ALocations") -> """{"query":{"categorymembers":[{"title":"Alexandria Safe-Zone"},{"title":"Hilltop Colony"}]}}"""
        api == "https://walkingdead.fandom.com/api.php" && q.contains("prop=info") -> {
            val wanted = Regex("titles=([^&]+)").find(q)!!.groupValues[1].let { java.net.URLDecoder.decode(it, "UTF-8") }.split("|")
            val have = setOf("Rick Grimes", "Daryl Dixon", "Zed Minor")
            """{"query":{"pages":[${wanted.joinToString(",") { if (it in have) """{"pageid":1,"title":"$it"}""" else """{"title":"$it","missing":true}""" }}]}}"""
        }
        api == "https://walkingdead.fandom.com/api.php" -> null
        api.endsWith("fandom.com/api.php") -> null
        api.contains("wikipedia.org") && q.contains("list=search") -> """{"query":{"search":[{"title":"List of The Walking Dead (TV series) characters"},{"title":"The Walking Dead (season 1)"}]}}"""
        api.contains("wikipedia.org") && q.contains("action=parse") -> """{"parse":{"title":"x","sections":[{"toclevel":1,"level":"2","line":"Main characters","index":"1"},{"toclevel":2,"level":"3","line":"Rick Grimes","index":"2"},{"toclevel":2,"level":"3","line":"Michonne","index":"3"},{"toclevel":1,"level":"2","line":"References","index":"4"}]}}"""
        api.contains("wikipedia.org") && q.contains("prop=extracts") -> """{"query":{"pages":[{"pageid":5,"title":"The Walking Dead (TV series)","extract":"Intro.\n\n== Cast ==\nAndrew Lincoln as Rick Grimes, sheriff\nDanai Gurira as Michonne, a warrior\n"}]}}"""
        api.contains("wikipedia.org") && q.contains("prop=info") -> """{"query":{"pages":[{"pageid":9,"title":"Michonne"}]}}"""
        else -> null
    }

    @Test fun plannerFindsFandomCharactersPlacesAndListsOnItsOwn() = runBlocking {
        val fake = FakeWiki(::fandomHandler)
        val plan = SourcePlanner(fake).plan(identity, "BASICA", listOf("en"))
        assertEquals("https://walkingdead.fandom.com/api.php", plan.fandomApi)
        val names = plan.characters.map { it.name }
        assertTrue(names.containsAll(listOf("Rick Grimes", "Daryl Dixon", "Michonne")))
        assertFalse(names.contains("Season 3"))
        val rick = plan.characters.first { it.name == "Rick Grimes" }
        assertEquals(0, rick.tier); assertTrue(rick.pages.any { it.api.contains("fandom") })
        // Un nombre de una sola palabra no se busca en Wikipedia (podría ser otra cosa): su ficha saldrá del listado.
        assertTrue(plan.characters.first { it.name == "Michonne" }.let { it.pages.isEmpty() && it.fromList })
        assertTrue(plan.lorePages.any { it.role == PageRole.LISTA })
        assertTrue(plan.places.map { it.title }.containsAll(listOf("Alexandria Safe-Zone", "Hilltop Colony")))
        assertTrue(fake.calls.all { c -> c.startsWith("https://") })
        assertTrue(fake.calls.all { c -> WikiHosts.isTrustedApi(c.substringBefore('?')) })
        // Principales primero
        assertTrue(names.indexOf("Rick Grimes") < names.indexOf("Zed Minor").let { if (it < 0) 99 else it })
    }
    @Test fun plannerRespectsDepthLimit() = runBlocking {
        val plan = SourcePlanner(FakeWiki(::fandomHandler)).plan(identity, "BASICA", listOf("en"))
        assertTrue(plan.characters.size <= CharacterNames.limitFor("BASICA"))
    }
    @Test fun plannerWorksWithoutFandom() = runBlocking {
        val fake = FakeWiki { api, q -> if (api.contains("fandom")) null else fandomHandler(api, q) }
        val plan = SourcePlanner(fake).plan(identity, "BASICA", listOf("en"))
        assertNull(plan.fandomApi)
        assertTrue(plan.notes.any { it.contains("Fandom") })
        assertTrue(plan.characters.any { it.name == "Rick Grimes" })   // por el reparto del artículo y el listado
    }
    @Test fun plannerRejectsFandomWikiOfAnotherWork() = runBlocking {
        val fake = FakeWiki { api, q ->
            when {
                api == "https://walkingdead.fandom.com/api.php" && q.contains("meta=siteinfo") -> """{"query":{"general":{"sitename":"Otra Wiki"}}}"""
                api == "https://walkingdead.fandom.com/api.php" && q.contains("list=search") -> """{"query":{"search":[{"title":"Cooking Recipes"}]}}"""
                else -> null
            }
        }
        val plan = SourcePlanner(fake).plan(identity, "BASICA", listOf("en"))
        assertNull(plan.fandomApi)
        assertTrue(plan.notes.any { it.contains("no parece ser de") })
    }
    @Test fun plannerFlagsRetryableFailures() = runBlocking {
        val fake = FakeWiki { _, _ -> throw WikiFetchException("saturado", true) }
        val plan = SourcePlanner(fake).plan(identity, "BASICA", listOf("en"))
        assertTrue(plan.hadRetryableFailure); assertTrue(plan.characters.isEmpty()); assertTrue(plan.notes.isNotEmpty())
    }

    // ---------------- imágenes canónicas ----------------
    @Test fun sniffAndPolicy() {
        val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A) + ByteArray(3000)
        val jpg = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte()) + ByteArray(3000)
        val webp = "RIFF".toByteArray() + ByteArray(4) + "WEBP".toByteArray() + ByteArray(3000)
        assertEquals(ImageSniff.PNG, ImageSniff.typeOf(png)); assertEquals(ImageSniff.JPEG, ImageSniff.typeOf(jpg)); assertEquals(ImageSniff.WEBP, ImageSniff.typeOf(webp))
        assertNull(ImageSniff.typeOf("<html>".toByteArray()))
        val ok = "https://upload.wikimedia.org/a.png"
        assertNull(CanonImagePolicy.reject(ok, png))
        assertNotNull(CanonImagePolicy.reject("https://evil.com/a.png", png))
        assertNotNull(CanonImagePolicy.reject(ok, "<html>".toByteArray() + ByteArray(3000)))
        assertNotNull(CanonImagePolicy.reject(ok, ByteArray(10)))
        assertNotNull(CanonImagePolicy.reject(ok, png + ByteArray(4_000_000)))
    }
    @Test fun rightsNeverPretendToBeFree() {
        assertTrue(CanonImagePolicy.rightsNote("", false, "").contains("desconocida"))
        assertTrue(CanonImagePolicy.rightsNote("", true, "CC-BY-SA").contains("no libre"))
        assertTrue(CanonImagePolicy.rightsNote("CC BY-SA 4.0", false, "").contains("CC BY-SA 4.0"))
    }
    @Test fun fileNameFilter() {
        assertTrue(CanonImagePolicy.looksLikeCharacterImage("Rick_Grimes_S10.png"))
        assertFalse(CanonImagePolicy.looksLikeCharacterImage("Site-logo.png")); assertFalse(CanonImagePolicy.looksLikeCharacterImage("Poster_season1.jpg"))
        assertFalse(CanonImagePolicy.looksLikeCharacterImage("sound.ogg"))
    }
    @Test fun finderReturnsImageWithLicenseAndSkipsLogos() = runBlocking {
        val api = "https://en.wikipedia.org/w/api.php"
        val fake = FakeWiki { _, q ->
            when {
                q.contains("prop=pageimages") -> """{"query":{"pages":[
                    {"pageid":1,"title":"Rick Grimes","thumbnail":{"source":"https://upload.wikimedia.org/wikipedia/en/thumb/a/ab/Rick.png/600px-Rick.png","width":600,"height":800},"pageimage":"Rick.png"},
                    {"pageid":2,"title":"Michonne","thumbnail":{"source":"https://upload.wikimedia.org/wikipedia/en/thumb/a/ab/logo.png/600px-logo.png","width":600,"height":800},"pageimage":"Site-logo.png"},
                    {"pageid":3,"title":"Daryl Dixon"}]}}"""
                q.contains("prop=imageinfo") -> """{"query":{"pages":[{"title":"File:Rick.png","imageinfo":[{"url":"https://upload.wikimedia.org/wikipedia/en/a/ab/Rick.png","mime":"image/png","size":12345,"extmetadata":{"LicenseShortName":{"value":"Fair use"},"NonFree":{"value":"true"},"Artist":{"value":"<a href=\"x\">AMC</a>"}}}]}]}}"""
                else -> null
            }
        }
        val r = CanonImageFinder(fake).find(api, listOf("Rick Grimes", "Michonne", "Daryl Dixon"))
        assertEquals(setOf("Rick Grimes"), r.keys)
        val img = r.getValue("Rick Grimes")
        assertTrue(img.nonFree); assertEquals("Fair use", img.license); assertEquals("AMC", img.attribution); assertEquals("Rick.png", img.fileName)
    }
    @Test fun finderFallsBackToFandomThumbnails() = runBlocking {
        val api = "https://walkingdead.fandom.com/api.php"
        val fake = FakeWiki { a, q ->
            when {
                a == "fandom-v1" -> """{"items":{"11":{"title":"Rick Grimes","thumbnail":"https://static.wikia.nocookie.net/walkingdead/images/a/ab/Rick_Grimes.png/revision/latest/window-crop/width/600?cb=1"},"12":{"title":"Evil","thumbnail":"https://evil.com/x.png"}}}"""
                q.contains("prop=pageimages") -> """{"query":{"pages":[{"pageid":1,"title":"Rick Grimes"},{"pageid":2,"title":"Evil"}]}}"""
                else -> null
            }
        }
        val r = CanonImageFinder(fake).find(api, listOf("Rick Grimes", "Evil"))
        assertEquals(setOf("Rick Grimes"), r.keys)
        assertEquals("Rick_Grimes.png", r.getValue("Rick Grimes").fileName)
    }
    @Test fun finderIgnoresUntrustedApis() = runBlocking {
        val fake = FakeWiki { _, _ -> "{}" }
        assertTrue(CanonImageFinder(fake).find("https://evil.com/api.php", listOf("X")).isEmpty())
        assertTrue(fake.calls.isEmpty())
    }

    // ---------------- parsers tolerantes ----------------
    @Test fun parsersNeverThrowOnGarbage() {
        for (g in listOf("", "null", "[]", "{", "<html>", """{"query":5}""", """{"query":{"pages":"x"}}""", """{"query":{"pages":[1,2,"a",null]}}""")) {
            WikiParsers.workCandidates(g, "a", "en"); WikiParsers.searchTitles(g); WikiParsers.categoryMembers(g); WikiParsers.sections(g)
            WikiParsers.existingTitles(g); WikiParsers.pageImages(g); WikiParsers.fileInfo(g); WikiParsers.fandomThumbs(g)
            WikiParsers.claimEntityIds(g, "Q1", "P1"); WikiParsers.claimString(g, "Q1", "P1"); WikiParsers.labels(g); WikiParsers.sitelinks(g, "Q1")
        }
    }
    @Test fun existingTitlesFollowRedirectsAndSkipMissingAndDisambiguation() {
        val j = """{"query":{"redirects":[{"from":"Rick","to":"Rick Grimes"}],"pages":[{"pageid":1,"title":"Rick Grimes"},{"title":"Nope","missing":true},{"pageid":3,"title":"Carol","pageprops":{"disambiguation":""}}]}}"""
        val m = WikiParsers.existingTitles(j)
        assertEquals("Rick Grimes", m["Rick"]); assertEquals("Rick Grimes", m["Rick Grimes"])
        assertFalse(m.containsKey("Nope")); assertFalse(m.containsKey("Carol"))
    }
    @Test fun splitFandomIdIsStrict() {
        assertEquals("walkingdead" to "The Walking Dead", WikiParsers.splitFandomId("walkingdead:The Walking Dead"))
        assertNull(WikiParsers.splitFandomId("evil.com/x:Page")); assertNull(WikiParsers.splitFandomId("nocolon")); assertNull(WikiParsers.splitFandomId(":x"))
    }
}
