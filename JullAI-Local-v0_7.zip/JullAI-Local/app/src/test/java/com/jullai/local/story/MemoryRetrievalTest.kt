package com.jullai.local.story

import com.jullai.local.chat.ContextOverflowException
import com.jullai.local.engine.ChatMessage
import com.jullai.local.roleplay.RoleplayContextBuilder
import com.jullai.local.roleplay.RpCharacter
import com.jullai.local.roleplay.RpInput
import com.jullai.local.roleplay.RpScene
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryRetrievalTest {
    private val count: suspend (String) -> Int = { t -> t.split(Regex("\\s+")).count { it.isNotEmpty() } }
    private val template: suspend (List<ChatMessage>) -> String = { msgs -> msgs.joinToString("\n") { "<${it.role}> ${it.content}" } + "\n<assistant>" }

    private class FakeSource(
        val memories: List<MemoryItem> = emptyList(),
        val timeline: List<TimelineItem> = emptyList(),
        val relations: List<RelationItem> = emptyList(),
        val fts: Set<Long>? = null,
    ) : StorySource {
        override suspend fun candidateMemories(sessionId: Long, queryTokens: List<String>) = MemoryCandidates(memories, fts, if (fts != null) "texto completo (FTS4)" else "palabras clave")
        override suspend fun timeline(sessionId: Long) = timeline
        override suspend fun relationships(sessionId: Long) = relations
    }

    private fun mem(id: Long, text: String, imp: Int = 3, pinned: Boolean = false, related: List<String> = emptyList(), date: String = "", updated: Long = id) =
        MemoryItem(id, text, imp, date, pinned, related, Verification.CONFIRMADO, updated)

    private fun req(vararg recent: String, budget: Int = 200) = RetrievalRequest(1, recent.toList(), listOf("Aria", "Ana"), budget)
    private fun retrieve(src: StorySource, r: RetrievalRequest) = runBlocking { RankedMemoryRetriever(src).retrieve(r, count) }

    @Test fun factFromEarlySessionIsRecoveredInALaterScene() {
        val src = FakeSource(
            memories = listOf(
                mem(1, "La llave de la torre está escondida bajo el roble sagrado", 3),
                mem(2, "El rey Alden odia las tormentas", 3),
                mem(3, "Ana es alérgica a las flores de jazmín", 2),
            ),
        )
        val r = retrieve(src, req("Aria mira el bosque", "Ana: Creo que vi un roble enorme junto al río"))
        assertEquals(listOf(1L), r.memories.map { it.item.id })
        assertTrue(r.memories[0].why.contains("roble"))
    }

    @Test fun pinnedMemoriesAlwaysComeFirstEvenWithoutMatches() {
        val src = FakeSource(memories = listOf(mem(1, "Aria jamás miente", 5, pinned = true), mem(2, "El puente norte está roto", 3)))
        val r = retrieve(src, req("hablemos del clima de hoy"))
        assertEquals(1L, r.memories.first().item.id)
        assertEquals("fijado", r.memories.first().why)
        assertFalse(r.memories.any { it.item.id == 2L })
    }

    @Test fun pinnedMemoriesNeverExceedTheirBudgetShare() {
        val many = (1L..40L).map { mem(it, "dato fijado número $it con bastante texto para ocupar tokens reales", 3, pinned = true) }
        val r = retrieve(FakeSource(memories = many), req("hola", budget = 120))
        assertTrue("usado ${r.usedTokens} de 120", r.usedTokens <= 120)
        assertTrue(r.memories.sumOf { it.tokens } <= (120 * RankedMemoryRetriever.MEMORIES_SHARE).toInt())
        assertTrue(r.notFitting.isNotEmpty())
    }

    @Test fun irrelevantLowImportanceMemoriesAreNotSent() {
        val src = FakeSource(memories = (1L..30L).map { mem(it, "recuerdo irrelevante $it sobre minas de plata", 2) })
        val r = retrieve(src, req("vamos a nadar al lago"))
        assertTrue(r.memories.isEmpty())
    }

    @Test fun highImportanceFillsLeftoverButOnlyAFew() {
        val src = FakeSource(memories = (1L..10L).map { mem(it, "hecho crucial $it de la historia antigua", 5) })
        val r = retrieve(src, req("vamos a nadar", budget = 400))
        assertEquals(RankedMemoryRetriever.MAX_BASELINE, r.memories.size)
        assertTrue(r.memories.all { it.why == "importancia alta" })
    }

    @Test fun participantNamesDoNotCountAsMatches() {
        val src = FakeSource(memories = listOf(mem(1, "Aria nació en el norte", 2), mem(2, "Aria teme al fuego", 2)))
        val r = retrieve(src, req("Aria camina con Ana"))
        assertTrue("el nombre del personaje no debe disparar todo", r.memories.isEmpty())
    }

    @Test fun relatedNamesBoost() {
        val src = FakeSource(memories = listOf(mem(1, "Debe una fortuna", 2, related = listOf("Gorm")), mem(2, "Es muy veloz", 2, related = listOf("Lía"))))
        val r = retrieve(src, req("Aparece Gorm en la taberna"))
        assertEquals(listOf(1L), r.memories.map { it.item.id })
        assertTrue(r.memories[0].why.contains("nombre"))
    }

    @Test fun ftsHitsAreMarked() {
        val src = FakeSource(memories = listOf(mem(1, "Algo totalmente distinto", 2), mem(2, "Otra cosa", 2)), fts = setOf(2L))
        val r = retrieve(src, req("nada que ver"))
        assertEquals(listOf(2L), r.memories.map { it.item.id })
        assertEquals("texto completo", r.memories[0].why)
        assertTrue(r.describe().contains("FTS4"))
    }

    @Test fun relationsOnlyForParticipants() {
        val rels = listOf(
            RelationItem(1, "Aria", "Ana", 40, 30, 55, 10, "aliadas"),
            RelationItem(2, "Gorm", "Lía", 90, 90, 90, 90, ""),
        )
        val r = retrieve(FakeSource(relations = rels), req("hola"))
        assertEquals(1, r.relations.size)
        assertTrue(r.relations[0].text.contains("confianza 40"))
        assertTrue(r.relations[0].text.contains("aliadas"))
    }

    @Test fun timelineIsShownInChronologicalOrderAndIncludesLatest() {
        val tl = listOf(
            TimelineItem(1, "El rey fue coronado en la plaza", "día 1", 10),
            TimelineItem(2, "Una tormenta destruyó el puente", "día 2", 20),
            TimelineItem(3, "Aria encontró un mapa antiguo", "día 3", 30),
            TimelineItem(4, "Llegó la primavera", "día 9", 40),
        )
        val r = retrieve(FakeSource(timeline = tl), req("¿recuerdas la tormenta y el puente?", budget = 300))
        val keys = r.timeline.map { it.item.orderKey }
        assertEquals(keys.sorted(), keys)
        assertTrue(r.timeline.any { it.item.id == 2L && it.why.contains("tormenta") })
        assertTrue(r.timeline.any { it.item.id == 4L && it.why == "reciente" })
    }

    @Test fun totalNeverExceedsBudget() {
        val src = FakeSource(
            memories = (1L..50L).map { mem(it, "roble recuerdo $it " + "palabra ".repeat(12), 4) },
            timeline = (1L..30L).map { TimelineItem(it, "evento roble $it " + "dato ".repeat(10), "d$it", it.toInt()) },
            relations = listOf(RelationItem(1, "Aria", "Ana", 40, 30, 55, 10)),
        )
        for (b in listOf(0, 30, 100, 250, 600)) {
            val r = retrieve(src, req("el roble", budget = b))
            assertTrue("presupuesto $b usado ${r.usedTokens}", r.usedTokens <= b)
        }
    }

    @Test fun sectionsOrderIsRelationsMemoriesTimeline() {
        val src = FakeSource(
            memories = listOf(mem(1, "Dato sobre el roble", 3)), timeline = listOf(TimelineItem(1, "Evento del roble", "", 1)),
            relations = listOf(RelationItem(1, "Aria", "Ana", 40, 30, 55, 10)),
        )
        val s = retrieve(src, req("roble", budget = 300)).toSections()
        assertEquals(listOf("relations", "memories", "timeline"), s.map { it.id })
        assertTrue(s.all { it.items.isNotEmpty() && it.header != null })
    }

    @Test fun resultFitsInsideRoleplayContextWithoutOverflow() = runBlocking {
        val many = (1L..60L).map { mem(it, "dato fijado $it " + "texto ".repeat(15), 5, pinned = true) }
        val src = FakeSource(memories = many, relations = listOf(RelationItem(1, "Aria", "Ana", 40, 30, 55, 10)))
        for (ctx in listOf(900, 1500, 4096)) {
            val resp = 150
            val budget = (ctx * 0.16).toInt()
            val result = retrieve(src, req("hola Aria", budget = budget))
            val ch = RpCharacter(name = "Aria", personality = "Seria", appearance = "Elfa")
            val hist = listOf(ChatMessage("user", "hola Aria"))
            val input = RpInput("Eres narrador de {{char}}", ch, RpScene("Ana", scenario = "Bosque", summary = "Resumen"), emptyList(), emptyList(), 4, hist, ctx, resp, extra = result.toSections())
            val built = RoleplayContextBuilder.build(input, count, template)
            assertTrue("ctx $ctx prompt ${built.promptTokens}", built.promptTokens <= ctx - resp)
            assertEquals("hola Aria", built.messages.last().content)
        }
    }

    @Test fun builderDropsWholeItemsNeverCutsOne() = runBlocking {
        val items = listOf("- uno " + "a ".repeat(30), "- dos " + "b ".repeat(30), "- tres " + "c ".repeat(30))
        val sec = com.jullai.local.roleplay.PromptSection("memories", "Recuerdos", "", items, header = "# RECUERDOS")
        val ch = RpCharacter(name = "Aria")
        val input = RpInput("sys", ch, RpScene("Ana"), emptyList(), emptyList(), 4, listOf(ChatMessage("user", "hola")), 700, 100, extra = listOf(sec))
        val built = RoleplayContextBuilder.build(input, count, template)
        val sys = built.messages[0].content
        val lines = sys.lines().filter { it.startsWith("- ") }
        assertTrue(lines.all { it.trim().split(" ").size >= 30 }) // ninguna línea cortada por la mitad
        val note = built.report.first { it.id == "memories" }.note
        assertNotNull(note)
    }
}
