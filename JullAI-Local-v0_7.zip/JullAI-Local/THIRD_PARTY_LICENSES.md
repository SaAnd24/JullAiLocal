# Licencias de terceros (v0.6)

| Componente | Licencia | Uso |
|---|---|---|
| llama.cpp (ggml) | MIT | Motor de texto (`jullai_engine`), descargado por `tools/fetch_llama.sh` |
| stable-diffusion.cpp (+ su ggml) | MIT, © leejet y colaboradores | Motor de imágenes (`jullai_sd`), commit `e779d4f149aae16e3319b66a320ec4bee8fc5e7c`, descargado por `tools/fetch_sd.sh`. Al redistribuir un APK hay que conservar su aviso de copyright y licencia (el script deja `LICENSE` junto al código descargado). |
| Local Dream (xororz) | **CC BY-NC 4.0** | **NO se usa ni se ha copiado código.** Solo se estudió su README y su licencia para descartarlo. Si alguien lo integrase en el futuro: atribución, indicar modificaciones y **uso estrictamente no comercial**; no es equivalente a MIT. |
| Pesos de modelos de imagen y de texto | Cada modelo tiene la suya | **No se incluyen ni se redistribuyen.** La licencia del modelo es asunto del usuario y es distinta de la del motor: usa solo modelos cuyo uso tengas autorizado. |
